#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#

from __future__ import annotations

import math
from collections.abc import Iterable, Iterator
from contextlib import AbstractContextManager, contextmanager, nullcontext
from functools import partial
from typing import Any, cast

import numpy as np
import torch
import torch.nn as nn
import torch_npu
from vllm.config import CUDAGraphMode
from vllm.forward_context import get_forward_context
from vllm.logger import logger
from vllm.sequence import IntermediateTensors
from vllm.utils.math_utils import cdiv
from vllm.utils.torch_utils import get_dtype_size
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import (
    AttentionSpec,
    EncoderOnlyAttentionSpec,
    KVCacheConfig,
    KVCacheSpec,
    MambaSpec,
    MLAAttentionSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.spec_decode.metadata import SpecDecodeMetadata
from vllm.v1.utils import CpuGpuBuffer

from vllm_ascend._310p.block_table import MultiGroupBlockTable as MultiGroupBlockTable310
from vllm_ascend._310p.kv_block_zeroer import AscendKVBlockZeroer310
from vllm_ascend._310p.npu_input_batch import NPUInputBatch310 as NPUInputBatch
from vllm_ascend._310p.ops.rotary_embedding import prepare_mrope_cos_sin_slices_from_runner
from vllm_ascend._310p.prefix_mamba_state import (
    LiveMambaRequestSlots,
    PrefixMambaStateTier,
    prefix_mamba_active_columns,
    prefix_mamba_device_archive_slots,
    prefix_mamba_slot_count,
    prefix_mamba_state_bytes_per_slot,
    retain_prefix_mamba_blocks,
    supports_compact_live_mamba_state,
)
from vllm_ascend._310p.qwen4exp_mtp import (
    is_qwen4exp_mtp_config,
    stage_ple_history,
    validate_mtp_ple_scheduling,
)
from vllm_ascend._310p.sample.rejection_sampler import AscendRejectionSampler310
from vllm_ascend._310p.sample.sampler import AscendSampler310
from vllm_ascend.attention.attention_v1 import AscendAttentionState
from vllm_ascend.distributed.utils import get_decode_context_model_parallel_world_size
from vllm_ascend.spec_decode.utils import (
    update_num_computed_tokens_for_batch_change,
)
from vllm_ascend.utils import (
    ACL_FORMAT_FRACTAL_NZ,
    get_kv_cache_tensor_layers,
    is_rc_device,
    lmhead_tp_enable,
    vllm_version_is,
)
from vllm_ascend.worker.model_runner_v1 import NPUModelRunner

_NGRAM_GRAPH_UNIFORM_DECODE_QUERY_LEN = 1
_ATTENTION_BLOCK_SIZE_LIMIT = 128 * 128
_PREFIX_MAMBA_DEVICE_ARCHIVE_RESERVE_BYTES = 4 * (1 << 30)


def _iter_kv_cache_tensors(kv_caches: Iterable[Any]) -> Iterator[torch.Tensor]:
    """Yield tensors from the nested hybrid-cache layout used by 310P.

    Attention caches are ``(key, value)`` tuples while Mamba caches are lists
    of state tensors. Upstream's copy-on-write helper accepts only a flat
    tensor iterable.
    """
    for cache in kv_caches:
        if isinstance(cache, torch.Tensor):
            yield cache
        elif isinstance(cache, (list, tuple)):
            yield from _iter_kv_cache_tensors(cache)
        else:
            raise TypeError(f"Unsupported 310P KV cache entry: {type(cache)!r}")


def _concrete_size(v):
    """Concrete int from a kernel block-size / head-size that may be a vLLM
    ``MultipleOf`` alignment constraint rather than a plain int.

    Newer vLLM pads an MLA spec's ``head_size`` to a ``MultipleOf(base)``
    (``vllm.v1.attention.backend.MultipleOf`` has only a ``.base`` int), which
    the 310P page-attention block-size check below multiplies by an int -- hence
    ``TypeError: unsupported operand type(s) for *: 'MultipleOf' and 'int'``.
    Duck-type on ``.base`` so a plain int passes through unchanged.
    """
    return getattr(v, "base", v)


def _get_attention_cache_tensor_shape(
    backend: Any,
    num_blocks: int,
    cache_spec: AttentionSpec,
) -> tuple[int, ...]:
    """Return one 310P attention cache tensor's physical shape.

    A physical kernel page must divide the scheduler page; otherwise integer
    division can silently produce zero physical blocks. MLA backends describe
    one latent tensor directly, while the dense backend includes a leading K/V
    axis that is split into two tensors by the runner.
    """
    supported_sizes = [
        size
        for supported_size in backend.get_supported_kernel_block_sizes()
        if (size := _concrete_size(supported_size)) <= cache_spec.block_size
        and cache_spec.block_size % size == 0
        and size * _concrete_size(cache_spec.head_size) <= _ATTENTION_BLOCK_SIZE_LIMIT
    ]
    if supported_sizes:
        kernel_block_size = supported_sizes[0]
        kernel_blocks_per_scheduler_block = cache_spec.block_size // kernel_block_size
        cache_shape = backend.get_kv_cache_shape(
            num_blocks * kernel_blocks_per_scheduler_block,
            kernel_block_size,
            cache_spec.num_kv_heads,
            cache_spec.head_size,
        )
    else:
        cache_shape = backend.get_kv_cache_shape(
            num_blocks,
            cache_spec.block_size,
            cache_spec.num_kv_heads,
            cache_spec.head_size,
        )

    if isinstance(cache_spec, MLAAttentionSpec):
        return cache_shape
    assert cache_shape[0] == 2, "Dense 310P cache shape must include a K/V axis"
    return cache_shape[1:]


def _get_layer_attention_backends(attn_groups: Iterable[Iterable[Any]]) -> dict[str, Any]:
    """Map each cache layer to the backend selected during runner setup."""
    layer_backends: dict[str, Any] = {}
    for cache_group in attn_groups:
        for attention_group in cache_group:
            for layer_name in attention_group.layer_names:
                previous = layer_backends.setdefault(layer_name, attention_group.backend)
                if previous is not attention_group.backend:
                    raise ValueError(f"Multiple attention backends selected for {layer_name}")
    return layer_backends


def _allocate_attention_cache_tensor(
    shape: tuple[int, ...],
    dtype: torch.dtype,
    device: torch.device,
    cache_spec: AttentionSpec,
) -> torch.Tensor:
    if isinstance(cache_spec, MLAAttentionSpec) and not getattr(cache_spec, "use_nz_cache", False):
        # Ascend MLA consumes an ND latent cache. FRACTAL_NZ is the private
        # dense 310P K/V layout and can expand this rank-4 MLA tensor heavily.
        return torch.empty(shape, dtype=dtype, device=device)
    return torch_npu.empty_with_format(
        size=shape,
        dtype=dtype,
        device=device,
        acl_format=ACL_FORMAT_FRACTAL_NZ,
    )


def _allocate_attention_cache_pair(
    shape: tuple[int, ...],
    dtype: torch.dtype,
    device: torch.device,
    cache_spec: AttentionSpec,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Allocate the physical K/V pages required by a 310P backend."""
    key_cache = _allocate_attention_cache_tensor(
        shape,
        dtype,
        device,
        cache_spec,
    )
    if isinstance(cache_spec, MLAAttentionSpec) and getattr(cache_spec, "use_nz_cache", False):
        # Native NoPE MLA stores one normalized latent. It is both the key and
        # the value before W_UV, so two physical copies waste half the cache.
        return key_cache, key_cache
    value_cache = _allocate_attention_cache_tensor(
        shape,
        dtype,
        device,
        cache_spec,
    )
    return key_cache, value_cache


class NPUModelRunner310(NPUModelRunner):
    """
    310P model runner with a distinct ACL graph capture/replay contract from 910B:

    - Capture: ACLGraphWrapper records the full forward inside ``torch.npu.graph``.
      310P attention calls NPU ops directly (paged / splitfuse), without mainline
      ``full_graph_fia`` / ``full_graph_pa`` graph_task registration.
    - Replay: refresh shared runner buffers (block_table, seq_lens, query_start_loc,
      slot_mapping via CPU prepare + copy_to_gpu) so tensor addresses stay stable,
      then ``aclgraph.replay()``.
    """

    # Inherited from parent runner; annotated here to satisfy strict type checks.
    # 310P Attention requires private ACL NZ K/V buffers while Mamba uses
    # separate contiguous state buffers, so it cannot overlay both cache groups
    # on vLLM #51718's standardized shared backing allocation.
    supports_standardized_shared_kv_backing = False
    # GLM-Next has a narrower, model-specific shared-slot contract: its cache
    # planner only aliases layers from independent scheduler groups.  The base
    # Ascend allocator already materializes those descriptors as contiguous
    # per-layer views of one slot backing, which is compatible with 310P.
    supports_glm5_next_shared_kv_slots = True
    supports_compact_mamba_state = False
    supports_prefix_mamba_state_tier = False
    uniform_decode_query_len: int
    _spec_dummy_capture: bool = False

    def _make_buffer(self, *size: int | torch.SymInt, dtype: torch.dtype, numpy: bool = True) -> CpuGpuBuffer:
        # On 310P, zero-filling the pinned FP16 input-embedding staging buffer
        # can segfault inside PyTorch's CPU AVX2 fill kernel during TP startup.
        # Keep the same zero-initialized buffer, but allocate this one on normal
        # host memory. Other (small, frequently copied) buffers remain pinned.
        if dtype == torch.float16 and size == (self.max_num_tokens, self.inputs_embeds_size):
            return CpuGpuBuffer(*size, dtype=dtype, device=self.device, pin_memory=False, with_numpy=numpy)
        return super()._make_buffer(*size, dtype=dtype, numpy=numpy)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._qwen4exp_mtp_ple = is_qwen4exp_mtp_config(self.model_config, self.speculative_config)
        validate_mtp_ple_scheduling(self._qwen4exp_mtp_ple, self.use_async_scheduling)
        # MRV1 identifies recurrent state by scheduler block id. For the
        # single-request deployment without prefix caching, the only live
        # recurrent state is the current request's state (plus one state per
        # speculative token). Remap its staged block ids to those fixed slots
        # so GDN allocation is independent of context length. The native GDN
        # speculative kernel writes one state per candidate token and selects
        # the accepted state on the next step; its two slots must stay distinct.
        # Prefix-cached requests use a shared persistent ID-to-slot mapping,
        # not row-indexed slots: input rows can move when another request ends.
        self.supports_prefix_mamba_state_tier = (
            self.cache_config.enable_prefix_caching
            and self.cache_config.mamba_cache_mode == "align"
            and getattr(self.model_config.hf_text_config, "model_type", None) == "qwen4_exp_text"
            and (self.speculative_config is None or self._qwen4exp_mtp_ple)
        )
        self.supports_compact_mamba_state = self.supports_prefix_mamba_state_tier or (
            not self.cache_config.enable_prefix_caching
            and supports_compact_live_mamba_state(
                self.max_num_reqs,
                getattr(self.model_config.hf_text_config, "model_type", None),
            )
            and (self.speculative_config is None or self._qwen4exp_mtp_ple)
        )
        self.num_compact_mamba_blocks = (
            prefix_mamba_slot_count(
                self.max_num_reqs,
                self.speculative_config.num_speculative_tokens if self._qwen4exp_mtp_ple else 0,
            )
            if self.supports_prefix_mamba_state_tier
            else (1 + self.speculative_config.num_speculative_tokens if self._qwen4exp_mtp_ple else 1)
        )
        self._live_mamba_slots = (
            LiveMambaRequestSlots(self.max_num_reqs, self.num_compact_mamba_blocks)
            if self.supports_compact_mamba_state and not self.supports_prefix_mamba_state_tier and self.max_num_reqs > 1
            else None
        )
        # NoPE MLA models (GLM-5.3-Flash) have no extended/decoupled (xdrope)
        # rope; the base runner references these attributes without ever
        # initializing them on this path, so default them to 0.
        if not hasattr(self, "uses_xdrope_dim"):
            self.uses_xdrope_dim = 0
        if not hasattr(self, "draft_uses_xdrope_dim"):
            self.draft_uses_xdrope_dim = 0
        self.input_batch = NPUInputBatch(
            max_num_reqs=self.max_num_reqs,
            max_model_len=max(self.model_config.max_model_len, self.max_encoder_len),
            max_num_batched_tokens=self.max_num_tokens,
            device=self.device,
            pin_memory=self.pin_memory,
            vocab_size=self.model_config.get_vocab_size(),
            block_sizes=[self.block_size],
            kernel_block_sizes=[[self.cache_config.block_size]],
            is_spec_decode=bool(self.vllm_config.speculative_config),
            logitsprocs=self.input_batch.logitsprocs,
            is_pooling_model=self.is_pooling_model,
            num_speculative_tokens=(
                self.vllm_config.speculative_config.num_speculative_tokens if self.vllm_config.speculative_config else 0
            ),
            cp_kv_cache_interleave_size=self.parallel_config.cp_kv_cache_interleave_size,
        )
        if self._qwen4exp_mtp_ple:
            text_config = self.model_config.hf_text_config
            self._ple_context_len = int(text_config.ngram_size) - 1
            if self._ple_context_len < 1:
                raise ValueError("Qwen4Exp MTP requires ngram_size >= 2")
            self._ple_eos_token_id = int(text_config.eos_token_id)
            self._ple_context_cpu = torch.empty((self.max_num_reqs + 1, self._ple_context_len), dtype=torch.int32)
            self._ple_context_gpu = torch.empty_like(self._ple_context_cpu, device=self.device)
            self._ple_query_start_loc_cpu = torch.empty(self.max_num_reqs + 2, dtype=torch.int32)
            self._ple_query_start_loc_gpu = torch.empty_like(self._ple_query_start_loc_cpu, device=self.device)
        self._acl_format = ACL_FORMAT_FRACTAL_NZ
        logger.info_once("Weight layout uses FRACTAL_NZ.")
        self.sampler = AscendSampler310()
        if getattr(self, "rejection_sampler", None) is not None:
            self.rejection_sampler = AscendRejectionSampler310(self.sampler)
        if self.speculative_config is not None and self.speculative_config.method == "ngram":
            # 310P ngram requires decode-only graph shapes to be built with q_len=1.
            # Keep dispatcher's internal query_len in sync to avoid key-init assert.
            self.cudagraph_dispatcher.uniform_decode_query_len = _NGRAM_GRAPH_UNIFORM_DECODE_QUERY_LEN
            logger.info_once("Ngram speculative decoding uses uniform_decode_query_len=1 for graph capture.")

    def _stage_qwen4exp_ple_inputs(self, num_tokens_padded: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Supply stable, rollback-safe PLE history to the MRv1 target model."""
        stage_ple_history(
            self._ple_context_cpu,
            self._ple_query_start_loc_cpu,
            self.input_batch.token_ids_cpu,
            self.input_batch.num_computed_tokens_cpu,
            self.query_start_loc.np,
            self.input_batch.num_reqs,
            num_tokens_padded,
            self._ple_eos_token_id,
        )
        self._ple_context_gpu.copy_(self._ple_context_cpu, non_blocking=True)
        self._ple_query_start_loc_gpu.copy_(self._ple_query_start_loc_cpu, non_blocking=True)
        return self._ple_query_start_loc_gpu, self._ple_context_gpu

    def _update_states(self, scheduler_output: SchedulerOutput):
        block_copies = scheduler_output.kv_cache_block_copies
        prefix_tiers = getattr(self, "_prefix_mamba_tiers", None)
        layout_changed = bool(
            scheduler_output.finished_req_ids
            or scheduler_output.scheduled_new_reqs
            or scheduler_output.scheduled_cached_reqs.resumed_req_ids
            or getattr(scheduler_output, "preempted_req_ids", None)
        )
        if prefix_tiers and layout_changed:
            # A prior ACL graph can still be writing a request's recurrent
            # state on another stream. Drain it before the base runner moves
            # rows or this runner invalidates/reassigns prefix state slots.
            torch.npu.synchronize(self.device)
        elif scheduler_output.finished_req_ids:
            # Non-prefix 310P paths also stage slot mappings on the CPU.
            torch.npu.current_stream().synchronize()
        fresh_mamba_ids = self._new_prefix_mamba_block_ids(scheduler_output) if prefix_tiers else {}
        retained_mamba_ids = getattr(scheduler_output, "ascend_prefix_mamba_block_ids", None)
        if retained_mamba_ids is not None:
            retain_prefix_mamba_blocks(prefix_tiers, retained_mamba_ids, already_synchronized=layout_changed)
        copied_nested_caches = bool(block_copies) and any(
            not isinstance(cache, torch.Tensor) for cache in self.kv_caches
        )
        if copied_nested_caches:
            from vllm.v1.worker.utils import copy_kv_cache_blocks_inplace

            copy_kv_cache_blocks_inplace(
                (self._prefix_attention_copy_tensors if prefix_tiers else _iter_kv_cache_tensors(self.kv_caches)),
                self.kv_cache_config.num_blocks,
                block_copies,
            )
            # The base runner would invoke the tensor-only helper again with
            # the nested list/tuple layout. Temporarily mark these copies done.
            scheduler_output.kv_cache_block_copies = None
        try:
            deferred = super()._update_states(scheduler_output)
        finally:
            if copied_nested_caches:
                scheduler_output.kv_cache_block_copies = block_copies
        if prefix_tiers:
            # Preprocess also clears these later, but remapping runs first.
            # Resumed/new requests must not select an old running column.
            reset_ids = set(scheduler_output.finished_req_ids)
            reset_ids.update(getattr(scheduler_output, "preempted_req_ids", None) or ())
            reset_ids.update(scheduler_output.scheduled_cached_reqs.resumed_req_ids)
            reset_ids.update(req.req_id for req in scheduler_output.scheduled_new_reqs)
            state_indices = getattr(self, "mamba_state_idx", {})
            for req_id in reset_ids:
                state_indices.pop(req_id, None)
            multi_group_table = cast(MultiGroupBlockTable310, self.input_batch.block_table)
            for group_idx, tier in prefix_tiers.items():
                tier.invalidate(fresh_mamba_ids.get(group_idx, ()))
                if block_copies:
                    block_table = multi_group_table.block_tables[group_idx]
                    active_ids = {
                        int(block_id)
                        for row in range(self.input_batch.num_reqs)
                        for block_id in block_table.block_table.np[row, : block_table.num_blocks_per_row[row]]
                        if block_id > 0
                    }
                    active_ids.update(fresh_mamba_ids.get(group_idx, ()))
                    for source_id, target_id in block_copies:
                        if target_id in active_ids:
                            tier.copy(source_id, target_id)
        return deferred

    def _new_prefix_mamba_block_ids(self, scheduler_output: SchedulerOutput) -> dict[int, set[int]]:
        """Identify fresh IDs so a recycled scheduler block cannot load old state."""
        fresh = {group_idx: set() for group_idx in self._prefix_mamba_tiers}
        for req in scheduler_output.scheduled_new_reqs:
            for group_idx in fresh:
                block_size = self.kv_cache_config.kv_cache_groups[group_idx].kv_cache_spec.block_size
                first_new = cdiv(req.num_computed_tokens, block_size)
                fresh[group_idx].update(block_id for block_id in req.block_ids[group_idx][first_new:] if block_id > 0)
        cached = scheduler_output.scheduled_cached_reqs
        for req_idx, req_id in enumerate(cached.req_ids):
            new_block_ids = cached.new_block_ids[req_idx]
            if new_block_ids is None:
                continue
            for group_idx in fresh:
                ids = new_block_ids[group_idx]
                if req_id in cached.resumed_req_ids:
                    block_size = self.kv_cache_config.kv_cache_groups[group_idx].kv_cache_spec.block_size
                    ids = ids[cdiv(cached.num_computed_tokens[req_idx], block_size) :]
                fresh[group_idx].update(block_id for block_id in ids if block_id > 0)
        return fresh

    @contextmanager
    def temporary_modify_uniform_decode_query_len(self):
        # This is only needed for the 310P ngram path where dispatcher uses q_len=1
        # while runner's default uniform_decode_query_len remains 1 + num_spec_tokens.
        # TODO: remove this temporary override after upstream supports independent
        # decode capture query_len for backend-specific paths.
        if self.speculative_config is None or self.speculative_config.method != "ngram":
            yield
            return

        original_uniform_decode_query_len = self.uniform_decode_query_len
        self.uniform_decode_query_len = _NGRAM_GRAPH_UNIFORM_DECODE_QUERY_LEN
        try:
            yield
        finally:
            self.uniform_decode_query_len = original_uniform_decode_query_len

    def _determine_batch_execution_and_padding(
        self,
        num_tokens: int,
        num_reqs: int,
        num_scheduled_tokens_np: np.ndarray,
        max_num_scheduled_tokens: int,
        use_cascade_attn: bool,
        allow_microbatching: bool = False,
        force_eager: bool = False,
        force_uniform_decode: bool | None = None,
        force_has_lora: bool | None = None,
        force_num_active_loras: int | None = None,
        num_encoder_reqs: int = 0,
    ):
        is_prefilling = (
            self.input_batch.num_computed_tokens_cpu[:num_reqs] < self.input_batch.num_prompt_tokens[:num_reqs]
        )
        is_all_decode = not np.any(is_prefilling)

        # The parent dummy run starts with a prefill-like attention state and
        # switches to SpecDecoding while building metadata. Do not veto its
        # uniform speculative decode graph before that transition happens.
        if not self._spec_dummy_capture and self.attn_state in (
            AscendAttentionState.ChunkedPrefill,
            AscendAttentionState.PrefillCacheHit,
        ):
            force_eager = True

        # Spec decoding graph replay is only valid for uniform spec-decode batches (q_len = 1 + K).
        if (
            self.speculative_config is not None
            and not self._spec_dummy_capture
            and (
                self.attn_state != AscendAttentionState.SpecDecoding
                or max_num_scheduled_tokens != self.uniform_decode_query_len
                or num_tokens != max_num_scheduled_tokens * num_reqs
            )
        ):
            force_eager = True

        if force_uniform_decode is None and self.attn_state == AscendAttentionState.DecodeOnly:
            decode_query_len = _NGRAM_GRAPH_UNIFORM_DECODE_QUERY_LEN
            if (
                max_num_scheduled_tokens == decode_query_len
                and num_tokens == max_num_scheduled_tokens * num_reqs
                and is_all_decode
            ):
                # Respect explicit caller override: only force when unset.
                force_uniform_decode = True

        return super()._determine_batch_execution_and_padding(
            num_tokens=num_tokens,
            num_reqs=num_reqs,
            num_scheduled_tokens_np=num_scheduled_tokens_np,
            max_num_scheduled_tokens=max_num_scheduled_tokens,
            use_cascade_attn=use_cascade_attn,
            allow_microbatching=allow_microbatching,
            force_eager=force_eager,
            force_uniform_decode=force_uniform_decode,
            force_has_lora=force_has_lora,
            force_num_active_loras=force_num_active_loras,
            num_encoder_reqs=num_encoder_reqs,
        )

    def _build_attention_metadata(self, *args: Any, **kwargs: Any):
        # Parent dummy_run assigns ChunkedPrefill for non-MLA MTP (910B FIA graph).
        # 310P must capture SpecDecoding + splitfuse for SpecDecoding uniform decode graphs.
        # TODO: Migrate 310P MTP graph capture and replay before dropping SpecDecoding.
        if self._spec_dummy_capture:
            self.attn_state = AscendAttentionState.SpecDecoding
        return super()._build_attention_metadata(*args, **kwargs)

    def _pad_query_start_loc_for_fia(
        self,
        query_start_loc: torch.Tensor,
        num_tokens_padded: int,
        num_reqs_padded: int,
        num_reqs: int,
        cudagraph_runtime_mode: CUDAGraphMode | None = None,
        batch_desc_num_reqs: int | None = None,
    ) -> int:
        # Keep this aligned with the dispatcher because batch_desc.num_reqs is
        # generated by dispatcher._create_padded_batch_descriptor().
        # For 310P ngram we intentionally set dispatcher q_len=1, while runner's
        # default uniform_decode_query_len may remain 1 + num_spec_tokens.
        uniform_decode_query_len = self.cudagraph_dispatcher.uniform_decode_query_len

        if num_tokens_padded == num_reqs_padded * uniform_decode_query_len:
            # Uniform-batch case: num_reqs must be no greater than num_reqs_padded
            assert num_reqs <= num_reqs_padded

            last_loc = query_start_loc.np[num_reqs]
            query_start_loc.np[num_reqs + 1 : num_reqs_padded + 1] = (
                self.arange_np[1 : num_reqs_padded + 1 - num_reqs] * uniform_decode_query_len + last_loc
            )
        else:
            # Mixed-batch case: num_reqs must equal num_reqs_padded
            assert num_reqs == num_reqs_padded

            # Insert a dummy request instead of setting query_start_loc[num_reqs] = num_tokens_padded directly
            query_start_loc.np[num_reqs_padded + 1] = num_tokens_padded
            num_reqs_padded = num_reqs_padded + 1

        query_start_loc.copy_to_gpu()
        return num_reqs_padded

    def _build_attn_state(self, num_reqs, num_scheduled_tokens, num_valid_tokens):
        attn_state = super()._build_attn_state(num_reqs, num_scheduled_tokens, num_valid_tokens)
        if (
            self.speculative_config is not None
            and not np.all(self.input_batch.num_computed_tokens_cpu[:num_reqs] == 0)
            and np.all(num_scheduled_tokens == self.uniform_decode_query_len)
        ):
            # TODO: Retire this state with the 310P MTP splitfuse graph path.
            attn_state = AscendAttentionState.SpecDecoding
            self.attn_state = attn_state
        return attn_state

    def _remap_compact_mamba_block_tables(self, num_reqs: int, num_scheduled_tokens: np.ndarray | None = None) -> None:
        if not self.supports_compact_mamba_state:
            return
        live_slots = getattr(self, "_live_mamba_slots", None)
        live_lanes: tuple[int, ...] = ()
        if live_slots is not None:
            live_lanes, new_lanes = live_slots.assign(self.input_batch.req_ids[:num_reqs], set(self.requests))
            for lane in new_lanes:
                start = lane * self.num_compact_mamba_blocks
                stop = start + self.num_compact_mamba_blocks
                for state in self._compact_mamba_state_tensors:
                    state[start:stop].zero_()
            self._compact_mamba_lane_by_req = dict(zip(self.input_batch.req_ids[:num_reqs], live_lanes))
        multi_group_table = cast(MultiGroupBlockTable310, self.input_batch.block_table)
        self._prefix_mamba_active_columns = {}
        mapped_tables: dict[int, np.ndarray] = {}
        for group_idx, block_table in enumerate(multi_group_table.block_tables):
            if block_table.is_mamba_group:
                if self.supports_prefix_mamba_state_tier:
                    tier = self._prefix_mamba_tiers[group_idx]
                    used_columns = block_table.num_blocks_per_row[:num_reqs]
                    active_columns = tuple(tuple(range(int(used))) for used in used_columns)
                    if num_scheduled_tokens is not None:
                        spec = self.kv_cache_config.kv_cache_groups[group_idx].kv_cache_spec
                        computed = self.input_batch.num_computed_tokens_cpu[:num_reqs]
                        previous_columns = (computed.astype(np.int64) - 1) // spec.block_size
                        # Use request identity, never the previous batch row.
                        state_indices = getattr(self, "mamba_state_idx", {})
                        for row, req_id in enumerate(getattr(self.input_batch, "req_ids", ())):
                            previous_columns[row] = state_indices.get(req_id, int(previous_columns[row]))
                        active_columns = prefix_mamba_active_columns(
                            used_columns,
                            computed,
                            num_scheduled_tokens,
                            spec.block_size,
                            spec.num_speculative_blocks,
                            previous_columns,
                        )
                    self._prefix_mamba_active_columns[group_idx] = active_columns
                    mapped = tier.remap_rows(block_table.block_table.np[:num_reqs], used_columns, active_columns)
                    mapped_tables[group_idx] = mapped
                    block_table.block_table.gpu[:num_reqs].copy_(
                        torch.as_tensor(mapped, device=self.device), non_blocking=True
                    )
                    continue
                # The running block advances with context length. Reuse the
                # compact slots cyclically, including columns beyond the first
                # speculative window; otherwise all later columns alias slot 0.
                # Keep scheduler-owned CPU block ids unchanged.
                device_table = block_table.block_table.gpu
                num_columns = device_table.shape[1]
                if live_slots is not None:
                    mapped = live_slots.mapped_columns(live_lanes, num_columns)
                    device_table[:num_reqs].copy_(torch.as_tensor(mapped, device=device_table.device))
                    mapped_tables[group_idx] = mapped
                else:
                    compact_columns = torch.arange(num_columns, dtype=device_table.dtype, device=device_table.device)
                    compact_columns.remainder_(self.num_compact_mamba_blocks)
                    device_table[:num_reqs].copy_(compact_columns.unsqueeze(0))
                    mapped_tables[group_idx] = np.broadcast_to(
                        np.arange(num_columns, dtype=np.int32) % self.num_compact_mamba_blocks,
                        (num_reqs, num_columns),
                    ).copy()
        self.input_batch._prefix_mamba_postprocess_tables = mapped_tables

    def _stage_prefix_mamba_request_ids(self) -> None:
        """Give the upstream Mamba pre-copy the same slots as the NPU table.

        Its scalar pre-copy uses ``CachedRequestState.block_ids`` directly to
        derive device pointers, whereas the attention builder reads the staged
        block table. Keep the scheduler IDs in a separate reference and restore
        them immediately after execution so lifecycle updates remain correct.
        """
        self._prefix_raw_req_block_ids = {}
        prefix_tiers = getattr(self, "_prefix_mamba_tiers", {})
        block_tables = cast(MultiGroupBlockTable310, self.input_batch.block_table).block_tables
        for row, req_id in enumerate(self.input_batch.req_ids):
            req_state = self.requests[req_id]
            raw_ids = req_state.block_ids
            mapped = list(raw_ids)
            for group_idx, block_table in enumerate(block_tables):
                if not block_table.is_mamba_group:
                    continue
                if tier := prefix_tiers.get(group_idx):
                    mapped_ids = [0] * len(raw_ids[group_idx])
                    for column in self._prefix_mamba_active_columns[group_idx][row]:
                        mapped_ids[column] = tier.slot_for(raw_ids[group_idx][column])
                else:
                    lane = getattr(self, "_compact_mamba_lane_by_req", {}).get(req_id, 0)
                    mapped_ids = [
                        lane * self.num_compact_mamba_blocks + column % self.num_compact_mamba_blocks
                        for column in range(len(raw_ids[group_idx]))
                    ]
                mapped[group_idx] = mapped_ids
            self._prefix_raw_req_block_ids[req_id] = raw_ids
            req_state.block_ids = tuple(mapped)

    def _restore_prefix_mamba_request_ids(self) -> None:
        raw_by_request = getattr(self, "_prefix_raw_req_block_ids", None)
        if raw_by_request:
            for req_id, raw_ids in raw_by_request.items():
                if req_state := self.requests.get(req_id):
                    req_state.block_ids = raw_ids
        self._prefix_raw_req_block_ids = {}

    @torch.inference_mode()
    def execute_model(
        self,
        scheduler_output: SchedulerOutput,
        intermediate_tensors: IntermediateTensors | None = None,
    ):
        try:
            return super().execute_model(scheduler_output, intermediate_tensors)
        finally:
            if self.supports_compact_mamba_state:
                self._restore_prefix_mamba_request_ids()

    def _prepare_inputs(  # type: ignore[override]
        self,
        scheduler_output: SchedulerOutput,
        num_scheduled_tokens: np.ndarray,
    ) -> tuple[torch.Tensor, SpecDecodeMetadata | None, int]:
        """
        310P cannot use the Triton slot-mapping kernel or the generic NPU Add
        kernels used by the base runner for decode metadata. Keep those pieces
        on CPU and upload the prepared tensors.
        """
        total_num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens
        assert total_num_scheduled_tokens > 0
        num_reqs = self.input_batch.num_reqs
        assert num_reqs > 0

        self.input_batch.block_table.commit_block_table(num_reqs)
        self._remap_compact_mamba_block_tables(num_reqs, num_scheduled_tokens)

        req_indices = np.repeat(self.arange_np[:num_reqs], num_scheduled_tokens)

        if not scheduler_output.scheduled_spec_decode_tokens:
            num_valid_tokens = num_scheduled_tokens
        else:
            num_valid_tokens = np.array(
                [
                    scheduler_output.num_scheduled_tokens[i]
                    - len(scheduler_output.scheduled_spec_decode_tokens.get(i, []))
                    for i in self.input_batch.req_ids
                ],
                dtype=np.int32,
            )
        attn_state = self._build_attn_state(num_reqs, num_scheduled_tokens, num_valid_tokens)

        with_prefill = attn_state not in [AscendAttentionState.DecodeOnly, AscendAttentionState.SpecDecoding]
        self.with_prefill = with_prefill

        cu_num_tokens = self._get_cumsum_and_arange(num_scheduled_tokens, self.query_pos.np)
        prev_req_id_to_index = self.input_batch.prev_req_id_to_index
        self._compute_prev_positions(num_reqs)

        if self.num_accepted_tokens_event is not None:
            self.num_accepted_tokens_event.synchronize()
            # Keep accepted-token ownership by request when async scheduling
            # condenses/reorders the 310P input batch.
            self._sync_num_accepted_tokens(num_reqs, has_prev_mapping=bool(prev_req_id_to_index))
            self.num_accepted_tokens.np[num_reqs:].fill(1)
            self.num_accepted_tokens.copy_to_gpu()
        else:
            if is_rc_device():
                self.num_accepted_tokens.np[num_reqs:].fill(1)
                self.num_accepted_tokens.copy_to_gpu()
            else:
                self.num_accepted_tokens.np.fill(1)
                self.num_accepted_tokens.gpu.fill_(1)

        need_async_num_computed_update = (
            self.use_async_spec_decode and self.valid_sampled_token_count_gpu is not None and prev_req_id_to_index
        )

        if need_async_num_computed_update:
            self.prev_positions.copy_to_gpu(num_reqs)
            self.prev_num_draft_tokens.copy_to_gpu()
            cpu_values = self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs].to(
                device=self.device, non_blocking=True
            )
            update_num_computed_tokens_for_batch_change(
                self.num_computed_tokens,
                self.num_accepted_tokens.gpu[:num_reqs],
                self.prev_positions.gpu[:num_reqs],
                self.valid_sampled_token_count_gpu,
                self.prev_num_draft_tokens.gpu,
                cpu_values,
            )
            # Make sure D2H is synchronized.
            self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs].copy_(
                self.num_computed_tokens[:num_reqs], non_blocking=False
            )
        else:
            self.num_computed_tokens[:num_reqs].copy_(
                self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs],
                non_blocking=True,
            )
        # Make sure when you update the positions and slot mapping, num_computed_tokens_cpu
        # has been corrected.
        positions_np = self._positions_np_buf[:total_num_scheduled_tokens]
        np.add(
            self.input_batch.num_computed_tokens_cpu[req_indices],
            self.query_pos.np[: cu_num_tokens[-1]],
            out=positions_np,
        )
        block_table = cast(MultiGroupBlockTable310, self.input_batch.block_table)
        block_table.compute_slot_mapping(
            req_indices,
            positions_np[:total_num_scheduled_tokens],
        )

        if self.use_dcp:
            self.dcp_manager.init_batch_info(
                num_scheduled_tokens,
                self.input_batch.num_reqs,
                self.input_batch.num_computed_tokens_cpu,
                self.input_batch.num_prompt_tokens,
            )

        prev_req_id_to_index = self.input_batch.prev_req_id_to_index
        self._compute_prev_positions(num_reqs)
        prev_positions_gpu = None
        if self.use_async_scheduling and self.input_batch.prev_sampled_token_ids is not None and prev_req_id_to_index:
            self.prev_positions.copy_to_gpu(num_reqs)
            prev_positions_gpu = self.prev_positions.gpu[:num_reqs]

        if self.speculative_config and self.use_dcp:
            self.dcp_manager.generate_dcp_mtp_input(
                total_num_scheduled_tokens,
                scheduler_output.num_scheduled_tokens,
                with_prefill,
                self.input_batch,
                self.arange_np,
                req_indices,
                positions_np,
                cu_num_tokens,
                self._draft_token_ids,  # type: ignore[has-type]
                scheduler_output,
                self.num_spec_tokens,
                prev_positions=prev_positions_gpu,
            )

        self.query_lens = torch.from_numpy(num_scheduled_tokens)

        token_indices = positions_np + req_indices * self.input_batch.token_ids_cpu.shape[1]
        token_indices_tensor = torch.from_numpy(token_indices)
        torch.index_select(
            self.input_batch.token_ids_cpu_tensor.flatten(),
            0,
            token_indices_tensor,
            out=self.input_ids.cpu[:total_num_scheduled_tokens],
        )
        if self.enable_prompt_embeds:
            is_token_ids = self.input_batch.is_token_ids_tensor.flatten()
            torch.index_select(
                is_token_ids, 0, token_indices_tensor, out=self.is_token_ids.cpu[:total_num_scheduled_tokens]
            )

        if self.input_batch.req_prompt_embeds and (self.is_multimodal_model or self.enable_prompt_embeds):
            output_idx = 0
            for req_idx in range(num_reqs):
                num_sched = num_scheduled_tokens[req_idx]

                if req_idx not in self.input_batch.req_prompt_embeds:
                    output_idx += num_sched
                    continue

                if num_sched <= 0:
                    output_idx += num_sched
                    continue

                req_embeds = self.input_batch.req_prompt_embeds[req_idx]
                start_pos = self.input_batch.num_computed_tokens_cpu[req_idx]

                if start_pos >= req_embeds.shape[0]:
                    output_idx += num_sched
                    continue

                end_pos = start_pos + num_sched
                actual_end = min(end_pos, req_embeds.shape[0])
                actual_num_sched = actual_end - start_pos

                if actual_num_sched > 0:
                    self.inputs_embeds.cpu[output_idx : output_idx + actual_num_sched].copy_(
                        req_embeds[start_pos:actual_end]
                    )

                output_idx += num_sched

        self.query_start_loc.np[0] = 0
        self.query_start_loc.np[1 : num_reqs + 1] = cu_num_tokens
        if is_rc_device():
            self.query_start_loc.np[num_reqs + 1 :].fill(-1)
        self.query_start_loc.copy_to_gpu()

        if self._has_gdn:
            self.gdn_query_start_loc.np[0] = 0
            self.gdn_query_start_loc.np[1 : num_reqs + 1] = cu_num_tokens
            self.gdn_query_start_loc.np[num_reqs + 1 :].fill(cu_num_tokens[-1])
            self.gdn_query_start_loc.copy_to_gpu()

        torch.add(
            self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs],
            torch.from_numpy(num_scheduled_tokens),
            out=self.optimistic_seq_lens_cpu[:num_reqs],
        )
        self.optimistic_seq_lens_cpu[num_reqs:].fill_(0)

        if not is_rc_device():
            self.query_start_loc.gpu[num_reqs + 1 :].fill_(-1)

        self._prepare_input_ids(scheduler_output, num_reqs, total_num_scheduled_tokens, cu_num_tokens)
        if self.uses_mrope:
            self._calc_mrope_positions(scheduler_output)
            self.mrope_positions.gpu.copy_(
                self.mrope_positions.cpu,
                non_blocking=True,
            )
        num_tokens = [self.requests[r].num_tokens for r in self.input_batch.req_ids]
        num_tokens_np = np.array(num_tokens, dtype=np.int32)
        base_num_reqs = self.input_batch.num_reqs
        num_reqs = base_num_reqs
        discard_requests_mask = self.optimistic_seq_lens_cpu[:num_reqs].numpy() < num_tokens_np

        discard_request_indices = np.nonzero(discard_requests_mask)[0]
        self.num_discarded_requests = len(discard_request_indices)
        self.discard_request_indices.np[: self.num_discarded_requests] = discard_request_indices
        self.discard_request_indices.copy_to_gpu(self.num_discarded_requests)

        self.req_indices.np[:total_num_scheduled_tokens] = req_indices
        self.req_indices.copy_to_gpu(total_num_scheduled_tokens)

        self.query_pos.copy_to_gpu(total_num_scheduled_tokens)
        self.num_scheduled_tokens.np[:num_reqs] = num_scheduled_tokens
        self.num_scheduled_tokens.copy_to_gpu(num_reqs)
        num_scheduled_tokens_gpu = self.num_scheduled_tokens.gpu[:num_reqs]
        self.positions[:total_num_scheduled_tokens].copy_(
            self._positions_cpu_buf[:total_num_scheduled_tokens],
            non_blocking=True,
        )
        if need_async_num_computed_update:
            self.seq_lens[:num_reqs] = self.num_computed_tokens[:num_reqs] + num_scheduled_tokens_gpu
            if is_rc_device():
                tail_len = self.seq_lens.shape[0] - num_reqs
                if tail_len > 0:
                    self.seq_lens[num_reqs:].copy_(
                        self.optimistic_seq_lens_cpu[num_reqs:].to(self.device, non_blocking=True),
                    )
        else:
            if is_rc_device():
                self.seq_lens.copy_(
                    self.optimistic_seq_lens_cpu[: self.seq_lens.shape[0]],
                    non_blocking=True,
                )
            else:
                self.seq_lens[:num_reqs].copy_(
                    self.optimistic_seq_lens_cpu[:num_reqs],
                    non_blocking=True,
                )
        if not is_rc_device():
            self.seq_lens[num_reqs:].fill_(0)

        if (
            self._needs_seq_lens_cpu_sync
            and self.use_async_spec_decode
            and self.valid_sampled_token_count_gpu is not None
            and prev_req_id_to_index
        ):
            # Correct optimistic_seq_lens_cpu on CPU using the asynchronously
            # copied valid-sampled-token counts; avoids an extra NPU->CPU copy
            # of seq_lens and the event.synchronize() in attention metadata.
            # The shared helper synchronizes on the D2H copy event before the
            # host read to avoid consuming stale counts (see its docstring).
            self._correct_optimistic_seq_lens_cpu(num_reqs)

        use_spec_decode = len(scheduler_output.scheduled_spec_decode_tokens) > 0
        if not use_spec_decode:
            spec_decode_metadata = None
            num_draft_tokens = None
            num_sampled_tokens = np.ones(num_reqs, dtype=np.int32)
            logits_indices = self.query_start_loc.gpu[1 : num_reqs + 1] - 1
        else:
            num_draft_tokens = np.zeros(num_reqs, dtype=np.int32)
            new_schedule_reqs = [x.req_id for x in scheduler_output.scheduled_new_reqs]
            num_decode_draft_tokens = np.full(num_reqs, -1, dtype=np.int32)
            for (
                req_id,
                draft_token_ids,
            ) in scheduler_output.scheduled_spec_decode_tokens.items():
                req_idx = self.input_batch.req_id_to_index[req_id]
                draft_len = len(draft_token_ids)
                num_draft_tokens[req_idx] = draft_len
                if (self.is_kv_consumer and req_id in new_schedule_reqs) or (
                    self.input_batch.num_computed_tokens_cpu[req_idx] >= self.input_batch.num_prompt_tokens[req_idx]
                ):
                    num_decode_draft_tokens[req_idx] = draft_len
                else:
                    num_decode_draft_tokens[req_idx] = -1

            spec_decode_metadata = self._calc_spec_decode_metadata(
                num_draft_tokens,
                cu_num_tokens,
            )
            logits_indices = spec_decode_metadata.logits_indices
            num_sampled_tokens = num_draft_tokens + 1

            self.num_decode_draft_tokens.np[:num_reqs] = num_decode_draft_tokens
            self.num_decode_draft_tokens.np[num_reqs:].fill(-1)
            self.num_decode_draft_tokens.copy_to_gpu()

        self.logits_indices = logits_indices

        if self.lora_config:
            assert np.sum(num_sampled_tokens) <= self.vllm_config.scheduler_config.max_num_batched_tokens
            self.set_active_loras(self.input_batch, num_scheduled_tokens, num_sampled_tokens)
        if lmhead_tp_enable():
            max_num_reqs_across_dp = self.max_num_reqs * self.uniform_decode_query_len
            logits_indices = nn.functional.pad(logits_indices, (0, max_num_reqs_across_dp - logits_indices.shape[0]))

        if self.supports_compact_mamba_state:
            self._stage_prefix_mamba_request_ids()

        return (
            logits_indices,
            spec_decode_metadata,
            total_num_scheduled_tokens,
        )

    @torch.inference_mode()
    def _dummy_run(
        self,
        num_tokens: int,
        with_prefill: bool = False,
        cudagraph_runtime_mode=None,
        force_attention: bool = False,
        uniform_decode: bool = False,
        is_profile: bool = False,
        create_mixed_batch: bool = False,
        allow_microbatching: bool = True,
        skip_eplb: bool = False,
        remove_lora: bool = True,
        is_graph_capturing: bool = False,
        num_active_loras: int = 0,
        profile_seq_lens: int | None = None,
        skip_gdn_state_update: bool = False,
    ):
        temporary_context = self.temporary_modify_uniform_decode_query_len() if uniform_decode else nullcontext()
        # All the spec decoding cases has to run splitfuse op on 310P.
        is_spec_graph_capture = (
            uniform_decode
            and not is_profile
            and self.speculative_config is not None
            and not self.vllm_config.model_config.use_mla
        )
        with temporary_context:
            self._spec_dummy_capture = is_spec_graph_capture
            try:
                return super()._dummy_run(
                    num_tokens=num_tokens,
                    with_prefill=with_prefill,
                    cudagraph_runtime_mode=cudagraph_runtime_mode,
                    force_attention=force_attention,
                    uniform_decode=uniform_decode,
                    is_profile=is_profile,
                    create_mixed_batch=create_mixed_batch,
                    allow_microbatching=allow_microbatching,
                    skip_eplb=skip_eplb,
                    remove_lora=remove_lora,
                    is_graph_capturing=is_graph_capturing,
                    num_active_loras=num_active_loras,
                    profile_seq_lens=profile_seq_lens,
                    skip_gdn_state_update=skip_gdn_state_update,
                )
            finally:
                self._spec_dummy_capture = False

    def _model_forward(
        self,
        num_tokens_padded: int,
        input_ids: torch.Tensor | None = None,
        positions: torch.Tensor | None = None,
        intermediate_tensors: IntermediateTensors | None = None,
        inputs_embeds: torch.Tensor | None = None,
        **model_kwargs: dict[str, Any],
    ):
        if self.uses_mrope:
            assert positions is not None
            prepare_mrope_cos_sin_slices_from_runner(self, positions)

        if self._qwen4exp_mtp_ple:
            query_start_loc, ngram_context = self._stage_qwen4exp_ple_inputs(num_tokens_padded)
            model_kwargs["query_start_loc"] = query_start_loc
            model_kwargs["ngram_context"] = ngram_context
            # Synchronous Qwen4Exp scheduling already has authoritative token,
            # boundary, and rollback-safe history buffers on the host. Let the
            # PLE eager graph break hash those directly instead of launching a
            # tiny device graph and synchronously copying its row IDs back.
            model_kwargs["input_ids_cpu"] = self.input_ids.cpu[:num_tokens_padded]
            model_kwargs["query_start_loc_cpu"] = self._ple_query_start_loc_cpu
            model_kwargs["ngram_context_cpu"] = self._ple_context_cpu

        assert self.model is not None
        forward_context = get_forward_context()
        assert forward_context is not None
        model_inputs: dict[str, Any] = {
            "input_ids": input_ids,
            "positions": positions,
            "intermediate_tensors": intermediate_tensors,
            "inputs_embeds": inputs_embeds,
            **model_kwargs,
        }
        run_model = partial(self.model, **model_inputs)
        update_before_replay = (
            self.speculative_config is not None
            and not self.enable_enpu
            and forward_context.cudagraph_runtime_mode == CUDAGraphMode.FULL
            and not forward_context.capturing
            and hasattr(self, "update_stream")
        )

        if self.enable_enpu or update_before_replay:
            if update_before_replay:
                main_stream = torch.npu.current_stream()
                # Order the update after the previous replay without blocking
                # the host. BreakableACLGraphWrapper retains the final host
                # synchronization before replay, so mutable MTP/GDN metadata
                # is still complete before the graph consumes it.
                self.update_stream.wait_stream(main_stream)
            self._update_full_graph_params_if_needed(
                forward_context,
                num_tokens_padded,
            )
            if update_before_replay:
                main_stream.wait_stream(self.update_stream)
            hidden_states = run_model()
        else:
            hidden_states = run_model()
            self._update_full_graph_params_if_needed(
                forward_context,
                num_tokens_padded,
            )

        return hidden_states

    def _check_and_update_cudagraph_mode(
        self,
        attention_backends,
        kv_cache_groups,
    ) -> None:
        # 910B does not need this branch because runner/dispatcher query_len are
        # naturally consistent there. 310P ngram needs temporary alignment.
        with self.temporary_modify_uniform_decode_query_len():
            super()._check_and_update_cudagraph_mode(attention_backends, kv_cache_groups)

    def _init_kv_zero_meta(self) -> None:
        """310P uses torch zeroing because Triton is not available."""
        self._kv_block_zeroer = AscendKVBlockZeroer310(self.device, self.pin_memory)
        self._kv_block_zeroer.init_meta(
            attn_groups_iter=self._kv_cache_spec_attn_group_iterator(),
            kernel_block_sizes=self.kernel_block_sizes,
            cache_dtype=self.cache_config.cache_dtype,
            runner_only_attn_layers=self.runner_only_attn_layers,
            static_forward_context=(self.compilation_config.static_forward_context),
        )

    def initialize_kv_cache_tensors(
        self,
        kv_cache_config: KVCacheConfig,
        kernel_block_sizes: list[int] | None = None,
        kv_cache_allocation_context: AbstractContextManager | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Override the base class method.
        Initialize the memory buffer for KV cache.

        Args:
            kv_cache_config: The KV cache config
            kv_cache_allocation_context: Sleep-mode pool used only for discardable
            KV backing allocations. Sharing and bind stay outside.
        Returns:
            Dict[str, torch.Tensor]: A map between layer names to their
            corresponding memory buffer for KV cache.
        """
        # The private 310P allocator populates this map for QSA layers. GLM's
        # shared-slot path deliberately bypasses that allocator, so initialize
        # the empty state before choosing either path.
        self._qsa_index_caches: dict[str, torch.Tensor] = {}
        # 310P limitation: KV transfer is not supported
        if self.vllm_config.kv_transfer_config is not None:
            logger.error("KV cache transfer is not supported.")
            raise ValueError("KV cache transfer is not supported for 310P.")
        if self.use_sparse:
            logger.error("Deepseek Sparse Attention is not supported.")
            raise ValueError("Deepseek Sparse Attention is not supported for 310P.")
        if self.model_config.use_mla:
            # Gated bring-up path. With the experimental flag the MLA layers use
            # AscendMLABackend310 (see platform.get_attn_backend_cls) and their
            # KV cache is allocated as an MLA latent cache by the standard
            # _allocate_kv_cache_tensors path below. Keep the hard guard for all
            # default 310P runs until MLA is verified on hardware.
            from vllm_ascend import envs as ascend_envs

            if not ascend_envs.VLLM_ASCEND_310P_ENABLE_MLA:
                logger.error("MLAAttention is not supported.")
                raise ValueError("MLAAttention is not supported for 310P.")
            logger.warning(
                "VLLM_ASCEND_310P_ENABLE_MLA=1: initializing experimental MLA "
                "KV cache on 310P via AscendMLABackend310 (unverified on hardware)."
            )
        # GLM-Next's planner emits one descriptor per physical cache slot.
        # Indexer/state layers alias a slot; live KDA states have fixed
        # per-request descriptors. Reuse the base Ascend allocator so the
        # runner creates exactly the physical storage the planner admitted.
        layer_specs = self._get_layer_kv_cache_specs(kv_cache_config)
        uses_glm5_next_shared_slots = getattr(
            getattr(self.model_config, "hf_text_config", None), "model_type", None
        ) == "glm5_next_text" or any(
            getattr(spec, "model_version", None) == "glm5_next" for spec in layer_specs.values()
        )
        if uses_glm5_next_shared_slots:
            if (
                any(isinstance(spec, MambaSpec) and spec.mamba_cache_mode == "none" for spec in layer_specs.values())
                and not self.supports_compact_mamba_state
            ):
                raise ValueError("GLM-Next live KDA state requires compact Mamba block-table remapping on 310P")
            raw_caches = NPUModelRunner._allocate_kv_cache_tensors(
                self,
                kv_cache_config,
            )
            kv_caches = NPUModelRunner._reshape_kv_cache_tensors(
                self,
                kv_cache_config,
                raw_caches,
            )
            host_hot_names = [
                name
                for descriptor in getattr(kv_cache_config, "kv_cache_tensors", ())
                if getattr(descriptor, "glm_host_hot", False)
                for name in getattr(descriptor, "layers", getattr(descriptor, "shared_by", []))
            ]
            self._glm_host_kv_layers = {}
            if host_hot_names:
                from vllm_ascend.models.glm5next.host_kv import HOT_BLOCK_SIZE, NZ_INNER, GlmHostKVLayer

                if not self.model_config.enforce_eager:
                    raise ValueError("310P GLM host MLA requires --enforce-eager until transfers are graph-safe")
                if self.vllm_config.cache_config.enable_prefix_caching or self.speculative_config is not None:
                    raise ValueError("310P GLM host MLA does not support prefix caching or speculative decoding")
                if (
                    self.vllm_config.parallel_config.decode_context_parallel_size != 1
                    or self.vllm_config.parallel_config.prefill_context_parallel_size != 1
                ):
                    raise ValueError("310P GLM host MLA requires DCP=1 and PCP=1")
                for name in host_hot_names:
                    spec = layer_specs[name]
                    if spec.dtype != torch.float16 or spec.head_size != 512:
                        raise ValueError("310P GLM host MLA requires FP16 512-wide latent cache")
                    hot = (
                        raw_caches[name].view(spec.dtype).view(-1, spec.head_size // NZ_INNER, HOT_BLOCK_SIZE, NZ_INNER)
                    )
                    kv_caches[name] = [hot, hot]
                    self._glm_host_kv_layers[name] = GlmHostKVLayer(kv_cache_config.num_blocks, hot, spec.block_size)
        else:
            kv_caches = self._allocate_kv_cache_tensors(kv_cache_config)
        if self._live_mamba_slots is not None:
            self._compact_mamba_state_tensors = tuple(
                state
                for name, cache in kv_caches.items()
                if isinstance(layer_specs[name], MambaSpec)
                for state in cache
            )
        if self.supports_prefix_mamba_state_tier:
            self._prefix_mamba_tiers = {}
            self._prefix_attention_copy_tensors = tuple(
                tensor
                for name, cache in kv_caches.items()
                if isinstance(layer_specs[name], AttentionSpec)
                for tensor in _iter_kv_cache_tensors((cache,))
            ) + tuple(self._qsa_index_caches.values())
            tier_states = {
                group_idx: [kv_caches[name] for name in group.layer_names]
                for group_idx, group in enumerate(kv_cache_config.kv_cache_groups)
                if isinstance(group.kv_cache_spec, MambaSpec)
            }
            self._prefix_mamba_archive_bytes_per_checkpoint = sum(
                prefix_mamba_state_bytes_per_slot(states) for states in tier_states.values()
            )
            self._prefix_mamba_archive_maximum_slots = max(
                0,
                kv_cache_config.num_blocks - (self.num_compact_mamba_blocks - 1),
            )
            for group_idx, group in enumerate(kv_cache_config.kv_cache_groups):
                if isinstance(group.kv_cache_spec, MambaSpec):
                    self._prefix_mamba_tiers[group_idx] = PrefixMambaStateTier(
                        tier_states[group_idx],
                        self.num_compact_mamba_blocks,
                    )
        # Set up cross-layer KV cache sharing
        for layer_name, target_layer_name in self.shared_kv_cache_layers.items():
            logger.debug("%s reuses KV cache of %s", layer_name, target_layer_name)
            kv_caches[layer_name] = kv_caches[target_layer_name]
            if target_layer_name in self._qsa_index_caches:
                self._qsa_index_caches[layer_name] = self._qsa_index_caches[target_layer_name]

        from vllm.v1.worker.utils import bind_kv_cache

        bind_kv_cache(kv_caches, self.compilation_config.static_forward_context, self.kv_caches)
        for name, host_layer in getattr(self, "_glm_host_kv_layers", {}).items():
            attention = self.compilation_config.static_forward_context[name]
            attention.impl.host_kv_layer = host_layer
        for layer_name, index_cache in self._qsa_index_caches.items():
            layer = self.compilation_config.static_forward_context[layer_name]
            layer.qsa_index_cache = index_cache
        return kv_caches

    def allocate_prefix_mamba_device_archive(self) -> None:
        """Use post-capture NPU headroom for prefix states before host spill."""
        tiers = getattr(self, "_prefix_mamba_tiers", {})
        bytes_per_checkpoint = getattr(self, "_prefix_mamba_archive_bytes_per_checkpoint", 0)
        if not tiers or not bytes_per_checkpoint:
            return
        if any(tier.device_archive_slots for tier in tiers.values()):
            return
        free_device_bytes, _ = torch.npu.mem_get_info()
        archive_slots = prefix_mamba_device_archive_slots(
            free_device_bytes,
            _PREFIX_MAMBA_DEVICE_ARCHIVE_RESERVE_BYTES,
            bytes_per_checkpoint,
            self._prefix_mamba_archive_maximum_slots,
        )
        for tier in tiers.values():
            tier.allocate_device_archive(archive_slots)
        logger.info_once(
            "Prefix Mamba device archive: primary_slots=%d, archive_slots=%d, "
            "checkpoint_bytes=%d, archive_bytes=%.2f GiB, post_capture_free=%.2f GiB, "
            "reserve=%.2f GiB. Host spill starts only after both device tiers fill.",
            self.num_compact_mamba_blocks - 1,
            archive_slots,
            bytes_per_checkpoint,
            archive_slots * bytes_per_checkpoint / (1 << 30),
            free_device_bytes / (1 << 30),
            _PREFIX_MAMBA_DEVICE_ARCHIVE_RESERVE_BYTES / (1 << 30),
            scope="local",
        )

    def capture_model(self) -> int:
        graph_memory_bytes = super().capture_model()
        self.allocate_prefix_mamba_device_archive()
        return graph_memory_bytes

    def _allocate_kv_cache_tensors(self, kv_cache_config: KVCacheConfig) -> dict[str, torch.Tensor]:
        """
        Initializes the KV cache size. The buffer needs to be reshaped to the desired shape before being used by
        the models.

        Args:
            kv_cache_config: The KV cache config
        Returns:
            dict[str, torch.Tensor]: A map between layer names to their
            corresponding memory buffer.
        """
        # init kv cache tensors
        kv_cache: dict[str, list[torch.Tensor] | tuple[torch.Tensor, torch.Tensor]] = {}
        layer_attention_backends = _get_layer_attention_backends(getattr(self, "attn_groups", ()))
        # get kv cache spec for each layer
        layer_kv_cache_spec: dict[str, KVCacheSpec] = {}
        for group_kv_cache_spec in kv_cache_config.kv_cache_groups:
            group_spec = group_kv_cache_spec.kv_cache_spec
            if isinstance(group_spec, UniformTypeKVCacheSpecs):
                # GLM-5.3-Flash groups its per-layer KV specs into a
                # UniformTypeKVCacheSpecs wrapper (glm5next/cache_config.py); map
                # each layer to its *underlying* MambaSpec/AttentionSpec so the
                # spec-type dispatch below can route it (the wrapper is neither).
                for layer_name, sub_spec in group_spec.kv_cache_specs.items():
                    layer_kv_cache_spec[layer_name] = sub_spec
                # Layers present in the group but absent from the wrapper's
                # per-layer map fall back to the representative spec.
                representative = next(iter(group_spec.kv_cache_specs.values()), group_spec)
                for layer_name in group_kv_cache_spec.layer_names:
                    layer_kv_cache_spec.setdefault(layer_name, representative)
            else:
                for layer_name in group_kv_cache_spec.layer_names:
                    layer_kv_cache_spec[layer_name] = group_spec
        # Allocate kv cache buffers according to the kv_cache_config and kv_cache_spec
        for kv_cache_tensor in kv_cache_config.kv_cache_tensors:
            shared_names = get_kv_cache_tensor_layers(kv_cache_tensor)
            for idx in range(len(shared_names)):
                layer_name = shared_names[idx]
                if layer_name in self.runner_only_attn_layers:
                    continue
                cache_spec = layer_kv_cache_spec[layer_name]
                # Dispatch by KV-cache spec *type*, not layer-name substring:
                # GLM-5.3-Flash names both its KDA (linear attention, MambaSpec)
                # and DSA (MLA, AttentionSpec) layers ``self_attn``, so a name
                # match ("linear_attn"/"attn") misroutes the KDA state cache into
                # the attention branch and trips ``assert isinstance(..., AttentionSpec)``.
                if isinstance(cache_spec, MambaSpec) and layer_name not in kv_cache:
                    # vLLM #51718 packs all group layers into one tensor on main;
                    # MambaSpec.page_size_bytes is per-layer, so num_blocks times
                    # it is the per-layer byte count (matching v0.28.0's size).
                    compact_state = self.supports_compact_mamba_state
                    # The prefix tier already sizes one shared pool for all
                    # requests. Multiplying it by batch size both overallocates
                    # and violates PrefixMambaStateTier's slot-count contract.
                    compact_slots = self.num_compact_mamba_blocks if compact_state else 0
                    if compact_state and not self.supports_prefix_mamba_state_tier:
                        compact_slots *= self.max_num_reqs
                    per_layer_size = (
                        compact_slots * cache_spec.page_size_bytes
                        if compact_state
                        else (
                            kv_cache_tensor.size
                            if vllm_version_is("0.28.0")
                            else kv_cache_config.num_blocks * cache_spec.page_size_bytes
                        )
                    )
                    assert per_layer_size % cache_spec.page_size_bytes == 0
                    num_blocks = per_layer_size // cache_spec.page_size_bytes
                    if not compact_state:
                        assert num_blocks >= kv_cache_config.num_blocks
                    if vllm_version_is("0.28.0"):
                        # v0.28.0 `shared_by` aliases the same physical blocks.
                        raw_tensor = torch.zeros(per_layer_size, dtype=torch.int8, device=self.device)
                        state_tensors = []
                        target_idx = 0
                        start_idx = 0
                        for shape, dtype in zip(cache_spec.shapes, cache_spec.dtypes):
                            target_shape = (num_blocks, *shape)
                            target_idx += math.prod(target_shape) * get_dtype_size(dtype)
                            tensor = raw_tensor[start_idx:target_idx].view(dtype).view(target_shape)
                            start_idx = target_idx
                            state_tensors.append(tensor)
                        for layer_name_inner in shared_names:
                            if isinstance(layer_kv_cache_spec.get(layer_name_inner), MambaSpec):
                                kv_cache[layer_name_inner] = state_tensors
                    else:
                        # main: every layer owns its own region; allocate private
                        # state tensors per layer so blocks don't collide.
                        for layer_name_inner in shared_names:
                            if isinstance(layer_kv_cache_spec.get(layer_name_inner), MambaSpec):
                                raw_tensor = torch.zeros(per_layer_size, dtype=torch.int8, device=self.device)
                                state_tensors = []
                                target_idx = 0
                                start_idx = 0
                                for shape, dtype in zip(cache_spec.shapes, cache_spec.dtypes):
                                    target_shape = (num_blocks, *shape)
                                    target_idx += math.prod(target_shape) * get_dtype_size(dtype)
                                    tensor = raw_tensor[start_idx:target_idx].view(dtype).view(target_shape)
                                    start_idx = target_idx
                                    state_tensors.append(tensor)
                                kv_cache[layer_name_inner] = state_tensors
                elif isinstance(cache_spec, AttentionSpec) and layer_name not in kv_cache:
                    kv_cache_spec = cache_spec
                    attn_backend = layer_attention_backends[layer_name]
                    assert kv_cache_tensor.size % kv_cache_spec.page_size_bytes == 0
                    num_blocks = kv_cache_tensor.size // kv_cache_spec.page_size_bytes
                    # vLLM #51718 packs all group layers into one tensor;
                    # kv_cache_config.num_blocks is the per-layer block count.
                    num_blocks = kv_cache_config.num_blocks
                    assert num_blocks >= kv_cache_config.num_blocks
                    supported_sizes = [
                        size
                        for supported_size in attn_backend.get_supported_kernel_block_sizes()
                        if (size := _concrete_size(supported_size)) <= kv_cache_spec.block_size
                        and kv_cache_spec.block_size % size == 0
                        and size * _concrete_size(kv_cache_spec.head_size) <= _ATTENTION_BLOCK_SIZE_LIMIT
                    ]
                    kernel_block_size = supported_sizes[0] if supported_sizes else kv_cache_spec.block_size
                    k_shape = _get_attention_cache_tensor_shape(
                        attn_backend,
                        num_blocks,
                        kv_cache_spec,
                    )
                    dtype = kv_cache_spec.dtype
                    index_cache_shape = None
                    if getattr(kv_cache_spec, "has_qsa_index_cache", False):
                        kernel_blocks = k_shape[0]
                        groups_per_kernel_block = kernel_block_size // kv_cache_spec.index_compress_ratio
                        index_cache_shape = (
                            kernel_blocks,
                            groups_per_kernel_block + kv_cache_spec.index_compress_ratio - 1,
                            kv_cache_spec.index_head_size,
                        )
                    if vllm_version_is("0.28.0"):
                        # v0.28.0 `shared_by` aliases the same physical blocks.
                        k_cache, v_cache = _allocate_attention_cache_pair(
                            k_shape,
                            dtype,
                            self.device,
                            kv_cache_spec,
                        )
                        for layer_name_inner in shared_names:
                            # shared the kvcache between the self_attn specs in the same group
                            if isinstance(layer_kv_cache_spec.get(layer_name_inner), AttentionSpec):
                                kv_cache[layer_name_inner] = (k_cache, v_cache)
                                if index_cache_shape is not None:
                                    self._qsa_index_caches[layer_name_inner] = torch.empty(
                                        index_cache_shape,
                                        dtype=kv_cache_spec.index_dtype,
                                        device=self.device,
                                    )
                    else:
                        # main: every layer owns its own region; give each layer a
                        # private (k, v) so block indices don't collide across layers.
                        for layer_name_inner in shared_names:
                            if isinstance(layer_kv_cache_spec.get(layer_name_inner), AttentionSpec):
                                kv_cache[layer_name_inner] = _allocate_attention_cache_pair(
                                    k_shape,
                                    dtype,
                                    self.device,
                                    kv_cache_spec,
                                )
                                if index_cache_shape is not None:
                                    self._qsa_index_caches[layer_name_inner] = torch.empty(
                                        index_cache_shape,
                                        dtype=kv_cache_spec.index_dtype,
                                        device=self.device,
                                    )
        layer_names = set()
        for group in kv_cache_config.kv_cache_groups:
            for layer_name in group.layer_names:
                if layer_name in self.runner_only_attn_layers:
                    continue
                layer_names.add(layer_name)
        assert layer_names == set(kv_cache.keys()), "Some layers are not correctly initialized"
        return kv_cache

    # Override this function because of tensor.copy_(other) accuracy issue.
    # TODO: This override will be removed after tensor.copy_(other) accuracy issue is resolved.
    def _prepare_input_ids(
        self,
        scheduler_output: SchedulerOutput,
        num_reqs: int,
        total_num_scheduled_tokens: int,
        cu_num_tokens: np.ndarray,
    ) -> None:
        """Prepare the input IDs for the current batch.

        Carefully handles the `prev_sampled_token_ids` which can be cached
        from the previous engine iteration, in which case those tokens on the
        GPU need to be copied into the corresponding slots into input_ids."""

        if self.input_batch.prev_sampled_token_ids is None:
            # Normal scheduling case
            self.input_ids.copy_to_gpu(total_num_scheduled_tokens)
            if self.enable_prompt_embeds:
                self.inputs_embeds.copy_to_gpu(total_num_scheduled_tokens)
                self.is_token_ids.copy_to_gpu(total_num_scheduled_tokens)
            return

        # Async scheduling case, where some decode requests from the previous
        # iteration won't have entries in input_ids_cpu and need to be copied
        # on the NPU from prev_sampled_token_ids.
        prev_req_id_to_index = self.input_batch.prev_req_id_to_index
        assert prev_req_id_to_index is not None
        sample_flattened_indices: list[int] = []
        spec_flattened_indices: list[int] = []
        prev_common_req_indices: list[int] = []
        prev_draft_token_indices: list[int] = []
        indices_match = True
        max_flattened_index = -1
        total_num_spec_tokens = 0
        scheduled_spec_tokens = scheduler_output.scheduled_spec_decode_tokens

        for req_id, cur_index in self.input_batch.req_id_to_index.items():
            if (prev_index := prev_req_id_to_index.get(req_id)) is not None:
                prev_common_req_indices.append(prev_index)
                draft_len = len(scheduled_spec_tokens.get(req_id, ()))
                total_num_spec_tokens += draft_len
                flattened_index = int(cu_num_tokens[cur_index]) - 1
                sample_flattened_indices.append(flattened_index - draft_len)
                spec_flattened_indices.extend(range(flattened_index - draft_len + 1, flattened_index + 1))
                start = prev_index * self.num_spec_tokens
                prev_draft_token_indices.extend(range(start, start + draft_len))
                indices_match &= prev_index == flattened_index
                max_flattened_index = max(max_flattened_index, flattened_index)
        num_common_tokens = len(sample_flattened_indices)
        total_without_spec = total_num_scheduled_tokens - total_num_spec_tokens
        if num_common_tokens < total_without_spec:
            self.input_ids.copy_to_gpu(total_num_scheduled_tokens)
            if self.enable_prompt_embeds:
                self.inputs_embeds.copy_to_gpu(total_num_scheduled_tokens)
                self.is_token_ids.copy_to_gpu(total_num_scheduled_tokens)
        if num_common_tokens == 0:
            return
        if indices_match and max_flattened_index == (num_common_tokens - 1):
            # NOTE: Override the copy_ function here
            indices = torch.arange(num_common_tokens, device=self.input_ids.gpu.device)
            source = self.input_batch.prev_sampled_token_ids[:num_common_tokens, 0]
            self.input_ids.gpu.index_copy_(0, indices, source)
            if self.enable_prompt_embeds:
                self.is_token_ids.gpu[:num_common_tokens] = True
            return
        # Upload the index tensors asynchronously so the scatter can be non-blocking.
        sampled_tokens_index_tensor = torch.tensor(
            sample_flattened_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        prev_common_req_indices_tensor = torch.tensor(
            prev_common_req_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        self.input_ids.gpu.scatter_(
            dim=0,
            index=sampled_tokens_index_tensor,
            src=self.input_batch.prev_sampled_token_ids[prev_common_req_indices_tensor, 0],
        )
        # Scatter the draft tokens after the sampled tokens are scattered.
        if self._draft_token_ids is None or not spec_flattened_indices:
            return
        assert isinstance(self._draft_token_ids, torch.Tensor)
        draft_tokens_index_tensor = torch.tensor(
            spec_flattened_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        prev_draft_token_indices_tensor = torch.tensor(
            prev_draft_token_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        draft_token_ids = self._draft_token_ids.to(dtype=torch.int32)
        self.input_ids.gpu.scatter_(
            dim=0,
            index=draft_tokens_index_tensor,
            src=draft_token_ids.flatten()[prev_draft_token_indices_tensor],
        )

    def may_reinitialize_input_batch(
        self,
        kv_cache_config: KVCacheConfig,
        kernel_block_sizes: list[int] | None = None,
    ) -> None:
        """
        Re-initialize the input batch if the block sizes are different from
        `[self.cache_config.block_size]`. This usually happens when there
        are multiple KV cache groups.

        Args:
            kv_cache_config: The KV cache configuration.
        """
        # Generate kernel_block_sizes that matches each block_size
        # For attention backends that support virtual block splitting,
        # use the supported block sizes from the backend
        # For other backends (like Mamba), use [0] (no splitting)
        block_sizes = []
        self.kernel_block_sizes = []
        kv_cache_specs = []
        for kv_cache_group_id, kv_cache_group in enumerate(kv_cache_config.kv_cache_groups):
            kv_cache_spec = kv_cache_group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                kv_cache_spec = next(iter(kv_cache_spec.kv_cache_specs.values()))
            if isinstance(kv_cache_spec, EncoderOnlyAttentionSpec):
                continue
            kv_cache_specs.append(kv_cache_spec)
            block_sizes.append(kv_cache_spec.block_size)
            if isinstance(kv_cache_spec, AttentionSpec):
                try:
                    attn_groups = self.attn_groups[kv_cache_group_id]
                    backend = attn_groups[0].backend
                    # Page attention operation on 310P limits block_size * head_size <= 128 * 128
                    supported_sizes = [
                        _concrete_size(support_size)
                        for support_size in backend.get_supported_kernel_block_sizes()
                        if _concrete_size(support_size) * _concrete_size(kv_cache_spec.head_size)
                        <= _ATTENTION_BLOCK_SIZE_LIMIT
                    ]
                    kernel_block_size_list = supported_sizes if supported_sizes else [self.cache_config.block_size]
                except IndexError:
                    kernel_block_size_list = [self.cache_config.block_size]
                self.kernel_block_sizes.append(kernel_block_size_list)
            else:
                self.kernel_block_sizes.append([0])

        max_num_blocks = []
        max_model_len = max(self.max_model_len, self.max_encoder_len)
        dcp_world_size = get_decode_context_model_parallel_world_size()
        for kv_cache_spec in kv_cache_specs:
            max_num_blocks_per_req = cdiv(max_model_len, kv_cache_spec.block_size * dcp_world_size)
            if isinstance(kv_cache_spec, MambaSpec):
                mamba_blocks_per_req = (
                    max_num_blocks_per_req if self.cache_config.enable_prefix_caching else 1
                ) + kv_cache_spec.num_speculative_blocks
                max_num_blocks_per_req = max(max_num_blocks_per_req, mamba_blocks_per_req)
            max_num_blocks.append(max_num_blocks_per_req)

        if (
            block_sizes != [self.cache_config.block_size]
            or self.kernel_block_sizes != [[self.cache_config.block_size]]
            or len(kv_cache_config.kv_cache_groups) > 1
        ):
            assert self.offload_config.uva.cpu_offload_gb == 0, (
                "Cannot re-initialize the input batch when CPU weight "
                "offloading is enabled. See https://github.com/vllm-project/vllm/pull/18298 "  # noqa: E501
                "for more details."
            )
            self.input_batch = NPUInputBatch(
                max_num_reqs=self.max_num_reqs,
                max_model_len=max_model_len,
                max_num_batched_tokens=self.max_num_tokens,
                device=self.device,
                pin_memory=self.pin_memory,
                vocab_size=self.model_config.get_vocab_size(),
                block_sizes=block_sizes,
                is_spec_decode=bool(self.vllm_config.speculative_config),
                logitsprocs=self.input_batch.logitsprocs,
                is_pooling_model=self.is_pooling_model,
                num_speculative_tokens=(
                    self.vllm_config.speculative_config.num_speculative_tokens
                    if self.vllm_config.speculative_config
                    else 0
                ),
                kernel_block_sizes=self.kernel_block_sizes,
                max_num_blocks_per_req=max_num_blocks,
                kv_cache_groups=kv_cache_config.kv_cache_groups,
                cp_kv_cache_interleave_size=self.parallel_config.cp_kv_cache_interleave_size,
            )
