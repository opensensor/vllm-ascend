#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import Any

import torch
import torch.nn.functional as F
import torch_npu
from vllm.config import get_current_vllm_config
from vllm.model_executor.layers.linear import RowParallelLinear
from vllm.utils.math_utils import cdiv

from vllm_ascend.ascend_config import get_ascend_config
from vllm_ascend.ascend_forward_context import _EXTRA_CTX, use_cann_megamoe
from vllm_ascend.ops.fused_moe.dataclass.fused_experts import MoEWeights, build_fused_experts_input
from vllm_ascend.ops.fused_moe.dataclass.moe_mlp import MoEMlpComputeInput
from vllm_ascend.ops.fused_moe.moe_utils import cumsum_group_list, maybe_normalize_mxfp_scale_layout
from vllm_ascend.ops.fused_moe.routed_experts import AscendRoutedExperts  # noqa: F401
from vllm_ascend.utils import ACL_FORMAT_FRACTAL_NZ, COMPRESSED_TENSORS_METHOD, dispose_tensor

from ..base import (
    AscendLinearScheme,
    AscendMoEScheme,
    QuantType,
    WeightSwitchGatherSpec,
)
from ..registry import register_scheme


# Select checkpoint parameter names for packed compressed-tensors weights.
def _use_compressed_tensors_mxfp4_weight_names() -> bool:
    quant_config = get_current_vllm_config().quant_config
    if quant_config is None:
        return False

    get_name = getattr(quant_config, "get_name", None)
    return callable(get_name) and get_name() == COMPRESSED_TENSORS_METHOD


def _rename_packed_weight_parameter(layer: torch.nn.Module, weight_name: str) -> None:
    packed_weight_name = f"{weight_name}_packed"
    if not hasattr(layer, packed_weight_name):
        return

    setattr(
        layer,
        weight_name,
        torch.nn.Parameter(
            getattr(layer, packed_weight_name).data,
            requires_grad=False,
        ),
    )
    delattr(layer, packed_weight_name)


@register_scheme("W4A4_MXFP4", "linear")
class AscendW4A4MXFP4DynamicLinearMethod(AscendLinearScheme):
    """Linear method for Ascend W4A4_MXFP4 (Microscaling FP4) quantization.

    This scheme uses microscaling FP4 quantization with per-group scales.
    The activation is dynamically quantized to FP4 with microscaling, and
    weights are stored in packed FP4-compatible format with per-group scales.
    """

    model_dtype = None
    weight_switch_gather_specs = (
        WeightSwitchGatherSpec("weight"),
        WeightSwitchGatherSpec("weight_scale"),
    )
    weight_switch_output_gather_specs = (
        WeightSwitchGatherSpec("weight", gather_dim=1),
        WeightSwitchGatherSpec("weight_scale", gather_dim=1),
    )
    supports_weight_switch = True
    # Row-parallel shards may start halfway through a global MX group.
    supports_unaligned_tp_groups = True

    def __init__(self):
        vllm_config = get_current_vllm_config()
        self.group_size = vllm_config.quant_config.quant_description.get("group_size", 32)

    def get_weight(self, input_size: int, output_size: int, params_dtype: torch.dtype) -> dict[str, Any]:
        weight_name = "weight_packed" if _use_compressed_tensors_mxfp4_weight_names() else "weight"
        params_dict = {weight_name: torch.empty(output_size, input_size // 2, dtype=torch.uint8)}
        return params_dict

    def get_pergroup_param(
        self, input_size: int, output_size: int, params_dtype: torch.dtype, layer_type: str | None = None
    ) -> dict[str, Any]:
        params_dict = {}
        params_dict["weight_scale"] = torch.empty(output_size, cdiv(input_size, self.group_size), dtype=torch.uint8)
        return params_dict

    def apply(
        self,
        layer: torch.nn.Module,
        x: torch.Tensor,
        bias: torch.Tensor | None = None,
        tp_rank: int | None = 0,
    ) -> torch.Tensor:
        # reshape x for Qwen VL models
        original_shape = x.shape
        if x.dim() > 2:
            x = x.view(-1, x.shape[-1])
        # Read only an explicitly installed value. MagicMock-based CPU tests
        # synthesize missing attributes and cannot be unpacked as a pair.
        prefix_padding, suffix_padding = vars(layer).get("mxfp4_tp_padding", (0, 0))
        if prefix_padding or suffix_padding:
            # Apply the same padding as the weight so activation and weight MX
            # groups cover identical K ranges. The padded zeros contribute
            # nothing to GEMM, while keeping both operands' K dimensions equal.
            x = F.pad(x, (prefix_padding, suffix_padding), mode="constant", value=0)
        quantized_x, dynamic_scale = torch_npu.npu_dynamic_mx_quant(
            x, dst_type=torch_npu.float4_e2m1fn_x2, round_mode="round"
        )
        pertoken_scale = dynamic_scale
        output_dtype = x.dtype
        if bias is not None and bias.dtype != torch.float32:
            bias = bias.to(torch.float32)

        output = torch_npu.npu_quant_matmul(
            quantized_x,
            layer.weight,
            layer.weight_scale,
            scale_dtype=torch_npu.float8_e8m0fnu,
            pertoken_scale=pertoken_scale,
            pertoken_scale_dtype=torch_npu.float8_e8m0fnu,
            bias=bias,
            output_dtype=output_dtype,
            x1_dtype=torch_npu.float4_e2m1fn_x2,
            x2_dtype=torch_npu.float4_e2m1fn_x2,
            group_sizes=[1, 1, self.group_size],
        )
        # reshape output for Qwen VL models
        if len(original_shape) > 2:
            output = output.view(*original_shape[:-1], -1)

        return output

    def process_weights_after_loading(self, layer):
        """Process weights after loading for MXFP4 inference.

        This method transforms weights for NPU MXFP4 computation:
        - weight: (output_size, input_size) -> (input_size, output_size)
        - weight_scale: (n_dim, k_dim) -> (k_dim//2, n_dim, 2)
        """

        _rename_packed_weight_parameter(layer, "weight")

        # Row parallelism may split K in the middle of a globally quantized MX
        # group. Prefix padding restores that group's original phase; suffix
        # padding completes the final group. apply() pads activations at the
        # same positions, so these zero-valued entries do not change the GEMM.
        prefix_padding = suffix_padding = 0
        if isinstance(layer, RowParallelLinear):
            global_start = layer.tp_rank * layer.input_size_per_partition
            prefix_padding = global_start % self.group_size
            suffix_padding = -(prefix_padding + layer.input_size_per_partition) % self.group_size
            # Packed FP4 stores two logical K values per byte, so logical
            # padding is halved when applied to the packed weight tensor.
            if prefix_padding % 2 != 0 or suffix_padding % 2 != 0:
                raise ValueError("MXFP4 packed weight padding must be divisible by 2")
            if prefix_padding or suffix_padding:
                layer.weight.data = F.pad(
                    layer.weight.data,
                    (prefix_padding // 2, suffix_padding // 2),
                    mode="constant",
                    value=0,
                )
        layer.mxfp4_tp_padding = (prefix_padding, suffix_padding)

        n_dim, k_dim = layer.weight_scale.data.shape
        # Shape should be padded if it cannot be divided by 2
        if k_dim % 2 != 0:
            layer.weight_scale.data = F.pad(layer.weight_scale.data, (0, 1), mode="constant", value=0)
            layer.weight_scale.data = layer.weight_scale.data.reshape(n_dim, k_dim // 2 + 1, 2)
        else:
            layer.weight_scale.data = layer.weight_scale.data.reshape(n_dim, k_dim // 2, 2)
        # Keep packed MXFP4 weights in ND, even when weight_nz_mode is enabled.
        layer.weight.data = layer.weight.data.transpose(0, 1)
        layer.weight_scale.data = layer.weight_scale.data.transpose(0, 1)


@register_scheme("W4A4_MXFP4", "moe")
class AscendW4A4MXFP4DynamicFusedMoEMethod(AscendMoEScheme):
    """FusedMoe method for Ascend W4A4_MXFP4."""

    model_dtype = None
    quant_type: QuantType = QuantType.W4A4MXFP
    act_quant_type: torch.dtype = torch_npu.float4_e2m1fn_x2
    fused_activations = frozenset({"silu"})
    supports_eplb = True

    def __init__(self):
        vllm_config = get_current_vllm_config()
        self.group_size = vllm_config.quant_config.quant_description.get("group_size", 32)
        ascend_config = get_ascend_config()
        self.dynamic_eplb = False if vllm_config.use_v2_model_runner else ascend_config.eplb_config.dynamic_eplb

    @staticmethod
    def get_weight(
        num_experts: int, intermediate_size_per_partition: int, hidden_sizes: int, params_dtype: torch.dtype
    ) -> dict[str, Any]:
        param_dict = {}
        suffix = "_packed" if _use_compressed_tensors_mxfp4_weight_names() else ""
        param_dict[f"w13_weight{suffix}"] = torch.empty(
            num_experts, 2 * intermediate_size_per_partition, hidden_sizes // 2, dtype=torch.uint8
        )
        param_dict[f"w2_weight{suffix}"] = torch.empty(
            num_experts, hidden_sizes, intermediate_size_per_partition // 2, dtype=torch.uint8
        )
        return param_dict

    def get_dynamic_quant_param(
        self, num_experts: int, intermediate_size_per_partition: int, hidden_sizes: int, params_dtype: torch.dtype
    ) -> dict[str, Any]:
        param_dict = {}
        param_dict["w13_weight_scale"] = torch.empty(
            num_experts, 2 * intermediate_size_per_partition, hidden_sizes // self.group_size, dtype=torch.uint8
        )

        param_dict["w2_weight_scale"] = torch.empty(
            num_experts, hidden_sizes, intermediate_size_per_partition // self.group_size, dtype=torch.uint8
        )
        return param_dict

    def apply(
        self,
        layer: "AscendRoutedExperts",
        x: torch.Tensor,
        topk_weights: torch.Tensor,
        topk_ids: torch.Tensor,
        shared_experts: Any | None,
        shared_experts_input: torch.Tensor | None,
    ) -> torch.Tensor:
        moe_comm_method = _EXTRA_CTX.moe_comm_method
        return moe_comm_method.fused_experts(
            fused_experts_input=build_fused_experts_input(
                hidden_states=x,
                topk_weights=topk_weights,
                topk_ids=topk_ids,
                layer=layer,
                quant_type=self.quant_type,
                dynamic_eplb=self.dynamic_eplb,
                expert_map=layer.ascend_expert_map,
                global_redundant_expert_num=layer.global_redundant_expert_num,
                mc2_mask=layer.ascend_mc2_mask,
                apply_router_weight_on_input=layer.apply_router_weight_on_input,
                pertoken_scale=layer.ascend_pertoken_scale,
                activation=layer.activation,
                mxfp_act_quant_type=torch_npu.float4_e2m1fn_x2,
                mxfp_weight_quant_type=torch_npu.float4_e2m1fn_x2,
                mxfp_scale_dtype=torch_npu.float8_e8m0fnu,
                mxfp_per_token_scale_dtype=torch_npu.float8_e8m0fnu,
                mxfp_use_bf16=(x.dtype in [torch.bfloat16, torch.uint8]),
            ),
            quant_method=self,
        )

    def get_fused_mc2_weights(self, layer: torch.nn.Module) -> MoEWeights:
        if _EXTRA_CTX.use_mega_moe:
            # MegaMoe consumes the non-transposed per-expert weight/scale lists
            # built in process_weights_after_loading (the non-mega path uses the
            # transposed single tensors below).
            return MoEWeights(
                w1=layer.cann_mega_moe_w13_weight_list,
                w2=layer.cann_mega_moe_w2_weight_list,
                w1_scale=layer.cann_mega_moe_w13_weight_scale_list,
                w2_scale=layer.cann_mega_moe_w2_weight_scale_list,
                w1_scale_bias=None,
                w2_scale_bias=None,
            )
        else:
            return MoEWeights(
                w1=layer.w13_weight,
                w2=layer.w2_weight,
                w1_scale=layer.w13_weight_scale,
                w2_scale=layer.w2_weight_scale,
                w1_scale_bias=None,
                w2_scale_bias=None,
            )

    @staticmethod
    def get_eplb_weight_views(layer: torch.nn.Module) -> list[torch.Tensor]:
        return [
            layer.w13_weight.transpose(1, 2),
            layer.w2_weight.transpose(1, 2),
            layer.w13_weight_scale.transpose(1, 2),
            layer.w2_weight_scale.transpose(1, 2),
        ]

    def process_weights_after_loading(self, layer):
        _rename_packed_weight_parameter(layer, "w13_weight")
        _rename_packed_weight_parameter(layer, "w2_weight")

        g_num, n_size, k_size = layer.w13_weight_scale.shape
        # The NPU scale layout packs two adjacent MX scales together. Append
        # one neutral entry when a valid local shard contains an odd count.
        if k_size % 2 != 0:
            layer.w13_weight_scale.data = F.pad(layer.w13_weight_scale.data, (0, 1), mode="constant", value=0)
            k_size += 1
        layer.w13_weight_scale.data = layer.w13_weight_scale.data.reshape(g_num, n_size, k_size // 2, 2)
        g_num, n_size, k_size = layer.w2_weight_scale.shape
        # Apply the same pair-alignment rule independently to the down weight.
        if k_size % 2 != 0:
            layer.w2_weight_scale.data = F.pad(layer.w2_weight_scale.data, (0, 1), mode="constant", value=0)
            k_size += 1
        layer.w2_weight_scale.data = layer.w2_weight_scale.data.reshape(g_num, n_size, k_size // 2, 2)
        # MegaMoe (FUSED_MC2 on A5) expects the weights in their original
        # (out, in) layout — weight1=(E, 2*inter, hidden//2), weight2=(E,
        # hidden, inter//2) for packed FP4 — and the reshaped (not transposed)
        # E8M0 scales. Capture per-expert lists before the non-mega path
        # transposes everything below.
        if use_cann_megamoe(get_current_vllm_config()):
            # MegaMoe (FUSED_MC2) on A5 uses the packed FP4 weight format directly
            layer.cann_mega_moe_w13_weight_list = [
                torch_npu.npu_format_cast(weight.clone(), ACL_FORMAT_FRACTAL_NZ) for weight in layer.w13_weight.data
            ]

            layer.cann_mega_moe_w2_weight_list = [
                torch_npu.npu_format_cast(
                    weight.clone(),
                    ACL_FORMAT_FRACTAL_NZ,
                    customize_dtype=torch.float8_e4m3fn,
                    input_dtype=torch_npu.float4_e2m1fn_x2,
                )
                for weight in layer.w2_weight.data
            ]
            layer.cann_mega_moe_w13_weight_scale_list = [
                w13_weight_scale.clone() for w13_weight_scale in layer.w13_weight_scale.data.unbind(dim=0)
            ]
            layer.cann_mega_moe_w2_weight_scale_list = [
                w2_weight_scale.clone() for w2_weight_scale in layer.w2_weight_scale.data.unbind(dim=0)
            ]
            tensor_names = (
                "w13_weight",
                "w2_weight",
                "w13_weight_scale",
                "w2_weight_scale",
            )
            for tensor_name in tensor_names:
                dispose_tensor(getattr(layer, tensor_name))

        else:
            # The A5 MXFP4 fused grouped-matmul-swiglu op relies on the
            # transpose stride to interpret packed FP4 weights as logical K.
            layer.w13_weight.data = layer.w13_weight.data.transpose(1, 2)
            layer.w2_weight.data = layer.w2_weight.data.transpose(1, 2)
            layer.w13_weight_scale.data = layer.w13_weight_scale.data.transpose(1, 2)
            layer.w2_weight_scale.data = layer.w2_weight_scale.data.transpose(1, 2)

    def apply_gmm1_act_quant(self, mlp_compute_input: MoEMlpComputeInput):
        input_hidden_states = mlp_compute_input.hidden_states
        requantized_input = mlp_compute_input.dynamic_scale is None
        hidden_states, pertoken_scale = self._quant_hidden_states(input_hidden_states, mlp_compute_input.dynamic_scale)
        # Dynamic MXFP quantization produces a new FP4 activation tensor. The
        # original BF16 input is no longer consumed by GMM1, so release it
        # before launching GMM1 to avoid inflating the profile-run peak.
        if requantized_input:
            dispose_tensor(input_hidden_states)
        layer = mlp_compute_input.layer
        assert layer is not None
        out, out_scale = torch_npu.npu_grouped_matmul_swiglu_quant_v2(
            x=hidden_states,
            weight=[layer.w13_weight],
            group_list=cumsum_group_list(mlp_compute_input.group_list, mlp_compute_input.group_list_type, 0),
            weight_scale=[layer.w13_weight_scale],
            x_scale=pertoken_scale,
            dequant_mode=2,
            quant_mode=2,
            dequant_dtype=torch.float32,
            quant_dtype=torch_npu.float4_e2m1fn_x2,
            x_dtype=torch_npu.float4_e2m1fn_x2,
            weight_dtype=torch_npu.float4_e2m1fn_x2,
            weight_scale_dtype=torch_npu.float8_e8m0fnu,
            x_scale_dtype=torch_npu.float8_e8m0fnu,
        )
        # With a dispatcher-provided scale, GMM1 consumes the input directly.
        if not requantized_input:
            dispose_tensor(input_hidden_states)
        return out, maybe_normalize_mxfp_scale_layout(out_scale)

    def apply_gmm1(self, mlp_compute_input: MoEMlpComputeInput):
        input_hidden_states = mlp_compute_input.hidden_states
        requantized_input = mlp_compute_input.dynamic_scale is None
        hidden_states, pertoken_scale = self._quant_hidden_states(input_hidden_states, mlp_compute_input.dynamic_scale)
        # Keep the same input lifetime as the pre-refactor quant_apply_mlp:
        # once local dynamic quantization has produced a separate FP4 tensor,
        # the BF16 source must not overlap with the GMM1 allocation.
        if requantized_input:
            dispose_tensor(input_hidden_states)
        layer = mlp_compute_input.layer
        assert layer is not None
        # Packed FP4 tensors use uint8 storage. Pass their logical dtype so the
        # operator does not dispatch them as an unsupported uint8/uint8 pair.
        hidden_states = torch_npu.npu_grouped_matmul(
            x=[hidden_states],
            weight=[layer.w13_weight],
            scale=[layer.w13_weight_scale],
            per_token_scale=[pertoken_scale],
            split_item=2,
            group_type=0,
            group_list=mlp_compute_input.group_list,
            group_list_type=mlp_compute_input.group_list_type,
            output_dtype=torch.bfloat16,
            scale_dtype=torch_npu.float8_e8m0fnu,
            per_token_scale_dtype=torch_npu.float8_e8m0fnu,
            x_dtype=torch_npu.float4_e2m1fn_x2,
            weight_dtype=torch_npu.float4_e2m1fn_x2,
        )[0]
        if not requantized_input:
            dispose_tensor(input_hidden_states)
        return hidden_states

    def apply_act_quant(self, mlp_compute_input: MoEMlpComputeInput, hidden_states: torch.Tensor):
        hidden_states, dynamic_scale = torch_npu.npu_dynamic_mx_quant(
            hidden_states, dst_type=torch_npu.float4_e2m1fn_x2
        )
        return hidden_states, maybe_normalize_mxfp_scale_layout(dynamic_scale)

    def apply_gmm2(self, mlp_compute_input: MoEMlpComputeInput, hidden_states, act_out_scale):
        layer = mlp_compute_input.layer
        assert layer is not None
        input_dtype = mlp_compute_input.hidden_states.dtype
        use_bf16 = input_dtype in [torch.bfloat16, torch.uint8, torch.float4_e2m1fn_x2]
        output_dtype = (
            input_dtype
            if input_dtype in [torch.bfloat16, torch.float16]
            else (torch.bfloat16 if use_bf16 else torch.float16)
        )
        return torch_npu.npu_grouped_matmul(
            x=[hidden_states],
            weight=[layer.w2_weight],
            scale=[layer.w2_weight_scale],
            bias=None,
            per_token_scale=[act_out_scale],
            split_item=2,
            group_list_type=mlp_compute_input.group_list_type,
            group_type=0,
            group_list=mlp_compute_input.group_list,
            output_dtype=output_dtype,
            scale_dtype=torch_npu.float8_e8m0fnu,
            per_token_scale_dtype=torch_npu.float8_e8m0fnu,
            x_dtype=torch_npu.float4_e2m1fn_x2,
            weight_dtype=torch_npu.float4_e2m1fn_x2,
        )[0]
