import json,psutil,subprocess,sys
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
receipt=json.loads((root/'next-three-server-process-20261008.json').read_text())
p=psutil.Process(receipt['pid']);assert abs(p.create_time()-receipt['created'])<1
env=p.environ()
controllers=[]
for process in psutil.process_iter(['pid','cmdline']):
 args=process.info['cmdline'] or []
 if len(args)==2 and args[1]==str(root/'glm-next-three-live-bench.py'):controllers.append(process)
for process in controllers:process.terminate()
owned=[p,*p.children(recursive=True)]
(root/'next-three-recapture-oom-recovery.json').write_text(json.dumps(dict(receipt=receipt,controllers=[p.pid for p in controllers],pids=[p.pid for p in owned],reason='Paused recapture allocated new prefill scratch while inactive projection scratch remained live; add guarded cleanup after graph retirement'),indent=2)+'\n')
for process in owned:
 try:process.terminate()
 except psutil.NoSuchProcess:pass
_,pending=psutil.wait_procs(owned,timeout=30)
for process in pending:
 try:process.kill()
 except psutil.NoSuchProcess:pass
psutil.wait_procs(pending,timeout=5)
launch=(root/'night-speed-20261008/next-three-launch.py').read_text().replace('next-three-server-20261008','next-three-recapture-server-20261008').replace('next-three-server-process-20261008','next-three-recapture-server-process-20261008')
(root/'night-speed-20261008/next-three-recapture-launch.py').write_text(launch)
exec(compile(launch,'<recapture-recovery>','exec'),{'__name__':'__main__'})
steps=['glm-expert-cube-admit-base-only','glm-offset-v984-serving-admit','glm-offset-v985-serving-admit']+[f'glm-next-v{v}-serving-admit' for v in (992,993,994,995)]+['glm-qsa-v991-admit','glm-qsa-v996-admit']
for name in steps:
 with (root/(name+'-recapture-recovery.log')).open('x') as log:
  subprocess.run([sys.executable,str(root/(name+'.py'))],env=env,cwd=receipt['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
 print('RECOVERY ADMITTED',name,flush=True)
with (root/'next-three-paired-serving-v3.log').open('x') as log:
 subprocess.run([sys.executable,str(root/'glm-next-three-live-bench-v3.py')],env=env,cwd=receipt['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
print('Recovered server completed all seven source/graph switches',flush=True)
