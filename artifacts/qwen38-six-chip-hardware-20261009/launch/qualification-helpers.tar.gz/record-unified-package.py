import hashlib,json
from pathlib import Path
r=Path("/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009")
e=Path("/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009")
paths=[r/"bindings-stride/vllm_ascend_C.cpython-312-x86_64-linux-gnu.so"]
paths.extend(f for f in (r/"gdn-unified-v5-opp/vendors/qwen_gdn_unified_v5_transformer").rglob("*") if f.is_file())
paths.extend(f for f in (r/"csrc/moe").rglob("*.hpp") if any(n in str(f) for n in ["chunk_fwd_o_vllm", "chunk_gated_delta_rule_fwd_h"]))
paths.extend([r/"vllm_ascend/models/qwen4_exp/head_partition.py", r/"vllm_ascend/models/qwen4_exp/model.py"])
receipt={"source_commit":"f25e70c0943681c76ca253a973bb031256405ea1", "source_changes":"GDN odd-head scheduling, aligned causal mask writes, single owner initial-state copies", "binding_requires_stride_aware_conv_op":True, "files_sha256":{str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(paths)}}
(e/"unified-v5-package-receipt.json").write_text(json.dumps(receipt,indent=2))
print("Hashed",len(paths),"package and source files")
