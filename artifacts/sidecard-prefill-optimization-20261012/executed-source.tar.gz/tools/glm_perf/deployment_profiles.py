# SPDX-License-Identifier: Apache-2.0
"""Explicit two/three dual-chip-card recipes; no device discovery or launches."""

import argparse
import json
from dataclasses import asdict, dataclass

W4_LAYERS = tuple(range(3, 8)) + (11, 15) + tuple(range(18, 33))
SELECTIVE_W3_LAYERS = (8, 9, 10, 12, 13, 14, 16, 17)
PREFILL_TOKENS = 640
QUALIFICATION_CONTEXT = 8192


@dataclass(frozen=True)
class GlmDeploymentProfile:
    name: str
    cards: int
    tensor_parallel_size: int
    pipeline_parallel_size: int
    default_expert_bits: int
    w3_layers: tuple[int, ...]
    mtp_tokens: int
    native_expert_partitions: int | None = None

    @property
    def chips(self):
        return self.cards * 2

    @property
    def expert_partition_size(self):
        if self.native_expert_partitions is not None:
            return self.native_expert_partitions
        # Experts use the stage's TP group; total workers is NOT this field.
        return self.tensor_parallel_size

    def launch_args(
        self,
        model_path,
        *,
        max_model_len=QUALIFICATION_CONTEXT,
        port=8001,
        decode_graph_sizes=None,
        enforce_eager=False,
    ):
        if type(max_model_len) is not int or max_model_len < 1:
            raise ValueError("context limit must be a positive integer")
        if type(enforce_eager) is not bool or (enforce_eager and decode_graph_sizes is not None):
            raise ValueError("eager mode must be boolean and cannot specify decode graphs")
        if decode_graph_sizes is not None:
            sizes = tuple(decode_graph_sizes)
            max_decode_rows = 4 * (self.mtp_tokens + 1)
            if (
                not sizes
                or any(type(size) is not int or not 1 <= size <= max_decode_rows for size in sizes)
                or tuple(sorted(set(sizes))) != sizes
            ):
                raise ValueError("decode graph sizes must be distinct ascending supported row counts")
            decode_graph_sizes = sizes
        args = [
            "vllm",
            "serve",
            str(model_path),
            "--served-model-name",
            self.name,
            "--load-format",
            "glm_native_int4",
            "--dtype",
            "float16",
            "--tensor-parallel-size",
            str(self.tensor_parallel_size),
            "--pipeline-parallel-size",
            str(self.pipeline_parallel_size),
            "--max-model-len",
            str(max_model_len),
            "--max-num-batched-tokens",
            str(PREFILL_TOKENS),
            "--max-num-seqs",
            "4",
            "--enable-chunked-prefill",
            "--enable-prefix-caching",
            "--enable-prompt-tokens-details",
            "--no-async-scheduling",
            "--mamba-cache-mode",
            "align",
            "--disable-custom-all-reduce",
            "--reasoning-parser",
            "glm47",
            "--enable-auto-tool-choice",
            "--tool-call-parser",
            "poolside_v1",
            "--port",
            str(port),
        ]
        overrides = dict(
            ascend_glm_nz_packed_codes=True,
            ascend_glm_mhc_batched_round=True,
            ascend_glm_mhc_fp16_state=True,
            ascend_glm_mhc_ai_core_round=True,
            ascend_glm_kda_nz_grouped=True,
            ascend_glm_prefill_route_histogram=True,
            ascend_glm_native_mhc_post=True,
            ascend_glm_live_kpool_score=True,
            ascend_glm_decode_swiglu=True,
            ascend_glm_decode_combine=True,
            ascend_glm_kpool_state_block_size=32,
        )
        if self.mtp_tokens:
            overrides["ascend_glm_mtp_full_graph"] = True
            args += [
                "--speculative-config",
                json.dumps(
                    {
                        "method": "mtp",
                        "num_speculative_tokens": self.mtp_tokens,
                        "draft_load_config": {"load_format": "glm_native_int4"},
                    }
                ),
            ]
        if decode_graph_sizes is None and not enforce_eager:
            # Both real-weight profiles passed stage-local replay qualification.
            decode_graph_sizes = (2, 8) if self.mtp_tokens else (1, 4)
        if decode_graph_sizes is not None:
            args += [
                "--compilation-config",
                json.dumps({"cudagraph_mode": "FULL_DECODE_ONLY", "cudagraph_capture_sizes": decode_graph_sizes}),
            ]
        else:
            # Explicit eager mode remains available for qualification isolation.
            args += ["--enforce-eager"]
        args += ["--hf-overrides", json.dumps(overrides)]
        return args

    def conversion_args(self, source, output):
        return [
            "python",
            "-m",
            "tools.glm_w2.convert_full",
            "--source-dir",
            str(source),
            "--out-dir",
            str(output),
            "--expert-bits",
            str(self.default_expert_bits),
            "--w4-layers",
            ",".join(map(str, W4_LAYERS)),
            "--w3-layers",
            ",".join(map(str, self.w3_layers)),
        ]


def profile(cards):
    if type(cards) is not int:
        raise ValueError("GLM profile requires 2 or 3 dual-chip cards")
    if cards == 2:
        return GlmDeploymentProfile("two-card-selective-w2", 2, 4, 1, 2, SELECTIVE_W3_LAYERS, 1)
    if cards == 3:
        return GlmDeploymentProfile("three-card-w3", 3, 2, 3, 3, (), 0)
    raise ValueError("GLM profile requires 2 or 3 dual-chip cards")


def validate_profile(name, *, tensor_parallel_size, pipeline_parallel_size, mtp_tokens, layer_bits=None):
    candidates = (profile(2), profile(3), one_card_sidecard_profile())
    selected = next((candidate for candidate in candidates if candidate.name == name), None)
    if selected is None:
        raise ValueError("unknown GLM deployment profile")
    if (tensor_parallel_size, pipeline_parallel_size, mtp_tokens) != (
        selected.tensor_parallel_size,
        selected.pipeline_parallel_size,
        selected.mtp_tokens,
    ):
        raise ValueError("runtime topology or MTP differs from checkpoint deployment profile")
    if layer_bits is not None:
        for layer, bits in layer_bits.items():
            expected = (
                3
                if int(layer) in selected.w3_layers
                else 4
                if int(layer) in W4_LAYERS
                else selected.default_expert_bits
            )
            if bits != expected:
                raise ValueError("checkpoint precision differs from deployment profile")
    return selected


def one_card_sidecard_profile():
    # Four native 72-expert partitions are split between two NPU banks and
    # two CUDA banks. The explicit sidecard loader hook owns that placement.
    return GlmDeploymentProfile("one-card-sidecard-w2", 1, 2, 1, 2, SELECTIVE_W3_LAYERS, 0, 4)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cards", type=int, choices=(2, 3), required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--source", help="Higher-precision FP8 source, never a W2 checkpoint")
    parser.add_argument(
        "--max-model-len",
        type=int,
        default=QUALIFICATION_CONTEXT,
        help="Start short for qualification; raise only after memory admission",
    )
    parser.add_argument("--enforce-eager", action="store_true", help="Explicit graph qualification fallback")
    args = parser.parse_args()
    selected = profile(args.cards)
    result = dict(
        asdict(selected),
        expert_partition_size=selected.expert_partition_size,
        launch_args=selected.launch_args(
            args.model, max_model_len=args.max_model_len, enforce_eager=args.enforce_eager
        ),
        hardware_validation="pending",
    )
    if args.source:
        result["conversion_args"] = selected.conversion_args(args.source, args.model + "-canonical")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
