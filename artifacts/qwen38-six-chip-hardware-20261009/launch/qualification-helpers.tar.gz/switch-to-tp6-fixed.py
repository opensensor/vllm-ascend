import json,os,signal,subprocess,time,urllib.request
from pathlib import Path
root=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
old_pid=906495
cmd=Path(f'/proc/{old_pid}/cmdline').read_bytes().split(b'\0')
assert b'/srv/ai/models/Qwen3.8-Flash-Next-W4A16-G128-300i' in cmd
assert cmd[cmd.index(b'--port')+1]==b'8001'
metrics=urllib.request.urlopen('http://127.0.0.1:8001/metrics',timeout=10).read().decode()
for line in metrics.splitlines():
 if line.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{')): assert float(line.rsplit(' ',1)[1])==0,line
root.joinpath('tp4-restored-final-metrics.txt').write_text(metrics)
os.kill(old_pid,signal.SIGTERM)
for _ in range(90):
 alive=[p for p in [old_pid,910290,911307,911308,911309,911310] if Path(f'/proc/{p}').exists() and Path(f'/proc/{p}/stat').read_text().rpartition(')')[2].split()[0]!='Z']
 if not alive:break
 time.sleep(1)
else:raise RuntimeError(f'Baseline workers did not exit: {alive}')
info=subprocess.check_output(['npu-smi','info'],text=True,timeout=10)
root.joinpath('before-tp6-fixed-npu-smi.txt').write_text(info)
assert 'VLLMWorker' not in info and 'VLLM::Worker' not in info
settings={**os.environ,'LOG':str(root/'tp6-fixed-server.log'),'WATCHDOG_LOG':str(root/'tp6-fixed-watchdog.log'),'AFFINITY_LOG':str(root/'tp6-fixed-affinity.log')}
with root.joinpath('tp6-fixed-launch.log').open('x') as log:
 process=subprocess.Popen(['bash',str(root/'start-tp6-fixed.sh')],env=settings,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
root.joinpath('tp6-fixed-api.pid').write_text(str(process.pid))
print(json.dumps({'previous_api_pid':old_pid,'candidate_api_pid':process.pid}),flush=True)
