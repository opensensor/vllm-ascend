import hashlib,json,re,sys,time,urllib.request,uuid
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
from tools.glm_perf.resident_control import Control
client=ResidentClient('http://127.0.0.1:8001',timeout=900)
# Retain the already-tested complete streaming request/accounting protocol.
protocol=(root/'glm-next-qsa-996-paired-serving.py').read_text()
helpers=protocol[protocol.index('def idle():'):protocol.index('for version in (991,996):')]
exec(compile(helpers,'<complete-stream-accounting>','exec'))
base=(root/'night-speed-20261008/offset-v984-v985-candidate.py').read_text()
binding=(root/'qsa-shared-binding-vector-frozen.py').read_text()
release_source=(root/'source-next-three-20261008/tools/glm_perf/transient_projection.py').read_text()
records=[];switches=[]
report=root/'night-speed-20261008/next-three-paired-serving-v6.json';assert not report.exists()
def save(complete=False):report.write_text(json.dumps(dict(complete=complete,kda_package='prefill-kda-score-matrix-full-v1',scope='all candidates use the qualified KDA matrix package; synthetic cold token-ID prompts with cleared prefix state and full-request C1 generation',records=records,switches=switches),indent=2)+'\n')
def make_source(decode,prefill,qsa):
 source=base.replace('reconstruction_v984',f'reconstruction_v{decode}').replace('reconstruction_v985',f'reconstruction_v{prefill}')
 source=source.replace("'decode_version':984",f"'decode_version':{decode}").replace("'prefill_version':985",f"'prefill_version':{prefill}")
 source+=f'''
qsa_parent_replacements = replacements

def replacements(native_resources):
    from types import ModuleType
    capsule=ModuleType('next_three_qsa_binding_{decode}_{prefill}_{qsa}')
    exec(compile({binding!r},'<frozen-qsa-shared-binding>','exec'),capsule.__dict__)
    resource=native_resources['qsa_shared_v{qsa}']
    changes=capsule.extend_replacements(qsa_parent_replacements(native_resources),resource['shared'],resource['tiling_header'])
    cleanup=ModuleType('projection_scratch_cleanup')
    exec(compile({release_source!r},'<inactive-projection-scratch>','exec'),cleanup.__dict__)
    capture_base=changes['vllm_ascend._310p.worker_310p:NPUWorker310.resident_capture']
    retained=(native_resources['reconstruction_v{decode}']['fused_int4a4'],native_resources['reconstruction_v{prefill}']['fused_int4a4'])
    def capture(self):
        if self._resident_session().graphs_dirty:
            cleanup.release_projection_capture_buffers(native_resources,retained)
            import gc,torch
            gc.collect();torch.npu.empty_cache()
        return capture_base(self)
    changes['vllm_ascend._310p.worker_310p:NPUWorker310.resident_capture']=capture
    return changes
'''
 return source
cases=[('combined_softmax',992,995,996)]
for label,decode,prefill,qsa in cases:
 idle();source=make_source(decode,prefill,qsa)
 (root/f'night-speed-20261008/next-three-{label}-candidate.py').write_text(source)
 before=client._acknowledged_rpc('resident_status',matches=client._status_matches)
 rows=client.switch(Control(uuid.uuid4().hex,candidate='next_three_'+label,source=source));client.resume()
 assert len(rows)==4 and all(not row['graphs_dirty'] and not row['native_failed'] for row in rows)
 assert sorted((r['pid'],r['weight_storage_digest']) for r in rows)==sorted((r['pid'],r['weight_storage_digest']) for r in before)
 assert all(r['fp16_scale_storage']['decode_version']==decode and r['fp16_scale_storage']['prefill_version']==prefill for r in rows)
 switches.append(dict(label=label,decode=decode,prefill=prefill,qsa=qsa,source_sha256=hashlib.sha256(source.encode()).hexdigest(),ranks=4));save()
 tests=[(128,8,3),(640,1,4),(1280,1,5),(6400,1,6),(6400,1,6),(128,128,20),(128,128,21),(128,128,22)]
 for tokens,output,nonce in tests:
  idle();assert client.request('/pause?mode=wait&clear_cache=true')['status']=='paused';client.resume()
  row=stream(tokens,output,nonce);row['label']=label;records.append(row);save();print(json.dumps(row),flush=True)
idle()
smoke=client.request('/v1/completions',dict(model='glm53-flash-selective-w3',prompt='Explain why plants need sunlight in three short sentences.',max_tokens=80,temperature=0))
assert smoke.get('choices') and smoke['choices'][0].get('text')
status=client._acknowledged_rpc('resident_status',matches=client._status_matches)
assert len(status)==4 and all(not r['graphs_dirty'] and not r['native_failed'] and not r['reconstruction']['fallback_dispatches'] for r in status)
paused=client.request('/is_paused',method='GET')
save(True)
(root/'night-speed-20261008/next-three-final-status.json').write_text(json.dumps(dict(smoke=smoke,status=status,paused=paused),indent=2)+'\n')
print('Complete fresh-worker combined candidate benchmark; candidate retained healthy',flush=True)
