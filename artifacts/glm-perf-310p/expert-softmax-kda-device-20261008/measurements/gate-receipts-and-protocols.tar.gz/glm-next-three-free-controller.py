import hashlib,json,os,psutil,re,subprocess,sys,time,urllib.request
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
client=ResidentClient('http://127.0.0.1:8001')
paired=json.loads((root/'night-speed-20261008/qsa-v996-paired-serving.json').read_text());assert paired['complete']
receipt=json.loads((root/'prepared-offset-server-process-20261008.json').read_text())
parent=psutil.Process(receipt['pid']);assert abs(parent.create_time()-receipt['created'])<1
qualified_env=parent.environ()
with urllib.request.urlopen(client.base_url+'/metrics',timeout=30) as response:metrics=response.read().decode()
counts=[float(v) for v in re.findall(r'^vllm:num_requests_(?:running|waiting)(?:\{[^\n]*\})?\s+([0-9.eE+-]+)$',metrics,re.M)]
assert counts and not any(counts),'User request active; defer'
assert client.request('/pause?mode=wait&clear_cache=false')['status']=='paused'
owned=[parent,*parent.children(recursive=True)]
record=dict(previous_receipt=receipt,pids=[p.pid for p in owned],expert_gates={},kda_qualified=False,restored=False)
report=root/'next-three-free-controller.json'
def save():report.write_text(json.dumps(record,indent=2)+'\n')
save()
for process in owned:
 try:process.terminate()
 except psutil.NoSuchProcess:pass
_,pending=psutil.wait_procs(owned,timeout=30)
for process in pending:
 try:process.kill()
 except psutil.NoSuchProcess:pass
psutil.wait_procs(pending,timeout=5)
print('Released only the identity-checked idle GLM process tree',flush=True)
env=dict(qualified_env);env['ASCEND_RT_VISIBLE_DEVICES']='0'
try:
 for version in (992,993,994,995):
  started=time.monotonic()
  try:
   with (root/f'v{version}-schedule-free-gates.log').open('x') as log:
    subprocess.run([sys.executable,str(root/f'glm-next-v{version}-free-gates.py')],env=env,cwd=receipt['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
   result=json.loads((root/f'v{version}-free-gates-rank0.json').read_text());assert result['complete']
   record['expert_gates'][str(version)]=dict(passed=True,elapsed_s=time.monotonic()-started,independent=len(result['records']),real=len(result['real_weight_records']),paired=len(result['paired_boundaries']))
   print('EXPERT GATE PASSED',version,record['expert_gates'][str(version)],flush=True)
  except BaseException as error:
   record['expert_gates'][str(version)]=dict(passed=False,type=type(error).__name__,error=str(error));print('EXPERT GATE FAILED',version,str(error),flush=True)
  save()
 experiment=root/'prefill-kda-score-matrix-full-v1'
 old=Path('/home/matteius/experiments/glm-prompt-profile-20261005/validate-full-kda.py')
 source=old.read_text().replace('root = Path(__file__).resolve().parent',f'root = Path({str(experiment)!r})')
 graph_code='''
        if safe and layout == "BSND" and length in (64, 640) and raw_mean == -7.0:
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph):
                captured = execute()
            graph_records = []
            try:
                for phase in range(3):
                    if phase:
                        inputs[0].mul_(0.99)
                        inputs[1].mul_(1.01)
                        inputs[2].add_(0.001)
                        inputs[3].add_(0.001)
                        inputs[4].mul_(0.97)
                        inputs[5].mul_(0.95)
                    graph.replay()
                    torch.npu.synchronize()
                    replayed = [t.cpu().contiguous() if t is not None else None for t in captured]
                    eager = [t.cpu().contiguous() if t is not None else None for t in execute()]
                    assert all(a is b if a is None or b is None else torch.equal(a.view(torch.uint8), b.view(torch.uint8)) for a,b in zip(replayed,eager))
                    key = name + "_graph_" + str(phase)
                    saved[key] = replayed
                    if args.label != "baseline":
                        expected_graph = references[key]
                        assert all(a is b if a is None or b is None else torch.equal(a.view(torch.uint8), b.view(torch.uint8)) for a,b in zip(replayed,expected_graph))
                    graph_records.append(dict(phase=phase,exact_eager=True,exact_parent=args.label != "baseline"))
            finally:
                graph.reset()
                torch.npu.synchronize()
            record["changed_graph_replays"] = graph_records
'''
 anchor='        record["median_ms"] = statistics.median(samples)';assert source.count(anchor)==1
 source=source.replace(anchor,anchor+'\n'+graph_code)
 (experiment/'validate-full-kda.py').write_text(source)
 build_record=json.loads((experiment/'build.json').read_text())
 assert hashlib.sha256(Path(build_record['binary']).read_bytes()).hexdigest()==build_record['binary_sha256']
 old_vendor=str(root/'prefill-kda-score-row-batch-full-v2/opp-score-row-batch/vendors/custom_transformer')
 for label,package in (('baseline',root/'prefill-kda-score-row-batch-full-v2/opp-score-row-batch'),('cached',Path(build_record['package']))):
  gate_env=dict(env);vendor=str(package/'vendors/custom_transformer')
  assert old_vendor in gate_env['ASCEND_CUSTOM_OPP_PATH']
  gate_env['ASCEND_CUSTOM_OPP_PATH']=gate_env['ASCEND_CUSTOM_OPP_PATH'].replace(old_vendor,vendor)
  gate_env['LD_LIBRARY_PATH']=str(Path(vendor)/'op_api/lib')+':'+gate_env['LD_LIBRARY_PATH']
  with (experiment/f'gate-{label}.log').open('x') as log:
   subprocess.run([sys.executable,str(experiment/'validate-full-kda.py'),label],env=gate_env,cwd=receipt['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
  print('KDA FULL GATE',label,'completed',flush=True)
 rows=json.loads((experiment/'full-kda-cached.json').read_text())
 safe=[r for r in rows if '_True_' in r['case']]
 assert len(safe)==17 and all(r['finite'] and r['inputs_unchanged'] and len(r['bit_mismatches'])==12 and sum(r['bit_mismatches'])==0 and sum(r['repeat_bit_mismatches'])==0 for r in safe)
 graphs=[r for r in safe if r.get('changed_graph_replays')]
 assert len(graphs)==2 and all(len(r['changed_graph_replays'])==3 for r in graphs)
 record['kda_qualified']=True;save()
 print('KDA all 17 safe cases, all 12 outputs and changed 64/640-token graphs passed',flush=True)
except BaseException as error:
 record['error']=dict(type=type(error).__name__,error=str(error));save();print('Gate error; qualified parent recovery remains prepared:',error,flush=True)
finally:
 launch=(root/'night-speed-20261008/prepared-offset-launch.py').read_text().replace('prepared-offset-server-20261008','next-three-server-20261008').replace('prepared-offset-server-process-20261008','next-three-server-process-20261008')
 if record['kda_qualified']:
  launch=launch.replace('prefill-kda-score-row-batch-full-v2/opp-score-row-batch','prefill-kda-score-matrix-full-v1/opp-score-matrix')
 assert not (root/'next-three-server-20261008.log').exists()
 (root/'night-speed-20261008/next-three-launch.py').write_text(launch)
 exec(compile(launch,'<next-three-restoration>','exec'),{'__name__':'__main__'})
 for name in ('glm-expert-cube-admit-base-only','glm-offset-v984-serving-admit','glm-offset-v985-serving-admit','glm-qsa-v996-admit','glm-qsa-v996-live'):
  with (root/(name+'-next-three-restoration.log')).open('x') as log:
   subprocess.run([sys.executable,str(root/(name+'.py'))],env=qualified_env,cwd=receipt['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
  print('RESTORED',name,flush=True)
 record['restored']=True;save();print('GLM real weights, retained fusions, v996 QSA and qualified KDA ready again',flush=True)
