import importlib,json,statistics,subprocess,time
from functools import partial
from pathlib import Path
import torch
import torch.nn.functional as functional
import torch_npu
from tools.qwen4exp.native_prefill import NativeLocalRouteGather
from tools.qwen4exp.native_streaming_next import NativeStreamingProjectionNext
from tools.qwen4exp.streaming_epilogue import WindowPlan,run_streaming_epilogue
from tools.qwen4exp.streaming_operands import prepare_grouped_operands
from tools.qwen4exp.thermal_controller import parse_temperatures
from tools.qwen4exp.resident_worker import QwenResidentExtension
from vllm_ascend.models.qwen4_exp.moe import route_topk
from vllm_ascend.models.qwen4_exp.w4_moe import W4SparseMoE,build_grouped_expert_dispatch,finalize_grouped_routes
from vllm_ascend.models.qwen4_exp.w4a8_int4 import pack_activation_device
METHOD='resident_projection_abba_v11'
ROOT='/home/matteius/experiments/'
def guard():
 temperatures=parse_temperatures(subprocess.check_output(['npu-smi','info'],text=True,timeout=5),6)
 if max(temperatures)>=90:raise RuntimeError(f'Private benchmark thermal stop: {temperatures}')
 return temperatures

def prepare():
 resources={}
 for name,directory,namespace in [('streaming_v10','qwen-streaming-next-bundle-v10-20261009','qwen_streaming_v10'),('streaming_v11','qwen-streaming-full-tile-v11-20261010','qwen_streaming_v11')]:
  kernel=getattr(torch.classes,namespace).Kernel;launch=getattr(torch.ops,namespace).launch
  binary=str(Path(ROOT)/directory/'binaries/native_streaming_next.bin')
  resources[name]=NativeStreamingProjectionNext(kernel(binary,'qwen_streaming_projection_v2'),launch,kernel(binary,'qwen_streaming_columns_v2'))
  if name=='streaming_v11':resources['gather']=NativeLocalRouteGather(kernel(str(Path(ROOT)/directory/'binaries/native_route_gather.bin'),'qwen_local_route_gather_v1'),launch)
 return resources

def validate(resources):
 guard()
 checks=importlib.import_module('tests.e2e.nightly.310p.single_node.ops.streaming_next.test_projection')
 for name in ['streaming_v10','streaming_v11']:
  for rows,outputs,k,ends in [(1,160,128,[1]),(33,1280,2560,[0,33]),(33,160,640,[0]*84+[33]),(33,160,640,[0]*85+[17])]:
   checks.test_raw_parity_and_peer_zero(resources[name],rows,outputs,k,ends)
  for first in [0,8]:checks.test_down_windows(resources[name],first)
 assert not hasattr(QwenResidentExtension,METHOD)
 @torch.inference_mode()
 def benchmark(self,parameters):
  try:
   if getattr(self.model_runner,'execute_model_state',None) is not None:raise RuntimeError('model execution pending')
   layer=next(m for m in self.model_runner.model.modules() if isinstance(m,W4SparseMoE))
   assert layer.grouped_activation=='cann_builtin_fp16' and layer.grouped_finalize=='cann_v2'
   before=self.resident_status()['weight_storage_digest']
   rank=torch.distributed.get_rank()
   records=[]
   def streaming(inputs,weights,ids,name):
    projection=resources[name]
    prepared=prepare_grouped_operands(inputs,weights,ids,pack=pack_activation_device,dispatch=partial(build_grouped_expert_dispatch,weight_dtype=layer.compute_dtype,count_mode=layer.grouped_route_count_mode),gather=resources['gather'],num_local_experts=layer.num_local_experts,expert_offset=layer.expert_offset)
    projected=projection(layer.projections['gate_up_proj'],prepared.local_operands,prepared.group_ends)
    return run_streaming_epilogue(projected,prepared.dispatch,weights,prepared.group_ends,layer.projections['down_proj'],activation=lambda v:torch_npu.npu_swiglu(v,dim=-1),pack=lambda v,_ends:pack_activation_device(v),columns=projection.columns,finalize=lambda v,dispatch,weights:finalize_grouped_routes(v,dispatch,weights,layer.compute_dtype,'cann_v2'),complete=lambda *_:None,plan=WindowPlan(tile_columns=projection.tile_columns)).output
   for tokens in parameters['tokens']:
    for seed in parameters['seeds']:
     guard()
     inputs=(torch.randn(tokens,layer.gate.shape[1],generator=torch.Generator().manual_seed(seed))*.1).half().to(layer.gate.device)
     weights,ids=route_topk(functional.linear(inputs,layer.gate),layer.top_k,renormalize=layer.renormalize,routed_scaling_factor=layer.routed_scaling_factor)
     expected=layer._forward_grouped(inputs,weights,ids).cpu()
     for name in ['streaming_v10','streaming_v11']:torch.testing.assert_close(streaming(inputs,weights,ids,name).cpu(),expected,rtol=0,atol=0)
     samples={name:[] for name in ['baseline','streaming_v10','streaming_v11']}
     for _ in range(parameters['repeats']):
      for name in ['baseline','streaming_v10','streaming_v11','streaming_v11','streaming_v10','baseline']:
       guard();torch.npu.synchronize();started=time.perf_counter()
       output=layer._forward_grouped(inputs,weights,ids) if name=='baseline' else streaming(inputs,weights,ids,name)
       torch.npu.synchronize();samples[name].append((time.perf_counter()-started)*1000);del output
     records.append({'tokens':tokens,'seed':seed,'rank':rank,'exact':True,'samples_ms':samples,'median_ms':{k:statistics.median(v) for k,v in samples.items()},'temperatures_after_c':guard()})
   assert before==self.resident_status()['weight_storage_digest']
   return {'rank':rank,'passed':True,'records':records,'weight_storage_preserved':True,'serving_candidate':self.resident_status()['candidate']}
  except Exception as error:return {'rank':torch.distributed.get_rank(),'passed':False,'error':f'{type(error).__name__}: {error}'}
  finally:
   if hasattr(QwenResidentExtension,METHOD):delattr(QwenResidentExtension,METHOD)
 setattr(QwenResidentExtension,METHOD,benchmark)
 return {'passed':True,'eager_case_count_per_variant':6,'variants':['streaming_v10','streaming_v11'],'diagnostic_method':METHOD,'graph_gate':'deferred; no serving admission','changes_model_forward':False}
