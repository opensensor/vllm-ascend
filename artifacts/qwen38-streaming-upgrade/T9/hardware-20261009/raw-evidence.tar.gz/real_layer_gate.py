"""Real checkpoint partial-MoE parity/performance; synthetic activations."""

import importlib.util
import json
import statistics
import subprocess
import time
from functools import partial
from pathlib import Path

import torch
import torch_npu
import torch.nn.functional as F

from tools.qwen4exp.build_streaming import verify_bundle
from tools.qwen4exp.native_prefill import NativeLocalRouteGather
from tools.qwen4exp.native_streaming import NativeStreamingProjection
from tools.qwen4exp.profile_w4_layer_310 import load_layer
from tools.qwen4exp.streaming_operands import prepare_grouped_operands
from tools.qwen4exp.streaming_epilogue import run_streaming_epilogue
from vllm_ascend.models.qwen4_exp.moe import route_topk
from vllm_ascend.models.qwen4_exp.w4_moe import build_grouped_expert_dispatch, finalize_grouped_routes
from vllm_ascend.models.qwen4_exp.w4a8_int4 import pack_activation_device, NATIVE_INT4_BACKEND
from vllm_ascend.utils import enable_custom_op

BUNDLE = Path('/home/matteius/experiments/qwen-streaming-bundle-v5-20261009')
MODEL = Path('/srv/ai/models/Qwen3.8-Flash-Next-W4A16-G128-300i')
OUTPUT = Path('/home/matteius/experiments/qwen-streaming-hardware-20261009/real-layer-gate.jsonl')
assert not OUTPUT.exists()
verify_bundle(BUNDLE, require_compiled=True)
candidate = json.loads((BUNDLE / 'candidate.json').read_text())
torch.npu.set_device(0)
torch_npu.npu.set_compile_mode(jit_compile=False)
enable_custom_op()
torch.ops.load_library(str(BUNDLE / candidate['bridges'][0]['path']))
namespace = candidate['namespace']
kernel = getattr(torch.classes, namespace).Kernel
launch = getattr(torch.ops, namespace).launch
projection = NativeStreamingProjection(kernel(str(BUNDLE / 'binaries/native_streaming.bin'), 'qwen_streaming_projection_v1'),
                                      launch, kernel(str(BUNDLE / 'binaries/native_streaming.bin'), 'qwen_streaming_columns_v1'))
gather = NativeLocalRouteGather(kernel(str(BUNDLE / 'binaries/native_route_gather.bin'), 'qwen_local_route_gather_v1'), launch)
spec = importlib.util.spec_from_file_location('thermal', OUTPUT.parent / 'thermal-controller-fixed-v2.py')
thermal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(thermal)


def guard():
    temperatures = thermal.parse_temperatures(subprocess.check_output(['npu-smi', 'info'], text=True, timeout=3), 6)
    if max(temperatures) >= 90:
        raise RuntimeError(f'Standalone gate temperature stop: {temperatures}')
    return temperatures


def record(value):
    print(json.dumps(value), flush=True)
    with OUTPUT.open('a') as stream:
        stream.write(json.dumps(value) + '\n')


def run(layer, inputs, weights, ids):
    prepared = prepare_grouped_operands(inputs, weights, ids, pack=pack_activation_device,
        dispatch=partial(build_grouped_expert_dispatch, weight_dtype=layer.compute_dtype,
                         count_mode=layer.grouped_route_count_mode),
        gather=gather, num_local_experts=layer.num_local_experts, expert_offset=layer.expert_offset)
    projected = projection(layer.projections['gate_up_proj'], prepared.local_operands, prepared.group_ends)
    dispatch, boundaries = prepared.dispatch, prepared.group_ends
    del prepared
    return run_streaming_epilogue(projected, dispatch, weights, boundaries, layer.projections['down_proj'],
        activation=lambda value: torch_npu.npu_swiglu(value, dim=-1),
        pack=lambda value, _ends: pack_activation_device(value), columns=projection.columns,
        finalize=lambda routed, routed_dispatch, route_weights: finalize_grouped_routes(
            routed, routed_dispatch, route_weights, layer.compute_dtype, 'cann_v2'),
        complete=lambda _stage, _tensor: None).output


with torch.inference_mode():
    guard()
    layer = load_layer(MODEL, 0, 0, 4, NATIVE_INT4_BACKEND)
    layer.grouped_activation = 'cann_builtin_fp16'
    layer.grouped_finalize = 'cann_v2'
    layer.grouped_chunk_tokens = 2560
    for tokens in (128, 2560):
        for seed in (1024, 1025):
            guard()
            generator = torch.Generator().manual_seed(seed)
            inputs = (torch.randn(tokens, 2560, generator=generator) * 0.1).half().npu()
            weights, ids = route_topk(F.linear(inputs, layer.gate), layer.top_k,
                renormalize=layer.renormalize, routed_scaling_factor=layer.routed_scaling_factor)
            expected = layer._forward_grouped(inputs, weights, ids).cpu()
            actual = run(layer, inputs, weights, ids).cpu()
            error = (actual - expected).abs()
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)
            samples = {'baseline': [], 'streaming': []}
            for repeat in range(3):
                for name in ('baseline', 'streaming', 'streaming', 'baseline'):
                    guard()
                    torch.npu.synchronize()
                    start = time.perf_counter()
                    result = layer._forward_grouped(inputs, weights, ids) if name == 'baseline' else run(layer, inputs, weights, ids)
                    torch.npu.synchronize()
                    samples[name].append((time.perf_counter() - start) * 1000)
            record({'case': 'real_layer', 'layer': 0, 'rank_partial': 0, 'tokens': tokens, 'seed': seed,
                'exact': True, 'max_abs_error': error.max().item(), 'samples_ms': samples,
                'median_ms': {name: statistics.median(values) for name, values in samples.items()},
                'temperatures_c': guard(), 'full_model_validated': False,
                'includes_shared_expert_or_hccl': False})
    record({'real_layer_parity_passed': True, 'full_model_validated': False})
