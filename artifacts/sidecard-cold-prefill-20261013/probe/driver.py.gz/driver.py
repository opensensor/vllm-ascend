import argparse,hashlib,json,time,traceback
from pathlib import Path
from transformers import AutoTokenizer
from tools.sidecard.expert_actor import ExpertCoordinator
from tools.sidecard.prefill_gate import validate
from tools.sidecard.prefill_benchmark import exact_prompt
from tools.sidecard.layer_server import request_tokens
p=argparse.ArgumentParser();p.add_argument('--config',required=True);a=p.parse_args()
spec=json.loads(Path(a.config).read_text());out=Path(spec['output']);engine=None
report=dict(passed=False,cached_prompt_tokens=0,measurements=[])
try:
 engine=ExpertCoordinator(a.config)
 tokenizer=AutoTokenizer.from_pretrained(spec['checkpoint'],trust_remote_code=False)
 seed=tokenizer.encode('Inspect this module and explain its control flow. ')
 print(json.dumps(dict(kind='cold_batch_gate_started')),flush=True)
 gate=validate(engine,seed,output=out/'prefill-parity.json',reference_path=Path(spec['prefill_reference']),reference_sha256=spec['prefill_reference_sha256'])
 print(json.dumps(dict(kind='cold_batch_gate_completed',passed=gate['passed'])),flush=True)
 cases=[('2K',exact_prompt(seed,2048)),('8K',exact_prompt(seed,8192))]
 body=json.loads(Path('/tmp/sidecard-cold-full-code-request.json').read_bytes())
 full,_=request_tokens(body,tokenizer,engine.max_context,chat=True)
 cases.append(('full-code',full))
 report['full_code_tokens']=len(full);report['request_sha256']=hashlib.sha256(Path('/tmp/sidecard-cold-full-code-request.json').read_bytes()).hexdigest()
 report['token_sha256']=hashlib.sha256(json.dumps(full,separators=(',',':')).encode()).hexdigest()
 for name,tokens in cases:
  forced=[];baseline_hashes=[]
  for window in (32,64):
   engine.prefill_window_size=window
   engine.reset(context_limit=len(tokens)+64)
   engine.fingerprints=None
   started=time.perf_counter();logits=engine.prefill(tokens);elapsed=time.perf_counter()-started
   ttft=elapsed
   hashes=[]
   for step in range(64):
    hashes.append(hashlib.sha256(logits.cpu().numpy().tobytes()).hexdigest())
    if window==32:forced.append(int(logits.argmax().cpu()))
    if step<63:logits=engine.forward([forced[step]])
   decode=time.perf_counter()-started-elapsed
   if window==32:baseline_hashes=hashes
   equal=hashes==baseline_hashes
   row=dict(case=name,prompt_tokens=len(tokens),window_rows=window,cuda_chunk_rows=32,cached_prompt_tokens=0,prefill_seconds=elapsed,prompt_tokens_per_second=len(tokens)/elapsed,decode_tokens_per_second=63/decode,full_vocabulary_bitwise_equal=equal,logits_sha256=hashes)
   report['measurements'].append(row);(out/'cold-benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
   print(json.dumps({k:v for k,v in row.items() if k!='logits_sha256'}),flush=True)
   if not equal:raise AssertionError('Matched cold benchmark full-vocabulary parity failed')
 report['passed']=True
except BaseException as error:
 report['error']=dict(type=type(error).__name__,message=str(error));traceback.print_exc()
finally:
 (out/'cold-benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
 if engine is not None:engine.close()
 print(json.dumps(dict(kind='cold_probe_closed',passed=report['passed'])),flush=True)
