import shutil
from pathlib import Path
from torch_npu.profiler.profiler import analyse
root=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
source=Path('/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009/export_only_prof_dir')
destination=root/'loaded-stage-profile-raw'
shutil.copytree(source,destination)
analyse(str(destination),max_process_number=4)
traces=list(destination.rglob('trace_view.json'))
print('Parsed trace files:',[str(p) for p in traces],flush=True)
assert traces,'offline profiler parsing did not produce a trace'
shutil.copyfile(traces[0],root/'loaded-stage-rank0-trace.json')
