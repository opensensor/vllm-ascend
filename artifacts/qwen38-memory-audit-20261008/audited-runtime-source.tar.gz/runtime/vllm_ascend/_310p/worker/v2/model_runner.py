# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
# mypy: ignore-errors

from __future__ import annotations

from collections.abc import Sequence
from contextlib import AbstractContextManager, nullcontext
from copy import deepcopy
from typing import Any

import numpy as np
import torch
import torch_npu
from vllm.config import VllmConfig
from vllm.config.compilation import CUDAGraphMode
from vllm.model_executor.layers.mamba.ops.ssu_dispatch import initialize_mamba_ssu_backend
from vllm.utils.math_utils import cdiv
from vllm.utils.platform_utils import is_pin_memory_available
from vllm.utils.torch_utils import get_dtype_size
from vllm.v1 import kv_cache_interface
from vllm.v1.core.kv_cache_utils import KVCacheBlockCopy
from vllm.v1.core.sched.output import GrammarOutput, SchedulerOutput
from vllm.v1.kv_cache_interface import (
    AttentionSpec,
    KVCacheConfig,
    KVCacheSpec,
    MambaSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.utils import CpuGpuBuffer
from vllm.v1.worker.cp_utils import check_attention_cp_compatibility
from vllm.v1.worker.gpu.attn_utils import (
    get_shared_kv_cache_layers,
    init_attn_backend,
)
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.kv_connector import get_kv_connector
from vllm.v1.worker.gpu.model_runner import BatchReqState, sort_batch_req_ids
from vllm.v1.worker.gpu.spec_decode.speculator import DraftModelSpeculator
from vllm.v1.worker.utils import bind_kv_cache, copy_kv_cache_blocks_inplace

from vllm_ascend._310p.attention.attention_v1 import AscendAttentionBackend310
from vllm_ascend._310p.kv_cache_sharing import get_310p_shared_cache_slots
from vllm_ascend._310p.worker.v2.aclgraph import ModelAclGraphManager310
from vllm_ascend._310p.worker.v2.block_table import Ascend310PBlockTables
from vllm_ascend._310p.worker.v2.input_batch import Ascend310PInputBatch
from vllm_ascend._310p.worker.v2.kv_block_zeroer import AscendKVBlockZeroer310V2
from vllm_ascend._310p.worker.v2.spec_utils import (
    combine_sampled_and_draft_tokens_cpu,
    expand_idx_mapping_cpu,
    set_prefill_host_meta,
)
from vllm_ascend._310p.worker.v2.states import Ascend310PRequestState
from vllm_ascend.core.kv_cache_interface import get_storage_block_size
from vllm_ascend.ops.rotary_embedding import update_cos_sin
from vllm_ascend.utils import ACL_FORMAT_FRACTAL_NZ, get_kv_cache_tensor_layers
from vllm_ascend.worker.v2.attn_utils import build_attn_state
from vllm_ascend.worker.v2.model_runner import NPUModelRunner

_ATTENTION_BLOCK_SIZE_LIMIT = 128 * 128


def _post_update_cpu(
    idx_mapping_np: np.ndarray,
    query_start_loc_np: np.ndarray | None,
    req_states: Ascend310PRequestState,
    sampled_cpu: torch.Tensor,
    num_sampled_cpu: torch.Tensor,
    num_rejected_cpu: torch.Tensor,
    *,
    update_tokens: bool = True,
    update_computed: bool = True,
) -> torch.Tensor:
    """Run upstream ``post_update`` from sampler-owned CPU results."""
    for batch_idx, req_idx_value in enumerate(idx_mapping_np):
        req_idx = int(req_idx_value)
        if req_idx < 0:
            continue
        count = int(num_sampled_cpu[batch_idx])
        total_len = int(req_states.total_len.np[req_idx])
        if update_tokens and count > 0:
            tokens = sampled_cpu[batch_idx, :count].to(dtype=req_states.all_token_ids.cpu.dtype)
            req_states.all_token_ids.cpu[req_idx, total_len : total_len + count].copy_(tokens)
            req_states.last_sampled_tokens_cpu[req_idx, 0] = tokens[-1]
            req_states.total_len.stage_write_elem(req_idx, total_len + count)
        if not update_computed:
            continue
        query_len = (
            0 if query_start_loc_np is None else int(query_start_loc_np[batch_idx + 1] - query_start_loc_np[batch_idx])
        )
        computed_delta = query_len - int(num_rejected_cpu[batch_idx])
        if computed_delta:
            req_states.num_computed_tokens_np[req_idx] += computed_delta
            value = int(req_states.num_computed_tokens_np[req_idx])
            req_states.num_computed_tokens_cpu[req_idx] = value
            req_states.num_computed_tokens.stage_write_elem(req_idx, value)
    return num_sampled_cpu


class NPUModelRunner310V2(NPUModelRunner):
    """Model runner v2 for Ascend 310P."""

    # 310P Attention requires private ACL NZ K/V buffers while Mamba uses
    # private contiguous ND state buffers. It cannot consume vLLM main's
    # standardized shared backing, so the worker must scale multi-group KV
    # capacity before the engine computes num_blocks.
    supports_standardized_shared_kv_backing = False

    # Without prefix caching, GDN/Mamba state is addressed by a stable request
    # slot instead of by the scheduler's context-block id. This makes recurrent
    # state O(max_num_reqs), rather than O(max_model_len), while attention KV
    # remains fully paged.
    supports_compact_mamba_state = True

    # TODO: Refactor Triton-dependent overrides to register 310P
    # implementations through Triton Dispatcher after vLLM RFC #45133 lands.
    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        self._validate_config(vllm_config)
        super().__init__(vllm_config, device)
        self.req_states = Ascend310PRequestState(
            max_num_reqs=self.max_num_reqs,
            max_model_len=self.max_model_len,
            max_num_batched_tokens=self.max_num_tokens,
            num_speculative_steps=self.num_speculative_steps,
            vocab_size=self.vocab_size,
            device=self.device,
        )
        pin_memory = is_pin_memory_available()
        self.input_buffers.seq_lens_cpu = torch.zeros(
            self.max_num_reqs,
            dtype=torch.int32,
            device="cpu",
            pin_memory=pin_memory,
        )
        self.input_buffers.seq_lens_np = self.input_buffers.seq_lens_cpu.numpy()
        self.input_ids_cpu = torch.zeros(self.max_num_tokens, dtype=torch.int32, device="cpu", pin_memory=pin_memory)
        self.positions_cpu = torch.zeros(self.max_num_tokens, dtype=torch.int64, device="cpu", pin_memory=pin_memory)
        self.next_prefill_tokens_cpu = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device="cpu", pin_memory=pin_memory
        )
        make_buffer = self._make_metadata_buffer
        self._decode_req_indices = make_buffer(self.max_num_reqs, torch.int64, pin_memory)
        self._decode_input_indices = make_buffer(self.max_num_reqs, torch.int64, pin_memory)
        self._idx_mapping = make_buffer(self.max_num_reqs, torch.int32, pin_memory)
        self._cu_num_logits = make_buffer(self.max_num_reqs + 1, torch.int32, pin_memory)
        self._expanded_idx_mapping = make_buffer(self.max_num_tokens, torch.int32, pin_memory)
        self._expanded_local_pos = make_buffer(self.max_num_tokens, torch.int32, pin_memory)
        self._query_start_loc = make_buffer(self.max_num_reqs + 2, torch.int32, pin_memory)
        self._logits_indices = make_buffer(self.max_num_tokens, torch.int64, pin_memory)
        self._num_sampled_staging = make_buffer(self.max_num_reqs, torch.int32, pin_memory)
        self._num_rejected_staging = make_buffer(self.max_num_reqs, torch.int32, pin_memory)
        # Keep prefill and prefix-cache hits out of FULL mixed graphs.
        self._force_eager_pc_batch = False
        self._force_eager_spec_batch = False
        self._spec_dummy_capture = False
        # Populated in initialize_kv_cache; also set here so UT can call
        # ``_allocate_kv_cache_tensors`` without going through that path.
        self._attn_kv_copy_params: list[tuple[torch.Tensor, torch.Tensor, int]] = []
        self._attn_kv_storage_ptrs: set[int] = set()

    def _make_metadata_buffer(
        self,
        size: int,
        dtype: torch.dtype,
        pin_memory: bool,
    ) -> CpuGpuBuffer:
        return CpuGpuBuffer(
            size,
            dtype=dtype,
            device=self.device,
            pin_memory=pin_memory,
        )

    @staticmethod
    def _validate_config(vllm_config: VllmConfig) -> None:
        model_config = vllm_config.model_config
        # Qwen3-VL (multimodal + MRoPE) and Qwen3.5 (hybrid + GDN + MRoPE) are
        # in scope for 310P MRv2. MLA / sleep remain unsupported.
        if model_config.use_mla:
            # Gated bring-up: MRv2 MLA on 310P is only reachable with the
            # experimental flag. The decomposed MLA path is currently wired
            # through MRv1 (model_runner_310p); keep MRv2 blocked unless the
            # operator opts in explicitly.
            from vllm_ascend import envs as ascend_envs

            if not ascend_envs.VLLM_ASCEND_310P_ENABLE_MLA:
                raise NotImplementedError("MLA is not supported by model runner v2 on 310P.")
        if getattr(model_config, "enable_sleep_mode", False):
            raise NotImplementedError("Sleep mode is not supported by model runner v2 on 310P.")

        parallel_config = vllm_config.parallel_config
        # TODO: Restore data parallel support in the next 310P MRV2 iteration.
        # Pipeline and context parallelism remain unsupported on 310P.
        unsupported_parallel = {
            "pipeline_parallel_size": getattr(parallel_config, "pipeline_parallel_size", 1),
            "data_parallel_size": getattr(parallel_config, "data_parallel_size", 1),
            "decode_context_parallel_size": getattr(parallel_config, "decode_context_parallel_size", 1),
            "prefill_context_parallel_size": getattr(parallel_config, "prefill_context_parallel_size", 1),
        }
        enabled = [name for name, size in unsupported_parallel.items() if size != 1]
        if enabled:
            raise NotImplementedError(
                f"310P model runner v2 only supports tensor parallelism; unsupported settings: {', '.join(enabled)}."
            )
        if getattr(parallel_config, "enable_expert_parallel", False):
            raise NotImplementedError("Expert parallelism is not supported by model runner v2 on 310P.")
        if vllm_config.speculative_config is not None:
            spec = vllm_config.speculative_config
            # Bare objects (UT fixtures) and non-MTP methods are out of scope.
            method = getattr(spec, "method", None)
            if method != "mtp":
                raise NotImplementedError(
                    f"Speculative decoding is only supported via MTP on 310P model runner v2, got {method!r}."
                )
        if vllm_config.kv_transfer_config is not None:
            raise NotImplementedError("KV cache transfer is not supported by model runner v2 on 310P.")
        # Prefix caching is supported: 310P MRv2 reuses CPU Ascend310PBlockTables /
        # PrefillCacheHit→splitfuse (attention_v1) and hybrid Mamba page sizing below.

    def _prepare_inputs_310p(
        self,
        scheduler_output: SchedulerOutput,
        batch_desc: BatchExecutionDescriptor,
    ) -> Ascend310PInputBatch:
        # TODO: Refactor this Triton-free input preparation through Triton
        # Dispatcher after vLLM RFC #45133 lands.
        num_tokens = scheduler_output.total_num_scheduled_tokens
        num_tokens_after_padding = batch_desc.num_tokens
        assert num_tokens > 0
        num_tokens_per_req = scheduler_output.num_scheduled_tokens
        num_reqs = len(num_tokens_per_req)

        req_ids = sort_batch_req_ids(
            num_tokens_per_req,
            scheduler_output.scheduled_spec_decode_tokens,
            self.decode_query_len,
        )
        # Resolve scheduler rewinds before materializing device state.
        self._update_seq_lens_cpu(scheduler_output, req_ids)

        num_scheduled_tokens = np.fromiter(
            map(num_tokens_per_req.get, req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        num_valid_tokens = num_scheduled_tokens
        draft_tokens_map = scheduler_output.scheduled_spec_decode_tokens
        if draft_tokens_map:
            num_valid_tokens = np.array(
                [
                    num_tokens - len(draft_tokens_map.get(req_id, ()))
                    for num_tokens, req_id in zip(num_scheduled_tokens, req_ids)
                ],
                dtype=np.int32,
            )
        attn_state = build_attn_state(
            self.vllm_config,
            self.input_buffers.seq_lens_np,
            num_reqs,
            num_scheduled_tokens,
            num_valid_tokens,
            kv_cache_config=self.kv_cache_config,
        )
        idx_mapping_np = self._idx_mapping.np[:num_reqs]
        idx_mapping_np[:] = np.fromiter(
            map(self.req_states.req_id_to_index.get, req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        idx_mapping = self._idx_mapping.gpu[:num_reqs]
        self._idx_mapping.copy_to_gpu(num_reqs)
        # Preserve batch order for host-side postprocessing.
        self._postprocess_idx_mapping_np = idx_mapping_np

        num_draft_tokens_per_req = None
        if not draft_tokens_map:
            total_num_draft_tokens = 0
            cu_num_logits_np = self._cu_num_logits.np[: num_reqs + 1]
            cu_num_logits_np[:] = range(num_reqs + 1)
            cu_num_logits = self._cu_num_logits.gpu[: num_reqs + 1]
            self._cu_num_logits.copy_to_gpu(num_reqs + 1)
            expanded_idx_mapping = idx_mapping
            self._expanded_local_pos.np[:num_reqs].fill(0)
            expanded_local_pos = self._expanded_local_pos.gpu[:num_reqs]
            self._expanded_local_pos.copy_to_gpu(num_reqs)
        else:
            num_draft_tokens_per_req = np.fromiter(
                (len(draft_tokens_map.get(req_id, ())) for req_id in req_ids),
                dtype=np.int32,
                count=num_reqs,
            )
            num_bonus_tokens = self.model_state.num_new_sampled_tokens_per_step
            total_num_draft_tokens = int(num_draft_tokens_per_req.sum())
            num_logits_per_req = num_draft_tokens_per_req + num_bonus_tokens
            cu_num_logits_np = self._cu_num_logits.np[: num_reqs + 1]
            cu_num_logits_np[0] = 0
            np.cumsum(num_logits_per_req, out=cu_num_logits_np[1:])
            cu_num_logits = self._cu_num_logits.gpu[: num_reqs + 1]
            self._cu_num_logits.copy_to_gpu(num_reqs + 1)
            total_num_logits = int(cu_num_logits_np[-1])
            expand_idx_mapping_cpu(
                idx_mapping_np,
                total_num_logits,
                cu_num_logits_np,
                self._expanded_idx_mapping.np,
                self._expanded_local_pos.np,
            )
            expanded_idx_mapping = self._expanded_idx_mapping.gpu[:total_num_logits]
            expanded_local_pos = self._expanded_local_pos.gpu[:total_num_logits]
            self._expanded_idx_mapping.copy_to_gpu(total_num_logits)
            self._expanded_local_pos.copy_to_gpu(total_num_logits)

        num_reqs_padded = batch_desc.num_reqs or num_reqs
        query_start_loc_np = self._query_start_loc.np
        query_start_loc_np[0] = 0
        np.cumsum(num_scheduled_tokens, out=query_start_loc_np[1 : num_reqs + 1])
        query_start_loc_np[num_reqs + 1 :] = num_tokens
        if batch_desc.cg_mode == CUDAGraphMode.FULL:
            query_start_loc_np, num_reqs_padded = self._pad_query_start_loc_for_fia(
                num_tokens_after_padding,
                num_reqs_padded,
                num_reqs,
                query_start_loc_np,
                batch_desc.cg_mode,
                batch_desc.num_reqs,
            )
        self.input_buffers.query_start_loc.copy_(self._query_start_loc.cpu, non_blocking=True)
        query_start_loc_np = query_start_loc_np[: num_reqs_padded + 1]
        self._postprocess_query_start_loc_np = query_start_loc_np[: num_reqs + 1].copy()
        query_start_loc = self.input_buffers.query_start_loc[: num_reqs_padded + 1]

        prefill_len_np = self.req_states.prefill_len.np[idx_mapping_np]
        num_computed_prefill_tokens_np = self.req_states.num_computed_prefill_tokens[idx_mapping_np]
        is_prefilling_np = num_computed_prefill_tokens_np < prefill_len_np
        batch_has_prefill = bool(np.any(is_prefilling_np))
        self.eplb.set_batch_phase(batch_has_prefill)
        self._prepare_token_inputs_cpu(
            idx_mapping,
            idx_mapping_np,
            query_start_loc_np,
            prefill_len_np,
            draft_tokens_map,
            req_ids,
            num_tokens_after_padding,
        )

        self._prepare_pos_seq_lens(
            idx_mapping,
            query_start_loc,
            self.req_states.num_computed_tokens.gpu,
            self.input_buffers.positions,
            self.input_buffers.seq_lens,
            idx_mapping_np=idx_mapping_np,
            query_start_loc_np=query_start_loc_np,
            num_scheduled_tokens=num_scheduled_tokens,
        )
        seq_lens = self.input_buffers.seq_lens[:num_reqs_padded]
        # Pad rows must not carry stale host seq_lens into GDN/attention metadata.
        self.input_buffers.seq_lens_np[num_reqs:num_reqs_padded] = 0
        self.input_buffers.seq_lens_np[num_reqs_padded:] = 0
        total_num_logits = num_reqs if not draft_tokens_map else int(cu_num_logits_np[-1])
        logits_indices_np = self._logits_indices.np[:total_num_logits]
        for batch_idx in range(num_reqs):
            logits_start = int(query_start_loc_np[batch_idx + 1]) - int(
                cu_num_logits_np[batch_idx + 1] - cu_num_logits_np[batch_idx]
            )
            cu_start = int(cu_num_logits_np[batch_idx])
            cu_end = int(cu_num_logits_np[batch_idx + 1])
            logits_indices_np[cu_start:cu_end] = range(logits_start, logits_start + cu_end - cu_start)
        logits_indices = self._logits_indices.gpu[:total_num_logits]
        self._logits_indices.copy_to_gpu(total_num_logits)

        seq_lens_cpu_upper_bound_np = np.zeros(num_reqs_padded, dtype=np.int32)
        np.add(
            self.req_states.num_computed_tokens_np[idx_mapping_np],
            num_scheduled_tokens,
            out=seq_lens_cpu_upper_bound_np[:num_reqs],
        )
        input_batch_kwargs: dict[str, Any] = dict(
            req_ids=req_ids,
            num_reqs=num_reqs,
            num_reqs_after_padding=num_reqs_padded,
            idx_mapping=idx_mapping,
            idx_mapping_np=idx_mapping_np,
            expanded_idx_mapping=expanded_idx_mapping,
            expanded_local_pos=expanded_local_pos,
            num_scheduled_tokens=num_scheduled_tokens,
            num_tokens=num_tokens,
            num_tokens_after_padding=num_tokens_after_padding,
            num_draft_tokens=total_num_draft_tokens if draft_tokens_map else 0,
            num_draft_tokens_per_req=num_draft_tokens_per_req,
            query_start_loc=query_start_loc,
            query_start_loc_np=query_start_loc_np,
            seq_lens=seq_lens,
            seq_lens_cpu_upper_bound=torch.from_numpy(seq_lens_cpu_upper_bound_np),
            dcp_local_seq_lens=None,
            is_prefilling_np=is_prefilling_np,
            num_computed_tokens_np=self.req_states.num_computed_tokens_np[idx_mapping_np],
            prefill_len_np=prefill_len_np,
            num_computed_prefill_tokens_np=num_computed_prefill_tokens_np,
            input_ids=self.input_buffers.input_ids[:num_tokens_after_padding],
            positions=self.input_buffers.positions[:num_tokens_after_padding],
            is_padding=self.input_buffers.is_padding[:num_tokens_after_padding],
            logits_indices=logits_indices,
            cu_num_logits=cu_num_logits,
            cu_num_logits_np=cu_num_logits_np,
            has_structured_output_reqs=scheduler_output.has_structured_output_requests,
            prompt_lens=None,
            seq_lens_np=self.input_buffers.seq_lens_np,
            attn_state=attn_state,
            input_ids_cpu=self.input_ids_cpu[:num_tokens_after_padding],
            logits_indices_np=logits_indices_np,
        )
        input_batch_kwargs["has_prefill"] = batch_has_prefill
        input_batch = Ascend310PInputBatch(**input_batch_kwargs)
        # MRoPE positions are built in ``model_state.prepare_inputs``; the 1D
        # arange buffer above is only for slot-mapping / non-MRoPE paths.
        if not self.model_config.uses_mrope:
            update_cos_sin(input_batch.positions)
        return input_batch

    def _scheduler_output_needs_pc_eager(self, scheduler_output: SchedulerOutput) -> bool:
        """Force eager for PrefillCacheHit / ChunkedPrefill when mixed FULL graphs exist."""
        if not self.cache_config.enable_prefix_caching:
            return False
        cudagraph_mode = self.compilation_config.cudagraph_mode
        if not cudagraph_mode.has_full_cudagraphs():
            return False
        # FULL_DECODE_ONLY: mixed_mode is NONE → prefill/PC hits are already eager.
        if cudagraph_mode.mixed_mode() != CUDAGraphMode.FULL:
            return False

        num_tokens_per_req = scheduler_output.num_scheduled_tokens
        num_reqs = len(num_tokens_per_req)
        if num_reqs == 0:
            return False

        computed_by_req: dict[str, int] = {}
        for req in scheduler_output.scheduled_new_reqs:
            computed_by_req[req.req_id] = int(req.num_computed_tokens)
        cached = scheduler_output.scheduled_cached_reqs
        if cached is not None:
            for req_id, num_computed in zip(cached.req_ids, cached.num_computed_tokens):
                computed_by_req[req_id] = int(num_computed)
        for req_id in num_tokens_per_req:
            if req_id in computed_by_req:
                continue
            req_idx = self.req_states.req_id_to_index.get(req_id)
            if req_idx is not None:
                computed_by_req[req_id] = int(self.req_states.num_computed_tokens_np[req_idx])

        req_ids = list(num_tokens_per_req.keys())
        num_scheduled = np.fromiter(
            (num_tokens_per_req[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        seq_lens = np.fromiter(
            (computed_by_req.get(req_id, 0) + int(num_tokens_per_req[req_id]) for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        attn_state = build_attn_state(
            self.vllm_config,
            seq_lens,
            num_reqs,
            num_scheduled,
            num_scheduled,
            kv_cache_config=self.kv_cache_config,
        )
        # Avoid importing AscendAttentionState at module top (heavy attention_v1).
        return attn_state.name in ("PrefillCacheHit", "ChunkedPrefill")

    def _scheduler_output_needs_spec_eager(self, scheduler_output: SchedulerOutput) -> bool:
        """Force eager when MTP verify batch is not uniform SpecDecoding.

        Step 2 (FULL_DECODE_ONLY): apply decode-only padding constraints.
        Uniform decode with ``q_len == decode_query_len`` (1+K) may replay SpecDecoding
        FULL graphs; mixed / prefill / non-uniform MTP schedules stay eager.
        """
        if self.speculative_config is None:
            return False
        cudagraph_mode = self.compilation_config.cudagraph_mode
        if not cudagraph_mode.has_full_cudagraphs():
            return False

        num_tokens_per_req = scheduler_output.num_scheduled_tokens
        num_reqs = len(num_tokens_per_req)
        if num_reqs == 0:
            return False

        # Prefer stable req order (same as prepare_inputs) for draft counts.
        req_ids = sort_batch_req_ids(
            num_tokens_per_req,
            scheduler_output.scheduled_spec_decode_tokens,
            self.decode_query_len,
        )
        num_scheduled = np.fromiter(
            (num_tokens_per_req[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        if not np.all(num_scheduled == self.decode_query_len):
            return True
        if scheduler_output.total_num_scheduled_tokens != int(num_scheduled.sum()):
            return True

        computed_by_req: dict[str, int] = {}
        for req in scheduler_output.scheduled_new_reqs:
            computed_by_req[req.req_id] = int(req.num_computed_tokens)
        cached = scheduler_output.scheduled_cached_reqs
        if cached is not None:
            for req_id, num_computed in zip(cached.req_ids, cached.num_computed_tokens):
                computed_by_req[req_id] = int(num_computed)
        for req_id in req_ids:
            if req_id in computed_by_req:
                continue
            req_idx = self.req_states.req_id_to_index.get(req_id)
            if req_idx is not None:
                computed_by_req[req_id] = int(self.req_states.num_computed_tokens_np[req_idx])

        if any(computed_by_req.get(req_id, 0) == 0 for req_id in req_ids):
            return True

        draft_tokens_map = scheduler_output.scheduled_spec_decode_tokens or {}
        # SpecDecoding requires bonus/valid token count == 1 (rest are drafts).
        num_valid_tokens = np.fromiter(
            (int(num_tokens_per_req[req_id]) - len(draft_tokens_map.get(req_id, ())) for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        if not np.all(num_valid_tokens == 1):
            return True

        # Allow concurrent uniform SpecDecoding FULL. Accuracy
        # regressions are caught by E2E; do not blanket-eager on num_reqs.
        seq_lens = np.fromiter(
            (computed_by_req[req_id] + num_tokens_per_req[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        attn_state = build_attn_state(
            self.vllm_config,
            seq_lens,
            num_reqs,
            num_scheduled,
            num_valid_tokens,
            kv_cache_config=self.kv_cache_config,
        )
        from vllm_ascend.attention.attention_v1 import AscendAttentionState

        return attn_state != AscendAttentionState.SpecDecoding

    def _install_pc_eager_cudagraph_dispatch(self) -> None:
        """Wrap ACLGraph dispatch so PrefillCacheHit cannot replay FULL mixed graphs."""
        manager = self.cudagraph_manager
        if manager is None or getattr(manager, "_310p_pc_eager_wrapped", False):
            return
        orig_dispatch = manager.dispatch
        runner = self

        def dispatch(
            num_reqs: int,
            num_tokens: int,
            uniform_token_count: int | None,
            num_active_loras: int,
            max_query_len: int | None = None,
        ) -> BatchExecutionDescriptor:
            if runner._force_eager_pc_batch or runner._force_eager_spec_batch:
                return BatchExecutionDescriptor(
                    cg_mode=CUDAGraphMode.NONE,
                    num_tokens=num_tokens,
                    num_reqs=num_reqs,
                    num_active_loras=num_active_loras,
                )
            return orig_dispatch(
                num_reqs,
                num_tokens,
                uniform_token_count,
                num_active_loras,
                max_query_len=max_query_len,
            )

        manager.dispatch = dispatch  # type: ignore[method-assign]
        manager._310p_pc_eager_wrapped = True  # type: ignore[attr-defined]

    @torch.inference_mode()
    def execute_model(
        self,
        scheduler_output: SchedulerOutput,
        intermediate_tensors: Any | None = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        is_profile: bool = False,
        context_len: int = 0,
        valid_dummy_state_slots: bool = False,
    ):
        self._force_eager_pc_batch = False
        self._force_eager_spec_batch = False
        if not dummy_run:
            self._force_eager_pc_batch = self._scheduler_output_needs_pc_eager(scheduler_output)
            self._force_eager_spec_batch = self._scheduler_output_needs_spec_eager(scheduler_output)
        try:
            return super().execute_model(
                scheduler_output,
                intermediate_tensors=intermediate_tensors,
                dummy_run=dummy_run,
                skip_attn_for_dummy_run=skip_attn_for_dummy_run,
                is_profile=is_profile,
                context_len=context_len,
                valid_dummy_state_slots=valid_dummy_state_slots,
            )
        finally:
            self._force_eager_pc_batch = False
            self._force_eager_spec_batch = False

    def prepare_inputs(  # type: ignore[misc, override]
        self,
        scheduler_output: SchedulerOutput,
        batch_req_state: BatchReqState,
        batch_desc: BatchExecutionDescriptor,
    ) -> Ascend310PInputBatch:
        del batch_req_state
        return self._prepare_inputs_310p(scheduler_output, batch_desc)

    def finish_requests(self, scheduler_output: SchedulerOutput) -> None:
        super().finish_requests(scheduler_output)
        if scheduler_output.finished_req_ids:
            # ACLGraph may still
            # be reading the previous block-table layout while finish_requests
            # rewrites CPU NumPy tables for a reused slot. Upstream GPU/MRv2
            # does not need this because it does not use that CPU gather path.
            torch.npu.current_stream().synchronize()

    @staticmethod
    def _dedupe_kv_cache_block_copies(
        kv_cache_block_copies: Sequence[KVCacheBlockCopy],
    ) -> list[KVCacheBlockCopy]:
        """Drop duplicate CoW pairs from hybrid multi-manager prefix-cache hits."""
        seen: set[tuple[int, int]] = set()
        deduped: list[KVCacheBlockCopy] = []
        for copy in kv_cache_block_copies:
            key = (copy.src_block_id, copy.dst_block_id)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(copy)
        return deduped

    def _copy_kv_cache_blocks_310p(self, kv_cache_block_copies: Sequence[KVCacheBlockCopy]) -> None:
        """Copy-on-write for hybrid prefix cache on 310P NZ attention + ND Mamba."""
        if not kv_cache_block_copies:
            return

        indices_np = np.array(
            [[copy.src_block_id, copy.dst_block_id] for copy in kv_cache_block_copies],
            dtype=np.int64,
        )
        seen_attn_storage: set[int] = set()
        for k_cache, v_cache, blocks_per_kv_block in self._attn_kv_copy_params:
            storage_ptr = k_cache.untyped_storage().data_ptr()
            if storage_ptr in seen_attn_storage:
                continue
            seen_attn_storage.add(storage_ptr)
            for src_block_id, dst_block_id in indices_np:
                src_start = int(src_block_id) * blocks_per_kv_block
                src_end = src_start + blocks_per_kv_block
                dst_start = int(dst_block_id) * blocks_per_kv_block
                dst_end = dst_start + blocks_per_kv_block
                k_cache[dst_start:dst_end].copy_(k_cache[src_start:src_end])
                v_cache[dst_start:dst_end].copy_(v_cache[src_start:src_end])

        # Mamba layers store a list[Tensor] per layer (conv/ssm views). Upstream
        # copy_kv_cache_blocks_inplace expects Iterable[Tensor], not nested lists.
        mamba_tensors: list[torch.Tensor] = []
        for entry in self.kv_caches:
            if isinstance(entry, list):
                mamba_tensors.extend(t for t in entry if isinstance(t, torch.Tensor))
        if mamba_tensors:
            copy_kv_cache_blocks_inplace(
                mamba_tensors,
                self.kv_cache_config.num_blocks,
                kv_cache_block_copies,
            )

    def update_requests(self, scheduler_output: SchedulerOutput) -> None:
        copies = scheduler_output.kv_cache_block_copies
        pending_copies: list[KVCacheBlockCopy] | None = None
        if copies:
            pending_copies = self._dedupe_kv_cache_block_copies(copies)
        # Main derives this field from KVCacheConfig.has_mamba_layers, which is
        # broader than the 310P requirement. Filter at the actual consumer
        # before GPUModelRunner.update_requests invokes the zeroer.
        if scheduler_output.new_block_ids_to_zero and not self._needs_kv_cache_zeroing_310p(self.kv_cache_config):
            scheduler_output.new_block_ids_to_zero = None
        # Skip upstream copy (mishandles 310P NZ attention storages).
        scheduler_output.kv_cache_block_copies = None
        super().update_requests(scheduler_output)
        if pending_copies:
            self._copy_kv_cache_blocks_310p(pending_copies)

    def get_kv_cache_spec(self) -> dict[str, KVCacheSpec]:
        """Restore linear-attention specs omitted by some upstream V2 versions.

        The eager Qwen4Exp attention modules are plain ``nn.Module`` (not
        ``AttentionLayerBase``), so ``super()`` finds none of them; take the
        per-layer spec dict straight from the model when it provides one, then
        top up any ``linear_attn`` layer the model missed.
        """
        kv_cache_spec = super().get_kv_cache_spec()
        model_get_spec = getattr(self.model, "get_kv_cache_spec", None)
        if model_get_spec is not None:
            kv_cache_spec = {**kv_cache_spec, **model_get_spec(self.vllm_config)}
        static_forward_context = self.compilation_config.static_forward_context
        for layer_name, layer in static_forward_context.items():
            if "linear_attn" not in layer_name or layer_name in kv_cache_spec:
                continue
            get_spec = getattr(layer, "get_kv_cache_spec", None)
            if get_spec is None:
                continue
            if spec := get_spec(self.vllm_config):
                kv_cache_spec[layer_name] = spec
        return kv_cache_spec

    def initialize_kv_cache(
        self,
        kv_cache_config: KVCacheConfig,
        kv_cache_allocation_context: AbstractContextManager | None = None,
    ) -> None:
        """Allocate 310P attention caches as NZ and hybrid Mamba caches as ND."""
        kv_cache_config = deepcopy(kv_cache_config)
        self.kv_cache_config = kv_cache_config

        block_sizes = []
        max_num_blocks_per_group = []
        slot_mapping_enabled = []
        circular_buffer_spec = kv_cache_interface.CircularBufferSpec
        for kv_cache_group in kv_cache_config.kv_cache_groups:
            spec = kv_cache_group.kv_cache_spec
            block_sizes.append(spec.block_size)
            layer_spec = next(iter(spec.kv_cache_specs.values())) if isinstance(spec, UniformTypeKVCacheSpecs) else spec
            slot_mapping_enabled.append(
                circular_buffer_spec is None or not isinstance(layer_spec, circular_buffer_spec)
            )
            max_num_blocks = cdiv(self.max_model_len, spec.block_size)
            if spec.block_size <= 128:
                alignment = 128 // spec.block_size
                max_num_blocks = cdiv(max_num_blocks, alignment) * alignment
            if isinstance(spec, MambaSpec):
                # Without prefix caching, hybrid recurrent state uses one page
                # per request plus speculative slots (same as 820_new).
                max_num_blocks = (
                    max_num_blocks if self.cache_config.enable_prefix_caching else 1
                ) + spec.num_speculative_blocks
            max_num_blocks_per_group.append(max_num_blocks)

        self.attn_groups, attn_cg_support, self.kernel_block_sizes = init_attn_backend(
            kv_cache_config, self.vllm_config, self.device
        )
        self._adjust_kernel_block_sizes(kv_cache_config)
        self.block_tables = Ascend310PBlockTables(
            block_sizes=block_sizes,
            max_num_reqs=self.max_num_reqs,
            max_num_batched_tokens=self.max_num_tokens,
            max_num_blocks_per_group=max_num_blocks_per_group,
            device=self.device,
            kernel_block_sizes=self.kernel_block_sizes,
            cp_size=self.dcp_size,
            cp_rank=self.dcp_rank,
            cp_interleave=self.cp_interleave,
            slot_mapping_enabled=slot_mapping_enabled,
        )
        initialize_mamba_ssu_backend(self.vllm_config.mamba_config, self.kv_cache_config)

        cudagraph_mode = self.compilation_config.resolve_cudagraph_mode_and_sizes(
            attn_cg_support.min_cg_support,
            attn_cg_support.min_cg_attn_backend,
            self.decode_query_len,
            use_v2_model_runner=True,
            tensor_parallel_size=self.parallel_config.tensor_parallel_size,
            kv_cache_config=kv_cache_config,
            max_num_reqs=self.max_num_reqs,
        )
        self.cudagraph_manager = ModelAclGraphManager310(
            self.vllm_config,
            self.device,
            cudagraph_mode,
            self.decode_query_len,
            self,
            lora_capture_cases=self.lora_capture_cases,
        )
        check_attention_cp_compatibility(self.vllm_config)
        if isinstance(self.speculator, DraftModelSpeculator):
            self.speculator.set_attn(
                self.model_state,
                self.kv_cache_config,
                self.block_tables,
                self.input_buffers,
                self.attn_groups,
            )
        if self.speculator is not None:
            self.speculator.init_cudagraph_manager(cudagraph_mode)

        shared_layers = get_shared_kv_cache_layers(self.vllm_config)
        self._attn_kv_copy_params = []
        self._attn_kv_storage_ptrs = set()
        allocation_context = kv_cache_allocation_context or nullcontext()
        with allocation_context:
            kv_caches_dict = self._allocate_kv_cache_tensors(kv_cache_config, shared_layers)
        self.kv_caches: list[Any] = []
        bind_kv_cache(
            kv_caches_dict,
            self.compilation_config.static_forward_context,
            self.kv_caches,
        )
        if kv_cache_config.needs_kv_cache_zeroing:
            self._init_kv_zero_meta()
            self.kv_block_zeroer.enabled = self._needs_kv_cache_zeroing_310p(kv_cache_config)
        self.kv_connector = get_kv_connector(self.vllm_config, kv_caches_dict)
        self._install_pc_eager_cudagraph_dispatch()

    def _needs_kv_cache_zeroing_310p(self, kv_cache_config: KVCacheConfig) -> bool:
        """Use the narrow 310P Mamba speculative-decoding zeroing gate."""
        spec_config = self.speculative_config
        if spec_config is None:
            return False
        uses_eagle_block_drop = spec_config.use_eagle_block_drop()
        return bool(
            kv_cache_config.has_mamba_layers and uses_eagle_block_drop and spec_config.num_speculative_tokens > 1
        )

    def _adjust_kernel_block_sizes(self, kv_cache_config: KVCacheConfig) -> None:
        for group_id, kv_cache_group in enumerate(kv_cache_config.kv_cache_groups):
            group_spec = kv_cache_group.kv_cache_spec
            if isinstance(group_spec, UniformTypeKVCacheSpecs):
                specs = tuple(group_spec.kv_cache_specs.values())
            else:
                specs = (group_spec,)
            attention_specs = [spec for spec in specs if isinstance(spec, AttentionSpec)]
            # Hybrid groups may be pure MambaSpec; skip kernel-block sizing.
            if not attention_specs:
                continue
            max_head_size = max(spec.head_size for spec in attention_specs)
            if max_head_size > 256:
                raise NotImplementedError(f"310P paged attention requires head_size <= 256, got {max_head_size}.")
            backend = self.attn_groups[group_id][0].backend
            supported_sizes = [
                block_size
                for block_size in backend.get_supported_kernel_block_sizes()
                if block_size * max_head_size <= _ATTENTION_BLOCK_SIZE_LIMIT
            ]
            if not supported_sizes:
                raise NotImplementedError(
                    f"310P paged attention requires block_size * head_size <= {_ATTENTION_BLOCK_SIZE_LIMIT}."
                )
            self.kernel_block_sizes[group_id] = supported_sizes[0]

    def _init_kv_zero_meta(self) -> None:
        self.kv_block_zeroer = AscendKVBlockZeroer310V2(self.device, is_pin_memory_available())
        self.kv_block_zeroer.init_meta(
            attn_groups_iter=(group for groups in self.attn_groups for group in groups),
            kernel_block_sizes=self.kernel_block_sizes,
            cache_dtype=self.cache_config.cache_dtype,
            runner_only_attn_layers=getattr(self, "runner_only_attn_layers", set()),
            static_forward_context=self.compilation_config.static_forward_context,
        )
        self.kv_block_zeroer.enabled = self._needs_kv_cache_zeroing_310p(self.kv_cache_config)

    def _allocate_kv_cache_tensors(
        self,
        kv_cache_config: KVCacheConfig,
        shared_layers: dict[str, str],
    ) -> dict[str, Any]:
        """Allocate attention caches as NZ and hybrid Mamba state as ND."""
        # UT fixtures may construct via ``object.__new__`` without ``__init__``.
        if not hasattr(self, "_attn_kv_copy_params"):
            self._attn_kv_copy_params = []
        if not hasattr(self, "_attn_kv_storage_ptrs"):
            self._attn_kv_storage_ptrs = set()
        layer_specs: dict[str, KVCacheSpec] = {}
        layer_group_ids: dict[str, int] = {}
        for group_id, kv_cache_group in enumerate(kv_cache_config.kv_cache_groups):
            group_spec = kv_cache_group.kv_cache_spec
            for layer_name in kv_cache_group.layer_names:
                if isinstance(group_spec, UniformTypeKVCacheSpecs):
                    layer_specs[layer_name] = group_spec.kv_cache_specs[layer_name]
                else:
                    layer_specs[layer_name] = group_spec
                layer_group_ids[layer_name] = group_id

        layer_backends = {
            layer_name: group.backend
            for groups in self.attn_groups
            for group in groups
            for layer_name in group.layer_names
        }
        kv_caches: dict[str, Any] = {}
        layout_resolver = getattr(self.cache_config, "get_resolved_kv_cache_layout", None)
        share_slots = (
            get_310p_shared_cache_slots(kv_cache_config.kv_cache_groups, layout_resolver())
            if callable(layout_resolver)
            else {}
        )
        slot_caches: dict[tuple[Any, ...], Any] = {}
        for kv_cache_tensor in kv_cache_config.kv_cache_tensors:
            layer_names = [name for name in get_kv_cache_tensor_layers(kv_cache_tensor) if name not in shared_layers]
            if not layer_names:
                continue
            cache_groups: dict[tuple[Any, ...], list[str]] = {}
            for layer_name in layer_names:
                kv_cache_spec = layer_specs[layer_name]
                cache_key: tuple[Any, ...]
                if isinstance(kv_cache_spec, AttentionSpec):
                    backend = layer_backends[layer_name]
                    group_id = layer_group_ids[layer_name]
                    storage_block_size = get_storage_block_size(kv_cache_spec)
                    kernel_block_size = (
                        storage_block_size
                        if storage_block_size != kv_cache_spec.block_size
                        else self.kernel_block_sizes[group_id]
                    )
                    cache_key = (kv_cache_spec, backend, kernel_block_size)
                else:
                    cache_key = (kv_cache_spec,)
                cache_groups.setdefault(cache_key, []).append(layer_name)

            for cache_key, cache_layer_names in cache_groups.items():
                layer_name = cache_layer_names[0]
                kv_cache_spec = layer_specs[layer_name]
                # On main, descriptor.size is the complete standardized
                # backing size. 310P does not materialize that backing;
                # its private tensors must use the manager's per-layer
                # block count instead.
                num_blocks = kv_cache_config.num_blocks

                if isinstance(kv_cache_spec, AttentionSpec):
                    backend = cache_key[1]
                    kernel_block_size = cache_key[2]
                    if not issubclass(backend, AscendAttentionBackend310):
                        raise TypeError(f"310P selected unexpected attention backend {backend}.")
                    blocks_per_kv_block = kv_cache_spec.block_size // kernel_block_size
                    kv_cache_shape = backend.get_kv_cache_shape(
                        num_blocks * blocks_per_kv_block,
                        kernel_block_size,
                        kv_cache_spec.num_kv_heads,
                        kv_cache_spec.head_size,
                        self.cache_config.cache_dtype,
                    )
                    if getattr(kv_cache_spec, "head_size_v", kv_cache_spec.head_size) != kv_cache_spec.head_size:
                        raise NotImplementedError("310P MRV2 does not support asymmetric K/V head sizes.")
                    # Symmetric NZ only: K/V share the 4D view ``kv_cache_shape[1:]``.
                    kv_view_shape = kv_cache_shape[1:]
                    # Attention layers in the single supported attention group
                    # need separate NZ K/V storage for each layer.
                    for name in cache_layer_names:
                        k_cache = torch_npu.empty_with_format(
                            size=kv_view_shape,
                            dtype=kv_cache_spec.dtype,
                            device=self.device,
                            acl_format=ACL_FORMAT_FRACTAL_NZ,
                        )
                        v_cache = torch_npu.empty_with_format(
                            size=kv_view_shape,
                            dtype=kv_cache_spec.dtype,
                            device=self.device,
                            acl_format=ACL_FORMAT_FRACTAL_NZ,
                        )
                        kv_caches[name] = (k_cache, v_cache)
                        storage_ptr = k_cache.untyped_storage().data_ptr()
                        if storage_ptr not in self._attn_kv_storage_ptrs:
                            self._attn_kv_storage_ptrs.add(storage_ptr)
                            self._attn_kv_copy_params.append((k_cache, v_cache, blocks_per_kv_block))
                elif isinstance(kv_cache_spec, MambaSpec):
                    # Hybrid recurrent state stays ND (int8 raw plus views).
                    # Main's descriptor.size is the entire virtual backing;
                    # private 310P state uses only this layer's pages.
                    if self.supports_compact_mamba_state and not self.cache_config.enable_prefix_caching:
                        num_blocks = self.max_num_reqs
                    raw_size = kv_cache_tensor.size if legacy_shared_by else num_blocks * kv_cache_spec.page_size_bytes

                    def allocate_mamba_cache(
                        raw_size: int = raw_size,
                        kv_cache_spec: MambaSpec = kv_cache_spec,
                        num_blocks: int = num_blocks,
                    ) -> list[torch.Tensor]:
                        raw_tensor = torch.zeros(
                            raw_size,
                            dtype=torch.int8,
                            device=self.device,
                        )
                        state_tensors = []
                        storage_offset_bytes = 0
                        for shape, dtype in zip(
                            kv_cache_spec.shapes,
                            kv_cache_spec.dtypes,
                        ):
                            dtype_size = get_dtype_size(dtype)
                            target_shape = (num_blocks, *shape)
                            stride = torch.empty(target_shape).stride()
                            state_tensors.append(
                                torch.as_strided(
                                    raw_tensor.view(dtype),
                                    size=target_shape,
                                    stride=(stride[0], *stride[1:]),
                                    storage_offset=(storage_offset_bytes // dtype_size),
                                )
                            )
                            storage_offset_bytes += target_shape[0] * stride[0] * dtype_size
                        return state_tensors

                    for name in cache_layer_names:
                        slot_key = (share_slots[name], cache_key) if name in share_slots else None
                        if slot_key is not None and slot_key in slot_caches:
                            kv_caches[name] = slot_caches[slot_key]
                            continue
                        kv_caches[name] = allocate_mamba_cache()
                        if slot_key is not None:
                            slot_caches[slot_key] = kv_caches[name]
                else:
                    raise NotImplementedError(f"Unsupported 310P KV cache spec: {type(kv_cache_spec).__name__}.")

        for layer_name, target_layer_name in shared_layers.items():
            kv_caches[layer_name] = kv_caches[target_layer_name]
        expected_layers = {
            layer_name
            for kv_cache_group in kv_cache_config.kv_cache_groups
            for layer_name in kv_cache_group.layer_names
        }
        if expected_layers != set(kv_caches):
            raise RuntimeError("Some 310P KV cache layers were not initialized.")
        return kv_caches

    def _prepare_prefill_inputs(
        self,
        input_ids: torch.Tensor,
        next_prefill_tokens: torch.Tensor,
        idx_mapping: torch.Tensor,
        query_start_loc: torch.Tensor,
        all_token_ids: torch.Tensor,
        prefill_len: torch.Tensor,
        num_computed_tokens: torch.Tensor,
        *,
        idx_mapping_np: np.ndarray,
        query_start_loc_np: np.ndarray,
    ) -> None:
        # TODO: Refactor this CPU fallback to use Triton Dispatcher after vLLM
        # RFC #45133 lands.
        del idx_mapping, query_start_loc, all_token_ids, prefill_len, num_computed_tokens
        self.input_ids_cpu[: input_ids.shape[0]].zero_()
        self.next_prefill_tokens_cpu.zero_()
        for batch_idx, req_idx in enumerate(idx_mapping_np):
            num_computed = int(self.req_states.num_computed_tokens_np[req_idx])
            req_prefill_len = int(self.req_states.prefill_len.np[req_idx])
            if num_computed >= req_prefill_len:
                continue
            start = int(query_start_loc_np[batch_idx])
            end = int(query_start_loc_np[batch_idx + 1])
            self.input_ids_cpu[start:end] = self.req_states.all_token_ids.cpu[
                req_idx, num_computed : num_computed + end - start
            ]
            next_position = num_computed + end - start
            if next_position < req_prefill_len:
                self.next_prefill_tokens_cpu[req_idx] = self.req_states.all_token_ids.cpu[req_idx, next_position]
        input_ids.copy_(self.input_ids_cpu[: input_ids.shape[0]], non_blocking=True)
        next_prefill_tokens.copy_(self.next_prefill_tokens_cpu, non_blocking=True)

    def _prepare_token_inputs_cpu(
        self,
        idx_mapping: torch.Tensor,
        idx_mapping_np: np.ndarray,
        query_start_loc_np: np.ndarray,
        prefill_len_np: np.ndarray,
        draft_tokens_map: dict[str, list[int]] | None,
        req_ids: list[str],
        num_tokens_after_padding: int,
    ) -> None:
        """Build host-owned inputs, then patch decode tokens from NPU state."""
        draft_tokens_map = draft_tokens_map or {}
        active_draft_tokens_cpu = None
        if draft_tokens_map:
            # Gather real drafts; scheduler values may be placeholders.
            active_draft_tokens_cpu = (
                self.req_states.draft_tokens.index_select(0, idx_mapping.to(torch.int64))
                .to(dtype=self.input_ids_cpu.dtype)
                .cpu()
            )
        self.input_ids_cpu[:num_tokens_after_padding].zero_()
        self.next_prefill_tokens_cpu.zero_()
        decode_req_indices: list[int] = []
        decode_input_indices: list[int] = []
        needs_host_copy = False
        has_prefill = False
        for batch_idx, req_idx_value in enumerate(idx_mapping_np):
            req_idx = int(req_idx_value)
            start = int(query_start_loc_np[batch_idx])
            end = int(query_start_loc_np[batch_idx + 1])
            num_computed = int(self.req_states.num_computed_tokens_np[req_idx])
            prefill_len = int(prefill_len_np[batch_idx])
            if num_computed < prefill_len:
                needs_host_copy = True
                has_prefill = True
                self.input_ids_cpu[start:end].copy_(
                    self.req_states.all_token_ids.cpu[req_idx, num_computed : num_computed + end - start]
                )
                next_position = num_computed + end - start
                if next_position < prefill_len:
                    self.next_prefill_tokens_cpu[req_idx] = self.req_states.all_token_ids.cpu[req_idx, next_position]
                continue

            if end > start:
                decode_req_indices.append(req_idx)
                decode_input_indices.append(start)
            drafts = draft_tokens_map.get(req_ids[batch_idx], ())
            if drafts:
                assert active_draft_tokens_cpu is not None
                needs_host_copy = True
                draft_count = min(len(drafts), end - start - 1)
                self.input_ids_cpu[start + 1 : start + 1 + draft_count].copy_(
                    active_draft_tokens_cpu[batch_idx, :draft_count]
                )

        if needs_host_copy:
            self.input_buffers.input_ids[:num_tokens_after_padding].copy_(
                self.input_ids_cpu[:num_tokens_after_padding], non_blocking=True
            )
        if decode_req_indices:
            num_decode_reqs = len(decode_req_indices)
            pure_decode = (
                not needs_host_copy
                and num_decode_reqs == idx_mapping_np.size
                and np.all(np.diff(query_start_loc_np[: num_decode_reqs + 1]) == 1)
            )
            if pure_decode:
                decode_tokens = self.req_states.last_sampled_tokens.index_select(
                    0, idx_mapping.to(torch.int64)
                ).squeeze(1)
                self.input_buffers.input_ids[:num_decode_reqs].copy_(
                    decode_tokens.to(self.input_buffers.input_ids.dtype)
                )
                return
            self._decode_req_indices.np[:num_decode_reqs] = decode_req_indices
            self._decode_input_indices.np[:num_decode_reqs] = decode_input_indices
            req_indices = self._decode_req_indices.gpu[:num_decode_reqs]
            input_indices = self._decode_input_indices.gpu[:num_decode_reqs]
            self._decode_req_indices.copy_to_gpu(num_decode_reqs)
            self._decode_input_indices.copy_to_gpu(num_decode_reqs)
            decode_tokens = self.req_states.last_sampled_tokens.index_select(0, req_indices).squeeze(1)
            self.input_buffers.input_ids.index_copy_(
                0,
                input_indices,
                decode_tokens.to(self.input_buffers.input_ids.dtype),
            )
        if has_prefill:
            self.req_states.next_prefill_tokens.copy_(self.next_prefill_tokens_cpu, non_blocking=True)

    def _prepare_pos_seq_lens(
        self,
        idx_mapping: torch.Tensor,
        query_start_loc: torch.Tensor,
        num_computed_tokens: torch.Tensor,
        positions: torch.Tensor,
        seq_lens: torch.Tensor,
        *,
        idx_mapping_np: np.ndarray,
        query_start_loc_np: np.ndarray,
        num_scheduled_tokens: np.ndarray,
    ) -> None:
        # TODO: Refactor this CPU fallback to use Triton Dispatcher after vLLM
        # RFC #45133 lands.
        del idx_mapping, query_start_loc, num_computed_tokens
        self.input_buffers.seq_lens_cpu.zero_()
        self.positions_cpu[: positions.shape[0]].zero_()
        for batch_idx, (req_idx, num_tokens) in enumerate(zip(idx_mapping_np, num_scheduled_tokens)):
            num_computed = int(self.req_states.num_computed_tokens_np[req_idx])
            start = int(query_start_loc_np[batch_idx])
            end = start + int(num_tokens)
            self.positions_cpu[start:end] = torch.arange(num_computed, num_computed + num_tokens)
            self.input_buffers.seq_lens_cpu[batch_idx] = num_computed + num_tokens
        positions.copy_(self.positions_cpu[: positions.shape[0]], non_blocking=True)
        seq_lens.copy_(self.input_buffers.seq_lens_cpu, non_blocking=True)

    def _combine_sampled_and_draft_tokens(
        self,
        input_ids: torch.Tensor,
        idx_mapping: torch.Tensor,
        last_sampled_tokens: torch.Tensor,
        query_start_loc: torch.Tensor,
        seq_lens: torch.Tensor,
        prefill_len: torch.Tensor,
        draft_tokens: torch.Tensor,
        cu_num_logits: torch.Tensor,
        num_logits: int,
        num_bonus_tokens: int,
        *,
        idx_mapping_np: np.ndarray,
        query_start_loc_np: np.ndarray,
        seq_lens_np: np.ndarray,
        prefill_len_np: np.ndarray,
    ) -> torch.Tensor:
        cu_num_logits_np = cu_num_logits.detach().cpu().numpy().astype(np.int32, copy=False)
        return combine_sampled_and_draft_tokens_cpu(
            input_ids,
            idx_mapping_np,
            last_sampled_tokens,
            query_start_loc_np,
            seq_lens_np,
            prefill_len_np,
            draft_tokens,
            cu_num_logits_np,
            num_logits,
            num_bonus_tokens,
            device=self.device,
        )

    def prepare_attn(
        self,
        input_batch: Ascend310PInputBatch,
    ) -> tuple[tuple[torch.Tensor, ...], torch.Tensor]:
        # TODO: Refactor block-table preparation to use Triton Dispatcher after
        # vLLM RFC #45133 lands.
        block_tables = self.block_tables.gather_block_tables(
            input_batch.idx_mapping_np,
            num_reqs_padded=input_batch.num_reqs_after_padding,
        )
        input_batch.block_tables_np = tuple(
            table[: input_batch.num_reqs_after_padding] for table in self.block_tables.input_block_tables_cpu
        )
        positions_np = np.zeros(input_batch.num_tokens_after_padding, dtype=np.int64)
        for batch_idx, (start_position, num_scheduled_tokens) in enumerate(
            zip(input_batch.num_computed_tokens_np, input_batch.num_scheduled_tokens)
        ):
            start = int(input_batch.query_start_loc_np[batch_idx])
            end = start + int(num_scheduled_tokens)
            positions_np[start:end] = np.arange(
                start_position,
                start_position + num_scheduled_tokens,
                dtype=np.int64,
            )
        slot_mappings = self.block_tables.compute_slot_mappings(
            input_batch.idx_mapping_np,
            input_batch.query_start_loc_np,
            positions_np,
            num_tokens_padded=input_batch.num_tokens_after_padding,
        )
        return block_tables, slot_mappings

    def sample(
        self,
        hidden_states: torch.Tensor,
        input_batch: Ascend310PInputBatch,
        grammar_output: GrammarOutput | None,
    ):
        # TODO: Refactor 310P sampling to use Triton Dispatcher after vLLM RFC
        # #45133 lands.
        if grammar_output is not None:
            # TODO: Restore structured output support in the next 310P MRV2 iteration.
            raise NotImplementedError("Structured output is not supported by model runner v2 on 310P.")
        logits = self.model.compute_logits(hidden_states[input_batch.logits_indices])
        if input_batch.num_draft_tokens == 0 or self.rejection_sampler is None:
            sampler_output = self.sampler(logits, input_batch)
            can_sample_np = input_batch.seq_lens_np[: input_batch.num_reqs] >= input_batch.prefill_len_np
            self._sampled_tokens_cpu = None
            num_reqs = input_batch.num_reqs
            np.copyto(
                self._num_sampled_staging.np[:num_reqs],
                can_sample_np,
                casting="unsafe",
            )
            self._num_sampled_cpu = self._num_sampled_staging.cpu[:num_reqs]
            self._num_rejected_cpu = self._num_rejected_staging.cpu[:num_reqs]
            num_sampled = self._num_sampled_staging.gpu[:num_reqs]
            self._num_sampled_staging.copy_to_gpu(num_reqs)
            num_rejected = self._num_rejected_staging.gpu[:num_reqs]
            sampler_output.num_sampled = num_sampled
            sampler_output.num_rejected = num_rejected
            return sampler_output, num_sampled, num_rejected

        assert self.speculator is not None
        sampler_output = self.rejection_sampler(
            logits,
            input_batch,
            self.speculator.draft_logits,
        )
        num_reqs = input_batch.num_reqs
        self._sampled_tokens_cpu = self.rejection_sampler.sampled_tokens_cpu[:num_reqs]
        self._num_sampled_cpu = self.rejection_sampler.num_sampled_cpu[:num_reqs]
        self._num_rejected_cpu = self.rejection_sampler.num_rejected_cpu[:num_reqs]
        return sampler_output, sampler_output.num_sampled, sampler_output.num_rejected

    def postprocess_sampled(
        self,
        idx_mapping: torch.Tensor,
        sampled_tokens: torch.Tensor,
        num_sampled: torch.Tensor,
        num_rejected: torch.Tensor,
        query_start_loc: torch.Tensor | None = None,
    ) -> None:
        """Run request bookkeeping on CPU; upload only immediate NPU consumers."""
        # Device arguments remain for upstream API compatibility.
        del num_sampled, num_rejected, query_start_loc
        if self._sampled_tokens_cpu is not None:
            assert self.rejection_sampler is not None
            self.rejection_sampler.synchronize_cpu()
        # Host rejection counts are ready after synchronize_cpu; reuse them in
        # propose() instead of another device→host copy.
        if self.speculator is not None and self._num_rejected_cpu is not None:
            self.speculator._last_num_rejected_cpu = self._num_rejected_cpu
        sampled_tokens_cpu = self._sampled_tokens_cpu
        num_sampled_cpu = _post_update_cpu(
            self._postprocess_idx_mapping_np,
            self._postprocess_query_start_loc_np,
            self.req_states,
            sampled_tokens if sampled_tokens_cpu is None else sampled_tokens_cpu,
            self._num_sampled_cpu,
            self._num_rejected_cpu,
            update_tokens=sampled_tokens_cpu is not None,
        )
        # Chunked-prefill rows have no sample and retain prior state.
        valid_batch_np = np.flatnonzero(self._num_sampled_cpu.numpy() > 0)
        if valid_batch_np.size:
            all_rows_valid = sampled_tokens_cpu is None and valid_batch_np.size == self._postprocess_idx_mapping_np.size
            if all_rows_valid:
                valid_reqs = idx_mapping.to(torch.int64)
                last_tokens = sampled_tokens[:, 0]
            else:
                num_valid = valid_batch_np.size
                self._decode_input_indices.np[:num_valid] = valid_batch_np
                self._decode_req_indices.np[:num_valid] = self._postprocess_idx_mapping_np[valid_batch_np]
                valid_batch = self._decode_input_indices.gpu[:num_valid]
                valid_reqs = self._decode_req_indices.gpu[:num_valid]
                self._decode_input_indices.copy_to_gpu(num_valid)
                self._decode_req_indices.copy_to_gpu(num_valid)
                if sampled_tokens_cpu is None:
                    last_tokens = sampled_tokens.index_select(0, valid_batch)[:, 0]
                else:
                    last_tokens_cpu = torch.stack(
                        [
                            sampled_tokens_cpu[
                                batch_idx,
                                int(self._num_sampled_cpu[batch_idx]) - 1,
                            ]
                            for batch_idx in valid_batch_np
                        ]
                    ).to(torch.int64)
                    last_tokens = last_tokens_cpu.to(self.device, non_blocking=True)
            self.req_states.last_sampled_tokens.index_copy_(
                0,
                valid_reqs,
                last_tokens.to(self.req_states.last_sampled_tokens.dtype).view(-1, 1),
            )
        self.model_state.postprocess_state(
            torch.from_numpy(self._postprocess_idx_mapping_np),
            num_sampled_cpu,
            self.req_states.num_computed_tokens_cpu,
        )
        # Publish host mirrors for draft-prefill prepare (avoid 4× D2H there).
        if self.speculator is not None and self._num_rejected_cpu is not None:
            num_reqs = int(self._num_rejected_cpu.shape[0])
            next_cpu = getattr(self, "next_prefill_tokens_cpu", None)
            if next_cpu is not None:
                next_prefill_np = np.asarray(next_cpu)
            else:
                next_prefill_np = np.zeros(
                    int(self.req_states.next_prefill_tokens.shape[0]),
                    dtype=np.int64,
                )
            max_reqs = int(self.req_states.last_sampled_tokens.shape[0])
            last_sampled_np = np.zeros((max_reqs, 1), dtype=np.int64)
            if valid_batch_np.size and sampled_tokens_cpu is not None:
                for batch_idx in valid_batch_np:
                    req_idx = int(self._postprocess_idx_mapping_np[batch_idx])
                    n = int(self._num_sampled_cpu[batch_idx])
                    last_sampled_np[req_idx, 0] = int(sampled_tokens_cpu[batch_idx, n - 1])
            set_prefill_host_meta(
                num_reqs=num_reqs,
                num_sampled_np=self._num_sampled_cpu.numpy(),
                num_rejected_np=self._num_rejected_cpu.numpy(),
                last_sampled_np=last_sampled_np,
                next_prefill_np=next_prefill_np,
            )

    def _update_seq_lens_cpu(
        self,
        scheduler_output: SchedulerOutput,
        req_ids: list[str],
    ) -> list[int]:
        num_scheduled_tokens = scheduler_output.num_scheduled_tokens
        cached_req_indices = [
            self.req_states.req_id_to_index[req_id] for req_id in scheduler_output.scheduled_cached_reqs.req_ids
        ]
        if self.speculator is not None:
            # Restore post-rejection counts overwritten by the scheduler.
            for req_index in cached_req_indices:
                correct_val = int(self.req_states.num_computed_tokens_cpu[req_index])
                self.req_states.num_computed_tokens_np[req_index] = correct_val
        changed_req_indices = [
            req_index
            for req_index in cached_req_indices
            if int(self.req_states.num_computed_tokens_cpu[req_index])
            != int(self.req_states.num_computed_tokens_np[req_index])
        ]
        for req_index in changed_req_indices:
            self.req_states.num_computed_tokens_cpu[req_index] = self.req_states.num_computed_tokens_np[req_index]

        for i, req_id in enumerate(req_ids):
            req_index = self.req_states.req_id_to_index[req_id]
            num_computed_tokens = self.req_states.num_computed_tokens_cpu[req_index]
            self.input_buffers.seq_lens_cpu[i] = num_computed_tokens + num_scheduled_tokens[req_id]
            self.input_buffers.seq_lens_np[i] = self.input_buffers.seq_lens_cpu[i]
        return changed_req_indices

    def postprocess_num_computed_tokens(self, input_batch: Ascend310PInputBatch) -> None:
        # ``postprocess_sampled`` already advances CPU-owned request state.
        del input_batch
