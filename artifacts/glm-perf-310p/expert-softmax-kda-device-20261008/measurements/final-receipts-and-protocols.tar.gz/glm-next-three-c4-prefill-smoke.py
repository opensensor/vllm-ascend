import json,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
client=ResidentClient('http://127.0.0.1:8001',timeout=900)
protocol=(root/'glm-next-qsa-996-paired-serving.py').read_text()
helpers=protocol[protocol.index('def idle():'):protocol.index('for version in (991,996):')]
import re,urllib.request
exec(compile(helpers,'<complete-stream-accounting>','exec'))
r=json.loads((root/'night-speed-20261008/next-three-paired-serving-v7.json').read_text());assert r['complete']
idle();assert client.request('/pause?mode=wait&clear_cache=true')['status']=='paused';client.resume()
start=time.monotonic()
with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(lambda nonce:stream(128,128,nonce),(40,41,42,43)))
duration=time.monotonic()-start
idle();status=client._acknowledged_rpc('resident_status',matches=client._status_matches)
assert len(status)==4 and all(not s['native_failed'] and not s['graphs_dirty'] and not s['reconstruction']['fallback_dispatches'] for s in status)
report=dict(complete=True,scope='Four simultaneous complete requests on retained candidate; functional graph-size-8 exercise. No parent C4 comparison.',concurrency=4,records=records,wall_s=duration,full_request_aggregate_tok_s=sum(r['completion_tokens'] for r in records)/duration,status=status,paused=client.request('/is_paused',method='GET'))
(root/'night-speed-20261008/next-three-c4-prefill-smoke.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(complete=True,wall_s=duration,aggregate_tok_s=report['full_request_aggregate_tok_s'])),flush=True)
