# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

import copy
from collections.abc import Iterable
from dataclasses import dataclass, replace

import torch
from typing_extensions import Self
from vllm.config import VllmConfig
from vllm.utils.math_utils import cdiv
from vllm.utils.torch_utils import get_dtype_size
from vllm.v1 import kv_cache_interface as vllm_kv_cache_interface
from vllm.v1.core.single_type_kv_cache_manager import FullAttentionManager, SlidingWindowManager
from vllm.v1.kv_cache_interface import (
    FullAttentionSpec,
    KVCacheSpec,
    MambaSpec,
    MLAAttentionSpec,
    SlidingWindowMLASpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.kv_cache_spec_registry import KVCacheSpecRegistry

from vllm_ascend.utils import vllm_version_is


def get_kv_cache_compression_ratio(kv_cache_spec: KVCacheSpec) -> int:
    """Return the MLA compression ratio across vLLM cache-spec APIs."""
    if vllm_version_is("0.28.0"):
        return kv_cache_spec.compress_ratio
    return kv_cache_spec.tokens_per_state


def get_storage_block_size(kv_cache_spec: KVCacheSpec) -> int:
    """Return the physical token rows represented by one scheduler block."""

    def physical_size(spec: KVCacheSpec) -> int:
        configured = getattr(spec, "storage_block_size", None)
        if configured is not None:
            return configured
        if isinstance(spec, MLAAttentionSpec):
            return spec.block_size // get_kv_cache_compression_ratio(spec)
        return spec.block_size

    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        storage_block_sizes = {physical_size(spec) for spec in kv_cache_spec.kv_cache_specs.values()}
        assert len(storage_block_sizes) == 1, "All specs in one KV cache group must use the same storage block size."
        return storage_block_sizes.pop()
    return physical_size(kv_cache_spec)


def is_circular_kv_cache_spec(kv_cache_spec: KVCacheSpec) -> bool:
    """Resolve fixed-block addressing through uniform cache groups."""
    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        specs = tuple(kv_cache_spec.kv_cache_specs.values())
        return bool(specs) and all(is_circular_kv_cache_spec(spec) for spec in specs)
    circular_spec = getattr(vllm_kv_cache_interface, "CircularBufferSpec", None)
    return bool(getattr(kv_cache_spec, "is_circular", False)) or (
        circular_spec is not None and isinstance(kv_cache_spec, circular_spec)
    )


def is_prefix_cacheable(kv_cache_spec: KVCacheSpec) -> bool:
    """Resolve prefix cacheability through uniform cache groups."""
    if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
        return all(is_prefix_cacheable(spec) for spec in kv_cache_spec.kv_cache_specs.values())
    return bool(getattr(kv_cache_spec, "prefix_cacheable", True)) and bool(
        getattr(kv_cache_spec, "participates_in_prefix_caching", True)
    )


def requires_padded_page_layout(kv_cache_specs: Iterable[KVCacheSpec]) -> bool:
    """Whether a pooled recurrent-state view must advance by a physical page.

    GLM's indexer tail and, in historical mode, Mamba states can share
    physical slots with block-stride-addressed attention caches. Padding a
    Mamba spec alone is not enough: ordinary hybrid pools still pack states.
    """
    specs = tuple(kv_cache_specs)
    has_padded_state = any(
        isinstance(spec, (MambaSpec, AscendIndexerKPoolStateSpec))
        and getattr(spec, "page_size_padded", None) is not None
        for spec in specs
    )
    return has_padded_state and any(
        getattr(spec, "indexes_kv_by_block_stride", False) for spec in specs
    )


@dataclass(frozen=True, kw_only=True)
class AscendMLAAttentionSpec(MLAAttentionSpec):
    """MLA cache spec with Ascend-specific layout metadata.

    For SFA, this spec describes only the main MLA cache. The indexer K
    tensor, its quantization scale, and DCP replication are described by a
    separate :class:`AscendSFAIndexerCacheSpec`.
    """

    scale_dim: int = 0
    scale_dtype: torch.dtype = torch.int8
    # Sparse C8 changes the main cache into one packed byte tensor. Keep that
    # main-cache property here; indexer-specific C8 properties belong to the
    # indexer spec.
    cache_sparse_sfa_c8: bool = False
    store_on_host: bool = False
    # Some 310P MLA backends consume the latent cache through vector kernels
    # that require the physical FRACTAL_NZ page layout.  Keep this on the spec
    # so allocation follows backend selection rather than model-name checks.
    use_nz_cache: bool = False
    # Ascend kernels consume padded pages through an explicit physical block
    # stride. vLLM main removed this field from AttentionSpec, but it remains
    # part of the Ascend runner/backend contract.
    indexes_kv_by_block_stride: bool = False

    @property
    def storage_block_size(self) -> int:
        """Return the physical block size consumed by Ascend kernels.

        vLLM #51718 replaced ``MLAAttentionSpec.compress_ratio`` with
        ``AttentionSpec.tokens_per_state`` on main. Both express how many
        logical tokens one physical stored state covers.
        """
        if vllm_version_is("0.28.0"):
            return self.block_size // self.compress_ratio
        return self.block_size // self.tokens_per_state

    @storage_block_size.setter
    def storage_block_size(self, value: int) -> None:
        # vLLM main re-added ``storage_block_size`` as an AttentionSpec field,
        # so the frozen-dataclass __init__ assigns it (object.__setattr__ still
        # invokes this data descriptor). The Ascend spec keeps the value
        # computed from block_size / tokens_per_state, so accept and ignore the
        # field-init assignment.
        pass

    @property
    def real_page_size_bytes(self) -> int:
        return (
            self.storage_block_size
            * self.num_kv_heads
            * (self.head_size * get_dtype_size(self.dtype) + self.scale_dim * get_dtype_size(self.scale_dtype))
        )

    @property
    def unpadded_page_size_bytes(self) -> int:
        return self.real_page_size_bytes

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, MLAAttentionSpec) for spec in specs), (
            "All attention layers in the same KV cache group must be MLAAttentionSpec."
        )
        ascend_layouts = {
            (
                spec.scale_dim,
                spec.scale_dtype,
                spec.cache_sparse_sfa_c8,
                spec.store_on_host,
                spec.alignment,
                get_kv_cache_compression_ratio(spec),
                spec.indexes_kv_by_block_stride,
            )
            for spec in specs
        }
        assert len(ascend_layouts) == 1, (
            "All attention layers in the same KV cache group must use the same Ascend KV cache layout."
        )
        non_causal_multi_token_decode_set = set(spec.non_causal_multi_token_decode for spec in specs)
        assert len(non_causal_multi_token_decode_set) == 1, (
            "Causal target layers and non-causal multi-token draft layers must use separate KV cache groups."
        )
        first_spec = specs[0]
        merged = super().merge(specs)
        return replace(
            merged,
            scale_dim=first_spec.scale_dim,
            scale_dtype=first_spec.scale_dtype,
            alignment=first_spec.alignment,
            cache_sparse_sfa_c8=first_spec.cache_sparse_sfa_c8,
            store_on_host=first_spec.store_on_host,
            indexes_kv_by_block_stride=first_spec.indexes_kv_by_block_stride,
        )

    def max_memory_usage_bytes(self, vllm_config: VllmConfig) -> int:
        max_model_len = vllm_config.model_config.max_model_len
        dcp_world_size = vllm_config.parallel_config.decode_context_parallel_size
        # Note(hc): each dcp rank only need save
        # (max_model_len//dcp_world_size) tokens locally.
        if dcp_world_size > 1:
            max_model_len = cdiv(max_model_len, dcp_world_size)
        return cdiv(max_model_len, self.block_size) * self.page_size_bytes


@dataclass(frozen=True, kw_only=True)
class AscendSFAIndexerCacheSpec(MLAAttentionSpec):
    """KV cache spec for SFA indexer K/scale cache.

    The scheduler should treat this as a full-attention-compatible cache so it
    can share block ids with the MLA cache in the same UniformType group. The
    model runner still allocates it as an independent physical cache tensor.
    """

    scale_dim: int = 0
    scale_dtype: torch.dtype = torch.int8
    cache_sparse_li_c8: bool = False
    cache_dtype_str: str | None = None
    sfa_dcp_replicated_indexer_size: int = 1

    @property
    def page_size_bytes(self) -> int:
        return self.real_page_size_bytes

    @property
    def real_page_size_bytes(self) -> int:
        num_heads_per_page = self.block_size * self.num_kv_heads
        return (
            self.sfa_dcp_replicated_indexer_size
            * num_heads_per_page
            * (self.head_size * get_dtype_size(self.dtype) + self.scale_dim * get_dtype_size(self.scale_dtype))
        )

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, AscendSFAIndexerCacheSpec) for spec in specs), (
            "All attention layers in the same KV cache group must be AscendSFAIndexerCacheSpec."
        )
        cache_dtype_str_set = set(spec.cache_dtype_str for spec in specs)
        dtype_set = set(spec.dtype for spec in specs)
        scale_dim_set = set(spec.scale_dim for spec in specs)
        scale_dtype_set = set(spec.scale_dtype for spec in specs)
        cache_sparse_li_c8_set = set(spec.cache_sparse_li_c8 for spec in specs)
        sfa_dcp_replicated_indexer_size_set = set(spec.sfa_dcp_replicated_indexer_size for spec in specs)
        assert (
            len(cache_dtype_str_set) == 1
            and len(dtype_set) == 1
            and len(scale_dim_set) == 1
            and len(scale_dtype_set) == 1
            and len(cache_sparse_li_c8_set) == 1
            and len(sfa_dcp_replicated_indexer_size_set) == 1
        ), (
            "All SFA indexer cache layers in the same KV cache group must use "
            "the same dtype, scale layout, quantization method, sparse LI C8 "
            "setting and DCP replication size."
        )
        return cls(
            block_size=specs[0].block_size,
            num_kv_heads=specs[0].num_kv_heads,
            head_size=specs[0].head_size,
            dtype=dtype_set.pop(),
            cache_dtype_str=cache_dtype_str_set.pop(),
            scale_dim=scale_dim_set.pop(),
            scale_dtype=scale_dtype_set.pop(),
            cache_sparse_li_c8=cache_sparse_li_c8_set.pop(),
            sfa_dcp_replicated_indexer_size=sfa_dcp_replicated_indexer_size_set.pop(),
        )


@dataclass(frozen=True, kw_only=True)
class AscendSlidingWindowMLASpec(SlidingWindowMLASpec):
    """Sliding window attention with MLA cache format."""

    cache_dtype_str: str | None = None
    # DeepseekV4-only: see MLAAttentionSpec.model_version.
    alignment: int | None = None  # Default to None for no padding.
    compress_ratio: int = 1
    model_version: str | None = None
    indexes_kv_by_block_stride: bool = False

    def __post_init__(self):
        pass

    @property
    def storage_block_size(self) -> int:
        return self.block_size // self.compress_ratio

    @property
    def real_page_size_bytes(self) -> int:
        return self.storage_block_size * self.num_kv_heads * self.head_size * get_dtype_size(self.dtype)

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, AscendSlidingWindowMLASpec) for spec in specs), (
            "All attention layers in the same KV cache group must be AscendSlidingWindowMLASpec."
        )
        cache_dtype_str_set = set(spec.cache_dtype_str for spec in specs)
        compress_ratio_set = set(spec.compress_ratio for spec in specs)
        model_version_set = set(spec.model_version for spec in specs)
        sliding_window_set = set(spec.sliding_window for spec in specs)
        assert (
            len(cache_dtype_str_set) == 1
            and len(compress_ratio_set) == 1
            and len(model_version_set) == 1
            and len(sliding_window_set) == 1
        ), (
            "All attention layers in the same KV cache group must use the same "
            "quantization method, compress ratio, model version and sliding "
            "window size."
        )
        return cls(
            block_size=specs[0].block_size,
            num_kv_heads=specs[0].num_kv_heads,
            head_size=specs[0].head_size,
            dtype=specs[0].dtype,
            page_size_padded=specs[0].page_size_padded,
            sliding_window=sliding_window_set.pop(),
            cache_dtype_str=cache_dtype_str_set.pop(),
            compress_ratio=compress_ratio_set.pop(),
            model_version=model_version_set.pop(),
        )


@dataclass(frozen=True, kw_only=True)
class AscendIndexerKPoolStateSpec(AscendSlidingWindowMLASpec):
    """Paged FP32 state used by an indexer K-pool compressor."""

    cache_role: str = "indexer_state"

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.dtype != torch.float32:
            raise ValueError(f"Indexer K-pool compressor state must use FP32, got {self.dtype}.")
        if self.block_size != self.sliding_window:
            raise ValueError(
                "Indexer K-pool compressor state requires block_size == "
                f"sliding_window, got {self.block_size} and {self.sliding_window}."
            )

    @classmethod
    def merge(cls, specs: list[Self]) -> Self:
        assert all(isinstance(spec, cls) for spec in specs)
        assert all(spec == specs[0] for spec in specs[1:]), (
            "All indexer K-pool compressor-state layers in one cache group must have the same layout and cache role."
        )
        return copy.deepcopy(specs[0])

    def max_memory_usage_bytes(self, vllm_config: VllmConfig) -> int:
        if vllm_config.parallel_config.decode_context_parallel_size > 1:
            # The 310P context-parallel state path keeps one replicated current
            # pool per rank and does not use the ordinary sliding-window
            # admission contract (which rejects DCP outright).
            return self.page_size_bytes
        # The state kernel only reads the current incomplete pool, but the
        # SlidingWindowManager temporarily holds every page touched by one
        # scheduler chunk plus a rollover page. Advertising one page can admit
        # a pool that completes prefill and then stalls when decode crosses the
        # next compression boundary. Keep startup admission consistent with
        # the runtime manager's allocation bound.
        max_model_len = vllm_config.model_config.max_model_len
        max_in_flight_tokens = vllm_config.max_in_flight_tokens
        max_blocks = self.max_admission_blocks_per_request(
            max_in_flight_tokens=max_in_flight_tokens,
            max_model_len=max_model_len,
        )
        return max_blocks * self.page_size_bytes


# Keep the runner's historical name for the GLM compressor-state spec while
# the backend and model use the current StateSpec spelling.
AscendIndexerKPoolTailSpec = AscendIndexerKPoolStateSpec


def register_ascend_kv_cache_specs() -> None:
    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendMLAAttentionSpec,
        manager_class=FullAttentionManager,
        uniform_type_base_spec=FullAttentionSpec,
    )
    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendSFAIndexerCacheSpec,
        manager_class=FullAttentionManager,
        uniform_type_base_spec=FullAttentionSpec,
    )
    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendSlidingWindowMLASpec,
        manager_class=SlidingWindowManager,
        uniform_type_base_spec=SlidingWindowMLASpec,
    )

    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendIndexerKPoolStateSpec,
        manager_class=SlidingWindowManager,
        uniform_type_base_spec=SlidingWindowMLASpec,
    )

    # Qwen4Exp QSA raw index-key ring (plan T1.4). The pinned vLLM lane lacks
    # CircularBufferSpec, so the ring is materialized as a key-only Ascend spec
    # (its own uniform group). The compressed QSA index rides the upstream
    # MLAAttentionSpec (already registered). Import lazily to keep this core
    # module free of the model package's heavier imports at register time.
    from vllm_ascend.models.qwen4_exp.kv_cache import AscendQSARawRingSpec

    KVCacheSpecRegistry.register(
        kvcache_spec_cls=AscendQSARawRingSpec,
        manager_class=FullAttentionManager,
        uniform_type_base_spec=AscendQSARawRingSpec,
    )
