# Standard
import os
import threading
import time
from enum import Enum
from typing import Any

import torch
from vllm.config import ParallelConfig
from vllm.distributed.parallel_state import get_dp_group
from vllm.logger import logger

from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend.base import (
    QOS_VALUE_MAX,
    QOS_VALUE_MIN,
    Backend,
    BatchResultShapeError,
    get_scheduler_device_id,
    parse_qos_from_extra_config,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend.layerwise_keys import LayerwiseKeyBuilder


def _is_device_sdma() -> bool:
    config_path = os.getenv("MMC_LOCAL_CONFIG_PATH")
    if not config_path:
        raise ValueError("The environment variable 'MMC_LOCAL_CONFIG_PATH' is not set.")
    with open(config_path, encoding="utf-8") as config_file:
        for line in config_file:
            line = line.strip()
            if not line or line.startswith(("#", ";")):
                continue
            key, separator, value = line.partition("=")
            if separator and key.strip() == "ock.mmc.local_service.protocol":
                return value.strip() == "device_sdma"
    return False


MEMCACHE_THREAD_START_WAIT_S = 0.1


def _validate_device_ub_qos() -> None:
    """Validate MF_DEVICE_UB_QOS used by the MemCache store transfers.

    Only integers in [QOS_VALUE_MIN, QOS_VALUE_MAX] are supported; MemCache
    silently falls back to its default QoS on invalid values, so fail fast
    with a clear error instead.
    """
    qos_str = os.getenv("MF_DEVICE_UB_QOS")
    if qos_str is None or not qos_str.strip():
        return
    try:
        qos = int(qos_str)
    except ValueError as e:
        raise ValueError(
            f"Invalid MF_DEVICE_UB_QOS value {qos_str!r}: QoS must be an integer in [{QOS_VALUE_MIN}, {QOS_VALUE_MAX}]."
        ) from e
    if not (QOS_VALUE_MIN <= qos <= QOS_VALUE_MAX):
        raise ValueError(
            f"Invalid MF_DEVICE_UB_QOS value {qos}: QoS must be an integer in [{QOS_VALUE_MIN}, {QOS_VALUE_MAX}]."
        )


class MmcDirect(Enum):
    COPY_L2G = 0
    COPY_G2L = 1
    COPY_G2H = 2
    COPY_H2G = 3


# =========================================================================
# Layerwise transfer protocol
# =========================================================================
# The generic layers (worker / scheduler / layout) resolve these functions
# through backend/__init__.py:get_layerwise_protocol -- a module-convention
# lookup, they never import this module by name. The key strings are wire
# formats shared with deployed clusters: a single character of drift turns
# hits into misses after an upgrade.
# tests/ut/distributed/ascend_store/test_backend.py locks the key formats
# with snapshot assertions.

LAYERWISE_DATA_PLANE = "gva"


def bind_layerwise_keys(
    *,
    vllm_config: Any,
    kv_cache_config: Any,
    model_name: str,
    use_hybrid: bool,
    grouped_block_size: list[int],
) -> LayerwiseKeyBuilder:
    """Bind GVA key identity behind the same interface as block-key stores."""
    num_groups = len(grouped_block_size)
    pp_size = vllm_config.parallel_config.pipeline_parallel_size

    def make_key(group: int, block_hash: str, head: int, stage: int) -> str:
        return make_full_key(model_name, group, block_hash, head, num_groups, stage, pp_size)

    return LayerwiseKeyBuilder(make_key, pp_size)


def extract_layout_config(extra_config: dict[str, Any]) -> dict[str, Any] | None:
    """Return the connector's extra config when it opts into the layerwise
    transfer, None otherwise.

    Called by the generic layout layer through the backend registry; the
    protocol itself owns the opt-in check so the layout layer never spells
    out the gate.
    """
    if extra_config.get("use_layerwise", False):
        return extra_config
    return None


def make_full_key(
    model_name: str,
    group_id: int,
    block_hash_hex: str,
    head_or_tp_rank: int,
    num_groups: int,
    pp_rank: int = 0,
    pp_size: int = 1,
) -> str:
    """Full-block key for the layerwise transfer.

    Single-group models use the PR #11585 format (model@hash@rank) for
    backward compatibility. Multi-group models include group_id
    (model@group_id@hash@rank) to distinguish groups.
    """
    pp_tag = f"@pp{pp_rank}" if pp_size > 1 else ""
    if num_groups > 1:
        return f"{model_name}@{group_id}{pp_tag}@{block_hash_hex}@{head_or_tp_rank}"
    return f"{model_name}{pp_tag}@{block_hash_hex}@{head_or_tp_rank}"


def make_partial_key(
    model_name: str,
    req_id: str,
    group_id: int,
    block_index: int,
    end_token: int,
    head_or_tp_rank: int,
    pp_rank: int = 0,
    pp_size: int = 1,
) -> str:
    pp_tag = f"@pp{pp_rank}" if pp_size > 1 else ""
    return f"{model_name}@partial@{req_id}@{group_id}@{block_index}@{end_token}{pp_tag}@{head_or_tp_rank}"


def make_hit_check_keys(
    model_name: str,
    group_id: int,
    block_hash_hex: str,
    num_ranks: int,
    num_groups: int,
    pp_size: int = 1,
) -> list[str]:
    """All-rank keys for scheduler-side hit check.

    Returns one key per PP stage and head_or_tp_rank.
    """
    return [
        make_full_key(model_name, group_id, block_hash_hex, rank, num_groups, pp_rank, pp_size)
        for pp_rank in range(pp_size)
        for rank in range(num_ranks)
    ]


def _inject_device_ub_qos(extra_config: dict[str, Any] | None) -> None:
    """Inject the QoS from kv_connector_extra_config into MF_DEVICE_UB_QOS.

    The QoS is parsed from the connector's extra_config passed by the pool
    worker; the call is a no-op when no QoS is configured. An explicit
    extra-config value overrides a value already present in the environment.
    """
    qos = parse_qos_from_extra_config(extra_config)
    if qos is None:
        return
    current = os.getenv("MF_DEVICE_UB_QOS")
    if current is not None and current.strip() and current.strip() != str(qos):
        logger.warning(
            "Overriding MF_DEVICE_UB_QOS=%s with qos=%s from kv_connector_extra_config.",
            current.strip(),
            qos,
        )
    os.environ["MF_DEVICE_UB_QOS"] = str(qos)
    logger.info("Injected MF_DEVICE_UB_QOS=%d from kv_connector_extra_config.", qos)


class MemcacheBackend(Backend):
    def __init__(
        self,
        parallel_config: ParallelConfig,
        device_id: int | None = None,
        init_bm: bool = True,
        lazy_init: bool = False,
        extra_config: dict[str, Any] | None = None,
        dp_init_barrier: bool = True,
    ):
        if not isinstance(dp_init_barrier, bool):
            raise ValueError("memcache_dp_init_barrier in kv_connector_extra_config must be a boolean.")
        _inject_device_ub_qos(extra_config)
        _validate_device_ub_qos()
        self.device_id = torch.npu.current_device() if device_id is None else device_id
        self._init_bm = init_bm
        self._lazy_init = lazy_init and _is_device_sdma()
        # Lazy initialization can be triggered independently by each DP rank.
        self._dp_init_barrier = dp_init_barrier and parallel_config.data_parallel_size > 1 and not self._lazy_init

        self.store: Any | None = None
        self._store_initialized = False
        self._store_init_lock = threading.Lock()
        self._pending_buffers: tuple[list[int], list[int]] | None = None

        if not self._lazy_init:
            self.store = self._setup_store()
            self._store_initialized = True

    def ensure_initialized(self):
        if self._store_initialized:
            return

        with self._store_init_lock:
            if self._store_initialized:
                return

            logger.info("Initializing Memcache store. device_id=%d", self.device_id)
            self.store = self._setup_store()
            self._store_initialized = True
            self._register_buffers_if_needed()

    def _setup_store(self):
        try:
            from memcache_hybrid import DistributedObjectStore  # type: ignore
        except ImportError as e:
            raise ImportError(
                "Please install memcache by following the instructions at "
                "https://gitee.com/ascend/memfabric_hybrid "  # noqa: E501
                "to run vLLM with MemcacheConnector."
            ) from e

        # Scheduler clients are metadata-only. Binding them with set_device()
        # creates an otherwise unnecessary EngineCore NPU context.
        if self._init_bm:
            self.set_device()
        store = DistributedObjectStore()

        try:
            res = store.init(self.device_id, init_bm=self._init_bm)
        except ValueError as e:
            logger.error("Configuration loading failed. error=%s. Check memcache config and environment.", e)
            raise
        except Exception as exc:
            logger.error("Store initialization failed. error=%s. Check memcache setup and dependencies.", exc)
            raise

        assert res == 0
        if self._init_bm and self._dp_init_barrier:
            # Keep early ranks from entering NPU work while peers are still
            # establishing MemCache channels. Metadata-only clients must not join.
            logger.info("Waiting for all DP MemCache initializations")
            torch.distributed.barrier(group=get_dp_group().cpu_group)
            logger.info("All DP MemCache initializations completed")
        time.sleep(MEMCACHE_THREAD_START_WAIT_S)
        return store

    @classmethod
    def create_scheduler_client(cls, parallel_config: ParallelConfig):
        return cls(
            parallel_config,
            device_id=get_scheduler_device_id(parallel_config),
            init_bm=False,
        )

    def init_store(self, init_bm: bool = True):
        if self.store is not None:
            return
        self._init_bm = init_bm
        self.store = self._setup_store()
        self._store_initialized = True
        self._register_buffers_if_needed()

    def set_device(self):
        torch.npu.set_device(self.device_id)

    def register_buffer(self, ptrs: list[int], sizes: list[int]):
        self._pending_buffers = (list(ptrs), list(sizes))
        self._register_buffers_if_needed()

    def unregister_buffer(self, ptrs: list[int], sizes: list[int]):
        if len(ptrs) != len(sizes):
            raise ValueError(f"ptrs and sizes must have the same length: {len(ptrs)} != {len(sizes)}")
        if not self._store_initialized:
            return
        assert self.store is not None
        for ptr, size in zip(ptrs, sizes):
            self.store.unregister_buffer(ptr, size)

    def _register_buffers_if_needed(self):
        if self._pending_buffers is None or not self._store_initialized:
            return
        assert self.store is not None
        ptrs, sizes = self._pending_buffers
        for ptr, size in zip(ptrs, sizes):
            self.store.register_buffer(ptr, size)
        self._pending_buffers = None

    def exists(self, keys: list[str]) -> list[int]:
        if self._lazy_init and not self._store_initialized:
            logger.debug(
                "MemcacheBackend.exists called before store initialization; treating %d keys as missing.",
                len(keys),
            )
            return [0] * len(keys)
        assert self.store is not None
        return self.store.batch_is_exist(keys)

    def batch_get_key_info(self, keys: list[str]) -> list[Any]:
        if self._lazy_init and not self._store_initialized:
            logger.debug(
                "MemcacheBackend.batch_get_key_info called before store initialization; "
                "returning empty list for %d keys.",
                len(keys),
            )
            return []
        assert self.store is not None
        return self.store.batch_get_key_info(keys)

    def batch_get_into_buffers(
        self,
        keys: list[str],
        addrs: list[int],
        sizes: list[int],
        direction: int = MmcDirect.COPY_G2L.value,
    ) -> list[int] | None:
        if self._lazy_init and not self._store_initialized:
            logger.error(
                "Failed to get %d keys out of %d. Store is not initialized; "
                "call put() first to trigger initialization.",
                len(keys),
                len(keys),
            )
            logger.debug("Failed to get key details. keys=%s", keys)
            return None
        assert self.store is not None
        try:
            res = self.store.batch_get_into(keys, addrs, sizes, direction)
            failed_codes = [int(value) for value in res if value != 0]
            failed_count = len(failed_codes)
            if failed_count:
                error_codes = sorted(set(failed_codes))
                logger.error(
                    "Failed to get %d keys out of %d. error_codes=%s. Check key existence and memory state.",
                    failed_count,
                    len(keys),
                    error_codes,
                )
                logger.debug("Failed to get key details. keys=%s, result=%s", keys, res)
            return res
        except Exception as e:
            logger.error(
                "Failed to get %d keys out of %d. type=%s, error=%s. Check store state and network.",
                len(keys),
                len(keys),
                type(e).__name__,
                e,
            )
            logger.debug("Failed to get key details. keys=%s", keys)
            return None

    def batch_is_readable(self, keys: list[str]) -> list[bool]:
        """Map valid MemCache GVA metadata to the common readability contract."""
        if self._lazy_init and not self._store_initialized:
            return [False] * len(keys)
        key_infos = self.batch_get_key_info(keys)
        if len(key_infos) != len(keys):
            raise BatchResultShapeError(f"batch_get_key_info returned {len(key_infos)} results for {len(keys)} keys")
        readable = []
        for key_info in key_infos:
            try:
                size = int(key_info.size())
                gvas = key_info.gva_list()
                readable.append(size > 0 and bool(gvas) and int(gvas[0]) > 0)
            except (AttributeError, IndexError, TypeError, ValueError) as exc:
                raise BatchResultShapeError("batch_get_key_info returned invalid key metadata") from exc
        return readable

    def batch_alloc(self, keys: list[str], sizes: list[int], lease_ttl_ms: int = 0) -> list[int]:
        self.ensure_initialized()
        assert self.store is not None
        return self.store.batch_alloc(keys, sizes, 1, lease_ttl_ms)

    def batch_add_lease(self, keys: list[str], lease_ttl_ms: int = 0) -> list[int]:
        assert self.store is not None
        return self.store.batch_add_lease(keys, lease_ttl_ms)

    def batch_remove_lease(self, keys: list[str]) -> int:
        assert self.store is not None
        return self.store.batch_remove_lease(keys)

    def batch_write_finish(self, keys: list[str], results: list[int]) -> list[int]:
        assert self.store is not None
        finish = getattr(self.store, "batch_write_finish", None)
        if finish is None:
            # Older MemCache releases publish writes directly in batch_copy.
            return [0] * len(keys)
        return finish(keys, results)

    def get(
        self,
        key: list[str],
        addr: list[list[int]],
        size: list[list[int]],
    ):
        if self._lazy_init and not self._store_initialized:
            logger.error(
                "Failed to get %d keys out of %d. Store is not initialized; "
                "call put() first to trigger initialization.",
                len(key),
                len(key),
            )
            logger.debug("Failed to get key details. keys=%s", key)
            return
        assert self.store is not None
        try:
            res = self.store.batch_get_into_layers(key, addr, size, MmcDirect.COPY_G2L.value)
            failed_codes = [int(value) for value in res if value != 0]
            failed_count = len(failed_codes)
            if failed_count:
                error_codes = sorted(set(failed_codes))
                logger.error(
                    "Failed to get %d keys out of %d. error_codes=%s. Check key existence and memory state.",
                    failed_count,
                    len(key),
                    error_codes,
                )
                logger.debug("Failed to get key details. keys=%s, result=%s", key, res)
            return res
        except Exception as e:
            logger.error(
                "Failed to get %d keys out of %d. type=%s, error=%s. Check store state and network.",
                len(key),
                len(key),
                type(e).__name__,
                e,
            )
            logger.debug("Failed to get key details. keys=%s", key)
            return None

    def put(
        self,
        key: list[str],
        addr: list[list[int]],
        size: list[list[int]],
    ):
        self.ensure_initialized()
        assert self.store is not None
        try:
            res = self.store.batch_put_from_layers(key, addr, size, MmcDirect.COPY_L2G.value)
            failed_codes = [int(value) for value in res if value != 0]
            failed_count = len(failed_codes)
            if failed_count:
                error_codes = sorted(set(failed_codes))
                logger.error(
                    "Failed to put %d keys out of %d. error_codes=%s. Check memory and store capacity.",
                    failed_count,
                    len(key),
                    error_codes,
                )
                logger.debug("Failed to put key details. keys=%s, result=%s", key, res)
                if self._lazy_init:
                    logger.warning("First DSV4(compress) request failure is expected. This is normal behavior.")
        except Exception as e:
            logger.error(
                "Failed to put %d keys out of %d. type=%s, error=%s. Check store state and memory.",
                len(key),
                len(key),
                type(e).__name__,
                e,
            )
            logger.debug("Failed to put key details. keys=%s", key)
            if self._lazy_init:
                logger.warning("First DSV4(compress) request failure is expected. This is normal behavior.")

    def put_from(
        self,
        key: str,
        addr: int,
        size: int,
        direction: int = MmcDirect.COPY_L2G.value,
    ) -> int | None:
        self.ensure_initialized()
        assert self.store is not None
        try:
            res = self.store.put_from(key, addr, size, direction)
            if res != 0:
                logger.error(
                    "Failed to put key %s. error_code=%s. Check memory and store capacity.",
                    key,
                    res,
                )
            return res
        except Exception as e:
            logger.error(
                "Failed to put key %s. type=%s, error=%s. Check store state and memory.",
                key,
                type(e).__name__,
                e,
            )
            return None
