#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
import gc

import psutil
import torch
import torch_npu
from vllm.logger import logger
from vllm.utils.mem_constants import GiB_bytes
from vllm.utils.mem_utils import MemorySnapshot, memory_profiling
from vllm.utils.torch_utils import set_random_seed  # noqa: E402
from vllm.v1.core.kv_cache_utils import get_kv_cache_groups

import vllm_ascend.envs as envs_ascend
from vllm_ascend._310p.kv_cache_sharing import get_310p_shared_cache_slots
from vllm_ascend._310p.model_runner_310p import NPUModelRunner310
from vllm_ascend.utils import is_rc_device
from vllm_ascend.worker.worker import NPUWorker, init_workspace_manager


class NPUWorker310(NPUWorker):
    def _scale_kv_cache_memory_for_multi_group(self, available_memory: int) -> int:
        # Qwen4Exp's compact-state runner materializes only a fixed number of
        # recurrent-state slots, while the scheduler still addresses virtual
        # Mamba blocks.  Let the parent translate the physical attention
        # budget into that logical planner budget before considering the
        # generic cross-group sharing shortcut below.  Returning the raw
        # budget here strands most of the attention cache whenever the Mamba
        # page is larger than an attention page (especially with FP32 state).
        if getattr(self.model_runner, "supports_compact_mamba_state", False):
            return super()._scale_kv_cache_memory_for_multi_group(available_memory)

        kv_cache_spec = self.get_kv_cache_spec()
        layout_resolver = getattr(self.vllm_config.cache_config, "get_resolved_kv_cache_layout", None)
        if isinstance(kv_cache_spec, dict) and callable(layout_resolver):
            groups = get_kv_cache_groups(self.vllm_config, kv_cache_spec)
            share_slots = get_310p_shared_cache_slots(groups, layout_resolver()) if groups else {}
        else:
            share_slots = {}
        if share_slots:
            # Both 310P runners alias compatible Mamba groups at each slot,
            # matching the v0.28 shared_by allocation.
            logger.info_once("310P reuses uniform KV cache group slots without extra budget scaling.", scope="local")
            return available_memory
        return super()._scale_kv_cache_memory_for_multi_group(available_memory)

    def _create_model_runner(self):
        if self.use_v2_model_runner:
            from vllm_ascend._310p.worker.v2.model_runner import NPUModelRunner310V2

            model_runner = NPUModelRunner310V2(self.vllm_config, self.device)
            logger.info_once("Using NPUWorker310 and NPUModelRunner310V2.")
            return model_runner

        model_runner = NPUModelRunner310(self.vllm_config, self.device)
        logger.info_once("Using NPUWorker310 and NPUModelRunner310.")
        return model_runner

    def init_device(self):
        self.device = self._init_device()
        torch_npu.npu.set_compile_mode(jit_compile=False)

        init_workspace_manager(self.device, num_ubatches=1)
        self.model_runner = self._create_model_runner()
        self._maybe_emit_qwen4exp_runlog()

    def _is_qwen4exp_model(self) -> bool:
        """True when this worker is serving the Qwen4Exp (Qwen3.8-Flash-Next) model."""
        architectures = getattr(self.model_config, "architectures", None) or []
        return any("Qwen4Exp" in arch or "qwen4_exp" in arch.lower() for arch in architectures)

    def _maybe_emit_qwen4exp_runlog(self) -> None:
        """Additive, guarded Qwen4Exp run-log hook (plan TOBS, R13).

        Emits the machine-readable run-log summary (rank identity + token limits)
        only on the Qwen4Exp path. Fully wrapped in try/except so it never regresses
        worker init; a failure here is logged and swallowed.
        """
        try:
            if not self._is_qwen4exp_model():
                return
            from vllm_ascend.observability.qwen38_runlog import RankIdentity, RunLog

            rank = getattr(self, "rank", 0)
            world_size = getattr(self.parallel_config, "world_size", 1)
            local_rank = getattr(self, "local_rank", None)
            runlog = RunLog(run_id=f"qwen4exp-rank{rank}", world_size=world_size, rank=rank)
            runlog.set_rank_identity(
                RankIdentity(rank=rank, world_size=world_size, local_rank=local_rank)
            )
            max_model_len = getattr(self.model_config, "max_model_len", None)
            if max_model_len is not None:
                runlog.set_token_limits(
                    max_model_len=max_model_len,
                    max_num_batched_tokens=getattr(self.scheduler_config, "max_num_batched_tokens", None),
                    max_num_seqs=getattr(self.scheduler_config, "max_num_seqs", None),
                )
            logger.info_once("Qwen4Exp run-log:\n%s", runlog.human_summary(), scope="local")
        except Exception as exc:  # noqa: BLE001 - diagnostic hook must never fail init
            logger.warning("Qwen4Exp run-log hook failed (non-fatal): %s", exc)

    def save_sharded_state(
        self,
        path: str,
        pattern: str | None = None,
        max_size: int | None = None,
    ) -> None:
        from vllm_ascend._310p.sharded_state_loader_310p import ShardedStateLoader310

        ShardedStateLoader310.save_model(
            self.model_runner.model,
            path,
            pattern=pattern,
            max_size=max_size,
        )

        ShardedStateLoader310.generate_quant_description(
            self.model_runner.model,
            path,
            self.vllm_config.quant_config,
        )

    @torch.inference_mode()
    def determine_available_memory(self) -> int:
        """Profiles the peak memory usage of the model to determine how much
        memory can be used for KV cache without OOMs.

        The engine will first conduct a profiling of the existing memory usage.
        Then, it calculates the free memory that can be used for KV cache in
        bytes.
        """
        GiB = lambda b: b / GiB_bytes

        # A manually qualified cache budget already accounts for weights,
        # activations, recurrent-state pools, and operator workspaces.  The
        # generic worker still executes a maximum-token profile pass for
        # compilation in this case, but 310P runs these native operators with
        # JIT compilation disabled and performs its decode warmup during graph
        # capture.  Repeating the large prefill here adds startup latency and
        # does not warm GDN attention because profile metadata omits it.
        if kv_cache_memory_bytes := self.cache_config.kv_cache_memory_bytes:
            self.available_kv_cache_memory_bytes = int(kv_cache_memory_bytes)
            logger.info_once(
                "Using explicitly qualified KV cache memory: %.2f GiB; skipping 310P memory profile forward.",
                GiB(self.available_kv_cache_memory_bytes),
                scope="local",
            )
            return self._apply_kvpp_memory_budget(
                self._apply_kv_offload_decode_memory_constraints(self.available_kv_cache_memory_bytes)
            )

        # Execute a forward pass with dummy inputs to profile the memory usage
        # of the model.
        with memory_profiling(
            self.init_snapshot,
            weights_memory=int(self.model_runner.model_memory_usage),
        ) as profile_result:
            self.model_runner.profile_run()
            free_memory, total_memory = torch.npu.mem_get_info()
            # The host memory or device memory for RC devices refers to the available portion of memory
            # which cannot be obtained via torch.npu.mem_get_info()
            if is_rc_device():
                free_memory = psutil.virtual_memory().available
            torch_memory = torch.npu.memory_reserved()
            non_torch_memory_before_empty_cache = total_memory - free_memory - torch_memory

        self.non_torch_memory = profile_result.non_torch_increase
        self.peak_activation_memory = profile_result.torch_peak_increase
        non_torch_memory_cleared_by_empty_cache = non_torch_memory_before_empty_cache - self.non_torch_memory

        free_gpu_memory = profile_result.after_profile.free_memory
        assert self.init_snapshot.free_memory > free_gpu_memory, (
            "Error in memory profiling. "
            f"Initial free memory {GiB(self.init_snapshot.free_memory)} GiB, "
            f"current free memory {GiB(free_gpu_memory)} GiB. "
            "This happens when other processes sharing the same container "
            "release GPU memory while vLLM is profiling during initialization. "
            "To fix this, ensure consistent GPU memory allocation or "
            "isolate vLLM in its own container."
        )

        # Keep only a fraction of the profiled headroom for KV and Mamba cache;
        # the rest is left to operator workspaces, which are large on this SoC.
        # Half is the default because it avoids OOM at the default
        # gpu_memory_utilization, but it is also what caps the servable context:
        # raising gpu_memory_utilization cannot make up for it, since the reserve
        # scales with the budget. VLLM_ASCEND_KV_CACHE_FRACTION trades that
        # margin back for context on a box where the headroom has been measured.
        # The 310P RC device shares the host memory and device memory.
        # Therefore, the space available for allocating KV cache and Mamba cache needs to be calculated
        # based on the already occupied space of the system memory.
        kv_cache_fraction = envs_ascend.VLLM_ASCEND_KV_CACHE_FRACTION
        if not 0.0 < kv_cache_fraction <= 1.0:
            raise ValueError(
                f"VLLM_ASCEND_KV_CACHE_FRACTION must be in (0, 1], got {kv_cache_fraction}"
            )

        if is_rc_device():
            vm = psutil.virtual_memory()
            profiled_headroom = self.requested_memory - (vm.total - vm.available)
        else:
            profiled_headroom = (
                self.requested_memory - profile_result.non_kv_cache_memory - non_torch_memory_cleared_by_empty_cache
            )
        self.available_kv_cache_memory_bytes = int(profiled_headroom * kv_cache_fraction)

        self.available_kv_cache_memory_bytes = self._scale_kv_cache_memory_for_multi_group(
            self.available_kv_cache_memory_bytes,
        )

        logger.debug(profile_result)
        logger.info_once(
            "Available KV cache memory: %.2f GiB (%.0f%% of profiled headroom, rest reserved for workspace)",
            GiB(self.available_kv_cache_memory_bytes),
            kv_cache_fraction * 100,
            scope="local",
        )
        return int(self.available_kv_cache_memory_bytes)

    def _warm_up_atb(self):
        # 310p device do not support torch_npu._npu_matmul_add_fp32 atb ops
        logger.info_once("Skip warm-up atb ops for 310P device.")

    def _init_device(self):
        device = torch.device(f"npu:{self.local_rank}")
        torch.npu.set_device(device)

        # This lazy import avoids torch_npu re-initialization in patch
        # Note that this should be imported after torch.npu.set_device
        # to avoid repeated set_device in extra processes

        gc.collect()
        torch.npu.empty_cache()

        # take current memory snapshot
        self.init_snapshot = MemorySnapshot(device=device)
        self.requested_memory = self.init_snapshot.total_memory * self.cache_config.gpu_memory_utilization
        if is_rc_device():
            self.init_snapshot.free_memory = psutil.virtual_memory().available
            logger.info_once("Root Complex (RC) mode: host and device memory are shared.")
        if self.init_snapshot.free_memory < self.requested_memory:
            GiB = lambda b: round(b / GiB_bytes, 2)
            raise ValueError(
                f"Free memory on device "
                f"({GiB(self.init_snapshot.free_memory)}/"
                f"{GiB(self.init_snapshot.total_memory)} GiB) on startup "
                f"is less than desired GPU memory utilization "
                f"({self.cache_config.gpu_memory_utilization}, "
                f"{GiB(self.requested_memory)} GiB). Decrease GPU memory "
                f"utilization or reduce GPU memory used by other processes."
            )

        if (
            self.parallel_config.data_parallel_size > 1
            and self.parallel_config.data_parallel_size_local > 0
            and self.parallel_config.distributed_executor_backend not in ["ray", "external_launcher"]
            and self.vllm_config.parallel_config.data_parallel_backend != "ray"
            and self.vllm_config.parallel_config.nnodes_within_dp == 1
        ):
            visible_device_count = torch.npu.device_count() if torch.npu.is_available() else 0
            assert self.parallel_config.local_world_size <= visible_device_count, (
                f"local_world_size ({self.parallel_config.local_world_size}) must "
                f"be less than or equal to the number of visible devices "
                f"({visible_device_count})."
            )

        # Initialize the distributed environment.
        self._init_worker_distributed_environment()
        # Set random seed.
        set_random_seed(self.model_config.seed)

        return device
