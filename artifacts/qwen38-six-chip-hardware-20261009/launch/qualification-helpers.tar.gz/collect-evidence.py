import gzip,json,hashlib
from pathlib import Path
r=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
out=r/'export'
out.mkdir(exist_ok=True)
for name in sorted(d.name for d in r.iterdir() if d.is_dir() and (d / 'result.json').is_file()):
 for f in (r/name).iterdir():
  if f.is_file():
   target=out/(name+'-'+f.name+'.gz')
   with gzip.open(target,'wb') as dst:dst.write(f.read_bytes())
for f in r.iterdir():
 if f.is_file() and (f.suffix in ['.log','.json','.jsonl','.txt'] or f.name.endswith('.pid')):
  with gzip.open(out/(f.name+'.gz'),'wb') as dst:dst.write(f.read_bytes())
checks={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in out.iterdir() if f.is_file() and f.name != 'SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(checks,indent=2))
print(len(checks),'evidence files exported')
