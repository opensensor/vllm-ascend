import hashlib,importlib,json,re,sys,urllib.request
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
client=ResidentClient('http://127.0.0.1:8001')
with urllib.request.urlopen(client.base_url+'/metrics',timeout=30) as response:metrics=response.read().decode()
counts=[float(v) for v in re.findall(r'^vllm:num_requests_(?:running|waiting)(?:\{[^\n]*\})?\s+([0-9.eE+-]+)$',metrics,re.M)]
assert counts and not any(counts),'User request active; defer'
assert client.request('/pause?mode=wait&clear_cache=false')['status']=='paused'
build=root/'build-qsa-v996';sys.path.insert(0,str(build))
provenance=json.loads((build/'provenance.json').read_text())
for path,digest in provenance['files'].items():assert hashlib.sha256((build/path).read_bytes()).hexdigest()==digest,path
report=root/'qsa-v996-free-gates.json';assert not report.exists()
payload=dict(complete=False,comparator='v991 shared.bin through the v996 tiling/launch wrapper',provenance=provenance,records=[])
def save():report.write_text(json.dumps(payload,indent=2)+'\n')
try:
 import torch,torch_npu
 torch.npu.set_device(0);torch_npu.npu.set_compile_mode(jit_compile=False)
 from vllm_ascend.utils import enable_custom_op
 enable_custom_op()
 native=importlib.import_module(provenance['helper_package']+'.qsa_shared_native')
 probe=importlib.import_module(provenance['helper_package']+'.qsa_shared_probe')
 torch.ops.load_library(str(build/'glm_qsa_shared_v996.so'))
 cls=torch.classes.glm_qsa_shared_v996.Kernel;launch=torch.ops.glm_qsa_shared_v996.launch
 device=torch.device('npu:0')
 parent=native.NativeQsaShared(cls(str(root/'build-qsa-v991/shared.bin'),'qsa_sparse_attention_v310'),launch,device)
 candidate=native.NativeQsaShared(cls(str(build/'shared.bin'),'qsa_sparse_attention_v310'),launch,device)
 def record(row):
  payload['records'].append(row);save();print(json.dumps(row),flush=True)
 result=probe.qualify(parent,candidate,production=torch.ops._C_ascend.npu_qsa_sparse_attention_310,on_case=record)
 payload.update(complete=True,summary={k:v for k,v in result.items() if k!='cases'})
 save();print('Full QSA v991/v996/installed operator gate and changed graph replays passed',flush=True)
except BaseException as error:
 payload['error']=dict(type=type(error).__name__,message=str(error));save();raise
finally:
 client.resume()
