import numpy as np

def pack_nibbles(values):
    values = np.asarray(values, dtype=np.int8)
    return np.ascontiguousarray(
        ((values[..., ::2] & 15) | ((values[..., 1::2] & 15) << 4)).astype(np.uint8).view(np.int8)
    )

def fixture(rows, outputs, k, ends, seed):
    rng = np.random.default_rng(seed)
    experts = len(ends)
    groups = k // 128
    low_values = rng.integers(-8, 8, (rows, k), dtype=np.int8)
    high_values = rng.integers(-8, 8, (rows, k), dtype=np.int8)
    weights = rng.integers(-8, 8, (experts, outputs, k), dtype=np.int8)
    # Scale/sum lanes are replicated in the production quantizer.
    xs = rng.uniform(0.001, 0.025, (rows, groups)).astype(np.float32)
    sums = rng.uniform(-80, 80, (rows, groups)).astype(np.float32)
    sw = rng.uniform(0.002, 0.06, (experts, outputs, groups)).astype(np.float16)
    zw = rng.uniform(-1, 1, (experts, outputs, groups)).astype(np.float16)
    ws = rng.uniform(-100, 100, (experts, outputs, groups)).astype(np.float16)
    # Checkpoint N16 strips are [expert,N16,groups,K64,16,32] packed bytes.
    codes = pack_nibbles(weights).reshape(experts, outputs // 16, 16, groups, 2, 32)
    codes = np.ascontiguousarray(codes.transpose(0, 1, 3, 4, 2, 5))

    def metadata(value):
        return np.ascontiguousarray(value.reshape(experts, outputs // 16, 16, groups).transpose(0, 1, 3, 2))

    low, high = pack_nibbles(low_values), pack_nibbles(high_values)
    scale_lanes = np.ascontiguousarray(np.repeat(xs[..., None], 8, axis=-1))
    sum_lanes = np.ascontiguousarray(np.repeat(sums[..., None], 8, axis=-1))
    end_array = np.asarray(ends, dtype=np.int64)
    storage = np.full(rows * outputs + 32, np.float16(123.5))
    output = storage[16:-16].reshape(rows, outputs)
    config = np.asarray((rows, experts, outputs, k, 8, 0, 1), dtype=np.int64)
    arguments = [
        low,
        high,
        scale_lanes,
        sum_lanes,
        codes,
        metadata(sw),
        metadata(zw),
        metadata(ws),
        end_array,
        output,
        config,
    ]
    reference = np.zeros((rows, outputs), dtype=np.float32)
    start = 0
    for expert, end in enumerate(ends):
        if end > start:
            for group in range(groups):
                section = slice(group * 128, (group + 1) * 128)
                dot_low = (
                    low_values[start:end, section].astype(np.int32) @ weights[expert, :, section].astype(np.int32).T
                )
                dot_high = (
                    high_values[start:end, section].astype(np.int32) @ weights[expert, :, section].astype(np.int32).T
                )
                corrected = dot_low.astype(np.float32) + dot_high.astype(np.float32) * np.float32(16)
                corrected = corrected - zw[expert, :, group].astype(np.float32) * sums[start:end, group, None]
                corrected = corrected + ws[expert, :, group].astype(np.float32) * np.float32(8)
                corrected = corrected * sw[expert, :, group].astype(np.float32)
                corrected = corrected * xs[start:end, group, None]
                reference[start:end] = reference[start:end] + corrected
        start = end
    return arguments, reference.astype(np.float16), storage
