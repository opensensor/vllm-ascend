import base64,json,time,urllib.request,concurrent.futures,threading
from pathlib import Path
root=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
barrier=threading.Barrier(6)
labels=['ALPHA','BRAVO','CHARLIE','DELTA','ECHO','FOXTROT']
def run(label):
 image='data:image/png;base64,'+base64.b64encode((root/(label+'.png')).read_bytes()).decode()
 body={'model':'qwen38-flash-next','messages':[{'role':'user','content':[{'type':'text','text':'Transcribe the large word in this image. Respond with only that word.'},{'type':'image_url','image_url':{'url':image}}]}],'max_tokens':16,'temperature':0,'seed':42,'chat_template_kwargs':{'enable_thinking':False}}
 req=urllib.request.Request('http://127.0.0.1:8001/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 barrier.wait();started=time.monotonic()
 with urllib.request.urlopen(req,timeout=180) as response:r=json.load(response)
 text=r['choices'][0]['message'].get('content') or ''
 return {'label':label,'passed':label in text.upper(),'elapsed_s':time.monotonic()-started,'response':r}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:results=list(executor.map(run,labels))
(root/'tp6-fixed-six-images.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results),flush=True)
assert all(r['passed'] for r in results)
