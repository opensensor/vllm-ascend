#include "qsa_sparse_attention_v310.h"
#include "qsa_cube_sparse_attention_v310.h"

extern "C" __global__ __aicore__ void qsa_sparse_attention_v310(
    GM_ADDR query, GM_ADDR keyCache, GM_ADDR valueCache, GM_ADDR groupIndices, GM_ADDR groupCounts,
    GM_ADDR tailStarts, GM_ADDR tailCounts, GM_ADDR blockTable, GM_ADDR queryStartLoc, GM_ADDR output,
    GM_ADDR workspace, GM_ADDR tiling)
{
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AICORE);
    AscendC::GlobalTensor<int64_t> tilingGm;
    tilingGm.SetGlobalBuffer(reinterpret_cast<__gm__ int64_t *>(tiling));
    QsaSparseAttentionV310TilingData tilingData;
    tilingData.numTokens = tilingGm.GetValue(0);
    tilingData.numQueryHeads = tilingGm.GetValue(1);
    tilingData.numKvHeads = tilingGm.GetValue(2);
    tilingData.headsPerTask = tilingGm.GetValue(3);
    tilingData.taskTilesPerKvHead = tilingGm.GetValue(4);
    tilingData.headDim = tilingGm.GetValue(5);
    tilingData.cacheBlockSize = tilingGm.GetValue(6);
    tilingData.cacheHeadDimBlocks = tilingGm.GetValue(7);
    tilingData.maxBlocksPerSequence = tilingGm.GetValue(8);
    tilingData.selectedGroupsWidth = tilingGm.GetValue(9);
    tilingData.numRequests = tilingGm.GetValue(10);
    tilingData.tasksPerCore = tilingGm.GetValue(11);
    tilingData.taskCount = tilingGm.GetValue(12);
    tilingData.scaleQ24 = tilingGm.GetValue(13);
    AscendC::TPipe pipe;
    if ((tilingData.headDim == NsQsaCubeSparseAttention::MAX_HEAD_DIM ||
         tilingData.headDim == NsQsaCubeSparseAttention::GLM_LATENT_HEAD_DIM) &&
        tilingData.headsPerTask <= NsQsaCubeSparseAttention::MAX_QUERY_HEADS &&
        tilingData.selectedGroupsWidth <= NsQsaCubeSparseAttention::MAX_GROUP_WIDTH) {
        if (tilingData.headDim == NsQsaCubeSparseAttention::GLM_LATENT_HEAD_DIM) {
            NsQsaCubeSparseAttention::QsaCubeSparseAttentionV310Wide op;
            op.Init(query, keyCache, valueCache, groupIndices, groupCounts, tailStarts, tailCounts, blockTable,
                    queryStartLoc, output, &tilingData, &pipe);
            op.Process();
        } else {
            NsQsaCubeSparseAttention::QsaCubeSparseAttentionV310 op;
            op.Init(query, keyCache, valueCache, groupIndices, groupCounts, tailStarts, tailCounts, blockTable,
                    queryStartLoc, output, &tilingData, &pipe);
            op.Process();
        }
    } else {
        NsQsaSparseAttention::QsaSparseAttentionV310 op;
        op.Init(query, keyCache, valueCache, groupIndices, groupCounts, tailStarts, tailCounts, blockTable,
                queryStartLoc, output, &tilingData, &pipe);
        op.Process();
    }
}
