# mypy: ignore-errors
# SPDX-License-Identifier: Apache-2.0
import contextlib
import copy
import hashlib
import logging
import math
import os
import queue
import struct
import threading
import time
from collections import OrderedDict, defaultdict, deque
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import httpx
import msgspec
import numpy as np
import numpy.typing as npt
import torch
import torch_npu
import zmq
from mooncake.engine import TransferEngine  # type: ignore
from vllm.config import VllmConfig
from vllm.distributed import get_pcp_group
from vllm.distributed.kv_transfer.kv_connector.v1.base import (
    KVConnectorBase_V1,
    KVConnectorMetadata,
    KVConnectorRole,
    SupportsHMA,
)
from vllm.distributed.parallel_state import (
    get_tensor_model_parallel_rank,
    get_tp_group,
    get_world_group,
)
from vllm.logger import logger
from vllm.utils.math_utils import round_down
from vllm.utils.network_utils import get_ip, make_zmq_path, make_zmq_socket
from vllm.utils.torch_utils import get_dtype_size
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import (
    AttentionSpec,
    FullAttentionSpec,
    KVCacheConfig,
    KVCacheSpec,
    MambaSpec,
    SlidingWindowSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.worker.utils import extract_layer_index

from vllm_ascend.ascend_config import get_ascend_config
from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_connector import GET_META_MSG
from vllm_ascend.distributed.kv_transfer.utils.mooncake_transfer_engine import global_te
from vllm_ascend.distributed.kv_transfer.utils.utils import (
    PD_QOS_DEFAULT,
    RegisterRegions,
    align_memory,
    collect_storage_merged_register_regions,
    context_parallel_parameters_check,
    get_cp_group,
    get_local_remote_block_port_mappings,
    get_transfer_mappings,
    get_transfer_timeout_value,
    inject_qos,
    kv_alltoall_and_rearrange,
    parallel_info,
    validate_register_region_count,
)
from vllm_ascend.distributed.utils import get_decode_context_model_parallel_rank
from vllm_ascend.utils import get_kv_cache_tensor_layers, npu_stream_switch, trans_nd_to_nz

# isort: off
if TYPE_CHECKING:
    from vllm.v1.attention.backend import AttentionMetadata  # type: ignore
    from vllm.forward_context import ForwardContext
    from vllm.v1.core.kv_cache_manager import KVCacheBlocks
    from vllm.v1.request import Request
# isort: on

DONE_SENDING_MSG = b"done_sending_msg"
FAILED_SENDING_MSG = b"failed_sending_msg"
LAYERWISE_REUSE_WAIT_LOG_INTERVAL_SECONDS = 10.0


@dataclass
class LayerMetadata:
    tensor_group_idx: list[int]
    kv_caches_base_addr: list[int]
    block_len: list[int]
    block_size_scale: list[int]


class MooncakeAgentMetadata(msgspec.Struct, omit_defaults=True, dict=True):
    te_rpc_port: int
    layer_metadata: dict[str, LayerMetadata]


@dataclass
class ReqMeta:
    local_block_ids: list[list[int]]
    token_ids: list[int] | None
    # Not None if layer-wise is disabled
    remote_block_ids: list[list[int]]
    remote_block_size: list[list[int]]
    remote_engine_id: str | None
    remote_host: str | None
    remote_port: int | None
    remote_te_rpc_port: int | None
    remote_layer_metadata: dict[str, LayerMetadata] | None
    metaserver: str | None
    remote_tp_size: int | None
    remote_pcp_size: int | None
    remote_dcp_size: int | None
    chunk_finish: bool = False
    prompt_len: int = 0
    trans_count: list[int] | None = None
    remote_cache_tokens: int = 0
    local_computed_tokens: int = 0
    local_transed_tokens: int = 0
    do_virtual: bool = False


@dataclass
class SendTask:
    send_request: dict[str, ReqMeta] = field(default_factory=dict)
    # pd_head_ratio == 1 use
    wait_event: torch.npu.Event | None = None
    # pd_head_ratio > 1 use
    k_cache: torch.Tensor | None = None
    v_cache: torch.Tensor | None = None
    # kv cache quantization layer use
    k_quant_cache: torch.Tensor | None = None
    v_quant_cache: torch.Tensor | None = None
    layer_idx: int = 0
    layer_name: str = ""
    layer_names: list[str] = field(default_factory=list)
    failed_requests: dict[str, ReqMeta] = field(default_factory=dict)
    # trans block info
    group_rearrange_block_ids: list[list[int]] | None = None
    group_num_blocks: list[int] | None = None
    group_num_tokens: list[int] | None = None
    group_block_table: list[torch.Tensor | None] | None = None
    group_block_len_tensor: list[torch.Tensor | None] | None = None
    group_seq_start_tensor: list[torch.Tensor | None] | None = None


@dataclass
class TransferMeta:
    src: list[int]
    dst: list[int]
    length: list[int]
    req_ids: list[str]


@dataclass
class SendReqInfo:
    local_block_ids: list[list[int]]
    local_transferred_tokens: int
    local_computed_tokens: int
    request: "Request"

    def extend_local_block_ids(self, new_block_ids: list[list[int]]) -> None:
        """extend local block ids for this step"""
        for i, new_block_id in enumerate(new_block_ids):
            self.local_block_ids[i].extend(new_block_id)

    def update_computed_tokens(self, computed_tokens: int) -> None:
        """update local computen tokens for this step"""
        self.local_computed_tokens = computed_tokens

    def update_transferred_tokens(self, transferred_tokens: int) -> None:
        """update transferred tokens for this step"""
        self.local_transferred_tokens = transferred_tokens

    def unpack(self):
        return (
            self.local_block_ids,
            self.local_transferred_tokens,
            self.local_computed_tokens,
            self.request,
        )


@dataclass
class SizedDict(OrderedDict):
    def __init__(self, max_size=16000, *args, **kwargs):
        self.max_size = max_size
        super().__init__(*args, **kwargs)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        if len(self) > self.max_size:
            self.popitem(last=False)

    def __getitem__(self, key):
        try:
            return super().__getitem__(key)
        except KeyError:
            value: dict[int, list[int]] = {}
            self[key] = value
            return value


class KVCacheSendingLayerThread(threading.Thread):
    def __init__(
        self,
        engine: TransferEngine,
        vllm_config: VllmConfig,
        kv_cache_config: KVCacheConfig,
        kv_cache_specs: list[KVCacheSpec],
        attn_resharding_group_idx: set,
        total_layers: int,
        ready_event: threading.Event,
        tp_size: int,
        tp_rank: int,
        pd_head_ratio: int,
        num_head_replica: int,
        layer_metadata: dict[str, LayerMetadata],
        use_mla: bool,
        use_attn_mamba_hybrid: bool,
        k_buffer: torch.Tensor,
        v_buffer: torch.Tensor,
        enable_kv_quant: bool,
        enable_c8_quant: bool,
        resharding_stream: torch.npu.Stream,
        callback_func: Callable[..., None] = lambda x: None,
        reuse_completion_callback: Callable[[int, str | None], None] | None = None,
    ):
        super().__init__(daemon=True, name="KVCacheSendingLayerThread")
        self.engine = engine
        self.vllm_config = vllm_config
        self.kv_cache_config = kv_cache_config
        self.kv_cache_specs = kv_cache_specs
        self.attn_resharding_group_idx = attn_resharding_group_idx
        self.mamba_cache_mode = self.vllm_config.cache_config.mamba_cache_mode
        self.num_speculative_tokens = (
            self.vllm_config.speculative_config.num_speculative_tokens
            if self.vllm_config.speculative_config is not None
            else 0
        )
        self.tp_size = tp_size
        self.tp_rank = tp_rank
        self.pd_head_ratio = pd_head_ratio
        self.num_head_replica = num_head_replica
        self.layer_metadata = layer_metadata
        self.total_layers = total_layers
        self.use_mla = use_mla
        self.use_attn_mamba_hybrid = use_attn_mamba_hybrid
        self.resharding_stream = resharding_stream
        self.current_layer = -1

        send_queue_size = 0
        if self.pd_head_ratio != 1:
            if self.use_attn_mamba_hybrid:
                send_queue_size = len(self.kv_cache_specs)
            else:
                send_queue_size = 1
        self.send_queue = queue.Queue[SendTask](maxsize=send_queue_size)
        self.failed_reqs: set[str] = set()
        self.k_buffer = k_buffer
        self.v_buffer = v_buffer
        self.enable_kv_quant = enable_kv_quant
        self.enable_c8_quant = enable_c8_quant
        self.ready_event = ready_event
        self.callback_func = callback_func
        self.reuse_completion_callback = reuse_completion_callback

    def run(self):
        local_rank = get_world_group().local_rank
        device = torch.device(f"npu:{local_rank}")
        torch.npu.set_device(device)
        self.ready_event.set()
        while True:
            send_task = self.send_queue.get()
            self._handle_request(send_task)

    def _handle_request(self, send_task: SendTask):
        error: str | None = None
        try:
            error = self._transfer_kv_cache(send_task)
        except Exception as e:
            error = str(e)
            self.failed_reqs.update(send_task.send_request)
        finally:
            if error is not None:
                logger.error(
                    "Failed to transfer KV cache. layer_idx=%s, error=%s. Check transfer engine and memory state.",
                    send_task.layer_idx,
                    error,
                )
            self.failed_reqs.update(send_task.failed_requests)
            if send_task.layer_idx == (self.total_layers - 1):
                completion_requests = {
                    **send_task.send_request,
                    **send_task.failed_requests,
                }
                if completion_requests:
                    primary_group_idx = self.layer_metadata[send_task.layer_name].tensor_group_idx[0]
                    for req_id, req_meta in completion_requests.items():
                        if not req_meta.chunk_finish:
                            continue
                        transfer_succeeded = req_id not in self.failed_reqs
                        self.callback_func(
                            req_id,
                            req_meta,
                            primary_group_idx,
                            trans_flag=transfer_succeeded,
                        )
                        if not transfer_succeeded:
                            self.failed_reqs.discard(req_id)
            if self.reuse_completion_callback is not None:
                self.reuse_completion_callback(send_task.layer_idx, error)
            self.send_queue.task_done()

    def get_transfer_meta(
        self,
        send_task: SendTask,
        req_id: str,
        req_meta: ReqMeta,
        layer_name: str,
        layer_group_idx: int,
    ):
        src_list: list[int] = []
        dst_list: list[int] = []
        length_list: list[int] = []

        layer_kv_cache_spec = self.kv_cache_specs[layer_group_idx]
        remote_block_ids = req_meta.remote_block_ids[layer_group_idx]
        remote_layer_metadata = req_meta.remote_layer_metadata[layer_name]
        local_layer_metadata = self.layer_metadata[layer_name]
        local_block_ids = req_meta.local_block_ids[layer_group_idx]

        if isinstance(layer_kv_cache_spec, MambaSpec):
            # only support one block transfer for mamba
            if self.mamba_cache_mode == "align":
                local_transfer_idx = len(local_block_ids) - self.num_speculative_tokens - 1
            else:
                local_transfer_idx = 0
            remote_transfer_idx = len(remote_block_ids) - self.num_speculative_tokens - 1
            local_conv_addr, local_ssm_addr = local_layer_metadata.kv_caches_base_addr
            remote_conv_addr, remote_ssm_addr = remote_layer_metadata.kv_caches_base_addr
            local_conv_len, local_ssm_len = local_layer_metadata.block_len
            tp_ratio = self.tp_size // req_meta.remote_tp_size
            if tp_ratio == 1:
                src_list.extend(
                    [
                        local_conv_addr + local_block_ids[local_transfer_idx] * local_conv_len,
                        local_ssm_addr + local_block_ids[local_transfer_idx] * local_ssm_len,
                    ]
                )
                dst_list.extend(
                    [
                        remote_conv_addr + remote_block_ids[remote_transfer_idx] * local_conv_len,
                        remote_ssm_addr + remote_block_ids[remote_transfer_idx] * local_ssm_len,
                    ]
                )
                length_list.extend([local_conv_len, local_ssm_len])
            else:
                conv_shape, ssm_shape = layer_kv_cache_spec.shapes
                conv_dtype, ssm_dtype = layer_kv_cache_spec.dtypes
                remote_conv_len, remote_ssm_len = remote_layer_metadata.block_len
                # conv
                linear_key_head_dim = self.vllm_config.model_config.hf_text_config.linear_key_head_dim
                linear_num_key_heads = self.vllm_config.model_config.hf_text_config.linear_num_key_heads
                linear_value_head_dim = self.vllm_config.model_config.hf_text_config.linear_value_head_dim
                linear_num_value_heads = self.vllm_config.model_config.hf_text_config.linear_num_value_heads
                local_num_key_heads = linear_num_key_heads // self.tp_size
                local_num_value_heads = linear_num_value_heads // self.tp_size
                local_conv_offsets = [
                    0,
                    local_num_key_heads * linear_key_head_dim,
                    local_num_key_heads * 2 * linear_key_head_dim,
                ]
                local_conv_sizes = [
                    local_num_key_heads * linear_key_head_dim,
                    local_num_key_heads * linear_key_head_dim,
                    local_num_value_heads * linear_value_head_dim,
                ]
                for i in range(conv_shape[0]):
                    for local_conv_offset, local_conv_size in zip(local_conv_offsets, local_conv_sizes):
                        local_addr_offset = (i * conv_shape[1] + local_conv_offset) * get_dtype_size(conv_dtype)
                        remote_addr_offset = (
                            (i * conv_shape[1] + local_conv_offset) * tp_ratio
                            + (self.tp_rank % tp_ratio) * local_conv_size
                        ) * get_dtype_size(conv_dtype)
                        src_list.append(
                            local_conv_addr + local_block_ids[local_transfer_idx] * local_conv_len + local_addr_offset
                        )
                        dst_list.append(
                            remote_conv_addr
                            + remote_block_ids[remote_transfer_idx] * remote_conv_len
                            + remote_addr_offset
                        )
                        length_list.append(local_conv_size * get_dtype_size(conv_dtype))
                # ssm
                remote_addr_offset = (self.tp_rank % tp_ratio) * math.prod(ssm_shape) * get_dtype_size(ssm_dtype)
                src_list.append(local_ssm_addr + local_block_ids[local_transfer_idx] * local_ssm_len)
                dst_list.append(
                    remote_ssm_addr + remote_block_ids[remote_transfer_idx] * remote_ssm_len + remote_addr_offset
                )
                length_list.append(local_ssm_len)
        else:
            use_staging_buffer = layer_name == send_task.layer_name and (
                send_task.k_cache is not None or send_task.k_quant_cache is not None
            )
            if self.pd_head_ratio == 1 or not use_staging_buffer:
                layer_local_kv_base_addr = local_layer_metadata.kv_caches_base_addr
                layer_remote_kv_base_addr = remote_layer_metadata.kv_caches_base_addr
                block_lens = local_layer_metadata.block_len
                grouped_remote_block_ids, grouped_local_block_ids = group_concurrent_contiguous(
                    remote_block_ids, local_block_ids
                )
                # kv cache quantization scenario
                if (
                    use_staging_buffer
                    and (self.enable_kv_quant or self.enable_c8_quant)
                    and send_task.k_quant_cache is not None
                ):
                    assert len(block_lens) == 2, "Quantization block length must be 2!"
                    if self.enable_kv_quant:
                        quant_block_lens = [block_lens[0] // 2, block_lens[1]]
                    else:
                        quant_block_lens = [block_lens[0] // 2, block_lens[1] // 2]
                    layer_local_quant_kv_addr = [self.k_buffer.data_ptr(), self.v_buffer.data_ptr()]
                    rearrange_block_ids = send_task.group_rearrange_block_ids[layer_group_idx]
                    # eg:[5,6,7,9] -> {5:0, 6:1, 7:2, 9:3}
                    rearrange_block_dict = {
                        value: index
                        for index, value in enumerate(rearrange_block_ids)  # type:ignore
                    }
                    for block_len, src_layer_base_addr, dst_layer_base_addr in zip(
                        quant_block_lens, layer_local_quant_kv_addr, layer_remote_kv_base_addr
                    ):
                        for group_remote_block_id, group_local_block_id in zip(
                            grouped_remote_block_ids, grouped_local_block_ids
                        ):
                            src = src_layer_base_addr + rearrange_block_dict[group_local_block_id[0]] * block_len
                            dst = dst_layer_base_addr + group_remote_block_id[0] * block_len
                            length = len(group_local_block_id) * block_len
                            src_list.append(src)
                            dst_list.append(dst)
                            length_list.append(length)
                else:
                    for k, (src_layer_base_addr, dst_layer_base_addr) in enumerate(
                        zip(layer_local_kv_base_addr, layer_remote_kv_base_addr)
                    ):
                        block_len = block_lens[k]
                        for group_remote_block_id, group_local_block_id in zip(
                            grouped_remote_block_ids, grouped_local_block_ids
                        ):
                            src = src_layer_base_addr + group_local_block_id[0] * block_len
                            dst = dst_layer_base_addr + group_remote_block_id[0] * block_len
                            length = len(group_local_block_id) * block_len
                            src_list.append(src)
                            dst_list.append(dst)
                            length_list.append(length)
            else:
                rearrange_block_ids = send_task.group_rearrange_block_ids[layer_group_idx]
                rearrange_block_dict = {
                    value: index
                    for index, value in enumerate(rearrange_block_ids)  # type:ignore
                }
                layer_local_kv_base_addr = [self.k_buffer.data_ptr(), self.v_buffer.data_ptr()]
                layer_remote_kv_base_addr = remote_layer_metadata.kv_caches_base_addr
                block_lens = local_layer_metadata.block_len
                remote_block_lens = remote_layer_metadata.block_len
                assert len(layer_remote_kv_base_addr) == 2, (
                    "Layer kv_cache resharding only supports two kv cache tensors."
                )
                src_list, dst_list, length_list = [], [], []
                for k, (src_layer_base_addr, dst_layer_base_addr) in enumerate(
                    zip(layer_local_kv_base_addr, layer_remote_kv_base_addr)
                ):
                    block_len = block_lens[k]
                    if self.enable_c8_quant:
                        block_len = block_len // 2
                    remote_block_len = remote_block_lens[k]
                    for remote_block_id, local_block_id in zip(remote_block_ids, local_block_ids):
                        src = src_layer_base_addr + rearrange_block_dict[local_block_id] * block_len
                        dst = (
                            dst_layer_base_addr
                            + remote_block_id * remote_block_len
                            + block_len * ((self.tp_rank // self.num_head_replica) % self.pd_head_ratio)
                        )
                        src_list.append(src)
                        dst_list.append(dst)
                        length_list.append(block_len)
        return (src_list, dst_list, length_list)

    def _transfer_kv_cache(self, send_task: SendTask) -> str | None:
        key = send_task.k_cache
        value = send_task.v_cache
        if self.pd_head_ratio > 1 and key is not None and value is not None:
            with npu_stream_switch(self.resharding_stream):
                key = key.view(-1, key.shape[-1])  # type:ignore
                value = value.view(-1, key.shape[-1])  # type:ignore
                self.k_buffer[: key.shape[0]].copy_(key)  # [:4, 128] ->
                self.v_buffer[: value.shape[0]].copy_(value)
        if send_task.k_quant_cache is not None:
            with npu_stream_switch(self.resharding_stream):
                key_quant = send_task.k_quant_cache
                key_quant = key_quant.view(-1, key_quant.shape[-1])  # type:ignore
                self.k_buffer[: key_quant.shape[0]].copy_(key_quant)
                value_quant = send_task.v_quant_cache
                value_quant = value_quant.view(-1, value_quant.shape[-1])  # type:ignore
                self.v_buffer[: value_quant.shape[0]].copy_(value_quant)

        # Merge transmission tasks of the same session
        session_meta: dict[str, TransferMeta] = {}
        layer_names = send_task.layer_names or [send_task.layer_name]
        layer_group_idx = self.layer_metadata[send_task.layer_name].tensor_group_idx[0]
        for req_id, req_meta in send_task.send_request.items():
            session_id = f"{req_meta.remote_host}:{req_meta.remote_te_rpc_port}"
            if session_id not in session_meta:
                session_meta[session_id] = TransferMeta(src=[], dst=[], length=[], req_ids=[])

            for layer_name in layer_names:
                src_list, dst_list, length_list = self.get_transfer_meta(
                    send_task,
                    req_id,
                    req_meta,
                    layer_name,
                    layer_group_idx,
                )
                session_meta[session_id].src.extend(src_list)
                session_meta[session_id].dst.extend(dst_list)
                session_meta[session_id].length.extend(length_list)
            session_meta[session_id].req_ids.append(req_id)

        if send_task.k_quant_cache is not None:
            self.resharding_stream.synchronize()
        elif self.pd_head_ratio == 1:
            """
            Note: Due to a bug in ADXL, calling current_event.synchronize() may occasionally hang.
            This issue will be fixed in CANN version 8.5.rc1.
            You can manually build the master branch of the project at https://gitcode.com/cann/hixl
            to resolve this issue before the 8.5.RC1 release.
            """
            send_task.wait_event.synchronize()  # type:ignore
        elif self.pd_head_ratio > 1:
            self.resharding_stream.synchronize()

        transfer_errors: list[str] = []
        for session_id, transfer_meta in session_meta.items():
            if len(transfer_meta.src) > 0:
                req_start_time = time.perf_counter()
                ret = self.engine.batch_transfer_sync_write(
                    session_id, transfer_meta.src, transfer_meta.dst, transfer_meta.length
                )
                if ret < 0:
                    self.failed_reqs.update(transfer_meta.req_ids)
                    transfer_errors.append(
                        "Mooncake transfer failed for send requests. "
                        f"req_ids={transfer_meta.req_ids}, destination={session_id}, ret={ret}"
                    )
                else:
                    req_end_time = time.perf_counter()
                    total_transfer_size = sum(transfer_meta.length) / 1024
                    req_transfer_elapsed = (req_end_time - req_start_time) * 1000
                    logger.debug(
                        "Layer%d KV cache transfer task %dKB to remote_session_id [%s] took %.3f ms.",
                        send_task.layer_idx,
                        total_transfer_size,
                        session_id,
                        req_transfer_elapsed,
                    )
        return "; ".join(transfer_errors) if transfer_errors else None


class KVCacheRecvingLayerThread(threading.Thread):
    def __init__(
        self,
        tp_rank: int,
        side_channel_port: int,
        tp_size: int,
        pd_head_ratio: int,
        local_engine_id: str,
        metadata: MooncakeAgentMetadata,
        ready_event: threading.Event,
    ):
        super().__init__(daemon=True, name="KVCacheRecvingLayerThread")
        self.tp_rank = tp_rank
        self.tp_size = tp_size
        self.pd_head_ratio = pd_head_ratio
        self.local_engine_id = local_engine_id
        self.side_channel_host = get_ip()
        self.side_channel_port = side_channel_port
        self.lock = threading.Lock()
        self.done_requests = set[str]()
        self.failed_requests = set[str]()
        self.task_tracker = dict[str, int]()
        self.ready_event = ready_event
        self.metadata = metadata

    def get_and_clear_done_requests(self) -> set[str]:
        """
        Get and clear the requests that have been completed.
        Returns:
            A set of request IDs that have been completed.
        """
        with self.lock:
            finished_requests = self.done_requests
            self.done_requests = set()
        return finished_requests

    def get_and_clear_failed_requests(self) -> set[str]:
        """
        Get and clear the requests that have failed.
        Returns:
            A set of request IDs that have failed.
        """
        with self.lock:
            failed_requests = self.failed_requests
            self.failed_requests = set()
        return failed_requests

    def update_failed_task(self, req_id: str) -> None:
        """
        Handle a failed task by adding it to the failed_requests set and removing it from the task tracker.
        Args:
            req_id: The ID of the request that has failed.
        """
        with self.lock:
            if req_id not in self.task_tracker:
                self.task_tracker[req_id] = set()
            self.task_tracker.pop(req_id, None)
            self.failed_requests.add(req_id)

    def update_done_task(self, req_id, trans_count, side_channel_path):
        """
        Handle a completed task by adding it to the done_requests set and removing it from the task tracker.
        Args:
            req_id: The ID of the request that has completed.
        """
        with self.lock:
            if req_id not in self.task_tracker:
                self.task_tracker[req_id] = set()
            self.task_tracker[req_id].add(side_channel_path)
            if len(self.task_tracker[req_id]) == trans_count:
                self.task_tracker.pop(req_id)
                self.done_requests.add(req_id)

    def run(self):
        """Run the thread to handle KV cache transfer requests."""
        handshake_port = self.side_channel_port + self.tp_rank
        path = make_zmq_path("tcp", self.side_channel_host, handshake_port)
        logger.info("KVCacheRecvingLayerThread listening on %s, tp_rank=%d", path, self.tp_rank)
        encoder = msgspec.msgpack.Encoder()
        encoded_data = encoder.encode(self.metadata)
        with zmq_ctx(zmq.ROUTER, path) as sock:  # type: ignore
            self.ready_event.set()
            decoder = msgspec.msgpack.Decoder(type=tuple)
            while True:
                try:
                    frames = sock.recv_multipart()
                    if len(frames) < 2:
                        logger.error(
                            "Invalid message format. expected>=2 frames, got %d. frames=%s", len(frames), frames
                        )
                        continue

                    identity = frames[0]
                    payload = [f for f in frames[1:] if f != b""]
                    if len(payload) != 1:
                        logger.error("Invalid payload count. expected=1, got %d. frames=%s", len(payload), frames)
                        continue

                    msg = decoder.decode(payload[0])
                    if msg[0] == GET_META_MSG:
                        logger.info("Got GET META INFO for request %s", msg[0])
                        sock.send_multipart((identity, b"", encoded_data))
                    elif msg[0] == DONE_SENDING_MSG:
                        logger.debug("Got DONE_RECVING_MSG for request %s", msg[1])
                        request_id = msg[1]
                        trans_count = msg[2]
                        side_channel_path = msg[3]
                        self.update_done_task(request_id, trans_count, side_channel_path)
                        sock.send_multipart((identity, b"", b"ACK"))
                    elif msg[0] == FAILED_SENDING_MSG:
                        request_id = msg[1]
                        logger.error("Got FAILED_SENDING_MSG for request. request_id=%s. ", msg[1])
                        self.update_failed_task(request_id)
                        sock.send_multipart((identity, b"", b"ACK"))
                    else:
                        logger.error(
                            "Unexpected message type: %s. expected GET_META_MSG or DONE_RECVING_MSG. msg=%s",
                            msg[0] if msg else "empty",
                            msg,
                        )
                except Exception as e:
                    logger.error(
                        "Failed to decode message. type=%s, error=%s. context=decoding payload", type(e).__name__, e
                    )


class MooncakeLayerwiseConnectorMetadata(KVConnectorMetadata):
    def __init__(self):
        self.requests: dict[str, ReqMeta] = {}
        self.send_task: SendTask = SendTask()

    def add_new_req(
        self,
        request_id: str,
        local_block_ids: list[list[int]],
        kv_transfer_params: dict[str, Any],
        token_ids: list[int] | None = None,
        chunk_finish: bool = False,
        prompt_len: int = 0,
        remote_cache_tokens: int = 0,
        local_computed_tokens: int = 0,
        local_transed_tokens: int = 0,
    ):
        self.requests[request_id] = ReqMeta(
            token_ids=token_ids or [],
            local_block_ids=local_block_ids,
            remote_block_ids=kv_transfer_params.get("remote_block_ids", []),
            remote_block_size=kv_transfer_params.get("remote_block_size", []),
            remote_engine_id=kv_transfer_params.get("remote_engine_id"),
            remote_host=kv_transfer_params.get("remote_host"),
            remote_port=kv_transfer_params.get("remote_port"),
            remote_te_rpc_port=kv_transfer_params.get("remote_te_rpc_port"),
            remote_layer_metadata=kv_transfer_params.get("remote_layer_metadata"),
            metaserver=kv_transfer_params.get("metaserver"),
            remote_tp_size=kv_transfer_params.get("remote_tp_size"),
            remote_pcp_size=kv_transfer_params.get("remote_pcp_size"),
            remote_dcp_size=kv_transfer_params.get("remote_dcp_size"),
            do_virtual=kv_transfer_params.get("do_virtual"),
            chunk_finish=chunk_finish,
            remote_cache_tokens=remote_cache_tokens,
            local_computed_tokens=local_computed_tokens,
            prompt_len=prompt_len,
            local_transed_tokens=local_transed_tokens,
            trans_count=[],
        )


class MooncakeLayerwiseConnector(KVConnectorBase_V1, SupportsHMA):
    requires_full_blocks_on_update_after_alloc = True
    supports_layerwise_buffer_reuse = True

    def __init__(self, vllm_config: VllmConfig, role: KVConnectorRole, kv_cache_config: KVCacheConfig | None = None):
        super().__init__(vllm_config, role, kv_cache_config)
        assert vllm_config.kv_transfer_config is not None
        self._is_kv_producer = vllm_config.kv_transfer_config.is_kv_producer
        self.is_producer = self._is_kv_producer
        self.engine_id = vllm_config.kv_transfer_config.engine_id
        self._connector_metadata = MooncakeLayerwiseConnectorMetadata()

        if role == KVConnectorRole.SCHEDULER:
            self.connector_scheduler: MooncakeLayerwiseConnectorScheduler | None = MooncakeLayerwiseConnectorScheduler(
                vllm_config, kv_cache_config, str(self.engine_id)
            )
            self.connector_worker: MooncakeLayerwiseConnectorWorker | None = None
        elif role == KVConnectorRole.WORKER:
            self.connector_scheduler = None
            self.connector_worker = MooncakeLayerwiseConnectorWorker(vllm_config, kv_cache_config, str(self.engine_id))

    ############################################################
    # Scheduler Side Methods
    ############################################################

    def get_num_new_matched_tokens(self, request: "Request", num_computed_tokens: int) -> tuple[int, bool]:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.get_num_new_matched_tokens(request, num_computed_tokens)

    def update_state_after_alloc(self, request: "Request", blocks: "KVCacheBlocks", num_external_tokens: int):
        assert self.connector_scheduler is not None
        return self.connector_scheduler.update_state_after_alloc(request, blocks, num_external_tokens)

    def build_connector_meta(
        self,
        scheduler_output: SchedulerOutput,
    ) -> KVConnectorMetadata:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.build_connector_meta(scheduler_output)

    def request_finished(
        self,
        request: "Request",
        block_ids: list[int],
    ) -> tuple[bool, dict[str, Any] | None]:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.request_finished(request, block_ids)

    def request_finished_all_groups(
        self,
        request: "Request",
        block_ids: tuple[list[int], ...],
    ) -> tuple[bool, dict[str, Any] | None]:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.request_finished_all_groups(request, block_ids)

    ############################################################
    # Worker Side Methods
    ############################################################
    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]):
        assert self.connector_worker is not None
        self.connector_worker.register_kv_caches(kv_caches)

    def get_finished(self, finished_req_ids: set[str]) -> tuple[set[str], set[str]]:
        """Get the finished recving and sending requests."""
        assert self.connector_worker is not None
        return self.connector_worker.get_finished()

    def get_block_ids_with_load_errors(self) -> set[int]:
        """Get the block ids that have load errors."""
        assert self.connector_worker is not None
        return self.connector_worker.get_block_ids_with_load_errors()

    def start_load_kv(self, forward_context: "ForwardContext", **kwargs) -> None:
        assert self.connector_worker is not None
        assert isinstance(self._connector_metadata, MooncakeLayerwiseConnectorMetadata)
        self.connector_worker.start_load_kv(self._connector_metadata)

    def wait_for_layer_load(self, layer_name: str) -> None:
        """MooncakeLayerwiseConnector does not do layerwise saving."""
        assert self.connector_worker is not None
        assert isinstance(self._connector_metadata, MooncakeLayerwiseConnectorMetadata)
        self.connector_worker.wait_for_layer_load(layer_name)

    def wait_for_layer_reuse(self, layer_idx: int) -> None:
        assert self.connector_worker is not None
        self.connector_worker.wait_for_layer_reuse(layer_idx)

    def on_kv_cache_written(self, layer_name: str = "") -> None:
        if not self._is_kv_producer or not self.has_connector_metadata():
            return
        assert isinstance(self._connector_metadata, MooncakeLayerwiseConnectorMetadata)
        if not self._connector_metadata.requests:
            return
        assert self.connector_worker is not None
        self.connector_worker.on_kv_cache_written(layer_name)

    def save_kv_layer(
        self, layer_name: str, kv_layer: list[torch.Tensor], attn_metadata: "AttentionMetadata", **kwargs
    ) -> None:
        """MooncakeLayerwiseConnector does not save explicitly."""
        assert self.connector_worker is not None
        assert isinstance(self._connector_metadata, MooncakeLayerwiseConnectorMetadata)
        self.connector_worker.save_kv_layer(layer_name, kv_layer, attn_metadata, self._connector_metadata)

    def wait_for_save(self):
        """MooncakeLayerwiseConnector does not save explicitly."""
        pass


class MooncakeLayerwiseConnectorScheduler:
    """Implementation of Scheduler side methods"""

    def __init__(self, vllm_config: VllmConfig, kv_cache_config: KVCacheConfig, engine_id: str):
        self.vllm_config = vllm_config
        self.kv_cache_config = kv_cache_config
        self.block_size = [group_spec.kv_cache_spec.block_size for group_spec in kv_cache_config.kv_cache_groups]
        self.engine_id = engine_id
        logger.info("Initializing Mooncake Scheduler %s", engine_id)

        self.side_channel_host = get_ip()

        # disable prefill context parallel on decoder nodes
        if vllm_config.kv_transfer_config.is_kv_consumer:
            assert vllm_config.parallel_config.prefill_context_parallel_size == 1, (
                "Prefill context parallel is not support on decoder nodes"
            )

        # Handshake base port
        self.side_channel_port = (
            vllm_config.kv_transfer_config.kv_port
            + vllm_config.parallel_config.data_parallel_rank * vllm_config.parallel_config.tensor_parallel_size
        )

        # Requests that need to start recv.
        # New requests are added by update_state_after_alloc in
        # the scheduler. Used to make metadata passed to Worker.
        self._reqs_need_recv: dict[str, tuple[Request, list[int], list[list[int]]]] = {}
        self._reqs_need_send_layerwise: dict[str, SendReqInfo] = {}
        self.need_truncate = self._has_attn_mamba_hybrid_cache(kv_cache_config)
        self.executor = ThreadPoolExecutor(32)
        tls_config: dict[str, Any] = vllm_config.kv_transfer_config.get_from_extra_config("tls_config", {})
        ssl_keyfile = tls_config.get("ssl_keyfile")
        ssl_certfile = tls_config.get("ssl_certfile")
        ssl_ca_certs = tls_config.get("ssl_ca_certs", False)
        ssl_keyfile_password = tls_config.get("ssl_keyfile_password")
        self.cert_path = (ssl_certfile, ssl_keyfile, ssl_keyfile_password)
        self.ssl_enable = tls_config.get("ssl_enable", False)
        self.ca_path = ssl_ca_certs
        if self.ssl_enable:
            self.metaserver_client = httpx.Client(
                limits=httpx.Limits(max_connections=100000), timeout=None, cert=self.cert_path, verify=self.ca_path
            )
        else:
            self.metaserver_client = httpx.Client(limits=httpx.Limits(max_connections=100000), timeout=None)

    @staticmethod
    def _iter_kv_cache_specs(kv_cache_config: KVCacheConfig):
        for kv_cache_group in kv_cache_config.kv_cache_groups:
            kv_cache_spec = kv_cache_group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                yield from kv_cache_spec.kv_cache_specs.values()
            else:
                yield kv_cache_spec

    @classmethod
    def _has_attn_mamba_hybrid_cache(cls, kv_cache_config: KVCacheConfig) -> bool:
        has_attn = False
        has_mamba = False
        for kv_cache_spec in cls._iter_kv_cache_specs(kv_cache_config):
            has_attn = has_attn or isinstance(kv_cache_spec, AttentionSpec)
            has_mamba = has_mamba or isinstance(kv_cache_spec, MambaSpec)
        return has_attn and has_mamba

    def _hybrid_prefill_token_count(self, num_prompt_tokens: int) -> int:
        if self.need_truncate and num_prompt_tokens > 1:
            return num_prompt_tokens - 1
        return num_prompt_tokens

    def _truncate_request_for_hybrid_prefill(self, request: "Request") -> None:
        params = request.kv_transfer_params
        if (
            params is None
            or not self.need_truncate
            or params.get("_p_side_truncated")
            or getattr(request, "num_prompt_tokens", len(request.prompt_token_ids or [])) <= 1
        ):
            return

        if request.prompt_token_ids is not None:
            request.prompt_token_ids.pop()
        elif request.prompt_embeds is not None:
            request.prompt_embeds = request.prompt_embeds[:-1]
        else:
            return

        request._all_token_ids.pop()
        request.num_prompt_tokens -= 1
        request.max_tokens = 1
        params["_p_side_truncated"] = True

    def _trim_hybrid_remote_block_ids(self, block_ids: tuple[list[int], ...], prompt_len: int) -> tuple[list[int], ...]:
        if not self.need_truncate or prompt_len <= 1:
            return block_ids

        trimmed_block_ids: list[list[int]] = []
        for group_block_ids, block_size in zip(block_ids, self.block_size):
            if prompt_len % block_size == 1:
                trimmed_block_ids.append(list(group_block_ids[:-1]))
            else:
                trimmed_block_ids.append(list(group_block_ids))
        return tuple(trimmed_block_ids)

    def get_num_new_matched_tokens(self, request: "Request", num_computed_tokens: int) -> tuple[int, bool]:
        """
        For remote prefill, pull all prompt blocks from remote
        asynchronously relative to engine execution.

        Args:
            request (Request): the request object.
            num_computed_tokens (int): the number of locally
                computed tokens for this request
        Returns:
            * the number of tokens that can be loaded from the
              external KV cache beyond what is already computed.
            * true if the external KV cache tokens will be loaded
              asynchronously (between scheduler steps).
        """

        params = request.kv_transfer_params
        logger.debug(
            "MooncakeLayerwiseConnector get_num_new_matched_tokens: num_computed_tokens=%s, kv_transfer_params=%s",
            num_computed_tokens,
            params,
        )

        if params is not None and params.get("do_remote_prefill"):
            # Remote prefill: get all prompt blocks from remote.
            assert num_computed_tokens % min(self.block_size) == 0
            count = max(self._hybrid_prefill_token_count(len(request.prompt_token_ids)) - num_computed_tokens, 0)
            return count, count > 0

        if params is not None and params.get("do_remote_decode"):
            self._truncate_request_for_hybrid_prefill(request)

        # No remote prefill for this request.
        return 0, False

    def update_state_after_alloc(self, request: "Request", blocks: "KVCacheBlocks", num_external_tokens: int):
        params = request.kv_transfer_params
        logger.debug(
            "MooncakeLayerwiseConnector update_state_after_alloc: num_external_tokens=%s, kv_transfer_params=%s",
            num_external_tokens,
            params,
        )

        if params is not None and params.get("do_remote_prefill"):
            do_virtual = params.get("do_virtual", False)
            local_block_ids = (blocks.get_block_ids()) if num_external_tokens > 0 else []
            remote_block_ids = self._trim_hybrid_remote_block_ids(local_block_ids, len(request.prompt_token_ids))
            remote_cached_tokens = request.num_computed_tokens
            # Get unhashed blocks to pull from remote.
            logger.debug(
                "MooncakeLayerwiseConnector update_state_after_alloc: add %s to need recv queue", request.request_id
            )
            self._reqs_need_recv[request.request_id] = (
                request,
                [],  # request._all_token_ids,
                local_block_ids,
            )

            params["do_remote_prefill"] = False

            logger.info("Send request: %s to proxy metaserver: %s", request.request_id, params.get("metaserver", None))
            # All parameters here should appear in the returned dict of
            # request_finished in the scheduler side except "request_id".
            # change the format of request_id if vllm-version >= 0.14.0
            external_req_id = get_external_request_id(request.request_id)
            kv_transfer_params = dict(
                token_ids=[],
                request_id=external_req_id,
                do_remote_prefill=False,
                do_remote_decode=True,
                remote_block_ids=remote_block_ids,
                remote_block_size=self.block_size,
                remote_engine_id=self.engine_id,
                remote_host=self.side_channel_host,
                remote_port=self.side_channel_port,
                remote_tp_size=self.vllm_config.parallel_config.tensor_parallel_size,
                remote_pcp_size=self.vllm_config.parallel_config.prefill_context_parallel_size,
                remote_dcp_size=self.vllm_config.parallel_config.decode_context_parallel_size,
                remote_cached_tokens=remote_cached_tokens,
            )
            if not do_virtual:
                future = self.executor.submit(
                    self._access_metaserver, url=params.get("metaserver", None), message=kv_transfer_params
                )

                def handle_exception(future):
                    if future.exception():
                        logger.error("Access metaserver fail. error=%s. ", future.exception())

                future.add_done_callback(handle_exception)

        # Layerwise prefiller add request need send
        if params is not None and params.get("do_remote_decode"):
            local_block_ids = list(blocks.get_block_ids())
            logger.debug(
                "MooncakeLayerwiseConnector update_state_after_alloc: add %s to need send queue", request.request_id
            )
            remote_cache_tokens = params["remote_cached_tokens"]
            local_transferred_tokens = remote_cache_tokens
            local_computed_tokens = 0
            self._reqs_need_send_layerwise[request.request_id] = SendReqInfo(
                local_block_ids=local_block_ids,
                local_transferred_tokens=local_transferred_tokens,
                local_computed_tokens=local_computed_tokens,
                request=request,
            )

    def build_connector_meta(
        self,
        scheduler_output: SchedulerOutput,
    ) -> KVConnectorMetadata:
        meta = MooncakeLayerwiseConnectorMetadata()

        if self.vllm_config.kv_transfer_config.is_kv_consumer:
            # Loop through scheduled reqs and convert to ReqMeta.
            for req_id, (req, token_ids, block_ids) in self._reqs_need_recv.items():
                assert req.kv_transfer_params is not None
                # For the case where there are no remote blocks to pull
                # (block_ids is empty), we don't need to schedule
                # an async read on the worker side.
                meta.add_new_req(
                    request_id=req_id,
                    local_block_ids=block_ids,
                    kv_transfer_params=req.kv_transfer_params,
                    token_ids=token_ids,
                )

            # Clear the list once workers start the transfers
            self._reqs_need_recv.clear()
        else:
            cached_reqs = scheduler_output.scheduled_cached_reqs
            new_reqs = scheduler_output.scheduled_new_reqs
            scheduled_spec_decode_tokens = scheduler_output.scheduled_spec_decode_tokens
            for req_id, new_blocks in zip(cached_reqs.req_ids, cached_reqs.new_block_ids):
                if req_id in self._reqs_need_send_layerwise and new_blocks is not None:
                    self._reqs_need_send_layerwise[req_id].extend_local_block_ids(new_blocks)
            computed_tokens = dict(
                list(zip(cached_reqs.req_ids, cached_reqs.num_computed_tokens))
                + [(x.req_id, x.num_computed_tokens) for x in new_reqs]
            )
            for req_id, scheduled_tokens in scheduler_output.num_scheduled_tokens.items():
                if req_id in self._reqs_need_send_layerwise:
                    send_req_info = self._reqs_need_send_layerwise[req_id]
                    # update local transferred tokens
                    send_req_info.update_transferred_tokens(
                        round_down(send_req_info.local_computed_tokens, min(self.block_size))
                    )
                    # update local computed tokens, not transfer spec decode tokens
                    spec_decode_tokens = (
                        len(scheduled_spec_decode_tokens[req_id]) if (req_id in scheduled_spec_decode_tokens) else 0
                    )
                    send_req_info.update_computed_tokens(
                        computed_tokens.get(req_id, 0) + scheduled_tokens - spec_decode_tokens
                    )

                    def add_transfer_task(req_id, send_req_info: SendReqInfo, chunk_finish=False):
                        (
                            local_block_ids,
                            local_transed_tokens,
                            local_computed_tokens,
                            request,
                        ) = send_req_info.unpack()
                        meta.add_new_req(
                            request_id=req_id,
                            local_block_ids=local_block_ids,
                            kv_transfer_params=request.kv_transfer_params,
                            token_ids=[],
                            chunk_finish=chunk_finish,
                            remote_cache_tokens=request.kv_transfer_params.get("remote_cached_tokens"),
                            prompt_len=len(request.all_token_ids),
                            local_computed_tokens=local_computed_tokens,
                            local_transed_tokens=local_transed_tokens,
                        )
                        if logger.isEnabledFor(logging.DEBUG):
                            logger.debug(
                                "MooncakeLayerwiseConnector build_connector_meta: req_id=%r prompt_len=%s "
                                "local_computed_tokens=%r local_transed_tokens=%r remote_cache_tokens=%s "
                                "chunk_finish=%r local_block_ids=%r remote_block_ids=%s",
                                req_id,
                                len(request.all_token_ids),
                                local_computed_tokens,
                                local_transed_tokens,
                                request.kv_transfer_params.get("remote_cached_tokens"),
                                chunk_finish,
                                local_block_ids,
                                request.kv_transfer_params.get("remote_block_ids"),
                            )

                    # whether chunk finish
                    chunk_finish = send_req_info.local_computed_tokens >= len(send_req_info.request.all_token_ids)

                    add_transfer_task(req_id, send_req_info, chunk_finish=chunk_finish)
                    if chunk_finish:
                        self._reqs_need_send_layerwise.pop(req_id)
        return meta

    def _access_metaserver(self, url, message):
        success = False
        retry = 0
        while retry < 3 and success is False:
            retry += 1
            try:
                self.metaserver_client.post(url, json=message)
                success = True
            except Exception as e:
                logger.error("Failed to connect to metaserver. url=%s, retry=%d. ", url, retry)
                if retry == 3:
                    raise e

    def request_finished(
        self,
        request: "Request",
        block_ids: list[int],
    ) -> tuple[bool, dict[str, Any] | None]:
        """
        Once a request is finished, determine whether request blocks
        should be freed now or will be sent asynchronously and freed later.
        """
        # layer_wise push, not need delay_free_blocks
        return False, None

    def request_finished_all_groups(
        self,
        request: "Request",
        block_ids: tuple[list[int], ...],
    ) -> tuple[bool, dict[str, Any] | None]:
        """
        Once a request is finished, determine whether request blocks
        should be freed now or will be sent asynchronously and freed later.
        """
        # layer_wise push, not need delay_free_blocks
        return False, None


class MooncakeLayerwiseConnectorWorker:
    """Implementation of Worker side methods"""

    def __init__(self, vllm_config: VllmConfig, kv_cache_config: KVCacheConfig, engine_id: str):
        os.environ["ASCEND_TRANSFER_TIMEOUT"] = str(get_transfer_timeout_value())

        if TransferEngine is None:
            raise RuntimeError("mooncake is not available")
        logger.info("Initializing Mooncake work %s", engine_id)

        # Metadata.
        self.vllm_config = vllm_config
        self.kv_cache_config = kv_cache_config
        self.num_kv_cache_groups = len(self.kv_cache_config.kv_cache_groups)
        self.kv_cache_specs: list[KVCacheSpec] = [spec.kv_cache_spec for spec in self.kv_cache_config.kv_cache_groups]
        self.local_engine_id: str = " "
        self.engine_id = engine_id
        self.dp_rank: int = vllm_config.parallel_config.data_parallel_rank
        self.tp_rank: int = get_tensor_model_parallel_rank()
        self.tp_size: int = vllm_config.parallel_config.tensor_parallel_size
        self.pcp_size: int = vllm_config.parallel_config.prefill_context_parallel_size
        self.pcp_rank: int = get_pcp_group().rank_in_group if self.pcp_size > 1 else 0
        self.dcp_size: int = vllm_config.parallel_config.decode_context_parallel_size
        self.dcp_rank: int = get_decode_context_model_parallel_rank() if self.dcp_size > 1 else 0
        self.tp_group = get_tp_group()
        self.kv_caches: dict[str, torch.Tensor] = {}
        self.side_channel_host = get_ip()
        self.total_layers = vllm_config.model_config.get_num_layers(vllm_config.parallel_config)
        self.use_mla = self.vllm_config.model_config.use_mla
        self.request_map = dict[str, str]()
        self.use_attn_mamba_hybrid = False
        if self.use_mla:
            self.total_num_kv_heads = 1
        else:
            self.total_num_kv_heads = self.vllm_config.model_config.get_total_num_kv_heads()

        # Handshake base port
        self.side_channel_port = (
            vllm_config.kv_transfer_config.kv_port
            + self.dp_rank * self.pcp_size * self.tp_size
            + self.pcp_rank * self.tp_size
        )
        self.handshake_port = self.side_channel_port + self.tp_rank
        self.sockets: dict = {}
        logger.info("Initializing Mooncake work %s", engine_id)
        inject_qos(vllm_config.kv_transfer_config.get_from_extra_config("qos_priority", PD_QOS_DEFAULT))
        self.engine = global_te.get_transfer_engine(self.side_channel_host, device_name=None)
        self.te_rpc_port = self.engine.get_rpc_port()

        # Background thread for sending or receiving KV caches.
        self.kv_recv_layer_thread: KVCacheRecvingLayerThread | None = None
        self.kv_send_layer_thread: KVCacheSendingLayerThread | None = None
        self.layer_storage_slots: dict[int, tuple[int, ...]] = {}
        self.storage_send_done_events: list[threading.Event] = []
        self._storage_send_errors: dict[int, str] = {}
        self._pending_reuse_layers: set[int] = set()
        self._cache_write_events: list[torch.npu.Event | None] = [None] * self.total_layers

        self.block_size: list[int] = [spec.block_size for spec in self.kv_cache_specs]
        self.kernel_block_size_scale: list[int] = [1 for _ in range(self.num_kv_cache_groups)]
        self.layer_metadata: dict[str, LayerMetadata] = {}
        self.attn_resharding_group_idx = set[int]()

        self.enable_kv_quant = (
            vllm_config.quant_config.enable_fa_quant if vllm_config.quant_config is not None else False
        )
        self.enable_c8_quant = (
            vllm_config.quant_config.enable_c8_quant if vllm_config.quant_config is not None else False
        )
        self.pd_head_ratio = get_ascend_config().pd_head_ratio
        self.num_head_replica = get_ascend_config().num_head_replica
        self.resharding_stream = None
        if self.pd_head_ratio > 1 or self.enable_kv_quant or self.enable_c8_quant:
            self.resharding_stream = torch.npu.Stream()

        self.remote_poller = zmq.Poller()  # type: ignore
        self.decoder = msgspec.msgpack.Decoder(MooncakeAgentMetadata)
        self.encoder = msgspec.msgpack.Encoder()

        self.index_to_name = defaultdict(list)
        self.remote_layer_metadata: dict[str, dict[int, dict[str, LayerMetadata]]] = SizedDict()
        self.remote_te_port: dict[str, dict[int, int]] = SizedDict()
        self.remote_sockets_lock = threading.Lock()
        self.remote_sockets: dict[  # type: ignore
            str, deque[zmq.Socket]
        ] = defaultdict(  # type: ignore
            deque
        )
        self.remote_poller = zmq.Poller()  # type: ignore
        self.timeout = 1.0  # seconds
        self.k_buffer: torch.Tensor | None = None
        self.v_buffer: torch.Tensor | None = None
        self.virtual_request: set[str] = set()
        self._invalid_block_ids: set[int] = set()
        self._recving_metadata: dict[str, ReqMeta] = {}

    def _init_layerwise_reuse_state(self) -> None:
        slot_by_addr: dict[int, int] = {}
        layer_storage_slots: dict[int, tuple[int, ...]] = {}
        for layer_idx, layer_names in self.index_to_name.items():
            slots: list[int] = []
            for layer_name in layer_names:
                for addr in self.layer_metadata[layer_name].kv_caches_base_addr:
                    slot_id = slot_by_addr.setdefault(addr, len(slot_by_addr))
                    if slot_id not in slots:
                        slots.append(slot_id)
            layer_storage_slots[layer_idx] = tuple(slots)
        self.layer_storage_slots = layer_storage_slots
        self.storage_send_done_events = []
        for _ in range(len(slot_by_addr)):
            event = threading.Event()
            event.set()
            self.storage_send_done_events.append(event)

    def _mark_layer_reuse_pending(self, layer_idx: int) -> None:
        if layer_idx not in self.layer_storage_slots:
            raise RuntimeError(f"Mooncake layerwise reuse mapping is missing layer {layer_idx}")
        if layer_idx in self._pending_reuse_layers:
            return
        self._pending_reuse_layers.add(layer_idx)
        for slot_id in self.layer_storage_slots[layer_idx]:
            self._storage_send_errors.pop(slot_id, None)
            self.storage_send_done_events[slot_id].clear()

    def _complete_layer_reuse(self, layer_idx: int, error: str | None) -> None:
        if layer_idx not in self._pending_reuse_layers:
            return
        self._pending_reuse_layers.remove(layer_idx)
        for slot_id in self.layer_storage_slots[layer_idx]:
            if error is not None:
                self._storage_send_errors[slot_id] = error
            self.storage_send_done_events[slot_id].set()

    def wait_for_layer_reuse(self, layer_idx: int) -> None:
        send_thread = self.kv_send_layer_thread
        if send_thread is None:
            return
        if layer_idx not in self.layer_storage_slots:
            raise RuntimeError(f"Mooncake layerwise reuse mapping is missing layer {layer_idx}")
        for slot_id in self.layer_storage_slots[layer_idx]:
            event = self.storage_send_done_events[slot_id]
            while not event.wait(timeout=LAYERWISE_REUSE_WAIT_LOG_INTERVAL_SECONDS):
                if not send_thread.is_alive():
                    raise RuntimeError("Mooncake send thread stopped while waiting for layerwise buffer reuse")
                logger.info("Waiting for Mooncake transfer to release physical KV slot %d", slot_id)
            error = self._storage_send_errors.get(slot_id)
            if error is not None:
                raise RuntimeError(f"Mooncake failed to transfer physical KV slot {slot_id}: {error}")

    def create_kv_buffer(self, first_kv_cache_tuple):
        alignment = 2 * 1024 * 1024
        first_k_cache = first_kv_cache_tuple[0]
        first_v_cache = first_kv_cache_tuple[1]
        if self.pd_head_ratio > 1 or self.enable_kv_quant or self.enable_c8_quant:
            # regesit kv buffer
            if self.enable_kv_quant:
                k_dtype = torch.int8
                v_dtype = first_v_cache.dtype
            elif self.enable_c8_quant:
                k_dtype = torch.int8
                v_dtype = torch.int8
            else:
                k_dtype = first_k_cache.dtype
                v_dtype = first_v_cache.dtype
            self.k_buffer = torch.zeros(first_k_cache.numel() + alignment, dtype=k_dtype, device=first_k_cache.device)
            self.k_buffer = align_memory(self.k_buffer, alignment)[: first_k_cache.numel()].view(
                -1, first_k_cache.shape[-1]
            )
            self.v_buffer = torch.zeros(first_v_cache.numel() + alignment, dtype=v_dtype, device=first_k_cache.device)
            self.v_buffer = align_memory(self.v_buffer, alignment)[: first_v_cache.numel()].view(
                -1, first_v_cache.shape[-1]
            )
        for tensor in (self.k_buffer, self.v_buffer):
            assert tensor.data_ptr() % alignment == 0, "The address of the registered kv cache should be aligned to 2M"
            ret_value = self.engine.register_memory(tensor.data_ptr(), tensor.numel() * tensor.element_size())
            logger.info("Register memory buffer for transfer, buffer size:%s", tensor.numel() * tensor.element_size())
            if ret_value != 0:
                raise RuntimeError("Mooncake memory registration failed. ")

    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]):
        """Register the KV Cache data."""
        layer2group_ids: dict[str, int] = {}
        kv_cache_groups = self.kv_cache_config.kv_cache_groups
        for i, kv_cache_group_spec in enumerate(kv_cache_groups):
            for layer_name in kv_cache_group_spec.layer_names:
                layer2group_ids[layer_name] = i

        use_mamba, use_attn = False, False
        conv_total_padding_size = 0
        for kv_cache_tensor in self.kv_cache_config.kv_cache_tensors:
            for layer_name in get_kv_cache_tensor_layers(kv_cache_tensor):
                layer_kv_cache_spec = self.kv_cache_specs[layer2group_ids[layer_name]]
                if isinstance(layer_kv_cache_spec, MambaSpec):
                    use_mamba = True
                    conv_shape, conv_dtype = layer_kv_cache_spec.shapes[0], layer_kv_cache_spec.dtypes[0]
                    conv_total_padding_size = (
                        self.kv_cache_config.num_blocks * math.prod(conv_shape) * get_dtype_size(conv_dtype)
                    )
                if isinstance(layer_kv_cache_spec, AttentionSpec):
                    use_attn = True
            if use_mamba and use_attn:
                self.use_attn_mamba_hybrid = True
                break

        ptrs = []
        lengths = []
        kv_buffer = None
        group_block_size_scales: dict[int, int] = {}
        for layer_name, kv_cache_tuple in kv_caches.items():
            if isinstance(kv_cache_tuple, (list, tuple)) is False:
                kv_cache_tuple = [kv_cache_tuple]
            layer_kv_group_id = layer2group_ids[layer_name]
            layer_kv_cache_spec = kv_cache_groups[layer_kv_group_id].kv_cache_spec
            if isinstance(layer_kv_cache_spec, UniformTypeKVCacheSpecs):
                layer_kv_cache_spec = layer_kv_cache_spec.kv_cache_specs[layer_name]
            if getattr(layer_kv_cache_spec, "cache_sparse_sfa_c8", False) is True:
                raise NotImplementedError(
                    "Mooncake layerwise connector does not support sparse SFA C8 packed main KV cache yet."
                )
            if (
                (self.pd_head_ratio > 1 and (isinstance(layer_kv_cache_spec, (FullAttentionSpec, SlidingWindowSpec))))
                or self.enable_kv_quant
                or self.enable_c8_quant
            ):
                self.attn_resharding_group_idx.add(layer_kv_group_id)
                if kv_buffer is None and "indexer" not in layer_name.lower():
                    kv_buffer = kv_cache_tuple
            single_layer_meta = LayerMetadata([], [], [], [])
            for single_kv_cache in kv_cache_tuple:
                block_start_rank = 1
                num_blocks = self.kv_cache_config.num_blocks
                tensor_num_blocks = single_kv_cache.shape[0]
                assert tensor_num_blocks % num_blocks == 0, (
                    "The external block size must be an integer multiple of the kernel block size."
                )
                block_size_scale = tensor_num_blocks // num_blocks
                group_block_size_scale = group_block_size_scales.setdefault(
                    layer_kv_group_id,
                    block_size_scale,
                )
                if group_block_size_scale != block_size_scale:
                    raise NotImplementedError(
                        "Mooncake layerwise connector does not support KV cache components "
                        "with different block size scales in one group, including DCP replicated indexer cache."
                    )
                block_shape = single_kv_cache.shape[block_start_rank:]
                single_layer_meta.tensor_group_idx.append(layer_kv_group_id)
                single_layer_meta.kv_caches_base_addr.append(single_kv_cache.data_ptr())
                single_layer_meta.block_len.append(single_kv_cache.element_size() * math.prod(block_shape))
                single_layer_meta.block_size_scale.append(block_size_scale)
                self.kernel_block_size_scale[layer2group_ids[layer_name]] = block_size_scale
                if single_kv_cache.data_ptr() not in ptrs and not self.use_attn_mamba_hybrid:
                    ptrs.append(single_kv_cache.data_ptr())
                    lengths.append(
                        num_blocks * single_kv_cache.element_size() * math.prod(block_shape) * block_size_scale
                    )
                logger.info("layer: %s, num_blocks: %s, block_shape: %s", layer_name, num_blocks, block_shape)
            self.layer_metadata[layer_name] = single_layer_meta

        if self.use_attn_mamba_hybrid:
            for kv_cache_tensor in self.kv_cache_config.kv_cache_tensors:
                tensor_addrs = []
                for layer_name in get_kv_cache_tensor_layers(kv_cache_tensor):
                    tensor_addrs.extend(self.layer_metadata[layer_name].kv_caches_base_addr)
                    if "mtp" in layer_name:
                        tensor_addrs.append(min(tensor_addrs) - conv_total_padding_size)
                assert min(set(tensor_addrs)) % (2 * 1024 * 1024) == 0, "Tensor start addr is not align with 2M."
                ptrs.append(min(set(tensor_addrs)))
                lengths.append(kv_cache_tensor.size)

        if self.use_attn_mamba_hybrid:
            register_regions = RegisterRegions(ptrs=ptrs, lengths=lengths)
        else:
            # For normal attention / sparse-c8 KV cache, register merged memory
            # ranges while keeping layer metadata at logical tensor addresses.
            register_regions = collect_storage_merged_register_regions(kv_caches)

        validate_register_region_count(register_regions)
        global_te.register_buffer(register_regions.ptrs, register_regions.lengths)

        if kv_buffer is not None:
            self.create_kv_buffer(kv_buffer)

        model_type = self.vllm_config.model_config.hf_text_config.model_type
        num_attn_module = 2 if model_type in ("longcat_flash", "longcat_flash_ngram") else 1
        mtp_layer_name = ""
        for layer_name in kv_caches:
            if "mtp" in layer_name:
                mtp_layer_name = layer_name
                continue
            layer_idx = extract_layer_index(layer_name, num_attn_module)
            self.index_to_name[layer_idx].append(layer_name)
        for layer_names in self.index_to_name.values():
            layer_names.sort(key=lambda name: "indexer" in name.lower())
            primary_group_idx = self.layer_metadata[layer_names[0]].tensor_group_idx[0]
            assert all(self.layer_metadata[name].tensor_group_idx[0] == primary_group_idx for name in layer_names), (
                f"Mooncake layerwise merged components must share one KV cache group. layer_names={layer_names}"
            )
        if mtp_layer_name != "":
            self.index_to_name[max(self.index_to_name.keys()) + 1].append(mtp_layer_name)
        if self.index_to_name:
            self.total_layers = max(self.total_layers, max(self.index_to_name) + 1)

        self._init_layerwise_reuse_state()

        # After KV Caches registered, start the sending or receiving thread.
        metadata = MooncakeAgentMetadata(
            te_rpc_port=self.te_rpc_port,
            layer_metadata=self.layer_metadata,
        )
        if self.vllm_config.kv_transfer_config.is_kv_producer:
            ready_event = threading.Event()
            self.kv_send_layer_thread = KVCacheSendingLayerThread(
                engine=self.engine,
                vllm_config=self.vllm_config,
                kv_cache_config=self.kv_cache_config,
                kv_cache_specs=self.kv_cache_specs,
                attn_resharding_group_idx=self.attn_resharding_group_idx,
                total_layers=self.total_layers,
                ready_event=ready_event,
                tp_size=self.tp_size,
                tp_rank=self.tp_rank,
                pd_head_ratio=self.pd_head_ratio,
                num_head_replica=self.num_head_replica,
                layer_metadata=self.layer_metadata,
                use_mla=self.use_mla,
                use_attn_mamba_hybrid=self.use_attn_mamba_hybrid,
                k_buffer=self.k_buffer,
                v_buffer=self.v_buffer,
                enable_kv_quant=self.enable_kv_quant,
                enable_c8_quant=self.enable_c8_quant,
                resharding_stream=self.resharding_stream,
                callback_func=self.send_done_send_signal,
                reuse_completion_callback=self._complete_layer_reuse,
            )
            self.kv_send_layer_thread.start()
            ready_event.wait()

        if self.vllm_config.kv_transfer_config.is_kv_consumer:
            ready_event = threading.Event()
            self.kv_recv_layer_thread = KVCacheRecvingLayerThread(
                self.tp_rank,
                self.side_channel_port,
                self.tp_size,
                self.pd_head_ratio,
                self.engine_id,
                metadata,
                ready_event,
            )
            self.kv_recv_layer_thread.start()
            ready_event.wait()

    def get_finished(self) -> tuple[set[str], set[str]]:
        done_recving = (
            self.kv_recv_layer_thread.get_and_clear_done_requests(  # type: ignore[union-attr]
            )
            if self.vllm_config.kv_transfer_config.is_kv_consumer
            else set()
        )
        done_recving = {self.request_map[s] for s in done_recving if s in self.request_map}
        done_recving.update(self.virtual_request)
        self.virtual_request = set()

        failed_recving = (
            self.kv_recv_layer_thread.get_and_clear_failed_requests()
            if self.vllm_config.kv_transfer_config.is_kv_consumer and self.kv_recv_layer_thread is not None
            else set()
        )
        failed_recving = {self.request_map[s] for s in failed_recving if s in self.request_map}
        for req_id in failed_recving:
            if meta := self._recving_metadata.get(req_id):
                self._invalid_block_ids.update(block_id for group in meta.local_block_ids for block_id in group)
        for req_id in done_recving.union(failed_recving):
            org_req_id = req_id[:-9]
            self.request_map.pop(org_req_id, None)
            self._recving_metadata.pop(req_id, None)
        if len(done_recving) > 0:
            logger.info(
                "Number of completed KV cache recv requests: %s, receive requests: %s", len(done_recving), done_recving
            )
        return set(), done_recving

    def get_block_ids_with_load_errors(self) -> set[int]:
        """
        Return and clear the set of block IDs that failed to load.
        This is called by the scheduler to identify blocks that need
        to be retried after a transfer failure.
        """
        result = self._invalid_block_ids
        self._invalid_block_ids = set()
        return result

    # {(ip, port)]: {local_block_ids: [], remote_block_ids: {}}}
    def _get_kv_split_metadata(self, req_meta: ReqMeta, req_idx: int, req_id: str, group_idx: int):
        remote_pcp_size = req_meta.remote_pcp_size
        remote_dcp_size = req_meta.remote_dcp_size
        remote_tp_size = req_meta.remote_tp_size
        remote_hosts = [req_meta.remote_host]
        remote_port = req_meta.remote_port
        local_transed_tokens = max(req_meta.remote_cache_tokens, req_meta.local_transed_tokens)
        # local_transed_tokens tokens that have already been transmitted on the local side
        local_computed_tokens = req_meta.local_computed_tokens
        prompt_len = req_meta.prompt_len
        p_parallel_info = parallel_info(
            tp_size=self.tp_size,
            pcp_size=self.pcp_size,
            dcp_size=self.dcp_size,
            pd_head_ratio=self.pd_head_ratio,
            use_mla=self.use_mla,
        )
        d_parallel_info = parallel_info(
            tp_size=remote_tp_size,
            pcp_size=remote_pcp_size,
            dcp_size=remote_dcp_size,
            pd_head_ratio=self.pd_head_ratio,
            use_mla=self.use_mla,
        )
        cp_size = self.pcp_size * self.dcp_size
        # to_trans_idx all tokens that have been processed up to the current step
        if req_meta.chunk_finish:
            to_trans_idx = math.ceil(local_computed_tokens / self.block_size[group_idx])
        else:
            to_trans_idx = math.floor(local_computed_tokens / self.block_size[group_idx])
        prompt_block_size = math.ceil(prompt_len / self.block_size[group_idx])
        #
        num_local_blocks = prompt_block_size // cp_size + int(
            (prompt_block_size % cp_size) > (self.pcp_rank * self.dcp_size + self.dcp_rank)
        )
        already_send_blocks = to_trans_idx // cp_size + int(
            (to_trans_idx % cp_size) > (self.pcp_rank * self.dcp_size + self.dcp_rank)
        )
        if num_local_blocks == already_send_blocks:
            req_meta.chunk_finish = True
        transed_idx = math.floor(local_transed_tokens / self.block_size[group_idx])

        p_cp_group = get_cp_group(self.tp_size, self.total_num_kv_heads, self.dcp_size)
        d_cp_group = get_cp_group(remote_tp_size, self.total_num_kv_heads, remote_dcp_size)
        logger.debug("Compute cp group for P&D req_id=%r p_cp_group=%r d_cp_group=%r", req_id, p_cp_group, d_cp_group)

        cp_ratio = len(p_cp_group) // len(d_cp_group)
        if cp_ratio == 0:
            selected_p_cp_groups = p_cp_group
            selected_d_cp_groups = d_cp_group
        else:
            x = req_idx % cp_ratio
            start = x * len(d_cp_group)
            selected_p_cp_groups = p_cp_group[start : (start + len(d_cp_group))]
            selected_d_cp_groups = d_cp_group
        assert len(selected_p_cp_groups) == len(selected_d_cp_groups)

        p_head_group_rank = (self.tp_rank - self.dcp_rank) // self.dcp_size
        selected_p_cp_group = []
        selected_d_cp_group = []
        for idx, cp_group in enumerate(selected_p_cp_groups):
            if p_head_group_rank in cp_group:  # Check whether the rank is in selected_p_cp_groups
                selected_p_cp_group = cp_group
                selected_d_cp_group = selected_d_cp_groups[idx]
        if len(selected_p_cp_group) == 0:
            return {}

        logger.debug(
            "MooncakeLayerwiseConnector _get_kv_split_metadata req_id=%r "
            "P-side selected head_group cp group: %s, D-side selected head_group cp group: %s",
            req_id,
            selected_p_cp_group,
            selected_d_cp_group,
        )

        context_parallel_parameters_check(
            remote_pcp_size, remote_dcp_size, p_parallel_info, d_parallel_info, self.total_num_kv_heads
        )
        p_rank_block_mapping, d_block_rank_mapping, pd_head_mapping, d_trans_count_mapping = (
            get_local_remote_block_port_mappings(
                to_trans_idx,
                p_parallel_info,
                d_parallel_info,
                remote_hosts,
                remote_port,
                selected_p_cp_group,
                selected_d_cp_group,
                prompt_len,
                self.block_size[group_idx],
                req_meta,
                self.total_num_kv_heads,
                req_id,
            )
        )
        transfer_mappings = get_transfer_mappings(
            p_rank_block_mapping,
            d_block_rank_mapping,
            pd_head_mapping,
            d_trans_count_mapping,
            req_meta,
            group_idx,
            p_parallel_info,
            req_id,
            transed_idx,
            to_trans_idx,
            self.tp_rank,
            self.pcp_rank,
            self.dcp_rank,
        )
        return transfer_mappings

    def _get_kv_split_metadata_for_mamba(self, req_meta: ReqMeta, req_idx: int, req_id: str, group_idx: int):
        assert self.tp_size >= req_meta.remote_tp_size, (
            "Mamba group prefill TP_size must equal or larger than decode TP_size."
        )
        remote_tp_size = req_meta.remote_tp_size
        tp_raito = self.tp_size // remote_tp_size
        remote_host = req_meta.remote_host
        remote_port = req_meta.remote_port + self.tp_rank // tp_raito
        transfer_mappings: dict[tuple[str, int], dict[str, Any]] = {}
        if req_meta.chunk_finish:
            transfer_mappings[(remote_host, remote_port)] = {
                "local_block_ids": req_meta.local_block_ids[group_idx],
                "remote_block_ids": req_meta.remote_block_ids[group_idx],
                "trans_count": self.tp_size // remote_tp_size,
            }

        return transfer_mappings

    def _align_remote_block_ids(self, req_meta: ReqMeta):
        remote_block_size = req_meta.remote_block_size
        remote_block_ids = req_meta.remote_block_ids
        for i in range(self.num_kv_cache_groups):
            if isinstance(self.kv_cache_specs[i], MambaSpec):
                continue
            if remote_block_size[i] != self.block_size[i] and len(req_meta.remote_block_ids[i]) > 0:
                assert remote_block_size[i] > self.block_size[i] and remote_block_size[i] % self.block_size[i] == 0, (
                    "Remote block size must be divisible by local block size."
                )
                assert self.pcp_size * self.dcp_size * req_meta.remote_pcp_size * req_meta.remote_dcp_size == 1, (
                    "Context parallel does not support different P/D block size now."
                )
                pd_block_size_ratio = remote_block_size[i] // self.block_size[i]
                remtote_block_ids_with_scale = [
                    block_id * pd_block_size_ratio + j
                    for block_id in remote_block_ids[i]
                    for j in range(pd_block_size_ratio)
                ]
                req_meta.remote_block_ids[i] = remtote_block_ids_with_scale

    def _get_kernel_block_ids(self, block_ids):
        for i in range(self.num_kv_cache_groups):
            if isinstance(self.kv_cache_specs[i], MambaSpec):
                continue
            if len(block_ids[i]) > 0:
                block_ids[i] = [
                    block_id * self.kernel_block_size_scale[i] + j
                    for block_id in block_ids[i]
                    for j in range(self.kernel_block_size_scale[i])
                ]
        return block_ids

    def start_load_kv(self, metadata: MooncakeLayerwiseConnectorMetadata):
        """Start loading KV blocks from remote engine."""
        self.current_layer = 0
        self._cache_write_events = [None] * self.total_layers
        if self.vllm_config.kv_transfer_config.is_kv_consumer:
            for req_id, meta in metadata.requests.items():
                if meta.do_virtual:
                    self.virtual_request.add(req_id)
                    continue
                external_req_id = get_external_request_id(req_id)
                assert self.kv_recv_layer_thread is not None
                self.request_map[external_req_id] = req_id
                self._recving_metadata[req_id] = meta
        elif self.vllm_config.kv_transfer_config.is_kv_producer:
            # update trans info
            update_metadata = {}
            for req_idx, (req_id, req_meta) in enumerate(metadata.requests.items()):
                transfer_mappings: dict[tuple[str, int], dict[str, Any]] = {}
                self._align_remote_block_ids(req_meta)
                for i, kv_cache_spec in enumerate(self.kv_cache_specs):
                    if isinstance(kv_cache_spec, MambaSpec):
                        single_group_transfer_mappings = self._get_kv_split_metadata_for_mamba(
                            req_meta, req_idx, req_id, i
                        )
                    else:
                        single_group_transfer_mappings = self._get_kv_split_metadata(req_meta, req_idx, req_id, i)
                    for (host, port), block_dict in single_group_transfer_mappings.items():
                        if (host, port) not in transfer_mappings:
                            transfer_mappings[(host, port)] = {
                                "local_block_ids": [[] for _ in range(self.num_kv_cache_groups)],
                                "remote_block_ids": [[] for _ in range(self.num_kv_cache_groups)],
                                "trans_count": [0 for _ in range(self.num_kv_cache_groups)],
                            }
                        transfer_mappings[(host, port)]["local_block_ids"][i].extend(
                            single_group_transfer_mappings[(host, port)]["local_block_ids"]
                        )
                        transfer_mappings[(host, port)]["remote_block_ids"][i].extend(
                            single_group_transfer_mappings[(host, port)]["remote_block_ids"]
                        )
                        transfer_mappings[(host, port)]["trans_count"][i] = single_group_transfer_mappings[
                            (host, port)
                        ]["trans_count"]
                assert len(transfer_mappings) <= 1, f"Not support add mutil transfer task for req_id:{req_id}"
                update_req_meta = copy.deepcopy(req_meta)
                for (host, port), block_dict in transfer_mappings.items():
                    update_req_meta.remote_host = host
                    update_req_meta.remote_port = port
                    update_req_meta.local_block_ids = self._get_kernel_block_ids(block_dict["local_block_ids"])
                    update_req_meta.remote_block_ids = self._get_kernel_block_ids(block_dict["remote_block_ids"])
                    update_req_meta.trans_count = block_dict["trans_count"]
                    update_metadata[req_id] = update_req_meta
            metadata.requests = {}
            for req_id, req_meta in update_metadata.items():
                metadata.requests[req_id] = update_metadata[req_id]

            # update send task trans block info
            if self.pd_head_ratio != 1 or self.enable_kv_quant or self.enable_c8_quant:
                send_task = metadata.send_task
                send_task.group_rearrange_block_ids = [[] for _ in range(self.num_kv_cache_groups)]
                send_task.group_num_blocks = [0 for _ in range(self.num_kv_cache_groups)]
                send_task.group_num_tokens = [0 for _ in range(self.num_kv_cache_groups)]
                send_task.group_block_table = [None for _ in range(self.num_kv_cache_groups)]
                send_task.group_block_len_tensor = [None for _ in range(self.num_kv_cache_groups)]
                send_task.group_seq_start_tensor = [None for _ in range(self.num_kv_cache_groups)]
                device = self.k_buffer.device  # type: ignore
                for i in self.attn_resharding_group_idx:
                    send_task.group_rearrange_block_ids[i].extend(
                        sorted(
                            {
                                block_id
                                for req_id in metadata.requests
                                for block_id in metadata.requests[req_id].local_block_ids[i]
                            }
                        )
                    )
                    flat_block_ids = send_task.group_rearrange_block_ids[i]
                    block_ids_tensor = torch.tensor(flat_block_ids, dtype=torch.int32, device=device)
                    send_task.group_num_blocks[i] = len(flat_block_ids)
                    send_task.group_num_tokens[i] = send_task.group_num_blocks[i] * (
                        self.block_size[i] // self.kernel_block_size_scale[i]
                    )

                    send_task.group_block_table[i] = block_ids_tensor.view(1, -1)
                    send_task.group_block_len_tensor[i] = torch.tensor(
                        [send_task.group_num_tokens[i]], dtype=torch.int32, device=device
                    )
                    send_task.group_seq_start_tensor[i] = torch.tensor([0], dtype=torch.int32, device=device)

    def on_kv_cache_written(self, layer_name: str) -> None:
        if self.current_layer >= self.total_layers:
            return
        layer_names = self.index_to_name[self.current_layer]
        if not layer_names:
            raise RuntimeError(f"Mooncake layerwise metadata is missing physical layer {self.current_layer}")
        if layer_name and layer_name not in layer_names:
            raise RuntimeError(
                f"Mooncake layer hook {layer_name!r} does not belong to physical layer {self.current_layer}: "
                f"{layer_names}"
            )
        cache_write_event = torch.npu.Event()
        cache_write_event.record()
        self._cache_write_events[self.current_layer] = cache_write_event

    def save_kv_layer(
        self,
        layer_name: str,
        kv_layer: list[torch.Tensor],
        attn_metadata: "AttentionMetadata",
        connector_metadata: MooncakeLayerwiseConnectorMetadata,
        **kwargs,
    ) -> None:
        """MooncakeLayerwiseConnector does not save explicitly."""
        if self.vllm_config.kv_transfer_config.is_kv_producer and connector_metadata.requests.keys():
            if self.current_layer >= self.total_layers:
                self.current_layer += 1
                return
            layer_names = self.index_to_name[self.current_layer]
            if not layer_names:
                raise RuntimeError(f"Mooncake layerwise metadata is missing physical layer {self.current_layer}")
            # Use the scatter-time event recorded by on_kv_cache_written.
            # The fallback preserves correctness for attention paths that do
            # not call the early hook, but gives up transfer/compute overlap.
            if layer_name == "":
                layer_name = layer_names[0]
            elif layer_name not in layer_names:
                raise RuntimeError(
                    f"Mooncake layer hook {layer_name!r} does not belong to physical layer {self.current_layer}: "
                    f"{layer_names}"
                )
            cache_write_event = self._cache_write_events[self.current_layer]
            self._cache_write_events[self.current_layer] = None
            if cache_write_event is None:
                cache_write_event = torch.npu.Event()
                cache_write_event.record()
            send_task = connector_metadata.send_task
            layer_group_idx = self.layer_metadata[layer_name].tensor_group_idx[0]
            keys = None
            values = None
            quant_keys = None
            quant_values = None
            if (
                (
                    self.pd_head_ratio != 1
                    and (isinstance(self.kv_cache_specs[layer_group_idx], (FullAttentionSpec, SlidingWindowSpec)))
                    and send_task.group_num_blocks[layer_group_idx] > 0
                )
                or (self.enable_c8_quant and self.current_layer in self.vllm_config.quant_config.c8_quant_layers)
                or (self.enable_kv_quant and self.current_layer in self.vllm_config.quant_config.kvcache_quant_layers)
            ):
                assert self.resharding_stream is not None
                with npu_stream_switch(self.resharding_stream):
                    cache_write_event.wait()
                    device = self.k_buffer.device  # type: ignore
                    # Initialize buffers
                    keys = torch.empty(
                        (send_task.group_num_tokens[layer_group_idx], *kv_layer[0].size()[-2:]),
                        dtype=kv_layer[0].dtype,
                        device=device,
                    )
                    values = torch.empty(
                        (send_task.group_num_tokens[layer_group_idx], *kv_layer[1].size()[-2:]),
                        dtype=kv_layer[1].dtype,
                        device=device,
                    )

                    # Load cache data into buffers
                    torch_npu.npu_gather_pa_kv_cache(
                        kv_layer[0],
                        kv_layer[1],
                        send_task.group_block_table[layer_group_idx],
                        send_task.group_block_len_tensor[layer_group_idx],
                        seq_offset=send_task.group_seq_start_tensor[layer_group_idx],
                        key=keys,
                        value=values,
                    )
                    if self.pd_head_ratio != 1:
                        # sort kv caches for each block
                        keys = (
                            keys.view(
                                send_task.group_num_blocks[layer_group_idx], self.pd_head_ratio, -1, *keys.shape[1:]
                            )
                            .transpose(0, 1)
                            .reshape_as(keys)
                        )
                        values = (
                            values.view(
                                send_task.group_num_blocks[layer_group_idx], self.pd_head_ratio, -1, *values.shape[1:]
                            )
                            .transpose(0, 1)
                            .reshape_as(values)
                        )
                        # reshard kv cache
                        keys = keys.reshape(-1, *kv_layer[0].shape[2:])
                        values = values.reshape(-1, *kv_layer[1].shape[2:])

                        (keys, values) = kv_alltoall_and_rearrange(self.pd_head_ratio, keys, values)
                    if self.enable_c8_quant:
                        layer = self.vllm_config.compilation_config.static_forward_context[layer_name]
                        quant_keys = torch.clamp(
                            torch.round(keys * layer._c8_k_inv_scale + layer._c8_k_offset),
                            -128,
                            127,
                        ).to(torch.int8)
                        quant_values = torch.clamp(
                            torch.round(values * layer._c8_v_inv_scale + layer._c8_v_offset),
                            -128,
                            127,
                        ).to(torch.int8)
                        quant_keys = self.get_nz_cache(quant_keys, layer_group_idx)
                        quant_values = self.get_nz_cache(quant_values, layer_group_idx)
                    if (
                        self.enable_kv_quant
                        and self.current_layer in self.vllm_config.quant_config.kvcache_quant_layers
                    ):
                        layer = self.vllm_config.compilation_config.static_forward_context[layer_name]
                        keys = torch.ops.vllm.quantize(
                            keys, layer.fak_descale, layer.fak_descale_reciprocal, layer.fak_offset
                        )
                        quant_keys = self.get_nz_cache(keys, layer_group_idx)
                        quant_values = self.get_nz_cache(values, layer_group_idx)

            assert self.kv_send_layer_thread is not None
            layer_send_task = SendTask(
                wait_event=cache_write_event,
                k_cache=keys,
                v_cache=values,
                k_quant_cache=quant_keys,
                v_quant_cache=quant_values,
                layer_idx=self.current_layer,
                layer_name=layer_name,
                layer_names=layer_names,
                group_rearrange_block_ids=send_task.group_rearrange_block_ids,
            )
            for req_id, req_meta in connector_metadata.requests.items():
                if len(req_meta.local_block_ids) <= layer_group_idx or not req_meta.local_block_ids[layer_group_idx]:
                    continue
                try:
                    req_meta_update = self.update_decoder_info(req_id, req_meta)
                except Exception as e:
                    logger.warning(
                        "MooncakeLayerwiseConnector transfer fail. req_id=%s, layer_idx=%s, error=%s. ",
                        req_id,
                        self.current_layer,
                        e,
                    )
                    layer_send_task.failed_requests[req_id] = req_meta
                    continue
                logger.debug("Add request %s to kv send layer thread. req_meta_update=%r", req_id, req_meta_update)
                layer_send_task.send_request[req_id] = req_meta_update

            needs_reuse_gate = any(
                len(req_meta.local_block_ids) > layer_group_idx and bool(req_meta.local_block_ids[layer_group_idx])
                for req_meta in connector_metadata.requests.values()
            )
            if needs_reuse_gate:
                # This must happen before AscendStore publishes StoreSaveDone.
                # Otherwise its receiver may consume the previous set state
                # and start H2D before this transfer is registered as pending.
                self._mark_layer_reuse_pending(self.current_layer)
            try:
                self.kv_send_layer_thread.send_queue.put(layer_send_task)
            except Exception as error:
                if needs_reuse_gate:
                    self._complete_layer_reuse(self.current_layer, str(error))
                raise
            self.current_layer += 1

    # NOTE: Due to the FIA operator constraints, the expected kv cache is ND format, NZ shape,
    # while the npu_format_cast method only modifies the memory layout, we manually convert it to NZ shape here
    def get_nz_cache(self, cache_tensor: torch.Tensor, layer_group_idx: int):
        head_num, head_dim = cache_tensor.shape[-2], cache_tensor.shape[-1]
        cache_tensor = cache_tensor.view(-1, self.block_size[layer_group_idx], head_num * head_dim)
        cache_tensor = trans_nd_to_nz(cache_tensor)
        cache_tensor = cache_tensor.reshape(-1, head_num, head_dim)
        return cache_tensor

    def _get_remote_socket(self, remote_host: str, remote_handshake_port: int) -> zmq.Socket:  # type: ignore
        """Get a socket to the remote host."""
        remote_path = make_zmq_path("tcp", remote_host, remote_handshake_port)
        with self.remote_sockets_lock:
            if self.remote_sockets[remote_path]:
                return self.remote_sockets[remote_path].popleft()

            ctx = zmq.Context()  # type: ignore
            sock = make_zmq_socket(
                ctx=ctx,
                path=remote_path,
                socket_type=zmq.REQ,  # type: ignore
                bind=False,
            )
            sock.setsockopt(
                zmq.SNDTIMEO,  # type: ignore
                int(self.timeout * 1000),
            )
            self.remote_poller.register(sock, zmq.POLLIN)  # type: ignore
            return sock

    def update_decoder_info(self, req_id, req_meta: ReqMeta):
        if (
            req_meta.remote_engine_id not in self.remote_layer_metadata
            or req_meta.remote_port not in self.remote_layer_metadata[req_meta.remote_engine_id]
        ):
            try:
                encoded_data = self.encoder.encode((GET_META_MSG, req_id))
                sock = self._get_remote_socket(req_meta.remote_host, req_meta.remote_port)
                path = f"{req_meta.remote_host}:{req_meta.remote_port}"
                ensure_zmq_send(sock, encoded_data, path)
                metadata_bytes = ensure_zmq_recv(sock, self.remote_poller, path)
                agent_meta: MooncakeAgentMetadata = self.decoder.decode(metadata_bytes)
            except Exception as e:
                logger.error(
                    "Query to port and kv base addr for request fail. req_id=%s, source=%s:%s, error=%s. ",
                    req_id,
                    req_meta.remote_host,
                    req_meta.remote_port,
                    e,
                )
                raise e
            assert req_meta.remote_engine_id != self.engine_id, (
                f"Conflict engine id {req_meta.remote_engine_id} with local engine id {self.local_engine_id}."
            )
            self.remote_layer_metadata[req_meta.remote_engine_id][req_meta.remote_port] = agent_meta.layer_metadata
            self.remote_te_port[req_meta.remote_engine_id][req_meta.remote_port] = agent_meta.te_rpc_port
            logger.debug(
                "Query to port and kv base addr for request %s from %s:%s success "
                "agent_meta.layer_metadata=%r agent_meta.te_rpc_port=%r",
                req_id,
                req_meta.remote_host,
                req_meta.remote_port,
                agent_meta.layer_metadata,
                agent_meta.te_rpc_port,
            )
            if self.pd_head_ratio > 1:
                # for tp inequal, pre-create link to prevent alltoall out of memory
                session_id = f"{req_meta.remote_host}:{agent_meta.te_rpc_port}"
                first_layer_name = next(iter(self.layer_metadata.keys()))
                ret = self.engine.batch_transfer_sync_write(
                    session_id,
                    [self.layer_metadata[first_layer_name].kv_caches_base_addr[0]],
                    [agent_meta.layer_metadata[first_layer_name].kv_caches_base_addr[0]],
                    [128],
                )
                if ret < 0:
                    logger.error("Mooncake transfer failed to create link. session_id=%s, ret=%d. ", session_id, ret)
        req_meta.remote_te_rpc_port = self.remote_te_port[req_meta.remote_engine_id][req_meta.remote_port]
        req_meta.remote_layer_metadata = self.remote_layer_metadata[req_meta.remote_engine_id][req_meta.remote_port]
        return req_meta

    def send_done_send_signal(self, req_id, req_meta, group_idx, trans_flag: bool = True):
        external_req_id = get_external_request_id(req_id)
        send_msg_type = DONE_SENDING_MSG if trans_flag else FAILED_SENDING_MSG
        logger.info(
            "Sending transmitting signal %s for request %s to %s:%d",
            send_msg_type,
            external_req_id,
            req_meta.remote_host,
            req_meta.remote_port,
        )
        try:
            path = make_zmq_path("tcp", req_meta.remote_host, req_meta.remote_port)
            msg_encoder = msgspec.msgpack.Encoder()
            side_channel_path = f"{self.side_channel_host}:{self.handshake_port}"
            encoded_data = msg_encoder.encode(
                (send_msg_type, external_req_id, req_meta.trans_count[group_idx], side_channel_path)
            )
            max_retries = 3
            for attempt in range(1, max_retries + 1):
                try:
                    with zmq_ctx(zmq.REQ, path) as sock:  # type: ignore
                        sock.setsockopt(zmq.SNDTIMEO, int(self.timeout * 1000))
                        ensure_zmq_send(sock, encoded_data, f"{req_meta.remote_host}:{req_meta.remote_port}")
                        if not sock.poll(int(self.timeout * 1000), zmq.POLLIN):  # type: ignore[attr-defined]
                            raise TimeoutError(
                                f"Timed out waiting for ACK from {req_meta.remote_host}:{req_meta.remote_port}"
                            )
                        ack = sock.recv()
                        if ack != b"ACK":
                            raise ValueError(f"Unexpected ACK response: {ack}")
                        return
                except Exception as e:
                    if attempt < max_retries:
                        logger.warning(
                            "Failed to send done sending signal. "
                            "request_id=%s, destination=%s:%d, attempt=%d/%d, error=%s. ",
                            external_req_id,
                            req_meta.remote_host,
                            req_meta.remote_port,
                            attempt,
                            max_retries,
                            e,
                        )
                        time.sleep(0.1)
                    else:
                        raise RuntimeError(f"Failed to receive ACK after {max_retries} attempts: {e}") from e
        except Exception as e:
            logger.error(
                "Sending signal fail. signal_type=%s, request_id=%s, destination=%s:%s, error=%s. ",
                send_msg_type,
                external_req_id,
                req_meta.remote_host,
                req_meta.remote_port,
                e,
            )

    def wait_for_layer_load(self, layer_name: str) -> None:
        pass


@contextlib.contextmanager
def zmq_ctx(socket_type: Any, addr: str) -> Iterator[zmq.Socket]:  # type: ignore
    """Context manager for a ZMQ socket"""

    if socket_type not in (zmq.ROUTER, zmq.REQ, zmq.DEALER):  # type: ignore
        raise ValueError(f"Unexpected socket type: {socket_type}")

    ctx: zmq.Context | None = None  # type: ignore
    try:
        ctx = zmq.Context()  # type: ignore
        yield make_zmq_socket(ctx=ctx, path=addr, socket_type=socket_type, bind=socket_type == zmq.ROUTER)  # type: ignore
    finally:
        if ctx is not None:
            ctx.destroy(linger=0)


def group_concurrent_contiguous(
    src: list[int], dst: list[int] | None = None
) -> tuple[list[npt.NDArray[np.int64]], list[npt.NDArray[np.int64]]]:
    """Vectorised NumPy implementation."""
    if dst is None:
        dst = []
    if not dst:
        src_only_indices: npt.NDArray[np.int64] = np.array(src, dtype=np.int64)

        if src_only_indices.size == 0:
            return [], []

        brk = np.where(np.diff(src_only_indices) != 1)[0] + 1
        src_groups = np.split(src_only_indices, brk)
        src_groups = [g.tolist() for g in src_groups]

        return src_groups, []

    else:
        src_indices: npt.NDArray[np.int64] = np.array(src, dtype=np.int64)
        dst_indices: npt.NDArray[np.int64] = np.array(dst, dtype=np.int64)

        if src_indices.size == 0:
            return [], []

        brk = np.where((np.diff(src_indices) != 1) | (np.diff(dst_indices) != 1))[0] + 1
        src_groups = np.split(src_indices, brk)
        dst_groups = np.split(dst_indices, brk)

        src_groups = [g.tolist() for g in src_groups]
        dst_groups = [g.tolist() for g in dst_groups]

        return src_groups, dst_groups


def string_to_int64_hash(input_str):
    """
    Hash the string using SHA-256 and convert it into an int64 integer.
    """
    hashed_bytes = hashlib.sha256(input_str.encode("utf-8")).digest()
    trunked_bytes = hashed_bytes[:8]
    uint64_value = struct.unpack("<Q", trunked_bytes)[0]
    return uint64_value


def ensure_zmq_send(
    socket: zmq.Socket,  # type: ignore
    data: bytes,
    path: str,
    max_retries: int = 3,
):
    retries_left = max_retries
    while True:
        try:
            socket.send(data)
            return
        except zmq.ZMQError as e:  # type: ignore
            retries_left -= 1
            if retries_left > 0:
                logger.warning("Send failed. error=%s, attempts_left=%d. ", e, retries_left)
                time.sleep(0.1)
            else:
                logger.error("Send failed after all retries. error=%s. ", e)
                raise RuntimeError(f"Failed to send data to {path} after {max_retries} retries: {e}")


def ensure_zmq_recv(
    socket: zmq.Socket,  # type: ignore
    poller: zmq.Poller,  # type: ignore
    path: str,
    timeout: float = 1.0,
    max_retries: int = 3,
) -> bytes:
    retries_left = max_retries
    while True:
        try:
            if dict(poller.poll(int(timeout * 1000))):  # milliseconds
                data = socket.recv()
                return data
            else:
                raise zmq.ZMQError("Receive timeout")  # type: ignore
        except zmq.ZMQError as e:  # type: ignore
            retries_left -= 1
            if retries_left > 0:
                logger.warning("Receive failed. error=%s, attempts_left=%d. ", e, retries_left)
                time.sleep(0.1)
            else:
                logger.error("Receive failed after all retries. error=%s. ", e)
                raise RuntimeError(f"Failed to receive data from {path} after {max_retries} retries: {e}")


def get_external_request_id(request_id: str):
    # NOTE(zxr): vLLM PR #27987 add additional suffix
    # to EngineCore request_id with len(suffix) == 9
    return request_id[:-9]
