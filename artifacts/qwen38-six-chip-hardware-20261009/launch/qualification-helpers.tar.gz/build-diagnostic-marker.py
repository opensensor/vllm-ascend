import subprocess
from pathlib import Path
import torch
from torch.utils.cpp_extension import include_paths, library_paths
root=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
command=['c++','-std=c++17','-O2','-shared','-fPIC',f'-D_GLIBCXX_USE_CXX11_ABI={int(torch.compiled_with_cxx11_abi())}',str(root/'diagnostic-marker.cpp'),'-o',str(root/'diagnostic-marker-v12.so')]
command += [f'-I{p}' for p in include_paths()]
command += [f'-L{p}' for p in library_paths()]
command += ['-ltorch_cpu','-lc10','-ltorch']
subprocess.run(command,check=True)
print('Host-only diagnostic marker compiled; no device runtime initialized',flush=True)
