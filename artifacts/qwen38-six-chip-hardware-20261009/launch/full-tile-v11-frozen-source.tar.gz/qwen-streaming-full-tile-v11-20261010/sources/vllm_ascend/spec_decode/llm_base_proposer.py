# SPDX-License-Identifier: Apache-2.0
import copy
import inspect as _inspect
from collections.abc import Callable
from contextlib import AbstractContextManager, nullcontext
from functools import partial
from typing import Any, Protocol, cast

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from vllm.compilation.breakable_cudagraph import is_breakable_cudagraph_enabled
from vllm.config import CUDAGraphMode, VllmConfig, get_layers_from_vllm_config, set_current_vllm_config
from vllm.distributed.parallel_state import (
    get_pp_group,
    get_tp_group,
    get_world_group,
    init_model_parallel_group,
)
from vllm.forward_context import BatchDescriptor, ForwardContext, get_forward_context
from vllm.logger import logger
from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
from vllm.model_executor.model_loader import get_model
from vllm.model_executor.models import supports_multimodal
from vllm.model_executor.models.deepseek_eagle3 import Eagle3DeepseekV2ForCausalLM
from vllm.model_executor.models.llama_eagle3 import Eagle3LlamaForCausalLM
from vllm.model_executor.models.qwen3_dflash import DFlashQwen3ForCausalLM
from vllm.model_executor.models.qwen3_dspark import Qwen3DSparkForCausalLM
from vllm.models.kimi_k3.nvidia.dspark_mla import K3DSparkForCausalLM
from vllm.triton_utils import HAS_TRITON, triton
from vllm.utils.platform_utils import is_pin_memory_available
from vllm.v1.attention.backends.utils import CommonAttentionMetadata
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.sample.metadata import SamplingMetadata
from vllm.v1.spec_decode.llm_base_proposer import SpecDecodeBaseProposer
from vllm.v1.spec_decode.metadata import SpecDecodeMetadata
from vllm.v1.spec_decode.utils import (
    PADDING_SLOT_ID,
    compute_new_slot_mapping,
    extend_all_queries_by_N,
)
from vllm.v1.worker.gpu_input_batch import CachedRequestState, InputBatch

from vllm_ascend import utils as ascend_utils
from vllm_ascend._310p.qwen4exp_mtp import qwen4exp_mtp_hidden_width
from vllm_ascend.ascend_config import get_ascend_config
from vllm_ascend.ascend_forward_context import _EXTRA_CTX, set_ascend_forward_context
from vllm_ascend.attention.attention_v1 import AscendAttentionState
from vllm_ascend.attention.utils import AscendCommonAttentionMetadata
from vllm_ascend.compilation.acl_graph import ACLGraphWrapper, update_full_graph_params
from vllm_ascend.compilation.breakable_aclgraph import BreakableACLGraphWrapper
from vllm_ascend.device.device_op import DeviceOperator
from vllm_ascend.distributed.kv_transfer.sparse_kv_offload.copy_sfa_topk_slots import (
    prepare_copy_sfa_dummy_slots,
)
from vllm_ascend.distributed.kv_transfer.sparse_kv_offload.sparse_kv_offload_manager import (
    prepare_sparse_kv_offload_mtp_dummy_metadata,
)
from vllm_ascend.models.deepseek_v4.dspark import DSparkDeepseekV4ForCausalLM
from vllm_ascend.models.llama_eagle3_vwn import Eagle3VwnLlamaForCausalLM
from vllm_ascend.ops.triton.spec_decode.utils import prepare_inputs_padded_kernel
from vllm_ascend.ops.triton.triton_utils import get_vectorcore_num
from vllm_ascend.spec_decode.utils import (
    SlidingWindowAdapter,
    _maybe_eager_context,
    compact_mtp_topk_indices,
    patch_tensor_parallel_group,
)
from vllm_ascend.utils import (
    _is_glm_model,
    check_gdn_layer,
    enable_sp,
    lmhead_tp_enable,
    use_updatable_graph,
    vllm_version_is,
)
from vllm_ascend.worker.device_metadata import DeviceMetadataTask, DeviceMetadataTaskProvider


class _HiddenStateDrafter(Protocol):
    def combine_hidden_states(self, aux_hidden_states: torch.Tensor) -> torch.Tensor: ...


# Currently we will fix block size to a small one since `num_reqs` can't be too large
_PREPARE_INPUTS_BLOCK_SIZE = 4

_HIDDEN_STATE_DRAFTER_TYPES: tuple[type, ...] = (
    Eagle3LlamaForCausalLM,
    DFlashQwen3ForCausalLM,
    Qwen3DSparkForCausalLM,
    K3DSparkForCausalLM,
    Eagle3VwnLlamaForCausalLM,
    Eagle3DeepseekV2ForCausalLM,
    DSparkDeepseekV4ForCausalLM,
)

# DeepSeek V4.1 is skipped on Triton-less builds such as 310P (newer main's
# sparse_mqa_logits calls tl.constexpr at module scope, crashing the import).
if HAS_TRITON:
    from vllm_ascend.models.deepseek_v41.dspark import DSparkDeepseekV41ForCausalLM

    _HIDDEN_STATE_DRAFTER_TYPES += (DSparkDeepseekV41ForCausalLM,)


def greedy_sample(logits: torch.Tensor) -> torch.Tensor:
    tp_group = get_tp_group()
    B, V_local = logits.shape
    rank = tp_group.rank_in_group

    local_max_logits, local_max_indices = logits.max(dim=-1)

    local_global_idx = local_max_indices + rank * V_local  # [B]

    # [B, world_size]
    gathered_logits = tp_group.all_gather(local_max_logits.unsqueeze(-1), dim=-1)
    gathered_global_idx = tp_group.all_gather(local_global_idx.unsqueeze(-1), dim=-1)  # [B, world_size]
    global_max_rank = gathered_logits.argmax(dim=-1)  # [B]
    target_argmax = gathered_global_idx.gather(dim=-1, index=global_max_rank.unsqueeze(-1)).squeeze(-1)  # [B]
    return target_argmax


class AscendSpecDecodeBaseProposer(SpecDecodeBaseProposer):
    _runnable: ACLGraphWrapper | Callable
    arange: torch.Tensor
    # Models without extended/decoupled (xdrope) rope never set these, but
    # the proposer reads them unconditionally. Mirror the defaults that
    # NPUModelRunner310.__init__ applies to the runner for the same reason.
    uses_xdrope_dim: int = 0
    draft_uses_xdrope_dim: int = 0

    def _ensure_query_start_loc_arange_capacity(self) -> None:
        """Ensure ``arange`` includes the terminal query boundary."""
        required_size = max(self.max_batch_size, self.max_num_tokens) + 1
        if self.arange.numel() < required_size:
            self.arange = torch.arange(
                required_size,
                device=self.arange.device,
                dtype=self.arange.dtype,
            )

    def _create_draft_vllm_config(self) -> VllmConfig:
        """Expose the draft runner type during model construction.

        ``_get_model`` calls this hook before ``get_model`` installs the
        returned config as the current vLLM config. Attention constructors can
        then identify the draft model from ``runner_type="draft"``.

        Keep the target-derived model config otherwise unchanged. Replacing it
        with ``draft_model_config`` changes how generic proposers construct
        their layers and can invalidate target parallel settings.
        """
        draft_vllm_config = super()._create_draft_vllm_config()
        draft_vllm_config = copy.copy(draft_vllm_config)
        draft_vllm_config.model_config = copy.copy(draft_vllm_config.model_config)
        draft_vllm_config.model_config.runner_type = self.speculative_config.draft_model_config.runner_type
        return draft_vllm_config

    @staticmethod
    def _get_multimodal_image_token_index(model_name: str, config: Any) -> int | None:
        if model_name in [
            "Qwen2_5_VLForConditionalGeneration",
            "Qwen3VLForConditionalGeneration",
            "Qwen3VLMoeForConditionalGeneration",
            "Qwen3_5ForConditionalGeneration",
            "Qwen3_5MoeForConditionalGeneration",
            "Step3p7ForConditionalGeneration",
            "Gemma4ForConditionalGeneration",
            "Gemma4UnifiedForConditionalGeneration",
            "Glm5NextForConditionalGeneration",
        ]:
            return config.image_token_id
        if model_name == "PixtralForConditionalGeneration":
            return config.vision_config.image_token_id
        if model_name in {
            "KimiK25ForConditionalGeneration",
            "KimiK3ForConditionalGeneration",
            "AscendKimiK3ForConditionalGeneration",
        }:
            return config.media_placeholder_token_id
        # Some models (for example DeepSeek-V4 Vision) use multiple
        # position-dependent image sentinel tokens instead of one placeholder
        # token. Their text-only drafter does not need a synthetic image token
        # index during decode.
        return getattr(config, "image_token_index", None)

    def __init__(self, vllm_config: VllmConfig, device: torch.device, pass_hidden_states_to_model: bool, runner=None):
        super().__init__(vllm_config, device, pass_hidden_states_to_model, runner=runner)
        self._ensure_query_start_loc_arange_capacity()

        # Qwen4Exp passes its complete hyperconnection state to MTP. Upstream's
        # proposer only widens this buffer for hc_mult (DeepSeek V4); the Qwen
        # checkpoint calls the same dimension hc_count. Keep the draft input
        # wide enough for the target state before any proposal or graph capture.
        expected_width = qwen4exp_mtp_hidden_width(self.draft_model_config, self.method)
        if expected_width is not None and self.hidden_size != expected_width:
            self.hidden_size = expected_width
            self.hidden_states = torch.zeros(
                (self.max_num_tokens, expected_width), dtype=self.dtype, device=self.device
            )

        # Assign runner before it's used in the methods below
        self.runner = runner

        logger.debug(
            "[spec_decode/base] Initializing spec decode proposer: method=%s,"
            " num_speculative_tokens=%s, hidden_size=%s, pass_hidden_states=%s,"
            " parallel_drafting=%s, use_cuda_graph=%s, device=%s",
            self.method,
            self.num_speculative_tokens,
            self.hidden_size,
            pass_hidden_states_to_model,
            self.speculative_config.parallel_drafting if self.speculative_config else False,
            runner._use_aclgraph() if runner else False,
            device,
        )
        self.use_async_scheduling = self.vllm_config.scheduler_config.async_scheduling
        self.use_compress = hasattr(self.vllm_config.model_config.hf_config, "compress_ratios")
        self.has_gdn = check_gdn_layer(self.vllm_config)
        self.pass_hidden_states_to_model = pass_hidden_states_to_model
        self.decode_threshold = 1 + self.num_speculative_tokens
        self.query_start_loc = self.runner._make_buffer(self.runner.max_num_reqs + 2, dtype=torch.int32)

        self.dcp_size = self.runner.dcp_size
        self.dcp_rank = self.runner.dcp_rank

        self.use_sparse = hasattr(vllm_config.model_config.hf_text_config, "index_topk")

        self._share_mtp_indices = False
        spec_config = self.vllm_config.speculative_config
        draft_model_config = getattr(spec_config, "draft_model_config", None)
        draft_hf_config = draft_model_config.hf_config if draft_model_config is not None else None
        # Reuse/compaction serves subsequent draft steps; MTP1 has none.
        self._share_mtp_indices = self.num_speculative_tokens > 1 and getattr(
            draft_hf_config, "index_share_for_mtp_iteration", False
        )
        self._lim_topk_compactors: list[nn.Module] = []

        # NOTE:
        # `draft_tensor_parallel_size` does not take effect for Eagle:
        # the draft model uses the same TP size as the target model in practice.
        # so we applied this patch to set tp=1 of draft model separately.
        # Due to verification of `_verify_and_get_draft_tp` in vllm,
        # the value of `draft_tensor_parallel_size` here will either be 1 separately
        # or the same as target model.
        # TODO(zhaomingyu13): If we want to adapt to the case where draft model tp
        # is not 1 and differs from target model, this part should be rewritten.
        if vllm_config.parallel_config.tensor_parallel_size != self.speculative_config.draft_tensor_parallel_size:
            tp_group = init_model_parallel_group(
                [[get_world_group().rank]],
                get_world_group().rank,
                torch.distributed.get_backend(get_world_group().device_group),
                use_message_queue_broadcaster=True,
                group_name="tp",
            )
            self.tp_group_context: AbstractContextManager[Any] = patch_tensor_parallel_group(tp_group)
        else:
            self.tp_group_context = nullcontext()

        self.use_cuda_graph = self.runner._use_aclgraph() and not self.speculative_config.enforce_eager
        self._raise_if_padded_drafter_batch_disabled_and_full_graph_enabled()

        # GLM series models: speculative decoding does not yet support running
        # the draft model in graph mode. Force the draft model to always use
        # eager mode. This is equivalent to the user adding
        # `"enforce_eager": true` to the `--speculative-config`, and keeps
        # the target model's graph-mode setting untouched.
        # TODO(lilinsiman): Remove this code segment after future versions of the GLM
        # series models support graph input for speculative inference.
        if _is_glm_model(self.vllm_config.model_config) and not self._glm_draft_graph_supported:
            if self.use_cuda_graph:
                logger.warning(
                    "GLM series models with speculative decoding currently do "
                    "not support graph mode. The draft model has been "
                    "automatically switched to eager mode "
                    "(enforce_eager=true). Graph mode support for GLM "
                    "speculative decoding will be added in a future release. "
                )
            self.use_cuda_graph = False

        # NOTE: _enable_probabilistic_draft_probs is set by the upstream
        # SpecDecodeBaseProposer.__init__.
        if self._enable_probabilistic_draft_probs:
            if self.use_local_argmax_reduction:
                raise ValueError(
                    "use_local_argmax_reduction is not compatible with draft_sample_method='probabilistic'."
                )
            if self.use_heterogeneous_vocab:
                raise ValueError("use_heterogeneous_vocab is not compatible with draft_sample_method='probabilistic'.")

        # TODO: Remove it when the bug of fx-graph is solved
        self.maybe_eager_context: AbstractContextManager[Any] = nullcontext()
        if not self.use_cuda_graph and enable_sp(vllm_config):
            self.maybe_eager_context = _maybe_eager_context(vllm_config)

        self.token_indices_to_sample = torch.zeros(
            self.vllm_config.scheduler_config.max_num_batched_tokens, dtype=torch.int32, device=device
        )
        metadata_lens = self.runner.max_num_tokens + 2 * self.runner.max_num_reqs
        num_mtp_draft_slots = max(self.num_speculative_tokens - 1, 0) * self.runner.max_num_reqs
        slot_mapping_lens = self.runner.max_num_tokens + num_mtp_draft_slots
        self.slot_mapping_group = [
            torch.zeros(slot_mapping_lens, dtype=torch.int32, device=device, pin_memory=self.runner.pin_memory)
            for _ in range(self.num_speculative_tokens)
        ]

        # dsv32 needs seq_lens and query_start_loc persistent tensors for full graph mode
        self.seq_lens_group = [
            torch.zeros(metadata_lens, dtype=torch.int32, device=device, pin_memory=self.runner.pin_memory)
            for _ in range(self.num_speculative_tokens)
        ]
        self.query_start_loc_group = [
            torch.zeros(metadata_lens, dtype=torch.int32, device=device, pin_memory=self.runner.pin_memory)
            for _ in range(self.num_speculative_tokens)
        ]

        # DCP needs independent block-table tensors for the first and later steps.
        # since final block table tensor is not ready in __init__, it is delayed until dummy_run
        self.block_table_tensor_clone: torch.Tensor | None = None

        self._runnable: Any = self._run_merged_draft
        if self.uses_mrope:
            num_dims = self.draft_model_config.mrope_num_dims
            self.mrope_positions = torch.zeros((num_dims, self.max_num_tokens + 1), dtype=torch.int32, device=device)
        else:
            # RoPE need (max_num_tokens,)
            self.positions = torch.zeros(self.max_num_tokens, dtype=torch.int32, device=device)

        self.token_arange_np = np.arange(self.max_num_tokens + 1, dtype=np.int32)
        self.enable_enpu = self.runner.enable_enpu
        self.use_eagle = self.runner.use_eagle
        self.draft_window_size = None
        self.sliding_window = None

    def _raise_if_padded_drafter_batch_disabled_and_full_graph_enabled(self):
        if (
            self.speculative_config.disable_padded_drafter_batch
            and self.use_cuda_graph
            and self.compilation_config.cudagraph_mode.has_full_cudagraphs()
        ):
            raise NotImplementedError(
                "Speculative Decoding with cudagraph mode containing full cudagraphs only "
                "supports padded drafter batch. Please unset "
                "disable_padded_drafter_batch in the speculative_config."
            )

    def _is_cache_only_draft_attn_group(self, attn_group: Any) -> bool:
        # Cache-only backends provide metadata without an attention impl,
        # regardless of the KV cache spec's inheritance hierarchy.
        # Executable backends may resolve their impl from the current config.
        with set_current_vllm_config(self.vllm_config):
            return attn_group.backend.get_impl_cls() is None

    def _get_primary_draft_attn_group(self) -> Any:
        for attn_group in self.draft_attn_groups:
            if not self._is_cache_only_draft_attn_group(attn_group):
                return attn_group
        raise ValueError("Draft attention groups contain no executable attention backend.")

    def _maybe_remove_d2t(self, draft_model: nn.Module) -> None:
        """Drop the identity d2t mapping of a full-vocab EAGLE3 draft."""
        if self.method != "eagle3":
            return
        target_vocab_size = self.speculative_config.draft_model_config.get_vocab_size()
        draft_vocab_size = draft_model.config.draft_vocab_size
        if draft_vocab_size == target_vocab_size:
            draft_model.draft_id_to_target_id = None

    def _get_model(self) -> nn.Module:
        """
        Default method to call get_model(). Can be overridden by subclasses which
        need to customize model loading.
        """
        from vllm.compilation.backends import set_model_tag

        draft_vllm_config = self._create_draft_vllm_config()
        draft_load_config = self.speculative_config.draft_load_config
        logger.info(
            "[spec_decode/base] Loading draft model: method=%s, load_format=%s, model=%s",
            self.method,
            getattr(draft_load_config, "load_format", None),
            getattr(self.speculative_config.draft_model_config, "model", None),
        )
        with set_model_tag("eagle_head"):
            model = get_model(
                vllm_config=draft_vllm_config,
                model_config=self.speculative_config.draft_model_config,
                load_config=self.speculative_config.draft_load_config,
            )
            self._maybe_remove_d2t(model)

        return model

    def load_model(self, model: nn.Module) -> None:
        assert get_pp_group().is_last_rank, f"{self.method} drafter must be loaded on the last pipeline stage."

        target_attn_layer_names = set(get_layers_from_vllm_config(self.vllm_config, AttentionLayerBase).keys())

        with self.maybe_eager_context:
            self.model = self._get_model()

        if self.supports_mm_inputs:
            # Match upstream: a multimodal target can use a text-only drafter.
            if not _draft_embed_accepts_mm(getattr(self.model, "embed_input_ids", None)):
                # Main lane: introspect the draft embed signature instead of
                # calling it. Drafts that share the target embedding (e.g. K3
                # DSpark on a kv_consumer) have no own embed_tokens before the
                # target sharing step, so the runtime probe asserts on
                # embed_tokens=None.
                logger.warning("Draft model does not support multimodal inputs, falling back to text-only mode")
                self.supports_mm_inputs: bool = False

        # Find draft layers (attention layers added by draft model)
        all_attn_layers = get_layers_from_vllm_config(
            self.vllm_config,
            AttentionLayerBase,  # type: ignore[type-abstract]
        )
        # Filter to only layers that have KV cache specs. Split indexer cache
        # layers must stay in this set: they now own a metadata builder even
        # though the draft model shares their physical cache with the target.
        self._draft_attn_layer_names = {
            name
            for name in (set(all_attn_layers.keys()) - target_attn_layer_names)
            if all_attn_layers[name].get_kv_cache_spec(self.vllm_config) is not None
        }

        self.attn_layer_names = list(sorted(self._draft_attn_layer_names))
        draft_attn_layers_dict = get_layers_from_vllm_config(self.vllm_config, AttentionLayerBase)
        # initialized for mamba models
        self.kernel_block_size = (
            draft_attn_layers_dict[self.attn_layer_names[0]].get_attn_backend().get_supported_kernel_block_sizes()[0]
        )

        # Sliding-window draft attention adapter.
        # Read from the validated AscendConfig singleton instead of bypassing it
        # via additional_config["draft_window_size"] (architecture debt #7).

        self.draft_window_size = get_ascend_config().draft_window_size
        if self.draft_window_size is not None:
            # Compatibility validation before enabling sliding-window draft
            # attention. model_config may be absent in unit-test harnesses,
            # so look it up defensively.
            _target_hf_config = getattr(getattr(self.vllm_config, "model_config", None), "hf_config", None)
            _target_model_type = getattr(_target_hf_config, "model_type", "") or ""
            _target_is_deepseek_v4 = _target_model_type.startswith("deepseek_v4")
            if self.method == "mtp":
                # MTP reuses the target's own layers; capping its attention
                # to a window would also window the target model.
                logger.warning(
                    "[sliding-window] draft method is MTP, which is not "
                    "compatible with draft_window_size; the window is ignored."
                )
            elif self.method == "dspark" and _target_is_deepseek_v4:
                logger.warning(
                    "[sliding-window] DSpark drafts trained natively with a "
                    "DeepSeek-V4 target are long-context stable; enabling the "
                    "sliding window degrades acceptance length."
                )

        if self.draft_window_size is not None and self.method != "mtp":
            # EAGLE3: seq_lens is context-only, K draft positions lie beyond it
            #   -> future_offset = K.
            # DFlash / DSpark: set_inputs_first_pass bakes the query stretch into
            #   seq_lens (dspark_proposer adds num_query_per_req at cad.seq_lens),
            #   so the window end must not add K again -> future_offset = 0.
            # MTP is excluded: it reuses the target's own layers, so windowing
            # it would also window the target model.
            future_offset = 0 if self.method in ("dflash", "dspark") else self.num_speculative_tokens
            self.sliding_window = SlidingWindowAdapter(
                self.draft_window_size,
                self.kernel_block_size,
                self.runner.max_num_reqs,
                future_offset,
                self.device,
            )

        if supports_multimodal(model):
            # handle multimodality
            model_name = self.get_model_name(model)
            image_token_index = self._get_multimodal_image_token_index(model_name, model.config)
            if image_token_index is not None:
                self.model.config.image_token_index = image_token_index
            target_language_model = model.get_language_model()
        else:
            target_language_model = model

        # share embed_tokens with the target model if needed
        self._maybe_share_embeddings(target_language_model)
        self._maybe_share_topk_indices(target_language_model)
        self._maybe_share_lm_head(target_language_model)

        # Align draft weights before precomputing draft hidden states.
        if self.method in ("dspark", "dflash") and hasattr(self.model, "post_process"):
            self.model.post_process(self.vllm_config)

        if (
            self.parallel_drafting
            and self.pass_hidden_states_to_model
            and self.parallel_drafting_hidden_state_tensor is not None
        ):
            self.parallel_drafting_hidden_state_tensor.copy_(
                self.model.combine_hidden_states(self.model.mask_hidden.view(3 * self.hidden_size))
                if self.eagle3_use_aux_hidden_state
                else self.model.mask_hidden.view(self.hidden_size)
            )

    def _maybe_share_embeddings(self, target_language_model: nn.Module) -> None:
        """
        Some draft models may not have their own embedding layers, and some may
        have a duplicate copy of the target model's embedding layers. In these cases,
        we share the target model's embedding layers with the draft model to save
        memory.
        """
        if get_pp_group().world_size == 1:
            if hasattr(target_language_model.model, "embed_tokens"):
                target_embed_tokens = target_language_model.model.embed_tokens
            elif hasattr(target_language_model.model, "embedding"):
                target_embed_tokens = target_language_model.model.embedding
            else:
                raise AttributeError("Target model does not have 'embed_tokens' or 'embedding' attribute")
            # If pp>1, the weights of mtp and the main model's embedding are not on the same device.
            # check if mtp model use main model's embedding and LMhead
            share_embeddings = False
            if self.method in ("eagle", "eagle3"):
                # EAGLE model
                if not getattr(self.model, "has_own_embed_tokens", True):
                    share_embeddings = True
                    logger.info(
                        "[spec_decode/base] Detected EAGLE model without its own"
                        " embed_tokens in the checkpoint. Sharing target model"
                        " embedding weights with the draft model."
                    )
                elif (
                    isinstance(target_embed_tokens.weight, torch.Tensor)
                    and isinstance(self.model.model.embed_tokens.weight, torch.Tensor)
                    # TODO: Offload to CPU for comparison to avoid extra NPU memory
                    # usage in CI testing environments with limited NPU memory
                    and torch.equal(
                        target_embed_tokens.weight.cpu(),
                        self.model.model.embed_tokens.weight.cpu(),
                    )
                ):
                    share_embeddings = True
                    logger.info(
                        "[spec_decode/base] Detected EAGLE model with embed_tokens"
                        " identical to the target model. Sharing target model embedding"
                        " weights with the draft model."
                    )
                else:
                    logger.info(
                        "[spec_decode/base] Detected EAGLE model with distinct"
                        " embed_tokens weights. Keeping separate embedding weights"
                        " from the target model."
                    )
            elif self.method == "dspark":
                if not getattr(self.model, "has_own_embed_tokens", True):
                    share_embeddings = True
                    logger.info(
                        "[spec_decode/base] Detected DSpark model without its own"
                        " embed_tokens in the checkpoint. Sharing target model"
                        " embedding weights with the draft model."
                    )
                else:
                    logger.info(
                        "[spec_decode/base] Detected DSpark model with distinct"
                        " embed_tokens weights. Keeping separate embedding weights"
                        " from the target model."
                    )
            else:
                # MTP model
                share_embeddings = not self.use_compress
                if share_embeddings:
                    logger.info(
                        "[spec_decode/base] Detected MTP model. Sharing target model"
                        " embedding weights with the draft model."
                    )

            if share_embeddings:
                if hasattr(self.model.model, "embed_tokens"):
                    del self.model.model.embed_tokens
                self.model.model.embed_tokens = target_embed_tokens
        else:
            logger.info(
                "[spec_decode/base] PP>1: draft model loaded its own vocab embedding"
                " weights instead of sharing them with the target model."
            )

    # share lm_head with the target model if needed
    def _maybe_share_lm_head(self, model: nn.Module) -> None:
        if self.method == "mtp":
            share_identical_head = getattr(self.model, "share_target_lm_head_if_identical", None)
            if share_identical_head is not None and share_identical_head(model):
                logger.info("[spec_decode/base] Sharing identical MTP and target LM head weights.")
        # some model definition do not define lm_head explicitly
        # and reuse embed_tokens for lm_head, e.g., CohereForCausalLM
        if self.method in ("eagle", "dflash", "dspark"):
            # For DFlash drafters trained with a reduced draft vocabulary, the
            # draft model ships its own lm_head of shape [draft_vocab_size,
            # hidden] whose rows map to a trained subset of the target vocab via
            # the draft_id_to_target_id (d2t) buffer. Overwriting it with the
            # target lm_head ([target_vocab_size, hidden]) makes the draft emit
            # logits over the wrong vocabulary, so the verifier rejects almost
            # every speculative token. Keep the draft's own lm_head in that case.
            draft_has_own_lm_head = (getattr(self.model, "draft_id_to_target_id", None) is not None) or (
                getattr(self.model, "has_own_lm_head", True)
            )
            if draft_has_own_lm_head and self.method == "dflash":
                logger.info(
                    "[spec_decode/base] DFlash draft uses d2t vocab remapping;"
                    " keeping the draft's own lm_head instead of sharing the target"
                    " lm_head."
                )
            elif draft_has_own_lm_head and self.method == "dspark":
                logger.info(
                    "[spec_decode/base] Detected DSpark model with distinct lm_head weights."
                    " Keeping separate lm_head weights from the target model."
                )
            else:
                logger.info("[spec_decode/base] Loading EAGLE/DFLASH LM head weights from the target model.")
                target_lm_head = None
                if hasattr(model, "lm_head"):
                    target_lm_head = model.lm_head
                elif hasattr(model, "get_language_model") and hasattr(model.get_language_model(), "lm_head"):
                    target_lm_head = model.get_language_model().lm_head
                if target_lm_head is None:
                    logger.warning(
                        "[spec_decode/base] Target model has no accessible lm_head"
                        " for sharing. Draft model will use its own lm_head."
                        " This may cause incorrect logits if the draft lm_head"
                        " is not trained."
                    )
                else:
                    self.model.lm_head = target_lm_head

        if self.method == "mtp" and self.vllm_config.model_config.is_deepseek_mla:
            # Multimodal wrappers such as Glm5NextForConditionalGeneration keep
            # lm_head on the nested language model, so resolve it the same way
            # the EAGLE branch above does.
            target_lm_head = getattr(model, "lm_head", None)
            if target_lm_head is None and hasattr(model, "get_language_model"):
                target_lm_head = getattr(model.get_language_model(), "lm_head", None)
            if target_lm_head is None and hasattr(model, "language_model"):
                target_lm_head = getattr(model.language_model, "lm_head", None)
            if target_lm_head is None:
                logger.warning(
                    "[spec_decode/base] Target model has no accessible lm_head;"
                    " MTP layers keep their own shared_head weights."
                )
            else:
                # Comparing weights only tells the two heads apart when the draft
                # actually loaded one. A checkpoint that ships no MTP head leaves
                # shared_head.head at its allocation-time contents, which compare
                # unequal and would leave the draft predicting from garbage, so ask
                # the model whether it owns a head before falling back to the
                # comparison.
                draft_owns_head = getattr(self.model, "has_own_lm_head", None)
                for _, layer_module in self.model.model.layers.items():
                    if draft_owns_head is False or torch.equal(
                        layer_module.shared_head.head.weight, target_lm_head.weight
                    ):
                        layer_module.shared_head.head = target_lm_head

        if self._should_wrap_outer_draft_graph():
            logger.info(
                "[spec_decode/base] Wrapping draft model with ACLGraphWrapper:"
                " runtime_mode=FULL, use_eagle=%s, enable_enpu=%s",
                self.use_eagle,
                self.enable_enpu,
            )
            self.update_stream = None
            self._runnable = ACLGraphWrapper(
                self._run_merged_draft,
                self.vllm_config,
                runtime_mode=CUDAGraphMode.FULL,
                use_eagle=self.use_eagle,
                enable_enpu=self.enable_enpu,
            )

    def _should_wrap_outer_draft_graph(self) -> bool:
        if not self.vllm_config.compilation_config.cudagraph_mode.has_full_cudagraphs() or not self.use_cuda_graph:
            return False
        # The runner wraps MTP with BreakableACLGraphWrapper after load_model
        # returns. This check must include the enabled mode, not just the
        # current model type, or the proposer creates an outer graph first and
        # both captures try to record into the same NPU memory pool.
        return not (
            self.method == "mtp"
            and (is_breakable_cudagraph_enabled() or isinstance(self.model, BreakableACLGraphWrapper))
        )

    def set_update_stream(self, update_stream: Any) -> None:
        if hasattr(self._runnable, "set_update_stream"):
            self._runnable.set_update_stream(update_stream)
        self.update_stream = update_stream

    def _maybe_update_metadata(
        self,
        att_backend: Any,
        multi_steps_attn_metadata: list[dict[str, Any]],
    ) -> None:
        if (
            not use_updatable_graph(att_backend)
            or not hasattr(self._runnable, "update_draft_model_metadata")
            or not hasattr(self._runnable, "set_attn_backend")
        ):
            return

        update_params = []
        for per_step_metadata in multi_steps_attn_metadata:
            for layer_name, metadata in per_step_metadata.items():
                update_params.append(
                    {
                        "layer_name": layer_name,
                        "actual_seq_lengths": metadata.actual_seq_lengths_q,
                        "actual_seq_lengths_kv": metadata.seq_lens_list,
                        "block_table": metadata.block_tables,
                    }
                )
        self._runnable.update_draft_model_metadata(update_params)  # type: ignore
        self._runnable.set_attn_backend(att_backend)  # type: ignore

    def _maybe_share_topk_indices(self, target_language_model: nn.Module) -> None:
        self._lim_topk_compactors = []
        draft_model = getattr(self.model, "model", None)
        if hasattr(target_language_model.model, "topk_indices_buffer"):
            if hasattr(self.model.model, "topk_indices_buffer"):
                del self.model.model.topk_indices_buffer
            self.model.model.topk_indices_buffer = target_language_model.model.topk_indices_buffer
            logger.info(
                "[spec_decode/base] Detected MTP model with topk_indices_buffer."
                " Sharing target model topk_indices_buffer with the draft model."
            )
            target_buffer = target_language_model.model.topk_indices_buffer
            if target_buffer is not None and draft_model is not None:
                for module in draft_model.modules():
                    if hasattr(module, "topk_indices_buffer"):
                        module.topk_indices_buffer = target_buffer
        if draft_model is not None:
            self._lim_topk_compactors.extend(
                module for module in draft_model.modules() if getattr(module, "uses_lim_topk_metadata", False)
            )

    def get_model(self) -> nn.Module:
        # get raw model out of the aclgraph wrapper.
        if isinstance(self.model, ACLGraphWrapper):
            return self.model.unwrap()
        return self.model

    def shallow_copy_metadata(self, attn_metadata):
        # Currently, new objects will be assigned to the lists in attn_metadata
        # when update. So we can use the shallow copy.
        return copy.copy(attn_metadata)

    def _build_multi_group_graph_capture_metadata(self, common_attn_metadata, draft_index):
        return None

    def _common_attn_metadata_for_draft_group(
        self,
        common_attn_metadata,
        attn_group,
        num_input_tokens,
        draft_index=0,
    ):
        """Return the common metadata view consumed by one draft group."""
        return common_attn_metadata

    def _build_cache_only_group_next_step_attn_metadata(
        self,
        common_attn_metadata,
        draft_index,
        num_input_tokens,
        primary_group,
        primary_metadata,
        cache_only_groups,
    ):
        """Build metadata for cache-only groups without advancing MTP state."""
        per_layer_attn_metadata = {layer_name: primary_metadata for layer_name in primary_group.layer_names}
        for attn_group in cache_only_groups:
            attn_metadata = attn_group.get_metadata_builder().build_for_drafting(
                common_attn_metadata,
                draft_index,
            )
            for layer_name in attn_group.layer_names:
                per_layer_attn_metadata[layer_name] = attn_metadata
        return per_layer_attn_metadata

    def _get_attn_metadata_layer_names(self, attn_group):
        return self.attn_layer_names

    @torch.inference_mode()
    def dummy_run(
        self,
        num_tokens: int,
        with_prefill: bool = False,
        in_graph_capturing: bool = False,
        num_reqs: int = 0,
        num_tokens_across_dp: torch.Tensor | None = None,
        aclgraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        batch_descriptor=None,
        dummy_compute_logits=lambda hidden_states: None,
        is_profile=False,
    ):
        (
            num_tokens,
            num_tokens_across_dp,
            _,
        ) = self.runner._sync_metadata_across_dp(num_tokens, is_draft_model=True)
        dcp_manager = getattr(self.runner, "dcp_manager", None)

        multi_steps_attn_metadata = []
        if not self.use_cuda_graph:
            aclgraph_runtime_mode = CUDAGraphMode.NONE

        # init block table tensor clone is only available after profile run and is only used for graph mode
        if self.dcp_size > 1 and self.use_cuda_graph and not is_profile and self.block_table_tensor_clone is None:
            self.block_table_tensor_clone = torch.zeros(
                (
                    self.runner.max_num_tokens + 2 * self.runner.max_num_reqs,
                    self.runner.input_batch.block_table[0].get_device_tensor().shape[1],
                ),
                dtype=torch.int32,
                device=self.device,
                pin_memory=self.runner.pin_memory,
            )

        # dummy_run shares pinned CPU buffer (query_start_loc, etc.) with
        # execute_model. It must participate in the same event protocol so that
        # back-to-back dummy/real steps don't overwrite pinned memory while a
        # prior non_blocking H2D DMA is still reading. Mirrors upstream
        # gpu_model_runner._dummy_run.
        with self.runner.synchronize_input_prep():
            if aclgraph_runtime_mode == CUDAGraphMode.FULL and len(self.runner.attn_groups) > 0:
                num_computed_tokens_cpu = self.runner.input_batch.num_computed_tokens_cpu_tensor[:num_reqs]

                # num_reqs is already the padded version
                self.query_start_loc.cpu[: num_reqs + 1].copy_(self.runner.query_start_loc.cpu[: num_reqs + 1])
                self.query_start_loc.copy_to_gpu()
                if self.runner._offload_pool_slots is not None:
                    assert self.runner._offload_pool_active is not None
                    prepare_copy_sfa_dummy_slots(
                        self.runner._offload_pool_slots.np,
                        self.runner._offload_pool_active.np,
                        num_reqs,
                    )
                    self.runner._copy_sfa_need_eager_tail_restore = False
                req_ids_tensor, token_to_req = prepare_sparse_kv_offload_mtp_dummy_metadata(
                    num_tokens,
                    num_reqs,
                    self.query_start_loc.cpu,
                    self.runner._offload_req_ids_tensor,
                    self.runner._offload_token_to_req,
                )

                common_attn_metadata = AscendCommonAttentionMetadata(
                    query_start_loc=self.query_start_loc.gpu[: num_reqs + 1],
                    query_start_loc_cpu=self.query_start_loc.cpu[: num_reqs + 1],
                    seq_lens_cpu=self.runner.optimistic_seq_lens_cpu,
                    _seq_lens_cpu=self.runner.optimistic_seq_lens_cpu,
                    seq_lens_cpu_upper_bound=self.runner.optimistic_seq_lens_cpu,
                    seq_lens=self.runner.seq_lens[:num_reqs],
                    num_reqs=num_reqs,
                    num_actual_tokens=num_tokens,
                    num_input_tokens=num_tokens,
                    max_query_len=self.num_speculative_tokens + 1,
                    num_computed_tokens_cpu=num_computed_tokens_cpu,
                    actual_seq_lengths_q=self.runner.actual_seq_lengths_q,
                    block_table_tensor=self.runner.input_batch.block_table[self.kv_cache_gid].get_device_tensor()[
                        :num_reqs
                    ],
                    # This is used to hold a position.
                    slot_mapping=self.runner.input_batch.block_table[self.kv_cache_gid].slot_mapping.gpu,
                    positions=self.runner.positions,
                    positions_cpu=self.runner._dsa_positions_cpu_buf if self.use_compress else None,
                    attn_state=self.runner.attn_state,
                    decode_token_per_req=self.runner.decode_token_per_req,
                    is_prefilling=torch.zeros(num_reqs, dtype=torch.bool),
                    max_seq_len=0,
                    group_len=self.runner.group_len.gpu[:num_reqs],
                    group_key_idx=self.runner.group_key_idx.gpu[:num_reqs],
                    group_key_cache_idx=self.runner.group_key_cache_idx.gpu[:num_reqs],
                    req_topk_buffer_slots=(
                        self.runner._offload_pool_slots.cpu[:num_reqs]
                        if self.runner._offload_pool_slots is not None
                        else None
                    ),
                    req_topk_buffer_active=(
                        self.runner._offload_pool_active.cpu[:num_reqs]
                        if self.runner._offload_pool_active is not None
                        else None
                    ),
                    offload_dummy=True,
                    req_ids_tensor=req_ids_tensor,
                    token_to_req=token_to_req,
                )
                if dcp_manager is not None:
                    # update long_seq related params and flatten block_table
                    common_attn_metadata.context_parallel_metadata = dcp_manager.long_seq_metadata

                assert len(self.draft_attn_groups) > 0
                # update the tensor's address for each step.
                for draft_index in range(self.num_speculative_tokens):
                    common_attn_metadata = self.shallow_copy_metadata(common_attn_metadata)
                    common_attn_metadata.copy_sfa_draft_index = draft_index
                    common_attn_metadata.copy_sfa_restore_tails = False
                    extra_attn_metadata_args: dict = {}
                    if self.use_compress:
                        extra_attn_metadata_args.update(
                            common_ratio_to_sas_metadata=dict(),
                        )
                    # Set the real slot_mapping.
                    slot_mapping_lens = common_attn_metadata.slot_mapping.shape[0]
                    self.slot_mapping_group[draft_index][:slot_mapping_lens].copy_(common_attn_metadata.slot_mapping)
                    self.slot_mapping_group[draft_index][slot_mapping_lens:].fill_(PADDING_SLOT_ID)
                    common_attn_metadata.slot_mapping = self.slot_mapping_group[draft_index]
                    self.seq_lens_group[draft_index][:num_reqs].copy_(common_attn_metadata.seq_lens)
                    self.seq_lens_group[draft_index][num_reqs:].fill_(0)
                    common_attn_metadata.seq_lens = self.seq_lens_group[draft_index][:num_reqs]
                    self.query_start_loc_group[draft_index][: num_reqs + 1].copy_(common_attn_metadata.query_start_loc)
                    self.query_start_loc_group[draft_index][num_reqs + 1 :].fill_(0)
                    common_attn_metadata.query_start_loc = self.query_start_loc_group[draft_index][: num_reqs + 1]
                    if self.dcp_size > 1 and draft_index > 0:
                        assert self.block_table_tensor_clone is not None, "block_table_tensor_clone is not init"
                        common_attn_metadata.block_table_tensor = self.block_table_tensor_clone[:num_reqs]
                    if dcp_manager is not None:
                        dcp_manager.prepare_common_attn_metadata(common_attn_metadata)
                    per_layer_attn_metadata = self._build_multi_group_graph_capture_metadata(
                        common_attn_metadata, draft_index
                    )
                    if per_layer_attn_metadata is not None:
                        multi_steps_attn_metadata.append(per_layer_attn_metadata)
                        continue
                    per_layer_attn_metadata = dict()
                    for attn_group in self.draft_attn_groups:
                        builder = attn_group.get_metadata_builder()
                        if not self.use_compress or draft_index == 0:
                            attn_metadata_eagle = builder.build_for_graph_capture(
                                common_attn_metadata,
                                AscendAttentionState.SpecDecoding
                                if self.method == "mtp"
                                else AscendAttentionState.ChunkedPrefill,
                                **extra_attn_metadata_args,
                            )
                        else:
                            attn_metadata_eagle = builder.build_for_drafting(
                                common_attn_metadata,
                                draft_index,
                                **extra_attn_metadata_args,
                            )
                        for layer_name in attn_group.layer_names:
                            per_layer_attn_metadata[layer_name] = attn_metadata_eagle
                    multi_steps_attn_metadata.append(per_layer_attn_metadata)

        model_positions = self._get_positions(num_tokens)

        batch_size = max(num_tokens // (self.num_speculative_tokens + 1), 1)
        # TODO: temporarily hack here, we should find out batch_size for profile_run
        if is_profile:
            batch_size = min(batch_size, self.runner.max_num_reqs)

        if self.supports_mm_inputs:
            mm_embeds, is_mm_embed = (None, None)
            if _draft_embed_accepts_mm(self.model.embed_input_ids):
                inputs_embeds = self.model.embed_input_ids(
                    self.input_ids[:num_tokens], multimodal_embeddings=mm_embeds, is_multimodal=is_mm_embed
                )
            else:
                inputs_embeds = self.model.embed_input_ids(self.input_ids[:num_tokens])
            self.inputs_embeds[:num_tokens] = inputs_embeds
            inputs_embeds = self.inputs_embeds[:num_tokens]
        else:
            inputs_embeds = None

        self.token_indices_to_sample.fill_(0)

        if aclgraph_runtime_mode == CUDAGraphMode.FULL:
            self._maybe_update_metadata(
                self.draft_attn_groups[0].backend,
                multi_steps_attn_metadata,
            )

        with set_ascend_forward_context(
            multi_steps_attn_metadata[0] if multi_steps_attn_metadata else None,
            self.vllm_config,
            num_tokens=num_tokens,
            num_tokens_across_dp=num_tokens_across_dp,
            num_actual_tokens=0,
            in_profile_run=is_profile,
            batch_descriptor=batch_descriptor,
            aclgraph_runtime_mode=aclgraph_runtime_mode,
            is_draft_model=True,
            draft_attn_metadatas=multi_steps_attn_metadata,
            eplb_heat_collection_status=(
                self.runner.eplb_heat_collection_status if self.runner.dynamic_eplb else False
            ),
        ):
            # Reset MOE layer index before first model call
            forward_context = get_forward_context()
            if forward_context is not None:
                forward_context.moe_layer_index = 0

            self._runnable(
                num_input_tokens=num_tokens,
                batch_size=batch_size,
                token_indices_to_sample=self.token_indices_to_sample[: batch_size * self.extra_slots_per_request],
                # The target_position's address is same as the model_positions's
                target_positions=model_positions,
                inputs_embeds=inputs_embeds,
                multi_steps_attn_metadata=multi_steps_attn_metadata,
                num_tokens=num_tokens,
            )
            forward_context = get_forward_context()
            if forward_context.cudagraph_runtime_mode == CUDAGraphMode.FULL and not _EXTRA_CTX.capturing:
                self._update_full_graph_params(forward_context, num_tokens, multi_steps_attn_metadata)

    def _update_full_graph_params_if_needed(
        self,
        forward_context: ForwardContext,
        num_input_tokens: int,
        multi_steps_attn_metadata: list[dict[str, Any]],
    ) -> None:
        if forward_context.cudagraph_runtime_mode == CUDAGraphMode.FULL:
            self._update_full_graph_params(forward_context, num_input_tokens, multi_steps_attn_metadata)

    def _propose(
        self,
        num_speculative_tokens: int,
        # [num_tokens]
        target_token_ids: torch.Tensor,
        # [num_tokens] or [3, num_tokens] when M-RoPE is enabled
        target_positions: torch.Tensor,
        # [num_tokens, hidden_size]
        target_hidden_states: torch.Tensor,
        # [batch_size]
        next_token_ids: torch.Tensor,
        token_indices_to_sample: torch.Tensor | None,
        common_attn_metadata: CommonAttentionMetadata,
        target_model_batch_desc: BatchDescriptor,
        sampling_metadata: SamplingMetadata,
        mm_embed_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        req_scheduled_tokens=None,
        long_seq_metadata=None,
        num_prefill_reqs=0,
        num_decode_reqs=0,
        scheduler_output: SchedulerOutput = None,
        num_scheduled_tokens: int = 0,
        num_rejected_tokens_gpu: torch.Tensor | None = None,
    ) -> torch.Tensor:
        batch_size = common_attn_metadata.batch_size()

        # Dynamic SD: take the scheduled per-step K as an explicit argument and
        # set it here -- mirroring vLLM's ``propose(num_speculative_tokens=...)``
        # (which sets ``self.num_speculative_tokens`` on entry) and unified with
        # the other proposers (ngram/suffix/medusa/extract) that also receive the
        # scheduled K through their propose call. The value never exceeds the
        # configured maximum, so pre-allocated buffers stay valid; K == 0 is
        # handled just below.
        self.num_speculative_tokens = num_speculative_tokens

        # Dynamic SD may schedule K == 0 draft tokens for the current batch
        # size. Return an empty [batch_size, 0] draft so downstream copy/unpack
        # paths (which key off ``draft_token_ids.shape[1]``) stay consistent.
        # Mirrors vLLM's llm_base_proposer._propose empty-draft early return.
        if self.num_speculative_tokens == 0:
            return torch.empty(
                batch_size,
                0,
                device=target_token_ids.device,
                dtype=torch.int64,
            )

        if token_indices_to_sample is None:
            token_indices_to_sample = common_attn_metadata.query_start_loc[1:] - 1

        if self.method in ("eagle3", "dflash", "dspark"):
            model = self.model
            if isinstance(model, BreakableACLGraphWrapper):
                model = model.unwrap()
            assert isinstance(model, _HIDDEN_STATE_DRAFTER_TYPES)
            target_hidden_states = cast(_HiddenStateDrafter, model).combine_hidden_states(target_hidden_states)
            assert target_hidden_states.shape[-1] == self.hidden_size

        num_tokens, token_indices_to_sample, common_attn_metadata, long_seq_args = self.set_inputs_first_pass(
            target_token_ids=target_token_ids,
            next_token_ids=next_token_ids,
            target_positions=target_positions,
            target_hidden_states=target_hidden_states,
            token_indices_to_sample=token_indices_to_sample,
            cad=common_attn_metadata,
            num_rejected_tokens_gpu=num_rejected_tokens_gpu,
            req_scheduled_tokens=req_scheduled_tokens,
            long_seq_metadata=long_seq_metadata,
            num_prefill_reqs=num_prefill_reqs,
            num_decode_reqs=num_decode_reqs,
        )
        assert self.runner is not None
        dcp_manager = getattr(self.runner, "dcp_manager", None)
        if dcp_manager is not None and not self.parallel_drafting:
            assert long_seq_args is not None
            _, ori_token_indices_to_sample = long_seq_args

        has_lora = len(self.runner.input_batch.lora_id_to_lora_request) > 0
        uniform_decode = target_model_batch_desc.uniform

        if self.use_cuda_graph:
            _, batch_descriptor = self.runner.cudagraph_dispatcher.dispatch(
                num_tokens=num_tokens, uniform_decode=uniform_decode, has_lora=has_lora
            )
            num_input_tokens = batch_descriptor.num_tokens
        else:
            num_input_tokens = num_tokens

        (
            num_input_tokens,
            num_tokens_across_dp,
            _,
        ) = self.runner._sync_metadata_across_dp(num_input_tokens, is_draft_model=True)

        if self.use_cuda_graph:
            aclgraph_runtime_mode, batch_descriptor = self.runner.cudagraph_dispatcher.dispatch(
                num_tokens=num_input_tokens, uniform_decode=uniform_decode, has_lora=has_lora
            )
            num_input_tokens = batch_descriptor.num_tokens
        else:
            aclgraph_runtime_mode = CUDAGraphMode.NONE
            batch_descriptor = None

        if aclgraph_runtime_mode == CUDAGraphMode.FULL:
            # TODO: Due to the inconsistency between the proposer `dispatcher` and model runner, this padding
            # should have been done in model runner but not. For example, at prefill stage, target model
            # is run in eager mode currently, which means `_pad_query_start_loc_for_fia` is not called,
            # while draft model is run in graph model, which means we should pad the `query_start_loc`.
            # Need to be fixed in the future.
            num_reqs = common_attn_metadata.query_start_loc.shape[0]
            self.query_start_loc.gpu[:num_reqs].copy_(common_attn_metadata.query_start_loc)
            self.query_start_loc.cpu[:num_reqs].copy_(common_attn_metadata.query_start_loc_cpu)
            num_reqs_padded = self.runner._pad_query_start_loc_for_fia(
                self.query_start_loc,
                num_input_tokens,
                batch_descriptor.num_reqs if batch_descriptor.num_reqs is not None else common_attn_metadata.num_reqs,
                common_attn_metadata.num_reqs,
                aclgraph_runtime_mode,
                batch_descriptor.num_reqs,
            )
            common_attn_metadata.num_reqs = num_reqs_padded
            common_attn_metadata.query_start_loc = self.query_start_loc.gpu[: num_reqs_padded + 1]
            common_attn_metadata.query_start_loc_cpu = self.query_start_loc.cpu[: num_reqs_padded + 1]
            slicing_length = num_reqs_padded * self.decode_threshold if self.dcp_size > 1 else num_reqs_padded
            common_attn_metadata.block_table_tensor = self._adjust_tensor(
                common_attn_metadata.block_table_tensor, slicing_length
            )
            if self.method == "dflash":
                common_attn_metadata.seq_lens = self._adjust_tensor(common_attn_metadata.seq_lens, num_reqs_padded)
            elif self.method == "dspark":
                # DSpark already rewrote both device and host sequence lengths
                # in set_inputs_first_pass. Preserve those values while
                # extending only the padded tail for full-graph replay.
                common_attn_metadata.seq_lens = self._adjust_tensor(common_attn_metadata.seq_lens, num_reqs_padded)
                if common_attn_metadata.seq_lens_cpu is not None:
                    common_attn_metadata.seq_lens_cpu = self._adjust_tensor(
                        common_attn_metadata.seq_lens_cpu, num_reqs_padded
                    )
                if common_attn_metadata._seq_lens_cpu is not None:
                    common_attn_metadata._seq_lens_cpu = self._adjust_tensor(
                        common_attn_metadata._seq_lens_cpu, num_reqs_padded
                    )
            else:
                common_attn_metadata.seq_lens = self._adjust_tensor(self.runner.seq_lens, num_reqs_padded)
                common_attn_metadata.seq_lens_cpu = self._adjust_tensor(
                    self.runner.optimistic_seq_lens_cpu, num_reqs_padded
                )
                # Keep the upstream-canonical mirror length-aligned with the
                # padded subclass field, but only if the caller already
                # populated it (production cm_base does; some unit-test mocks
                # leave it None and assert it stays None). ``.clone()`` keeps
                # the two fields independent so per-step in-place updates in
                # ``attn_update_stack_num_spec_norm`` don't double-count.
                if common_attn_metadata._seq_lens_cpu is not None:
                    common_attn_metadata._seq_lens_cpu = common_attn_metadata.seq_lens_cpu.clone()
            if common_attn_metadata.num_computed_tokens_cpu is not None:
                common_attn_metadata.num_computed_tokens_cpu = self._adjust_tensor(
                    common_attn_metadata.num_computed_tokens_cpu, num_reqs_padded
                )

        else:
            num_reqs_padded = common_attn_metadata.num_reqs
            # In the below scenario, padding has been applied by _pad_query_start_loc_for_fia in the model runner.
            # We need to unpad here for eager mode to maintain compatibility.
            if not self.draft_model_config.use_mla and self.dcp_size == 1:
                common_attn_metadata.block_table_tensor = self._adjust_tensor(
                    common_attn_metadata.block_table_tensor, num_reqs_padded
                )

        if self.draft_window_size is not None and self.method not in ("dspark", "mtp"):
            # DSpark's draft attention reads the per-group block_table assembled
            # in build_draft_attn_metadata (which overwrites this table), so the
            # window is applied there instead. Applying here would window a table
            # that gets discarded and leave seq_lens windowed against an unwindowed
            # table -> FIA reads the oldest blocks. See sw-dspark-flow-analysis.md.
            # MTP is excluded: it reuses the target's own layers, so windowing
            # it would also window the target model.
            self.sliding_window.apply(common_attn_metadata)

        if self.supports_mm_inputs:
            mm_embeds, is_mm_embed = mm_embed_inputs or (None, None)
            if _draft_embed_accepts_mm(self.model.embed_input_ids):
                inputs_embeds = self.model.embed_input_ids(
                    self.input_ids[:num_tokens], multimodal_embeddings=mm_embeds, is_multimodal=is_mm_embed
                )
            else:
                inputs_embeds = self.model.embed_input_ids(self.input_ids[:num_tokens])
            self.inputs_embeds[:num_tokens] = inputs_embeds
            inputs_embeds = self.inputs_embeds[:num_input_tokens]
        else:
            inputs_embeds = None

        # Update slot_mapping for different speculative.
        # NOTE: Currently, we only remake the slot_mapping, because it's the
        # only tensor which will be used in current FIA.
        # Strictly speaking, `query_start_loc`, `seq_lens` should also have
        # their memory allocated separately for each step just like `slot_mapping`.
        slot_mapping_lens = common_attn_metadata.slot_mapping.shape[0]
        self.slot_mapping_group[0][:slot_mapping_lens].copy_(common_attn_metadata.slot_mapping)
        self.slot_mapping_group[0][slot_mapping_lens:].fill_(-1)
        common_attn_metadata.slot_mapping = self.slot_mapping_group[0]

        self.seq_lens_group[0][:num_reqs_padded].copy_(common_attn_metadata.seq_lens)
        self.seq_lens_group[0][num_reqs_padded:].fill_(0)
        common_attn_metadata.seq_lens = self.seq_lens_group[0][:num_reqs_padded]

        self.query_start_loc_group[0][: num_reqs_padded + 1].copy_(common_attn_metadata.query_start_loc)
        self.query_start_loc_group[0][num_reqs_padded + 1 :].fill_(0)
        common_attn_metadata.query_start_loc = self.query_start_loc_group[0][: num_reqs_padded + 1]

        common_attn_metadata.num_input_tokens = num_input_tokens

        self._pad_draft_buffers(num_tokens, num_input_tokens)
        multi_steps_attn_metadata, attn_metadata_i = self.build_draft_attn_metadata(
            common_attn_metadata, num_input_tokens, num_tokens
        )

        # Merged step 0 is the draft model's first-pass/prefill forward, not a
        # one-token draft decode step. It reuses the target-model layout and
        # therefore keeps the unadjusted sequence lengths. Before building the
        # remaining one-token draft decode steps, remove the rejected target
        # tokens from an independent NPU buffer. This mirrors upstream vLLM's
        # rejection-correction boundary while preserving step 0 metadata and
        # the model runner's shared seq_lens.
        if not self.parallel_drafting and self.num_speculative_tokens > 1 and num_rejected_tokens_gpu is not None:
            next_step_seq_lens = self.seq_lens_group[1][: common_attn_metadata.seq_lens.shape[0]]
            next_step_seq_lens.copy_(common_attn_metadata.seq_lens)
            next_step_seq_lens[:batch_size].sub_(num_rejected_tokens_gpu[:batch_size])
            common_attn_metadata.seq_lens = next_step_seq_lens

        if self.uses_mrope:
            used_update_positions = self.mrope_positions[:, token_indices_to_sample]
        else:
            used_update_positions = self.positions[token_indices_to_sample]

        # Clone the data so that when calculating the data at position 2 and position 3
        # in the merged graph, it does not affect position 1
        # FIXME(lilinsiman)
        if self.dcp_size > 1 and self.use_cuda_graph:
            assert self.block_table_tensor_clone is not None, "block_table_tensor_clone is not init"
            self.block_table_tensor_clone[: common_attn_metadata.block_table_tensor.shape[0]] = (
                common_attn_metadata.block_table_tensor
            )
            common_attn_metadata.block_table_tensor = self.block_table_tensor_clone[
                : common_attn_metadata.block_table_tensor.shape[0]
            ]
        else:
            common_attn_metadata.block_table_tensor = common_attn_metadata.block_table_tensor.clone()

        metadata_has_prefill = bool(getattr(attn_metadata_i, "num_prefills", 0))
        is_prefill_batch = num_prefill_reqs > 0 or metadata_has_prefill
        dcp_mtp_inputs = None
        draft_cp_kwargs = {
            "ori_seq_len": None,
            "ori_seq_len_cpu": None,
            "slot_indices": None,
            "mtp_slot_mapping": None,
        }
        if dcp_manager is not None and not self.parallel_drafting:
            dcp_mtp_inputs = dcp_manager.prepare_spec_decode_mtp_drafting_inputs(
                common_attn_metadata=common_attn_metadata,
                attn_metadata=attn_metadata_i,
                ori_token_indices_to_sample=ori_token_indices_to_sample,
                batch_size=batch_size,
                num_decode_reqs=num_decode_reqs,
                is_prefill_batch=is_prefill_batch,
                num_speculative_tokens=self.num_speculative_tokens,
            )
            if dcp_mtp_inputs is not None:
                draft_cp_kwargs.update(
                    ori_seq_len=dcp_mtp_inputs.seq_lens,
                    ori_seq_len_cpu=dcp_mtp_inputs.seq_lens_cpu,
                    slot_indices=dcp_mtp_inputs.slot_indices,
                    mtp_slot_mapping=dcp_mtp_inputs.slot_mapping,
                )

        should_update_next_steps = not self.parallel_drafting and (self.dcp_size == 1 or dcp_mtp_inputs is not None)
        if should_update_next_steps:
            cache_only_groups = (
                [group for group in self.draft_attn_groups if self._is_cache_only_draft_attn_group(group)]
                if self.method == "mtp"
                else []
            )
            if cache_only_groups:
                primary_group = self._get_primary_draft_attn_group()
                if len(cache_only_groups) + 1 != len(self.draft_attn_groups):
                    raise ValueError("MTP with cache-only groups requires exactly one main attention group.")
            # Copy the old attn_metadata and update
            for draft_index in range(1, self.num_speculative_tokens):
                per_layer_attn_metadata = dict()
                if cache_only_groups:
                    # Attention and cache-only groups describe the same draft
                    # step. Advance shared state once while building metadata
                    # for the executable attention group.
                    common_attn_metadata, primary_metadata = self.attn_update_stack_num_spec_norm(
                        draft_index,
                        common_attn_metadata,
                        batch_size,
                        num_input_tokens,
                        used_update_positions,
                        aclgraph_runtime_mode,
                        **draft_cp_kwargs,
                        attn_group=primary_group,
                    )
                    per_layer_attn_metadata = self._build_cache_only_group_next_step_attn_metadata(
                        common_attn_metadata,
                        draft_index,
                        num_input_tokens,
                        primary_group,
                        primary_metadata,
                        cache_only_groups,
                    )
                else:
                    for attn_group in self.draft_attn_groups:
                        common_attn_metadata, attn_metadata = self.attn_update_stack_num_spec_norm(
                            draft_index,
                            common_attn_metadata,
                            batch_size,
                            num_input_tokens,
                            used_update_positions,
                            aclgraph_runtime_mode,
                            **draft_cp_kwargs,
                            attn_group=attn_group,
                        )
                        for layer_name in self._get_attn_metadata_layer_names(attn_group):
                            per_layer_attn_metadata[layer_name] = attn_metadata
                multi_steps_attn_metadata.append(per_layer_attn_metadata)

        token_indices_to_sample_len = token_indices_to_sample.shape[0]
        self.token_indices_to_sample[:token_indices_to_sample_len].copy_(token_indices_to_sample)
        self.token_indices_to_sample[token_indices_to_sample_len:].fill_(0)

        if aclgraph_runtime_mode == CUDAGraphMode.FULL:
            self._maybe_update_metadata(
                self.draft_attn_groups[0].backend,
                multi_steps_attn_metadata,
            )

        active_device_metadata_executor = (
            getattr(self.runner, "device_metadata_executor", None) if self.method == "dspark" else None
        )
        if active_device_metadata_executor is not None and not active_device_metadata_executor.submission_in_flight:
            active_device_metadata_executor = None
        with set_ascend_forward_context(
            multi_steps_attn_metadata[0],
            self.vllm_config,
            num_tokens=num_input_tokens,
            num_tokens_across_dp=num_tokens_across_dp,
            num_actual_tokens=num_tokens,
            batch_descriptor=batch_descriptor,
            aclgraph_runtime_mode=aclgraph_runtime_mode,
            is_draft_model=True,
            draft_attn_metadatas=multi_steps_attn_metadata,
            device_metadata_executor=active_device_metadata_executor,
            eplb_heat_collection_status=(
                self.runner.eplb_heat_collection_status if self.runner.dynamic_eplb else False
            ),
        ):
            # Reset MOE layer index for forward pass
            forward_context = get_forward_context()
            if forward_context is not None:
                forward_context.moe_layer_index = 0

            model_inputs: dict[str, Any] = {
                "num_input_tokens": num_input_tokens,
                "batch_size": batch_size,
                "token_indices_to_sample": self.token_indices_to_sample[:token_indices_to_sample_len],
                "target_positions": target_positions,
                "inputs_embeds": inputs_embeds,
                "multi_steps_attn_metadata": multi_steps_attn_metadata,
                "num_tokens": num_tokens,
                "is_prefill": is_prefill_batch,
                "sampling_metadata": sampling_metadata,
            }
            runnable = cast(Callable[..., Any], self._runnable)
            run_draft: Callable[[], Any] = partial(runnable, **model_inputs)

            if self.enable_enpu:
                self._update_full_graph_params_if_needed(forward_context, num_input_tokens, multi_steps_attn_metadata)
                draft_token_ids = run_draft()
            else:
                draft_token_ids = run_draft()
                self._update_full_graph_params_if_needed(forward_context, num_input_tokens, multi_steps_attn_metadata)
        if active_device_metadata_executor is not None:
            active_device_metadata_executor.release()
        return draft_token_ids

    def _sample_draft_from_logits(
        self,
        logits: torch.Tensor,
        sampling_metadata: SamplingMetadata | None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        """Sample draft tokens from logits.

        Delegates to the upstream ``_sample_from_logits`` which handles
        temperature alignment (repeat_interleave for parallel drafting) and
        Gumbel-max sampling via ``compute_probs_and_sample_next_token``.

        When ``sampling_metadata`` is None (e.g. during ``dummy_run`` /
        profile run), greedy argmax is used and ``draft_probs`` is None.
        """
        if sampling_metadata is None:
            if self._enable_probabilistic_draft_probs:
                logger.warning(
                    "draft_sample_method='probabilistic' is enabled but "
                    "sampling_metadata is None (expected during dummy_run "
                    "or profile run). Falling back to greedy argmax; "
                    "draft_probs will not be produced."
                )
            return logits.argmax(dim=-1), None

        return super()._sample_from_logits(logits, sampling_metadata)

    def compute_draft_token_ids(
        self,
        hidden_states: torch.Tensor,
        sampling_metadata: SamplingMetadata | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        """Compute draft token ids (and optionally draft probs).

        Returns (draft_token_ids, draft_probs) where draft_probs is None when
        probabilistic sampling is disabled, all-greedy, or vocab remapping
        prevents lossless probability export.
        """
        if self.method in ("eagle3", "dflash", "dspark"):
            logits = self.model.logits_processor(self.model.lm_head, hidden_states)
            if not hasattr(self.model, "draft_id_to_target_id") or self.model.draft_id_to_target_id is None:
                return self._sample_draft_from_logits(logits, sampling_metadata)
            # With vocab remapping, draft probs live in draft-vocab space and
            # cannot be used directly for target-space rejection sampling.
            # Fall back to greedy.
            logits = logits.contiguous()
            next_token = greedy_sample(logits)
            bias = torch.index_select(self.model.draft_id_to_target_id, dim=0, index=next_token.view(-1)).view(
                next_token.shape
            )
            return next_token + bias, None
        else:
            logits = self.model.compute_logits(hidden_states)
            return self._sample_draft_from_logits(logits, sampling_metadata)

    def _run_merged_draft(
        self,
        num_input_tokens,
        batch_size,
        token_indices_to_sample,
        target_positions,
        inputs_embeds,
        multi_steps_attn_metadata,
        num_tokens,
        is_prefill=None,
        sampling_metadata: SamplingMetadata | None = None,
    ) -> torch.Tensor:
        # Reset cached draft probs from the previous propose call.
        self._last_draft_probs = None
        # Fallback for dummy_run / profile run where sampling_metadata is not
        # passed explicitly. In probabilistic mode this triggers a warning in
        # _sample_draft_from_logits and falls back to greedy argmax.
        if sampling_metadata is None and self.runner is not None:
            sampling_metadata = self.runner.input_batch.sampling_metadata
        # The lifecycle of `input_ids`, `positions`, `hidden_states` runs through all
        # speculative tokens' proposings. `model_input_ids`, `model_positions` and
        # `model_hidden_states` represent the speculative model inputs.
        model_input_ids = self.input_ids[:num_input_tokens]
        model_positions = self._get_positions(num_input_tokens)
        model_kwargs = {"input_ids": model_input_ids, "positions": model_positions, "inputs_embeds": inputs_embeds}

        if self.method in ("dflash", "dspark"):
            self.build_model_inputs_first_pass(num_input_tokens, self._context_slot_mapping_buffers)
        else:
            if self.pass_hidden_states_to_model:
                model_hidden_states = self.hidden_states[:num_input_tokens]
                model_kwargs["hidden_states"] = model_hidden_states
                if self.method == "mtp":
                    model_kwargs["positions"] = model_positions

        # step 0
        draft_model = getattr(self.model, "model", None)
        if self._share_mtp_indices and draft_model is not None and hasattr(draft_model, "set_skip_topk"):
            draft_model.set_skip_topk(False)

        ret_hidden_states = self.model(**model_kwargs)
        last_hidden_states, hidden_states = _split_draft_outputs(ret_hidden_states)

        # step 1+ skip indexer
        draft_model = getattr(self.model, "model", None)
        if self._share_mtp_indices and draft_model is not None and hasattr(draft_model, "set_skip_topk"):
            draft_model.set_skip_topk(True)
            if hasattr(draft_model, "compact_topk_indices"):
                compact_mtp_topk_indices(
                    draft_model,
                    token_indices_to_sample,
                    num_input_tokens,
                    tp_group=get_tp_group() if ascend_utils.enable_dsa_cp() else None,
                    lim_topk_compactors=self._lim_topk_compactors,
                )

        num_indices = token_indices_to_sample.shape[0]
        if lmhead_tp_enable():
            if self.method == "dspark":
                # DSpark draft decoding runs outside ACLGraph. Its real LMHead
                # input is B * K; only pad it to the current target graph bucket.
                num_indices = batch_size * self.num_speculative_tokens
                token_indices_to_sample = token_indices_to_sample[:num_indices]
                max_num_reqs_across_dp = (num_input_tokens // self.num_query_per_req) * self.num_speculative_tokens
            else:
                max_num_reqs_across_dp = (
                    self.vllm_config.scheduler_config.max_num_seqs * self.runner.uniform_decode_query_len
                )
            # It is necessary to evaluate the case where num_indices becomes large
            # in the context of the dummy-run accompaniment of p-eagle.
            if num_indices > max_num_reqs_across_dp:
                ori_token_indices_to_sample = token_indices_to_sample
            else:
                ori_token_indices_to_sample = None

        if lmhead_tp_enable():
            token_indices_to_sample = nn.functional.pad(
                token_indices_to_sample, (0, max_num_reqs_across_dp - num_indices)
            )

        sample_hidden_states = last_hidden_states[token_indices_to_sample]

        draft_probs_step0: torch.Tensor | None = None
        if getattr(self, "use_dflash2_selector", False):
            # DFlash2 always drafts greedily (probabilistic is rejected in
            # its __init__), so draft_probs_step0 is always None here.
            draft_token_ids, draft_probs_step0 = self.compute_draft_token_ids(sample_hidden_states, sampling_metadata)
            if lmhead_tp_enable():
                draft_token_ids, token_indices_to_sample = self._align_tensor_and_indices(
                    draft_token_ids,
                    num_indices,
                    token_indices_to_sample,
                    ori_token_indices_to_sample,
                    is_logits=False,
                )
        else:
            if self.method == "dspark":
                # Dspark speculation requires autoregressive applications of MarkovHead and ConfidenceHead.
                # The MarkovHead performs bias correction on logits.
                # The ConfidenceHead predicts the expected acceptance length of tokens(Not yet achieved).

                # `sample_hidden_states` has been all-gathered to full.
                # `markov_emb` should also be full to match it.
                # When the draft model has a reduced vocab (draft_id_to_target_id),
                # draft logits/probs live in draft-vocab space and cannot be used
                # directly for target-space rejection sampling. The upstream
                # compute_draft_token_ids guard falls back to greedy in this case;
                # mirror that here since this autoregressive loop bypasses it.
                # implement d2t scatter (like upstream speculator) to enable
                # probabilistic sampling with vocab remapping.
                dspark_has_vocab_mapping = getattr(self.model, "draft_id_to_target_id", None) is not None
                use_probabilistic = self._enable_probabilistic_draft_probs and not dspark_has_vocab_mapping
                if self._enable_probabilistic_draft_probs and dspark_has_vocab_mapping:
                    logger.warning_once(
                        "draft_sample_method='probabilistic' is disabled for dspark "
                        "with vocab remapping (draft_id_to_target_id): draft probs "
                        "are in draft-vocab space and incompatible with target-space "
                        "rejection sampling. Falling back to greedy."
                    )
                # Reduced-vocab drafters (e.g. Qwen3DSparkForCausalLM) must
                # compute logits in draft-vocab space so that the Markov bias
                # (draft_vocab_size) can be added; sampled draft ids are then
                # remapped to target ids.
                raw_logits = self.model.compute_draft_logits(sample_hidden_states)
                if lmhead_tp_enable():
                    # Remove B_max - B communication padding.
                    raw_logits = raw_logits[:num_indices]
                logits = raw_logits.view(-1, self.num_speculative_tokens, raw_logits.shape[-1])
                num_blk = logits.shape[0]
                draft_token_ids = self._dspark_draft_buffer[:num_blk]
                draft_token_ids[:, 0].copy_(self._dspark_seed_buffer[:num_blk])
                dspark_probs_list: list[torch.Tensor] = []
                for idx in range(self.num_speculative_tokens):
                    markov_emb = self.model.markov_embed(draft_token_ids[:, idx])
                    logits_bias = self.model.markov_bias(markov_emb)
                    logits[:, idx].add_(logits_bias)
                    if use_probabilistic:
                        # Use probabilistic sampling instead of argmax.
                        # logits[:, idx] is [num_blk, V], matching
                        # batch_size for per-request temperature.
                        token_ids, probs = self._sample_draft_from_logits(logits[:, idx], sampling_metadata)
                        draft_token_ids[:, idx + 1].copy_(token_ids)
                        if probs is not None:
                            dspark_probs_list.append(probs)
                    else:
                        next_token_ids = logits[:, idx].argmax(dim=-1)
                        if dspark_has_vocab_mapping:
                            next_token_ids = self.model.map_draft_to_target(next_token_ids)
                        draft_token_ids[:, idx + 1].copy_(next_token_ids)
                if use_probabilistic and dspark_probs_list:
                    # Stack [K x [num_blk, V]] -> [num_blk, K, V] ->
                    # [num_blk * K, V] to match early_exit view logic.
                    draft_probs_step0 = torch.stack(dspark_probs_list, dim=1).view(-1, logits.shape[-1]).contiguous()

                # Dynamic verify-length path, implemented in DynamicSpecScheduler
                # Only the dspark method is handled here since it relies on
                # the DSpark confidence head.
                if self.dynamic_spec is not None:
                    self.dynamic_spec.update(
                        model=self.model,
                        last_hidden_states=last_hidden_states,
                        draft_token_ids=draft_token_ids,
                        num_reqs=num_blk,
                    )
            else:
                logits = self.model.compute_logits(sample_hidden_states)
                if lmhead_tp_enable():
                    logits, token_indices_to_sample = self._align_tensor_and_indices(
                        logits,
                        num_indices,
                        token_indices_to_sample,
                        ori_token_indices_to_sample,
                        is_logits=True,
                    )
                draft_token_ids, draft_probs_step0 = self._sample_draft_from_logits(logits, sampling_metadata)

                # Dynamic verify-length path for head-free DFlash only.
                if hasattr(self, "dynamic_spec") and self.dynamic_spec is not None:
                    self.dynamic_spec.update(
                        logits=logits,
                    )

        # Early exit if there is only one draft token to be generated.
        if self.num_speculative_tokens == 1 or self.parallel_drafting:
            if draft_probs_step0 is not None:
                self._last_draft_probs = draft_probs_step0.view(
                    -1, self.num_speculative_tokens, draft_probs_step0.shape[-1]
                ).contiguous()
            if self.method == "dspark":
                return draft_token_ids[:, 1:]
            else:
                # [batch_size, 1]
                return draft_token_ids.view(-1, self.num_speculative_tokens)

        # The logits are split and then merged only when lmhead_tp_enable() is enabled.
        # As a result, the batch size length becomes the actual length 32.
        # However, when lmhead_tp_enable() is disabled, the batch size uses the length after padding.
        # To decouple the scenarios, a judgment is required.
        # That is, the batch size needs to be modified only when lmhead_tp_enable() is enabled.
        if lmhead_tp_enable() and self.method == "mtp":
            batch_size = draft_token_ids.shape[0]

        # Generate the remaining draft tokens.
        draft_token_ids_tensor = torch.zeros(
            (self.num_speculative_tokens, *draft_token_ids.shape), dtype=draft_token_ids.dtype, device=self.device
        )
        draft_token_ids_tensor[0] = draft_token_ids
        draft_probs_list = [draft_probs_step0] if draft_probs_step0 is not None else None
        if self.uses_mrope:
            positions = self.mrope_positions[:, token_indices_to_sample]
        else:
            positions = self.positions[token_indices_to_sample]
        hidden_states = hidden_states[token_indices_to_sample]
        token_indices_to_sample = self.arange[:batch_size]

        forward_context = get_forward_context()
        input_batch_size = num_input_tokens if (self.method == "mtp" or self.use_cuda_graph) else batch_size
        if self.method == "mtp" and forward_context.cudagraph_runtime_mode != CUDAGraphMode.FULL:
            # Only the first draft consumes the target's prefill/verify rows.
            # Later drafts have one row per request, matching the metadata
            # built by attn_update_stack_num_spec_norm. Keep the capture bucket
            # for FULL graphs, but never feed a stale prefill-sized tail to an
            # eager draft (not even for a single request, where it broadcasts).
            input_batch_size = batch_size
        _EXTRA_CTX.num_tokens = input_batch_size
        _EXTRA_CTX.num_accept_tokens = batch_size

        for draft_index in range(self.num_speculative_tokens - 1):
            # Reset MOE layer index for each draft step iteration
            forward_context = get_forward_context()
            if forward_context is not None:
                forward_context.moe_layer_index = 0

            # Update the inputs.
            # cast to int32 is crucial when eagle model is compiled.
            # tensor.argmax() returns int64 by default.
            input_ids = draft_token_ids_tensor[draft_index]
            if not getattr(self, "constant_draft_positions", False):
                positions += 1

            # NOTE(woosuk): We should handle the case where the draft model
            # generates tokens beyond the max model length. Since it is complex
            # to remove such requests from the batch, we keep them in the batch
            # but adjust the position ids and slot mappings to avoid the
            # out-of-range access during the model execution. The draft tokens
            # generated with this adjustment should be ignored.
            if self.uses_mrope:
                exceeds_max_model_len = positions[0] >= self.vllm_config.model_config.max_model_len
                # Mask out the position ids that exceed the max model length.
                # Otherwise, we may get out-of-range error in RoPE.
                clamped_positions = torch.where(
                    exceeds_max_model_len.unsqueeze(0), torch.zeros_like(positions), positions
                )
            else:
                exceeds_max_model_len = positions >= self.vllm_config.model_config.max_model_len
                clamped_positions = torch.where(exceeds_max_model_len, 0, positions)

            # copy inputs to buffer for cudagraph
            self.input_ids[:batch_size] = input_ids
            self._set_positions(batch_size, clamped_positions)
            self.hidden_states[:batch_size] = hidden_states.view(batch_size, -1)
            if self.supports_mm_inputs:
                self.inputs_embeds[:batch_size] = self.model.embed_input_ids(input_ids)

                input_ids = self.input_ids[:input_batch_size]
                inputs_embeds = self.inputs_embeds[:input_batch_size]
            else:
                input_ids = self.input_ids[:input_batch_size]
                inputs_embeds = None

            # Run the model.

            # The lifecycle of `input_ids`, `positions`, `hidden_states` runs through all
            # speculative tokens' proposings. `model_input_ids`, `model_positions` and
            # `model_hidden_states` represent the speculative model inputs.
            model_input_ids = self.input_ids[:input_batch_size]
            model_positions = self._get_positions(input_batch_size)
            model_hidden_states = self.hidden_states[:input_batch_size]

            forward_context.attn_metadata = (
                multi_steps_attn_metadata[draft_index + 1] if multi_steps_attn_metadata else None
            )

            if self.use_compress:
                # The compressor metadata cached for the previous draft substep
                # is stale now; drop it before running the next one.
                from vllm_ascend.attention.dsa_v1 import reset_compressor_metadata_cache

                reset_compressor_metadata_cache()

            model_kwargs = {
                "input_ids": model_input_ids,
                "positions": model_positions,
                "inputs_embeds": inputs_embeds,
            }
            if self.pass_hidden_states_to_model:
                model_kwargs["hidden_states"] = model_hidden_states

            ret_hidden_states = self.model(**model_kwargs)
            last_hidden_states, hidden_states = _split_draft_outputs(ret_hidden_states)

            num_indices = token_indices_to_sample.shape[0]
            if lmhead_tp_enable():
                max_num_reqs_across_dp = (
                    self.vllm_config.scheduler_config.max_num_seqs * self.runner.uniform_decode_query_len
                )
                token_indices_to_sample = nn.functional.pad(
                    token_indices_to_sample,
                    (0, max_num_reqs_across_dp - num_indices),
                )

            sample_hidden_states = last_hidden_states[token_indices_to_sample]
            draft_probs_step: torch.Tensor | None = None
            logits = self.model.compute_logits(sample_hidden_states)
            if lmhead_tp_enable() and num_indices < logits.shape[0]:
                logits = logits[:num_indices]
                token_indices_to_sample = token_indices_to_sample[:num_indices]
            draft_token_ids, draft_probs_step = self._sample_draft_from_logits(logits, sampling_metadata)

            # TODO(wenlong): get more than one token for tree attention
            hidden_states = hidden_states[:batch_size]
            draft_token_ids_tensor[draft_index + 1] = draft_token_ids
            if draft_probs_list is not None:
                if draft_probs_step is not None:
                    draft_probs_list.append(draft_probs_step)
                else:
                    draft_probs_list = None

        # [batch_size, num_speculative_tokens]
        draft_token_ids = draft_token_ids_tensor.swapaxes(0, 1)
        if draft_probs_list is not None:
            self._last_draft_probs = torch.stack(draft_probs_list, dim=1).contiguous()
        return draft_token_ids

    def set_inputs_first_pass(
        self,
        target_token_ids: torch.Tensor,
        next_token_ids: torch.Tensor,
        target_positions: torch.Tensor,
        target_hidden_states: torch.Tensor,
        token_indices_to_sample: torch.Tensor | None,
        cad: CommonAttentionMetadata,
        num_rejected_tokens_gpu: torch.Tensor | None,
        req_scheduled_tokens=None,
        long_seq_metadata=None,
        num_prefill_reqs=0,
        num_decode_reqs=0,
    ) -> tuple[int, torch.Tensor, CommonAttentionMetadata, tuple[Any, Any] | None]:
        if not self.needs_extra_input_slots:
            # Default EAGLE pathway: no reshaping of input tensors needed.
            # Simply rotate the input ids and leave the positions unchanged,
            # Inserting the next token ids at the last slot in each request.
            if token_indices_to_sample is None:
                token_indices_to_sample = cad.query_start_loc[1:] - 1

            num_tokens = target_token_ids.shape[0]
            # Shift the input ids by one token.
            # E.g., [a1, b1, b2, c1, c2, c3] -> [b1, b2, c1, c2, c3, c3]
            self.input_ids[: num_tokens - 1] = target_token_ids[1:]
            # Replace the last token with the next token.
            # E.g., [b1, b2, c1, c2, c3, c3] -> [a2, b2, b3, c2, c3, c4]
            self.input_ids[token_indices_to_sample] = next_token_ids

            assert self.runner is not None
            dcp_manager = getattr(self.runner, "dcp_manager", None)
            long_seq_args = None
            if dcp_manager is not None:
                first_pass_inputs = dcp_manager.prepare_spec_decode_first_pass_inputs(
                    input_ids=self.input_ids[:num_tokens],
                    target_positions=target_positions,
                    target_hidden_states=target_hidden_states,
                    token_indices_to_sample=token_indices_to_sample,
                    common_attn_metadata=cad,
                    long_seq_metadata=long_seq_metadata,
                    req_scheduled_tokens=req_scheduled_tokens,
                    req_ids=self.runner.input_batch.req_ids,
                    logits_indices=self.runner.logits_indices,
                    num_tokens=num_tokens,
                    num_prefill_reqs=num_prefill_reqs,
                    num_decode_reqs=num_decode_reqs,
                    uses_mrope=self.uses_mrope,
                )
                num_tokens = first_pass_inputs.num_tokens
                target_positions = first_pass_inputs.target_positions
                target_hidden_states = first_pass_inputs.target_hidden_states
                token_indices_to_sample = first_pass_inputs.token_indices_to_sample
                self.input_ids[:num_tokens].copy_(first_pass_inputs.input_ids)
                long_seq_args = first_pass_inputs.long_seq_args

            # copy inputs to buffer for cudagraph
            self._set_positions(num_tokens, target_positions)
            self.hidden_states[:num_tokens] = target_hidden_states.view(num_tokens, -1)

            return num_tokens, token_indices_to_sample, cad, long_seq_args
        else:
            assert self.is_rejected_token_mask is not None
            assert self.is_masked_token_mask is not None
            # 1.
            # Call the CopyAndExpandEagleInputs AscendC operator to copy
            # input_ids and positions into the correct slots in the
            # preallocated buffers self.input_ids, self.positions.
            batch_size = cad.batch_size()
            total_num_input_tokens = target_token_ids.shape[0]
            total_num_output_tokens = total_num_input_tokens + (self.net_num_new_slots_per_request * batch_size)

            query_start_loc = cad.query_start_loc
            query_end_loc = cad.query_start_loc[1:] - 1
            if num_rejected_tokens_gpu is not None:
                query_end_loc = query_end_loc - num_rejected_tokens_gpu

            (
                out_input_ids,
                out_positions,
                out_is_rejected_token_mask,
                out_is_masked_token_mask,
                token_indices_to_sample,
                out_hidden_state_mapping,
            ) = torch.ops._C_ascend.npu_copy_and_expand_eagle_inputs(
                target_token_ids,
                target_positions.to(torch.int32),
                next_token_ids,
                query_start_loc,
                query_end_loc,
                0,  # padding_token_id
                self.parallel_drafting_token_id,
                self.extra_slots_per_request,
                self.pass_hidden_states_to_model,
                total_num_output_tokens,
            )

            # Copy returned tensors into pre-allocated buffers
            self.input_ids[:total_num_output_tokens].copy_(out_input_ids)
            self.positions[:total_num_output_tokens].copy_(out_positions)
            self.is_rejected_token_mask[:total_num_output_tokens].copy_(out_is_rejected_token_mask)
            self.is_masked_token_mask[:total_num_output_tokens].copy_(out_is_masked_token_mask)
            if self.pass_hidden_states_to_model:
                assert self.parallel_drafting_hidden_state_tensor is not None
                self.hidden_states[out_hidden_state_mapping] = target_hidden_states
                # Use torch.where to avoid DtoH sync from boolean indexing
                mask = self.is_masked_token_mask[:total_num_output_tokens]
                torch.where(
                    mask.unsqueeze(1),  # type: ignore
                    self.parallel_drafting_hidden_state_tensor,
                    self.hidden_states[:total_num_output_tokens],
                    out=self.hidden_states[:total_num_output_tokens],
                )

            # 2.
            # Recompute the slot mapping based on the new positions and
            # rejection mask.
            # The split indexer cache may be the first draft group, but its
            # storage layout is not the main attention cache layout.
            assert len(self.draft_attn_groups) > 0
            block_size = self._get_primary_draft_attn_group().kv_cache_spec.block_size

            new_slot_mapping = compute_new_slot_mapping(
                cad=cad,
                new_positions=self.positions[:total_num_output_tokens],
                is_rejected_token_mask=self.is_rejected_token_mask[:total_num_output_tokens],
                block_size=block_size,
                num_new_tokens=self.net_num_new_slots_per_request,
                max_model_len=self.max_model_len,
            )

            # 3. Update the common attention metadata with the new (meta)data
            new_cad = extend_all_queries_by_N(
                cad,
                N=self.net_num_new_slots_per_request,
                arange=self.arange,
                new_slot_mapping=new_slot_mapping,
            )
            # ``extend_all_queries_by_N`` adds N to every per-row GPU
            # ``seq_lens`` but cannot touch the host-side mirrors (it
            # only knows about upstream's deprecated ``_seq_lens_cpu``
            # field; the Ascend subclass also has its own
            # ``seq_lens_cpu`` field, which would be silently stale
            # after the dataclass ``replace``).
            #
            # NPU attention backends (MLA, AscendAttention, SFA) read
            # those CPU mirrors as kernel input, so they MUST be in
            # sync with the GPU view. We compute the +N update on CPU
            # to avoid an extra GPU->CPU sync (which was the original
            # FIXME): every consumer that needs the post-extend value
            # already had a valid pre-extend mirror, so a CPU-only
            # ``+N`` keeps both in lock-step at zero device-side cost.
            N = self.net_num_new_slots_per_request
            if cad._seq_lens_cpu is not None:
                new_cad._seq_lens_cpu = cad._seq_lens_cpu + N
            elif cad.seq_lens_cpu is not None:
                # Parent field absent but Ascend subclass field set:
                # populate ``_seq_lens_cpu`` so upstream code paths
                # that prefer the parent field still get a fresh value.
                new_cad._seq_lens_cpu = cad.seq_lens_cpu + N
            if cad.seq_lens_cpu is not None:
                new_cad.seq_lens_cpu = cad.seq_lens_cpu + N

            return total_num_output_tokens, token_indices_to_sample, new_cad, None

    def model_returns_tuple(self) -> bool:
        if self.method == "mtp":
            # These MTP models return separate hidden states for logits and
            # feedback into the next draft step.
            draft_model_config = getattr(self, "draft_model_config", None)
            hf_config = getattr(draft_model_config, "hf_config", None)
            architectures = getattr(hf_config, "architectures", []) or []
            if {"Glm5NextMTPModel", "Glm5NextW2MTPModel"}.intersection(architectures):
                return True
            if vllm_version_is("0.28.0"):
                return bool({"DeepSeekMTPModel", "KimiK3MTPModel", "Qwen4ExpMTP"}.intersection(architectures))
            else:
                return bool(
                    {
                        "DeepSeekMTPModel",
                        "DeepseekV32MTPModel",
                        "KimiK3MTPModel",
                        "Qwen4ExpMTP",
                    }.intersection(architectures)
                )
        return self.method not in ("mtp", "draft_model", "dflash", "dspark")

    def attn_update_stack_num_spec_norm(
        self,
        # `draft_index` must start from `1`, no `0`
        draft_index,
        old_common_metadata,
        batch_size,
        input_batch_size,
        used_update_positions,
        aclgraph_runtime_mode,
        ori_seq_len=None,
        ori_seq_len_cpu=None,
        slot_indices=None,
        mtp_slot_mapping=None,
        attn_group=None,
    ):
        assert draft_index > 0
        assert attn_group is not None, "vllm-ascend v0.17.0rc1 requires attn_group"
        common_attn_metadata = self.shallow_copy_metadata(old_common_metadata)

        if draft_index == 1:
            if aclgraph_runtime_mode == CUDAGraphMode.FULL:
                common_attn_metadata.num_reqs = input_batch_size
                common_attn_metadata.block_table_tensor = self._adjust_tensor(
                    common_attn_metadata.block_table_tensor, input_batch_size
                )
                common_attn_metadata.seq_lens = self._adjust_tensor(common_attn_metadata.seq_lens, input_batch_size)
                # seq_lens_cpu may be None here: the multi-KV-cache-group MTP
                # proposer invalidates stale CPU lengths at the draft_index==1
                # transition (no device-to-host sync). Guard like the fields
                # below instead of assuming a tensor.
                if common_attn_metadata.seq_lens_cpu is not None:
                    common_attn_metadata.seq_lens_cpu = self._adjust_tensor(
                        common_attn_metadata.seq_lens_cpu, input_batch_size
                    )
                if common_attn_metadata._seq_lens_cpu is not None:
                    common_attn_metadata._seq_lens_cpu = self._adjust_tensor(
                        common_attn_metadata._seq_lens_cpu, input_batch_size
                    )
                if common_attn_metadata.num_computed_tokens_cpu is not None:
                    common_attn_metadata.num_computed_tokens_cpu = self._adjust_tensor(
                        common_attn_metadata.num_computed_tokens_cpu, input_batch_size
                    )
                common_attn_metadata.query_start_loc = self.arange[: input_batch_size + 1]
                common_attn_metadata.query_start_loc_cpu = torch.from_numpy(
                    self.token_arange_np[: input_batch_size + 1]
                ).clone()
            else:
                if self.method == "mtp":
                    input_batch_size = batch_size
                common_attn_metadata.query_start_loc = self.arange[: batch_size + 1]
                common_attn_metadata.query_start_loc_cpu = torch.from_numpy(
                    self.token_arange_np[: batch_size + 1]
                ).clone()

            common_attn_metadata.num_actual_tokens = batch_size
            common_attn_metadata.max_query_len = 1
            common_attn_metadata.decode_token_per_req = 1
            common_attn_metadata.attn_state = (
                AscendAttentionState.SpecDecoding if self.method == "mtp" else AscendAttentionState.ChunkedPrefill
            )
            common_attn_metadata.graph_pad_size = -1
            common_attn_metadata.num_input_tokens = input_batch_size

            if getattr(self.runner, "sparse_kv_offload_enabled", False):
                # Draft steps run exactly one token per request, while the
                # inherited token_to_req still describes the verify-step
                # layout (num_spec + 1 tokens per request). Rebuild it to the
                # one-token-per-request layout so the Sparse KV offload path
                # routes every decode row to its own request's CPU-pool
                # blocks/seq_len; otherwise rows of requests >= 1 are mapped
                # onto request 0 and attend another request's KV.
                num_draft_reqs = common_attn_metadata.query_start_loc.shape[0] - 1
                common_attn_metadata.token_to_req = self.arange[:num_draft_reqs]

        # The loop part
        advance_draft_positions = not getattr(self, "constant_draft_positions", False)
        if advance_draft_positions:
            used_update_positions += 1

        # Clone the data so that when calculating the data at position 2 and position 3
        # in the merged graph, it does not affect position 1
        # FIXME(lilinsiman)
        common_attn_metadata.seq_lens = common_attn_metadata.seq_lens.clone()
        if common_attn_metadata.seq_lens_cpu is not None:
            common_attn_metadata.seq_lens_cpu = common_attn_metadata.seq_lens_cpu.clone()
        if common_attn_metadata._seq_lens_cpu is not None:
            common_attn_metadata._seq_lens_cpu = common_attn_metadata._seq_lens_cpu.clone()
        if common_attn_metadata.num_computed_tokens_cpu is not None:
            common_attn_metadata.num_computed_tokens_cpu = common_attn_metadata.num_computed_tokens_cpu.clone()
        common_attn_metadata.positions = common_attn_metadata.positions.clone()

        # NOTE(woosuk): We should handle the case where the draft model
        # generates tokens beyond the max model length. Since it is complex
        # to remove such requests from the batch, we keep them in the batch
        # but adjust the position ids and slot mappings to avoid the
        # out-of-range access during the model execution. The draft tokens
        # generated with this adjustment should be ignored.
        if self.uses_mrope:
            exceeds_max_model_len = used_update_positions[0] >= self.max_model_len
            # Mask out the position ids that exceed the max model length.
            # Otherwise, we may get out-of-range error in RoPE.
            clamped_positions = torch.where(
                exceeds_max_model_len.unsqueeze(0), torch.zeros_like(used_update_positions), used_update_positions
            )
        else:
            exceeds_max_model_len = used_update_positions >= self.max_model_len
            clamped_positions = torch.where(exceeds_max_model_len, 0, used_update_positions)

        # For data integrity when async scheduling, we shouldn't use in place
        # operations in case they are modified in next step's `prepare_input`
        # of main model.
        # Increment the sequence lengths.
        if advance_draft_positions:
            common_attn_metadata.seq_lens[:batch_size] += 1
        # For the requests that exceed the max model length, we set the
        # sequence length to 1 to minimize their overheads in attention.
        exceeds_mask = common_attn_metadata.seq_lens[:batch_size] > self.max_model_len
        common_attn_metadata.seq_lens[:batch_size].masked_fill_(exceeds_mask, 1)
        if common_attn_metadata.seq_lens_cpu is not None:
            if advance_draft_positions:
                common_attn_metadata.seq_lens_cpu[:batch_size] = common_attn_metadata.seq_lens_cpu[:batch_size] + 1
            exceeds_mask_cpu = common_attn_metadata.seq_lens_cpu[:batch_size] > self.max_model_len
            common_attn_metadata.seq_lens_cpu[:batch_size].masked_fill_(exceeds_mask_cpu, 1)
        if common_attn_metadata._seq_lens_cpu is not None:
            if advance_draft_positions:
                common_attn_metadata._seq_lens_cpu[:batch_size] = common_attn_metadata._seq_lens_cpu[:batch_size] + 1
            exceeds_mask_internal_cpu = common_attn_metadata._seq_lens_cpu[:batch_size] > self.max_model_len
            common_attn_metadata._seq_lens_cpu[:batch_size].masked_fill_(exceeds_mask_internal_cpu, 1)
        if common_attn_metadata.num_computed_tokens_cpu is not None:
            if advance_draft_positions:
                common_attn_metadata.num_computed_tokens_cpu[:batch_size] += 1
        if self.uses_mrope:
            common_attn_metadata.positions[:batch_size].copy_(clamped_positions[0])
        else:
            common_attn_metadata.positions[:batch_size].copy_(clamped_positions)

        dcp_manager = getattr(self.runner, "dcp_manager", None)
        if dcp_manager is not None:
            kv_cache_spec = getattr(attn_group, "kv_cache_spec", self.draft_attn_groups[0].kv_cache_spec)
            # update slot_mapping
            slot_indices += 1
            slot_mapping = mtp_slot_mapping[slot_indices]
            self.slot_mapping_group[draft_index][:batch_size] = slot_mapping
            self.slot_mapping_group[draft_index][batch_size:].fill_(PADDING_SLOT_ID)
            common_attn_metadata.slot_mapping = self.slot_mapping_group[draft_index]
        else:
            # NOTE: In vllm, `block_size = attn_metadata_builder.kv_cache_spec.block_size`.
            # However, in vllm-ascend, the above value can be multiple of `kernel_block_size`,
            # which is not correct for computing `slot_mapping` below.
            if self.has_gdn:
                block_size = self.kernel_block_size
            else:
                block_size = self.block_size

            # Compute the slot mapping.
            # When sliding window is enabled, block_table_tensor may be cropped
            # for attention, but slot mapping needs the full block table to
            # address the absolute KV cache positions. (self.sliding_window is
            # None for MTP - the adapter is not constructed for it.)
            if self.sliding_window is not None:
                block_table_for_slot = self.sliding_window.full_block_table
            else:
                block_table_for_slot = old_common_metadata.block_table_tensor

            if self.uses_mrope:
                block_numbers = clamped_positions[0] // block_size
            else:
                block_numbers = clamped_positions // block_size
            block_ids = block_table_for_slot.gather(dim=1, index=block_numbers.view(-1, 1))
            block_ids = block_ids.view(-1)
            if self.uses_mrope:
                slot_mapping = block_ids * block_size + clamped_positions[0] % block_size
            else:
                slot_mapping = block_ids * block_size + clamped_positions % block_size

            # Mask out the slot mappings that exceed the max model length.
            # Otherwise, the KV cache will be inadvertently updated with the
            # padding tokens.
            slot_mapping.masked_fill_(exceeds_max_model_len, PADDING_SLOT_ID)
            self.slot_mapping_group[draft_index][: slot_mapping.shape[0]].copy_(slot_mapping.to(torch.int32))
            self.slot_mapping_group[draft_index][slot_mapping.shape[0] :].fill_(PADDING_SLOT_ID)
            # Set the address of the attn_metadata.slot_mapping to the self.slot_mapping_group[idx]
            common_attn_metadata.slot_mapping = self.slot_mapping_group[draft_index]

        self.seq_lens_group[draft_index][: common_attn_metadata.seq_lens.shape[0]].copy_(common_attn_metadata.seq_lens)
        self.seq_lens_group[draft_index][common_attn_metadata.seq_lens.shape[0] :].fill_(0)
        common_attn_metadata.seq_lens = self.seq_lens_group[draft_index][: common_attn_metadata.seq_lens.shape[0]]

        self.query_start_loc_group[draft_index][: common_attn_metadata.query_start_loc.shape[0]].copy_(
            common_attn_metadata.query_start_loc
        )
        self.query_start_loc_group[draft_index][common_attn_metadata.query_start_loc.shape[0] :].fill_(0)
        common_attn_metadata.query_start_loc = self.query_start_loc_group[draft_index][
            : common_attn_metadata.query_start_loc.shape[0]
        ]

        attn_metadata_builder = attn_group.get_metadata_builder()

        extra_attn_metadata_args: dict[str, Any] = {}
        if self.use_compress:
            extra_attn_metadata_args = dict(
                common_ratio_to_sas_metadata=dict(),
            )
        if dcp_manager is not None:
            dcp_manager.prepare_spec_decode_drafting_cp_metadata(
                common_attn_metadata=common_attn_metadata,
                kv_cache_spec=kv_cache_spec,
                seq_lens=ori_seq_len,
                draft_index=draft_index,
                seq_lens_cpu=ori_seq_len_cpu,
            )
        group_common_attn_metadata = self._common_attn_metadata_for_draft_group(
            common_attn_metadata,
            attn_group,
            input_batch_size,
            draft_index,
        )
        attn_metadata = attn_metadata_builder.build_for_drafting(
            group_common_attn_metadata,
            draft_index,
            **extra_attn_metadata_args,
        )

        if dcp_manager is not None:
            dcp_manager.update_spec_decode_drafting_cp_metadata(
                attn_metadata=attn_metadata,
                kv_cache_spec=kv_cache_spec,
                seq_lens=ori_seq_len,
                draft_index=draft_index,
                seq_lens_cpu=ori_seq_len_cpu,
                attn_metadata_builder=attn_metadata_builder,
            )

        return common_attn_metadata, attn_metadata

    def prepare_next_token_ids_padded(
        self,
        sampled_token_ids: torch.Tensor,
        requests: dict[str, CachedRequestState],
        gpu_input_batch: InputBatch,
        discard_request_indices: torch.Tensor,
        num_discarded_requests: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        This function is used to prepare the inputs for speculative decoding.
        It calculates the next token ids and the number of valid sampled tokens
        for each request, considering the "discarded" requests whose next token
        is not sampled and comes from `request.get_token_id()` instead.
        It also accounts for the rejected tokens in `sampled_token_ids`.
        This function must use device functions to operate on the inputs, and
        should not introduce any blocking CPU-GPU synchronization.
        """
        # TODO(Ben): Combine this into a custom fused kernel

        # Precompute get_token_id for when there is no valid next token
        num_reqs = gpu_input_batch.num_reqs
        seq_lens_list = (gpu_input_batch.num_tokens_no_spec[:num_reqs] - 1).tolist()
        self.backup_next_token_ids.np[:num_reqs] = np.array(
            [requests[gpu_input_batch.req_ids[i]].get_token_id(seq_lens_list[i]) for i in range(num_reqs)]
        )
        self.backup_next_token_ids.copy_to_gpu(num_reqs)

        # Mask out the sampled tokens indices that should not be sampled.
        discard_sampled_tokens_req_indices = discard_request_indices[:num_discarded_requests]

        valid_sampled_token_ids_gpu = sampled_token_ids.clone()
        valid_sampled_token_ids_gpu = DeviceOperator.index_fill(
            valid_sampled_token_ids_gpu,
            0,
            discard_sampled_tokens_req_indices,
            -1,
        )

        # Generate a mask for all valid tokens within those requests
        valid_mask = (valid_sampled_token_ids_gpu != -1) & (valid_sampled_token_ids_gpu < gpu_input_batch.vocab_size)

        # Count the number of valid tokens in each request
        valid_sampled_tokens_count = valid_mask.sum(dim=1)

        # Get the rightmost valid index per row
        last_valid_indices = valid_sampled_tokens_count - 1
        last_valid_indices_safe = torch.clamp(last_valid_indices, min=0)

        # Get last valid token from each row
        # (assume undefined state where there is no valid token)
        selected_tokens = torch.gather(valid_sampled_token_ids_gpu, 1, last_valid_indices_safe.unsqueeze(1)).squeeze(1)

        # Use last token if valid, pre-computed backup if not
        batch_size = valid_sampled_token_ids_gpu.shape[0]
        next_token_ids = torch.where(
            last_valid_indices != -1,
            selected_tokens,
            self.backup_next_token_ids.gpu[:batch_size],
        )

        return next_token_ids, valid_sampled_tokens_count

    def prepare_inputs(
        self,
        common_attn_metadata: CommonAttentionMetadata,
        sampled_token_ids: list[list[int]],
        num_draft_tokens: list[int],
    ) -> tuple[CommonAttentionMetadata, torch.Tensor]:
        """
        This function is used to prepare the inputs for speculative decoding.
        It updates to the common_attn_metadata to account for the rejected
        tokens (and newly sampled tokens). It also returns the token indices
        of the tokens that should be fed to the speculator.
        """
        # E.g.
        #  common_attn_metadata.query_start_loc{_cpu}:
        #       [0, q1, q1 + q2, q1 + q2 + q3]
        #  common_attn_metadata.seq_lens{_cpu}: [s1, s2, s3]
        #  num_rejected_tokens: [n1, n2, n3]
        # This function computes the intermediate values:
        #  num_tokens_per_req: [q1 - n1, q2 - n2, q3 - n3]
        # And returns:
        #  common_attn_metadata.query_start_loc{_cpu}:
        #       [0, q1 - n1, q1 + q2 - n1 - n2, q1 + q2 + q3 - n1 - n2 - n3]
        #  common_attn_metadata.seq_lens{_cpu}:
        #       [s1 - n1 + 1, s2 - n2 + 1, s3 - n3 + 1]
        #  token_indices: [0, 1, ..., q1 - n1 - 1,
        #                 q1, q1 + 1, ..., q1 + q2 - n2 - 1,
        #                 q1 + q2, q1 + q2 + 1, ..., q1 + q2 + q3 - n3 - 1]

        num_actual_reqs = len(num_draft_tokens)
        num_rejected_tokens = [
            n + 1 - len(sampled_token_ids[i]) if n > 0 else 0 for i, n in enumerate(num_draft_tokens)
        ]
        num_rejected_tokens = torch.tensor(num_rejected_tokens, dtype=torch.int32)

        device = common_attn_metadata.query_start_loc.device
        query_start_loc_cpu = common_attn_metadata.query_start_loc_cpu[: num_actual_reqs + 1]
        # Prefer the upstream-canonical ``_seq_lens_cpu``; fall back to the
        # Ascend subclass field. In async-spec mode the model runner only
        # populates ``_seq_lens_cpu`` (optimistic_seq_lens_cpu) and leaves
        # ``seq_lens_cpu`` as None, so an unguarded read here would crash.
        if common_attn_metadata._seq_lens_cpu is not None:
            seq_lens_cpu = common_attn_metadata._seq_lens_cpu[:num_actual_reqs]
        else:
            seq_lens_cpu = common_attn_metadata.seq_lens_cpu[:num_actual_reqs]
        new_seq_lens_cpu = seq_lens_cpu - num_rejected_tokens

        # [0, q1, q1 + q2, q1 + q2 + q3] -> [q1, q2, q3]
        new_query_len_per_req = query_start_loc_cpu[1:] - query_start_loc_cpu[:-1]
        # [q1, q2, q3] -> [q1 - n1, q2 - n2, q3 - n3]
        new_num_tokens_per_req = new_query_len_per_req - num_rejected_tokens
        new_num_tokens_per_req_np = new_num_tokens_per_req.numpy()

        # [q1 - n1, q2 - n2, q3 - n3] ->
        # [0, q1 - n1, q1 + q2 - n1 - n2, q1 + q2 + q3 - n1 - n2 - n3]
        new_query_start_loc_cpu = torch.zeros(
            query_start_loc_cpu.shape,
            dtype=torch.int32,
            pin_memory=is_pin_memory_available(),
        )
        new_query_start_loc_np = new_query_start_loc_cpu.numpy()
        np.cumsum(new_num_tokens_per_req_np, out=new_query_start_loc_np[1:])

        total_num_tokens = new_query_start_loc_np[-1]
        # Example assuming num_tokens_per_req_np = [2, 4, 3]
        # this implies that `new_query_start_locs` is:
        # [0, 2, 6, 9] ->
        # [0, 0, 2, 2, 2, 2, 6, 6, 6]
        #  _r1_  ____r2____  ___r3__
        new_query_start_locs_expanded = np.repeat(new_query_start_loc_np[:-1], new_num_tokens_per_req_np)
        # [0, 1, 2, 3, 4, 5, 6, 7, 8] ->
        # [0, 1, 0, 1, 2, 3, 0, 1, 2]
        #  _r1_  ____r2____  ___r3__
        token_offsets = self.token_arange_np[:total_num_tokens] - new_query_start_locs_expanded

        # Expand starting positions to match token pattern
        # [0, q1, q1 + q2] ->
        # [0, 0, q1, q1, q1, q1, q1 + q2, q1 + q2, q1 + q2]
        #  _r1_  _____r2_______  ___________r3____________
        old_query_start_locs_expanded = np.repeat(query_start_loc_cpu[:-1].numpy(), new_num_tokens_per_req_np)
        # Final token indices are:
        # [0, 1,                                // req 1
        #  q1 + 0, q1 + 1, q1 + 2, q1 + 3,       // req 2
        #  q1 + q2 + 0, q1 + q2 + 1, q1 + q2 + 2] // req 3
        token_indices_np = token_offsets + old_query_start_locs_expanded
        token_indices = torch.from_numpy(token_indices_np).to(device, non_blocking=True)

        common_attn_metadata.slot_mapping[: token_indices.shape[0]].copy_(
            common_attn_metadata.slot_mapping[token_indices]
        )
        common_attn_metadata.slot_mapping[token_indices.shape[0] :].fill_(-1)
        token_to_req = (
            common_attn_metadata.token_to_req[token_indices] if common_attn_metadata.token_to_req is not None else None
        )

        # NOTE: Currently positions and seq_lens are not used in attn forward
        # so we do not need to fixed them. But if they are used in the future,
        # we should fixed them.
        # Mirror ``new_seq_lens_cpu`` into the upstream-canonical
        # ``_seq_lens_cpu`` slot so consumers preferring the parent field
        # (e.g. attention_cp builder) see the rejection-adjusted value.
        spec_common_attn_metadata = AscendCommonAttentionMetadata(
            query_start_loc=new_query_start_loc_cpu.to(device, non_blocking=True),
            query_start_loc_cpu=new_query_start_loc_cpu,
            seq_lens=new_seq_lens_cpu.to(device, non_blocking=True),
            seq_lens_cpu=new_seq_lens_cpu,
            _seq_lens_cpu=new_seq_lens_cpu,
            num_computed_tokens_cpu=common_attn_metadata.num_computed_tokens_cpu,
            _num_computed_tokens_cpu=common_attn_metadata._num_computed_tokens_cpu,
            seq_lens_cpu_upper_bound=new_seq_lens_cpu,
            num_reqs=common_attn_metadata.num_reqs,
            num_actual_tokens=total_num_tokens,
            num_input_tokens=common_attn_metadata.num_input_tokens,
            max_query_len=new_query_len_per_req.max().item(),
            block_table_tensor=common_attn_metadata.block_table_tensor,
            slot_mapping=common_attn_metadata.slot_mapping,
            actual_seq_lengths_q=self.runner.actual_seq_lengths_q,
            positions=common_attn_metadata.positions[token_indices],
            positions_cpu=common_attn_metadata.positions_cpu[token_indices]
            if common_attn_metadata.positions_cpu is not None
            else None,
            attn_state=self.runner.attn_state,
            decode_token_per_req=self.runner.decode_token_per_req,
            is_prefilling=common_attn_metadata.is_prefilling,
            max_seq_len=0,
            group_len=common_attn_metadata.group_len,
            group_key_idx=common_attn_metadata.group_key_idx,
            group_key_cache_idx=common_attn_metadata.group_key_cache_idx,
            req_topk_buffer_slots=common_attn_metadata.req_topk_buffer_slots,
            req_topk_buffer_active=common_attn_metadata.req_topk_buffer_active,
            offload_dummy=common_attn_metadata.offload_dummy,
            req_ids_tensor=common_attn_metadata.req_ids_tensor,
            token_to_req=token_to_req,
        )
        return spec_common_attn_metadata, token_indices

    def prepare_inputs_padded(
        self,
        common_attn_metadata: CommonAttentionMetadata,
        spec_decode_metadata: SpecDecodeMetadata,
        valid_sampled_tokens_count: torch.Tensor,
    ) -> tuple[CommonAttentionMetadata, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        This function is used to prepare the inputs for speculative decoding
        It updates the common_attn_metadata for speculative decoding,
        but does not consider the rejected tokens. Instead, all tokens
        are included as inputs to the speculator, with the rejected tokens
        used as padding and filtered out later by `token_indices_to_sample`.
        No blocking CPU operations should be introduced in this function.
        """
        if HAS_TRITON:
            num_reqs = common_attn_metadata.num_reqs
            device = valid_sampled_tokens_count.device

            token_indices_to_sample = torch.empty((num_reqs,), dtype=torch.int32, device=device)
            num_rejected_tokens_gpu = torch.empty((num_reqs,), dtype=torch.int32, device=device)
            num_blocks_needed = triton.cdiv(num_reqs, _PREPARE_INPUTS_BLOCK_SIZE)
            num_vector_core = get_vectorcore_num()
            grid_size = min(num_blocks_needed, num_vector_core)
            grid = (grid_size,)

            prepare_inputs_padded_kernel[grid](
                spec_decode_metadata.cu_num_draft_tokens,
                valid_sampled_tokens_count,
                common_attn_metadata.query_start_loc,
                token_indices_to_sample,
                num_rejected_tokens_gpu,
                num_reqs,
                BLOCK_SIZE=_PREPARE_INPUTS_BLOCK_SIZE,
            )
        else:
            num_draft_tokens_gpu = torch.cat(
                [
                    spec_decode_metadata.cu_num_draft_tokens[0:1],
                    spec_decode_metadata.cu_num_draft_tokens[1:] - spec_decode_metadata.cu_num_draft_tokens[:-1],
                ]
            )

            num_rejected_tokens_gpu = torch.where(
                num_draft_tokens_gpu > 0,
                num_draft_tokens_gpu + 1 - valid_sampled_tokens_count,
                torch.zeros_like(num_draft_tokens_gpu),
            )

            token_indices_to_sample = common_attn_metadata.query_start_loc[1:] - 1 - num_rejected_tokens_gpu

        query_start_loc_cpu = common_attn_metadata.query_start_loc_cpu

        new_query_len_per_req = query_start_loc_cpu[1:] - query_start_loc_cpu[:-1]

        total_num_tokens = query_start_loc_cpu[-1].item()
        token_indices = self.arange[:total_num_tokens]

        # NOTE: Currently positions and seq_lens are not used in attn forward
        # so we do not need to fixed them. But if they are used in the future,
        # we should fixed them.
        # ``prepare_inputs_padded`` does not change ``seq_lens`` (rejected
        # tokens are kept as padding and filtered out later). Pass through
        # both the subclass ``seq_lens_cpu`` field and the upstream-canonical
        # ``_seq_lens_cpu`` field unchanged. In async-spec mode only the
        # latter is populated (subclass field is None to signal "GPU is
        # authoritative"); dropping ``_seq_lens_cpu`` here causes downstream
        # backends (e.g. attention_cp) to crash on a None subscript.
        spec_common_attn_metadata = AscendCommonAttentionMetadata(
            query_start_loc=common_attn_metadata.query_start_loc,
            query_start_loc_cpu=query_start_loc_cpu,
            seq_lens_cpu=common_attn_metadata.seq_lens_cpu,
            _seq_lens_cpu=common_attn_metadata._seq_lens_cpu,
            seq_lens_cpu_upper_bound=common_attn_metadata.seq_lens_cpu_upper_bound,
            num_reqs=common_attn_metadata.num_reqs,
            num_actual_tokens=total_num_tokens,
            num_input_tokens=common_attn_metadata.num_input_tokens,
            max_query_len=new_query_len_per_req.max().item(),
            actual_seq_lengths_q=self.runner.actual_seq_lengths_q,
            block_table_tensor=common_attn_metadata.block_table_tensor,
            slot_mapping=common_attn_metadata.slot_mapping,
            positions=common_attn_metadata.positions,
            positions_cpu=common_attn_metadata.positions_cpu,
            attn_state=self.runner.attn_state,
            decode_token_per_req=self.runner.decode_token_per_req,
            num_computed_tokens_cpu=common_attn_metadata.num_computed_tokens_cpu,
            _num_computed_tokens_cpu=common_attn_metadata._num_computed_tokens_cpu,
            seq_lens=common_attn_metadata.seq_lens,
            is_prefilling=common_attn_metadata.is_prefilling,
            max_seq_len=0,
            group_len=common_attn_metadata.group_len,
            group_key_idx=common_attn_metadata.group_key_idx,
            group_key_cache_idx=common_attn_metadata.group_key_cache_idx,
            req_topk_buffer_slots=common_attn_metadata.req_topk_buffer_slots,
            req_topk_buffer_active=common_attn_metadata.req_topk_buffer_active,
            offload_dummy=common_attn_metadata.offload_dummy,
            req_ids_tensor=common_attn_metadata.req_ids_tensor,
            token_to_req=common_attn_metadata.token_to_req,
        )

        return spec_common_attn_metadata, token_indices, token_indices_to_sample, num_rejected_tokens_gpu

    # update full-graph params for one spec token
    def _update_full_graph_params(self, forward_context, num_tokens, draft_attn_metadatas=None):
        assert len(self.draft_attn_groups) > 0
        attn_backend = self._get_primary_draft_attn_group().backend
        update_full_graph_params(
            attn_backend,
            self.update_stream,
            forward_context,
            num_tokens,
            self.vllm_config,
            self.vllm_config.speculative_config,
            draft_attn_metadatas=draft_attn_metadatas,
        )

    # adjusting tensor into desired size
    def _adjust_tensor(self, tensor, desired_size):
        pad_size = desired_size - tensor.shape[0]
        if pad_size > 0:
            pad = [0] * (2 * tensor.dim() - 1) + [pad_size]
            tensor = F.pad(tensor, pad, mode="constant", value=0)
        else:
            tensor = tensor[:desired_size]
        return tensor

    # In the context of the dummy‑run accompaniment of p‑eagle, when num_indices becomes large,
    # enabling the LM head feature causes token_indices_to_sample to switch from padding to trimming.
    # The trimmed length may not be an integer multiple of the speculative length,
    # in which case padding is required to restore it to the original length.
    def _align_tensor_and_indices(
        self,
        tensor,
        num_indices,
        token_indices_to_sample,
        ori_token_indices_to_sample,
        is_logits=False,
    ):
        """
        Align the tensor (either draft_token_ids or logits) and token_indices_to_sample
        to the length specified by num_indices.

        Args:
        tensor: The tensor to be aligned (draft_token_ids or logits)
        num_indices: The target length
        token_indices_to_sample: The current index tensor
        ori_token_indices_to_sample: The original index tensor (used for restoration)
        is_logits: Whether the tensor is logits (affects the padding dimension and padding value)

        Returns:
        The adjusted tensor and token_indices_to_sample
        """
        if tensor.shape[0] == num_indices:
            return tensor, token_indices_to_sample

        if tensor.shape[0] > num_indices:
            # Trim to the target length.
            tensor = tensor[:num_indices]
            token_indices_to_sample = token_indices_to_sample[:num_indices]
        else:
            # Padding to the target length.
            pad_size = num_indices - tensor.shape[0]
            if is_logits:
                # logits: shape [seq_len, vocab_size], Padding at the end of the seq dimension.
                tensor = nn.functional.pad(tensor, (0, 0, 0, pad_size), value=-1e9)
            else:
                # draft_token_ids: shape [seq_len], Padding at the end
                tensor = nn.functional.pad(tensor, (0, pad_size))
            token_indices_to_sample = ori_token_indices_to_sample

        return tensor, token_indices_to_sample

    def build_draft_attn_metadata(
        self,
        common_attn_metadata,
        num_input_tokens,
        num_actual_tokens,
    ):
        # FIXME(woosuk): The below two ops cause synchronization. Optimize.
        assert len(self.draft_attn_groups) > 0
        if (
            getattr(self.runner, "sparse_kv_offload_enabled", False)
            and self.runner.sparse_kv_offload_config.use_fused_copy_sfa
        ):
            # Step 0 uses build(), unlike subsequent build_for_drafting() calls.
            common_attn_metadata = self.shallow_copy_metadata(common_attn_metadata)
            common_attn_metadata.copy_sfa_draft_index = 0
            common_attn_metadata.copy_sfa_restore_tails = False
        per_layer_attn_metadata: dict[str, Any] = {}
        # One DSA cache dict shared by all attn groups within this decode step.
        # DSpark draft layers span multiple kv-cache groups; every group gets
        # its own build_for_drafting call but most of the drafted metadata
        # (RoPE tables, local token metadata, SAS metadata) only depends
        # on group-invariant fields of common_attn_metadata, so it is computed
        # by the first group and reused by the remaining ones. Only the DSA
        # metadata builder (used by dspark) understands this kwarg; the generic
        # GQA builder used by dflash/eagle does not accept **kwargs, so leave
        # the cache empty in the non-compression path to avoid passing an
        # unexpected argument.
        shared_dsa_draft_cache: dict = dict(common_ratio_to_sas_metadata=dict()) if self.use_compress else {}
        dcp_manager = getattr(self.runner, "dcp_manager", None)
        device_metadata_tasks: list[DeviceMetadataTask] = []
        device_metadata_executor = (
            getattr(self.runner, "device_metadata_executor", None)
            if (
                self.method == "dspark"
                and self.dcp_size == 1
                and self.vllm_config.parallel_config.prefill_context_parallel_size == 1
            )
            else None
        )
        for attn_group in self.draft_attn_groups:
            builder = attn_group.get_metadata_builder()
            device_metadata_provider = (
                builder
                if device_metadata_executor is not None and isinstance(builder, DeviceMetadataTaskProvider)
                else None
            )
            extra_attn_metadata_args: dict = dict(shared_dsa_draft_cache)
            if self.use_compress:
                extra_attn_metadata_args["block_size"] = attn_group.kv_cache_spec.block_size
            if self.method == "dspark":
                gid = attn_group.kv_cache_group_id
                common_attn_metadata = copy.copy(common_attn_metadata)
                block_table = getattr(self, "_per_group_block_table_buffers", {}).get(gid)
                if block_table is not None:
                    common_attn_metadata.block_table_tensor = block_table[: common_attn_metadata.num_reqs]
                slot_mapping = self._per_group_query_slot_mapping_buffers[gid]
                if slot_mapping is not None:
                    common_attn_metadata.slot_mapping = slot_mapping[:num_input_tokens]
                # Apply the sliding window to the per-group block_table + seq_lens
                # that DSpark's draft FIA actually reads. This branch overwrites
                # common_attn_metadata.block_table_tensor with the full per-group
                # table, so the window applied earlier (line 922) is bypassed; we
                # skipped it there for dspark and re-apply here on the per-group
                # table so FIA reads the recent-blocks clone instead of block 0.
                # (dspark only - self.sliding_window is None for MTP.)
                if self.sliding_window is not None:
                    self.sliding_window.apply(common_attn_metadata)
                if dcp_manager is not None:
                    dcp_manager.prepare_common_attn_metadata(common_attn_metadata)
                attn_metadata = builder.build_for_drafting(
                    common_attn_metadata, draft_index=1, **extra_attn_metadata_args
                )
                if device_metadata_provider is not None:
                    device_metadata_tasks.extend(device_metadata_provider.take_device_metadata_tasks())
            else:
                if dcp_manager is not None:
                    dcp_manager.prepare_common_attn_metadata(common_attn_metadata)
                attn_metadata = builder.build(
                    0, common_attn_metadata, self.runner.get_model(), **extra_attn_metadata_args
                )
            if hasattr(attn_metadata, "causal") and not attn_metadata.causal:
                attn_metadata.attn_mask = None

            for layer_name in attn_group.layer_names:
                per_layer_attn_metadata[layer_name] = attn_metadata
        if device_metadata_executor is not None and device_metadata_tasks:
            device_metadata_executor.submit(device_metadata_tasks)
        multi_steps_attn_metadata = [per_layer_attn_metadata]
        # Copy the old attn_metadata and update
        primary_group = self._get_primary_draft_attn_group()
        attn_metadata_i = per_layer_attn_metadata[primary_group.layer_names[0]]
        return multi_steps_attn_metadata, attn_metadata_i

    def _pad_draft_buffers(
        self,
        num_actual_tokens: int,
        num_input_tokens: int,
    ) -> None:
        if not hasattr(self, "_per_group_block_table_buffers"):
            return
        if num_input_tokens <= num_actual_tokens:
            return
        self.input_ids[num_actual_tokens:num_input_tokens].fill_(self.parallel_drafting_token_id)
        self.positions[num_actual_tokens:num_input_tokens].fill_(0)
        self._slot_mapping_buffer[num_actual_tokens:num_input_tokens].fill_(-1)

        for buf in getattr(self, "_per_group_query_slot_mapping_buffers", {}).values():
            buf[num_actual_tokens:num_input_tokens].fill_(-1)
        for buf in getattr(self, "_per_group_context_slot_mapping_buffers", {}).values():
            buf[self._dflash_num_context :].fill_(-1)


# draft_embed_mm_kwargs: text-only MTP heads such as Glm5NextMTP expose
# embed_input_ids(input_ids) with no multimodal parameters, so forwarding the
# multimodal kwargs of a multimodal target model raises TypeError.

_DRAFT_EMBED_MM_SUPPORT: dict = {}


def _draft_embed_accepts_mm(embed_fn) -> bool:
    key = getattr(embed_fn, "__func__", embed_fn)
    cached = _DRAFT_EMBED_MM_SUPPORT.get(key)
    if cached is None:
        try:
            cached = "multimodal_embeddings" in _inspect.signature(embed_fn).parameters
        except (TypeError, ValueError):
            # C-bound callables and some test doubles reject introspection.
            # Treat them as text-only: that is the side that cannot raise
            # TypeError, since it only means the mm kwargs are not forwarded.
            cached = False
        _DRAFT_EMBED_MM_SUPPORT[key] = cached
    return cached


def _split_draft_outputs(ret):
    """Return (logit_hidden, recycle_hidden) for any MTP head return shape.

    draft_tuple_outputs: DeepSeek-family heads return
    ``(logit_hidden, recycle_hidden)``; Glm5NextMTP returns the same 2-tuple
    even though it is absent from the architecture whitelist; other families
    return a bare tensor.
    """
    if not isinstance(ret, (tuple, list)):
        return ret, ret
    if len(ret) == 2:
        return ret[0], ret[1]
    return ret[0], ret[0]
