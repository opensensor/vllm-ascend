import importlib.util,subprocess,time,json,urllib.request
from pathlib import Path
p=Path('/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009/tools/qwen4exp/thermal_controller.py')
s=importlib.util.spec_from_file_location('thermal_control',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
start=time.monotonic()
for i in range(150):
 temps=m.parse_temperatures(subprocess.check_output(['npu-smi','info'],text=True,timeout=5),6)
 if i%5==0:print(json.dumps({'elapsed_s':time.monotonic()-start,'temperatures_c':temps}),flush=True)
 if max(temps)<=80:
  metrics=urllib.request.urlopen("http://127.0.0.1:8001/metrics",timeout=10).read().decode()
  live=[float(l.rsplit(" ",1)[1]) for l in metrics.splitlines() if l.startswith(("vllm:num_requests_running{","vllm:num_requests_waiting{"))]
  if live and all(v==0 for v in live):break
 time.sleep(2)
else:raise SystemExit('cooling admission timed out')
