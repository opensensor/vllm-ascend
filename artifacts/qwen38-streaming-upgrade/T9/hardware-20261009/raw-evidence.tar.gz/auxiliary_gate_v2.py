"""Native auxiliary gates on the isolated new chip; no live model mutation."""

import json
from pathlib import Path

import torch
import torch_npu

from tools.qwen4exp.benchmark_prefill_next_310 import wy_gate
from tools.qwen4exp.native_prefill import NativeLocalRouteGather, NativeWY
from tools.qwen4exp.native_state_layout import NativeStateLayout
from tools.qwen4exp.build_streaming import verify_bundle
from tools.qwen4exp.thermal_controller import parse_temperatures
import subprocess

BUNDLE = Path('/home/matteius/experiments/qwen-streaming-bundle-v5-20261009')
OUTPUT = Path('/home/matteius/experiments/qwen-streaming-hardware-20261009/auxiliary-gate.jsonl')
assert not OUTPUT.exists()
verify_bundle(BUNDLE, require_compiled=True)
candidate = json.loads((BUNDLE / 'candidate.json').read_text())
torch.npu.set_device(0)
torch_npu.npu.set_compile_mode(jit_compile=False)
torch.empty(1, device='npu')
torch.ops.load_library(str(BUNDLE / candidate['bridges'][0]['path']))
namespace = candidate['namespace']
kernel = getattr(torch.classes, namespace).Kernel
launch = getattr(torch.ops, namespace).launch


def record(result):
    print(json.dumps(result), flush=True)
    with OUTPUT.open('a') as stream:
        stream.write(json.dumps(result) + '\n')


def guard():
    # Read the corrected monitor parser, without modifying the worker snapshot.
    import importlib.util
    spec = importlib.util.spec_from_file_location('thermal', OUTPUT.parent / 'thermal-controller-fixed-v2.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    values = module.parse_temperatures(subprocess.check_output(['npu-smi', 'info'], text=True, timeout=3), 6)
    if max(values) >= 90:
        raise RuntimeError(f'Standalone gate temperature stop: {values}')
    return values


state_binary = str(BUNDLE / 'binaries/native_state_layout.bin')
state_io = NativeStateLayout(kernel(state_binary, 'qwen_state_gather_v1'),
                             kernel(state_binary, 'qwen_state_scatter_v1'), launch)
generator = torch.Generator().manual_seed(918)
for heads, sequences in ((12, 1), (48, 4)):
    guard()
    cache = torch.randn(8, heads, 128, 128, generator=generator).npu()
    slots = torch.tensor([6, 2, 3, 4][:sequences], dtype=torch.int32).npu()
    initialized = torch.tensor([False, True, True, False][:sequences]).npu()
    expected = cache[slots.long()].clone()
    expected[~initialized] = 0
    actual = state_io.gather(cache, slots, initialized)
    torch.testing.assert_close(actual.cpu(), expected.transpose(-1, -2).contiguous().cpu(), rtol=0, atol=0)
    state_io.scatter(cache, slots, initialized, actual)
    torch.testing.assert_close(cache[slots.long()].cpu(), expected.cpu(), rtol=0, atol=0)
    record({'case': 'state_io', 'heads': heads, 'sequences': sequences, 'exact': True, 'temperatures_c': guard()})

gather = NativeLocalRouteGather(kernel(str(BUNDLE / 'binaries/native_route_gather.bin'), 'qwen_local_route_gather_v1'), launch)
from vllm_ascend.models.qwen4_exp.w4a8_int4 import pack_activation_device
inputs = torch.randn(128, 2560, generator=generator).half().npu()
packed = pack_activation_device(inputs)
order = torch.arange(1280, dtype=torch.int32).remainder(128).npu()
for active in (0, 1, 320, 1280):
    guard()
    ends = torch.tensor([active // 2, active], dtype=torch.int64, device=inputs.device)
    actual = gather(packed, order, ends)
    for got, original in zip(actual, packed):
        torch.testing.assert_close(got[:active].cpu(), original.index_select(0, order[:active].long()).cpu(), rtol=0, atol=0)
    record({'case': 'route_gather', 'active': active, 'exact': True, 'temperatures_c': guard()})

guard()
wy = NativeWY(kernel(str(BUNDLE / 'binaries/native_wy.bin'), 'qwen_fused_wy_v1'), launch)
record({'case': 'wy', 'result': wy_gate({'wy': wy}, tokens=128), 'temperatures_c': guard()})
record({'auxiliary_parity_passed': True, 'full_model_validated': False})
