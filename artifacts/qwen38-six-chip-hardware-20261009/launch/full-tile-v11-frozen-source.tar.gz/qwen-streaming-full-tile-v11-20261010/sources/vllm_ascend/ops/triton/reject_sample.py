#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from vllm.triton_utils import tl, triton
from vllm.utils.math_utils import next_power_of_2

from vllm_ascend.ops.triton.triton_utils import get_element, get_vectorcore_num


def cal_grid_and_block_size(batch_size: int):
    vectorcore_num = get_vectorcore_num()
    if batch_size <= vectorcore_num:
        grid = batch_size
        block_size = 1
    else:
        grid = vectorcore_num
        block_size = next_power_of_2(triton.cdiv(batch_size, grid))
    return grid, block_size


@triton.jit(do_not_specialize=["vec_len"])
def rejection_greedy_sample_spec_len_1_triton(
    output_token_ids_ptr,  # [batch_size, 2]
    draft_token_ids_ptr,  # [num_tokens]
    target_argmax_ptr,  # [num_tokens]
    bonus_token_ids_ptr,
    vec_len,
    uniform_probs_ptr,  # [num_tokens] or None (synthetic only)
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    SYNTHETIC_MODE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    block_idx = tl.program_id(0)
    offset = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offset < vec_len

    draft_token_id = tl.load(draft_token_ids_ptr + offset, mask)
    target_argmax_id = tl.load(target_argmax_ptr + offset, mask)
    bonus_token_id = tl.load(bonus_token_ids_ptr + offset, mask)

    if SYNTHETIC_MODE:
        # Synthetic: accept the draft token with prob conditional_rates[0],
        # regardless of target match. Accepted => emit draft token (pos 0) and
        # the bonus token (pos 1); rejected => emit target_argmax (pos 0).
        uniform_prob = tl.load(uniform_probs_ptr + offset, mask)
        # spec_len == 1 => only position 0.
        rate = tl.load(synthetic_conditional_rates_ptr + 0)
        accepted = (uniform_prob < rate) & (draft_token_id >= 0) & mask
        # Cast both arms to int32: draft_token_id is int32, target_argmax_id is
        # int64 (from argmax); tl.where requires matching dtypes.
        token_id = tl.where(accepted, draft_token_id.to(tl.int32), target_argmax_id.to(tl.int32))
        tl.store(output_token_ids_ptr + offset * 2, token_id, mask)
        accept_mask = accepted
    else:
        tl.store(output_token_ids_ptr + offset * 2, target_argmax_id, mask)
        accept_mask = (draft_token_id == target_argmax_id) & mask
    tl.store(output_token_ids_ptr + offset * 2 + 1, bonus_token_id, accept_mask)


@triton.jit(do_not_specialize=["max_spec_len"])
def bonus_renew(
    bonus_token_ids_ptr,
    position,
    output_token_ids_ptr,
    max_spec_len,
    num_tokens1,
):
    bonus_token_id = tl.load(bonus_token_ids_ptr + position)
    tl.store(output_token_ids_ptr + position * (max_spec_len + 1) + num_tokens1, bonus_token_id)


@triton.jit(do_not_specialize=["vec_len", "max_spec_len"])
def rejection_greedy_sample_triton(
    output_token_ids_ptr,  # [batch_size, max_spec_len + 1]
    cu_num_draft_tokens_ptr,  # [batch_size]
    draft_token_ids_ptr,  # [num_tokens]
    target_argmax_ptr,  # [num_tokens]
    bonus_token_ids_ptr,  # [batch_size]
    is_greedy_ptr,  # [batch_size] or None
    vec_len,
    max_spec_len,
    uniform_probs_ptr,  # [num_tokens] or None (synthetic only)
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    SYNTHETIC_MODE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    block_idx = tl.program_id(0)
    offset = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offset < vec_len

    if is_greedy_ptr is None:
        is_greedy_mask = mask
    else:
        is_greedy = tl.load(is_greedy_ptr + offset, mask=mask, other=0)
        is_greedy_mask = mask & (is_greedy != 0)

    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offset == 0 must
    # be masked out at the load. other=0 keeps num_draft_tokens deterministic
    # (0) for masked lanes, which the per-position loop below relies on to
    # skip them.
    start_idx = tl.load(cu_num_draft_tokens_ptr + offset - 1, mask=is_greedy_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_draft_tokens_ptr + offset, is_greedy_mask, other=0)
    num_draft_tokens = end_idx - start_idx

    for pos in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_draft_tokens, (pos,))
        rejected = False
        start_idx1 = get_element(start_idx, (pos,))
        is_greedy_mask1 = get_element(is_greedy_mask, (pos,))
        position = block_idx * BLOCK_SIZE + pos
        for i in range(num_tokens1):
            if not rejected:
                draft_token_id = tl.load(draft_token_ids_ptr + start_idx1 + i)
                target_argmax_id = tl.load(target_argmax_ptr + start_idx1 + i)
                if SYNTHETIC_MODE:
                    # Synthetic: accept draft token i with prob
                    # conditional_rates[i], independent of target match. Store
                    # each arm separately (draft on accept, target_argmax on
                    # reject) so the int32 (draft) / int64 (target_argmax)
                    # dtype mismatch is handled by the store's implicit cast --
                    # no ternary, no explicit cast (matches the random kernel's
                    # synthetic branch).
                    uniform_prob = tl.load(uniform_probs_ptr + start_idx1 + i)
                    rate = tl.load(synthetic_conditional_rates_ptr + i)
                    accepted = (uniform_prob < rate) & (draft_token_id >= 0)
                    if accepted:
                        tl.store(
                            output_token_ids_ptr + position * (max_spec_len + 1) + i,
                            draft_token_id,
                        )
                    else:
                        tl.store(
                            output_token_ids_ptr + position * (max_spec_len + 1) + i,
                            target_argmax_id,
                        )
                        rejected = True
                else:
                    tl.store(
                        output_token_ids_ptr + position * (max_spec_len + 1) + i,
                        target_argmax_id,
                    )
                    if draft_token_id != target_argmax_id:
                        # Reject.
                        rejected = True

        if not rejected and is_greedy_mask1:
            bonus_renew(
                bonus_token_ids_ptr,
                position,
                output_token_ids_ptr,
                max_spec_len,
                num_tokens1,
            )


@triton.jit(
    do_not_specialize=[
        "max_spec_len",
        "vec_len",
    ]
)
def rejection_random_sample_kernel(
    output_token_ids_ptr,  # [batch_size, max_spec_len + 1]
    cu_num_draft_tokens_ptr,  # [batch_size]
    draft_token_ids_ptr,  # [num_tokens]
    draft_probs_ptr,  # [num_tokens, vocab_size] or None
    target_probs_ptr,  # [num_tokens, vocab_size]
    bonus_token_ids_ptr,  # [batch_size]
    recovered_token_ids_ptr,  # [num_tokens]
    uniform_probs_ptr,  # [num_tokens]
    is_greedy_ptr,  # [batch_size]
    max_spec_len,
    vocab_size,
    global_vocab_size,
    vec_len,
    ori_target_probs_ptr,  # [num_tokens, ori_vocab_size] original probs for entropy
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    NO_ORI_TARGET_PROBS: tl.constexpr,
    NO_DRAFT_PROBS: tl.constexpr,
    SYNTHETIC_MODE: tl.constexpr,
    ENTROPY_VERIFY: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    POSTERIOR_THRESHOLD: tl.constexpr = 0.95,
    POSTERIOR_ALPHA: tl.constexpr = 0.4,
    SUB_BLOCK: tl.constexpr = 4096,
    EPSILON: tl.constexpr = 1e-10,
):
    block_idx = tl.program_id(0)
    offsets = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < vec_len
    is_greedy = tl.load(is_greedy_ptr + offsets, mask, other=1)
    not_greedy_mask = is_greedy == 0
    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offsets == 0 must
    # be masked out at the load.
    start_idxs = tl.load(cu_num_draft_tokens_ptr + offsets - 1, mask=not_greedy_mask & (offsets > 0), other=0)
    end_idxs = tl.load(cu_num_draft_tokens_ptr + offsets, not_greedy_mask, other=0)
    n_num_draft_tokens = end_idxs - start_idxs

    for req_i in range(BLOCK_SIZE):
        not_greedy = get_element(not_greedy_mask, (req_i,))
        if not_greedy:
            rejected = False
            start_idx = get_element(start_idxs, (req_i,))
            req_idx = block_idx * BLOCK_SIZE + req_i
            num_draft_tokens = get_element(n_num_draft_tokens, (req_i,))

            for pos in range(num_draft_tokens):
                if not rejected:
                    if SYNTHETIC_MODE:
                        # Synthetic: accept draft token with prob
                        # conditional_rates[pos], bypassing target/draft prob
                        # comparison. Output may be incorrect - benchmarking only.
                        token_idx = start_idx + pos
                        draft_token_id = tl.load(draft_token_ids_ptr + token_idx)
                        uniform_prob = tl.load(uniform_probs_ptr + token_idx)
                        rate = tl.load(synthetic_conditional_rates_ptr + pos)
                        accepted = (uniform_prob < rate) & (draft_token_id >= 0)
                        if accepted:
                            tl.store(
                                output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                                draft_token_id,
                            )
                        else:
                            rejected = True
                            recovered = tl.load(recovered_token_ids_ptr + token_idx)
                            tl.store(
                                output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                                recovered,
                            )
                    else:
                        token_idx = start_idx + pos
                        draft_token_id = tl.load(draft_token_ids_ptr + token_idx)
                        if draft_token_id == -1:
                            rejected = True
                            token_id = tl.load(recovered_token_ids_ptr + token_idx)
                        else:
                            target_prob = tl.load(target_probs_ptr + token_idx * global_vocab_size + draft_token_id)
                            if NO_DRAFT_PROBS:
                                draft_prob = 1
                            else:
                                draft_prob = tl.load(draft_probs_ptr + token_idx * global_vocab_size + draft_token_id)
                            uniform_prob = tl.load(uniform_probs_ptr + token_idx)

                            if ENTROPY_VERIFY:
                                loop = (vocab_size + SUB_BLOCK - 1) // SUB_BLOCK
                                entropy = 0.0
                                for loop_i in range(loop):
                                    vocab_start = loop_i * SUB_BLOCK
                                    vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
                                    vocab_mask = vocab_offset < vocab_size
                                    if NO_ORI_TARGET_PROBS:
                                        probs = tl.load(
                                            target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                            vocab_mask,
                                            other=0,
                                        )
                                    else:
                                        probs = tl.load(
                                            ori_target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                            vocab_mask,
                                            other=0,
                                        )
                                    log_probs = tl.log(probs + EPSILON)
                                    entropy_contrib = -probs * log_probs
                                    entropy += tl.sum(entropy_contrib)

                                exp_neg_entropy = tl.exp(-entropy * POSTERIOR_ALPHA)
                                threshold_by_entropy = exp_neg_entropy
                                threshold = tl.minimum(threshold_by_entropy, POSTERIOR_THRESHOLD)
                                _uniform_prob = threshold * uniform_prob
                            else:
                                _uniform_prob = uniform_prob
                            # NOTE(woosuk): While the draft probability should never be 0,
                            # we check it to avoid NaNs. If it happens to be 0, we reject.
                            if draft_prob > 0 and target_prob / draft_prob >= _uniform_prob:
                                # Accept.
                                token_id = draft_token_id
                            else:
                                # Reject. Use recovered token.
                                rejected = True
                                token_id = tl.load(recovered_token_ids_ptr + token_idx)
                        tl.store(output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos, token_id)

            if not rejected:
                # If all tokens are accepted, append the bonus token.
                bonus_token_id = tl.load(bonus_token_ids_ptr + req_idx)
                tl.store(
                    output_token_ids_ptr + req_idx * (max_spec_len + 1) + num_draft_tokens,
                    bonus_token_id,
                )


@triton.jit(do_not_specialize=["replace_from", "replace_to", "vec_len"])
def expand_kernel(
    output_ptr,  # [num_tokens]
    input_ptr,  # [batch_size]
    cu_num_tokens_ptr,  # [batch_size]
    replace_from,
    replace_to,
    vec_len,
    MAX_NUM_TOKENS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    offset = req_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    len_mask = offset < vec_len

    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offset == 0 must
    # be masked out at the load. other=0 keeps num_tokens deterministic (0)
    # for out-of-range lanes, which the store mask below relies on.
    start_idx = tl.load(cu_num_tokens_ptr + offset - 1, mask=len_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_tokens_ptr + offset, len_mask, other=0)
    num_tokens = end_idx - start_idx

    src_val = tl.load(input_ptr + offset, len_mask)
    src_val = tl.where(src_val == replace_from, replace_to, src_val)

    for i in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_tokens, (i,))
        start_idx1 = get_element(start_idx, (i,))
        src_val1 = get_element(src_val, (i,))
        offset1 = tl.arange(0, MAX_NUM_TOKENS)
        tl.store(output_ptr + start_idx1 + offset1, src_val1, mask=offset1 < num_tokens1)


@triton.jit
def sample_recovered_tokens_kernel(
    output_token_ids_ptr,
    cu_num_draft_tokens_ptr,
    draft_token_ids_ptr,
    draft_probs_ptr,
    target_probs_ptr,
    q_ptr,
    vocab_size,
    NO_DRAFT_PROBS: tl.constexpr,
    SUB_BLOCK: tl.constexpr,
):
    req_idx = tl.program_id(0)
    pos = tl.program_id(1)

    # Compute token index. Clamp the previous-request index instead of
    # relying on tl.where: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), and a 0-d masked load is
    # not reliably supported on triton-ascend. The clamped load address always
    # stays inside the buffer; tl.where merely discards the value for
    # req_idx == 0.
    prev_req_idx = tl.maximum(req_idx - 1, 0)
    start_idx = tl.where(req_idx == 0, 0, tl.load(cu_num_draft_tokens_ptr + prev_req_idx))
    end_idx = tl.load(cu_num_draft_tokens_ptr + req_idx)
    num_draft_tokens = end_idx - start_idx

    if pos >= num_draft_tokens:
        return

    loop = (vocab_size + SUB_BLOCK - 1) // SUB_BLOCK
    global_recovered_id = -1
    global_max_p = -1.0
    if NO_DRAFT_PROBS:
        draft_token_id = tl.load(draft_token_ids_ptr + start_idx + pos)
        for loop_i in range(loop):
            vocab_start = loop_i * SUB_BLOCK
            vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
            prob = tl.load(
                target_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                mask=vocab_offset < vocab_size,
                other=0,
            )
            prob = tl.where(vocab_offset == draft_token_id, 0.0, prob)
            q = tl.load(
                q_ptr + req_idx * vocab_size + vocab_offset, mask=vocab_offset < vocab_size, other=float("-inf")
            )
            new_p = prob / q
            recovered_id = tl.argmax(new_p, axis=-1)
            max_p = get_element(new_p, (recovered_id,))
            if max_p > global_max_p:
                global_max_p = max_p
                global_recovered_id = vocab_start + recovered_id
    else:
        for loop_i in range(loop):
            vocab_start = loop_i * SUB_BLOCK
            vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
            draft_prob = tl.load(
                draft_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                mask=vocab_offset < vocab_size,
                other=0,
            )
            target_prob = tl.load(
                target_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                mask=vocab_offset < vocab_size,
                other=0,
            )
            prob = tl.maximum(target_prob - draft_prob, 0)
            # NOTE(woosuk): We don't need `prob = prob / tl.sum(prob)` here because
            # `tl.argmax` will select the maximum value.

            q = tl.load(
                q_ptr + req_idx * vocab_size + vocab_offset, mask=vocab_offset < vocab_size, other=float("-inf")
            )
            new_p = prob / q
            recovered_id = tl.argmax(new_p, axis=-1)
            max_p = get_element(new_p, (recovered_id,))
            if max_p > global_max_p:
                global_max_p = max_p
                global_recovered_id = vocab_start + recovered_id

    tl.store(output_token_ids_ptr + start_idx + pos, global_recovered_id)


def rejection_greedy_sample_with_triton(
    output_token_ids,
    num_draft_tokens,
    cu_num_draft_tokens,
    draft_token_ids,
    target_argmax,
    bonus_token_ids,
    is_greedy,
    max_spec_len,
    grid,
    block_size,
    uniform_probs=None,
    synthetic_conditional_rates=None,
    synthetic_mode=False,
):
    vec_len = output_token_ids.shape[0]

    if min(num_draft_tokens) == 1 and max(num_draft_tokens) == 1 and is_greedy is None:
        rejection_greedy_sample_spec_len_1_triton[(grid,)](
            output_token_ids,
            draft_token_ids,
            target_argmax,
            bonus_token_ids,
            vec_len,
            uniform_probs,
            synthetic_conditional_rates,
            SYNTHETIC_MODE=synthetic_mode,
            BLOCK_SIZE=block_size,
        )
    else:
        rejection_greedy_sample_triton[(grid,)](
            output_token_ids,
            cu_num_draft_tokens,
            draft_token_ids,
            target_argmax,
            bonus_token_ids,
            is_greedy,
            vec_len,
            max_spec_len,
            uniform_probs,
            synthetic_conditional_rates,
            SYNTHETIC_MODE=synthetic_mode,
            BLOCK_SIZE=block_size,
        )


def expand_triton(batch_size, expanded_x, x, cu_num_tokens, replace_from, replace_to, max_num_tokens):
    vec_len = batch_size
    grid, block_size = cal_grid_and_block_size(batch_size)

    expand_kernel[(grid,)](
        expanded_x,
        x,
        cu_num_tokens,
        replace_from,
        replace_to,
        vec_len,
        MAX_NUM_TOKENS=max_num_tokens,  # To avoid recompilation.
        BLOCK_SIZE=block_size,
    )


@triton.jit(
    do_not_specialize=[
        "max_spec_len",
        "vec_len",
    ]
)
def rejection_random_sample_block_verify_kernel(
    output_token_ids_ptr,  # [batch_size, max_spec_len + 1]
    cu_num_draft_tokens_ptr,  # [batch_size]
    draft_token_ids_ptr,  # [num_tokens]
    draft_probs_ptr,  # [num_tokens, vocab_size] or None
    target_probs_ptr,  # [num_tokens, vocab_size]
    bonus_token_ids_ptr,  # [batch_size]
    recovered_token_ids_ptr,  # [num_tokens]
    uniform_probs_ptr,  # [num_tokens]
    is_greedy_ptr,  # [batch_size]
    max_spec_len,
    vocab_size,
    global_vocab_size,
    vec_len,
    ori_target_probs_ptr,  # [num_tokens, ori_vocab_size] original probs for entropy
    NO_ORI_TARGET_PROBS: tl.constexpr,
    NO_DRAFT_PROBS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    ENTROPY_VERIFY: tl.constexpr,
    POSTERIOR_THRESHOLD: tl.constexpr = 0.95,
    POSTERIOR_ALPHA: tl.constexpr = 0.4,
    SUB_BLOCK: tl.constexpr = 4096,
    EPSILON: tl.constexpr = 1e-10,
):
    block_idx = tl.program_id(0)
    offsets = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < vec_len
    is_greedy = tl.load(is_greedy_ptr + offsets, mask, other=1)
    not_greedy_mask = is_greedy == 0
    prev_mask = not_greedy_mask & (offsets > 0)
    prev_end_idxs = tl.load(cu_num_draft_tokens_ptr + offsets - 1, prev_mask, other=0)
    start_idxs = tl.where(offsets == 0, 0, prev_end_idxs)
    end_idxs = tl.load(cu_num_draft_tokens_ptr + offsets, not_greedy_mask)
    n_num_draft_tokens = end_idxs - start_idxs

    for req_i in range(BLOCK_SIZE):
        not_greedy = get_element(not_greedy_mask, (req_i,))
        if not_greedy:
            pi = 1.0
            uniform_prob = 1.0
            last_accepted_token_pos = -1
            start_idx = get_element(start_idxs, (req_i,))
            req_idx = block_idx * BLOCK_SIZE + req_i
            num_draft_tokens = get_element(n_num_draft_tokens, (req_i,))

            for pos in range(num_draft_tokens):
                token_idx = start_idx + pos
                draft_token_id = tl.load(draft_token_ids_ptr + token_idx)

                if draft_token_id == -1:
                    pi = 0.0
                else:
                    target_prob = tl.load(target_probs_ptr + token_idx * vocab_size + draft_token_id)

                    tmp_uniform_prob = tl.load(uniform_probs_ptr + token_idx)
                    uniform_prob = uniform_prob * tmp_uniform_prob

                    if NO_DRAFT_PROBS:
                        draft_prob = 1.0
                    else:
                        vocab_for_draft = vocab_size
                        draft_prob = tl.load(draft_probs_ptr + token_idx * vocab_for_draft + draft_token_id)

                    if ENTROPY_VERIFY:
                        loop = (vocab_size + SUB_BLOCK - 1) // SUB_BLOCK
                        entropy = 0.0
                        for loop_i in range(loop):
                            vocab_start = loop_i * SUB_BLOCK
                            vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
                            vocab_mask = vocab_offset < vocab_size
                            if NO_ORI_TARGET_PROBS:
                                probs = tl.load(
                                    target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                    vocab_mask,
                                    other=0,
                                )
                            else:
                                probs = tl.load(
                                    ori_target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                    vocab_mask,
                                    other=0,
                                )
                            log_probs = tl.log(probs + EPSILON)
                            entropy_contrib = -probs * log_probs
                            entropy += tl.sum(entropy_contrib)

                        exp_neg_entropy = tl.exp(-entropy * POSTERIOR_ALPHA)
                        threshold_by_entropy = exp_neg_entropy
                        threshold = tl.minimum(threshold_by_entropy, POSTERIOR_THRESHOLD)
                        _uniform_prob = threshold * uniform_prob
                    else:
                        _uniform_prob = uniform_prob

                    pi = min(pi * target_prob / draft_prob, 1.0)
                    if draft_prob > 0 and pi >= _uniform_prob:
                        last_accepted_token_pos = pos

            # Store accepted tokens
            if last_accepted_token_pos > -1:
                for pos in range(last_accepted_token_pos + 1):
                    token_id = tl.load(draft_token_ids_ptr + start_idx + pos)
                    tl.store(output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos, token_id)

            # Store recovered or bonus token
            if last_accepted_token_pos + 1 < num_draft_tokens:
                # Rejected - store recovered token
                recovered_token_id = tl.load(recovered_token_ids_ptr + start_idx + last_accepted_token_pos + 1)
                tl.store(
                    output_token_ids_ptr + req_idx * (max_spec_len + 1) + last_accepted_token_pos + 1,
                    recovered_token_id,
                )
            else:
                # All accepted - store bonus token
                bonus_token_id = tl.load(bonus_token_ids_ptr + req_idx)
                tl.store(output_token_ids_ptr + req_idx * (max_spec_len + 1) + num_draft_tokens, bonus_token_id)
