import importlib.util,subprocess,time,json
from pathlib import Path
p=Path('/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009/tools/qwen4exp/thermal_controller.py')
s=importlib.util.spec_from_file_location('thermal_control',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
start=time.monotonic()
for i in range(150):
 temps=m.parse_temperatures(subprocess.check_output(['npu-smi','info'],text=True,timeout=5),6)
 if i%5==0:print(json.dumps({'elapsed_s':time.monotonic()-start,'temperatures_c':temps}),flush=True)
 if max(temps)<=80:break
 time.sleep(2)
else:raise SystemExit('cooling admission timed out')
