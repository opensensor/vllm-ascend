#
# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

import torch
from vllm.config import get_current_vllm_config
from vllm.logger import logger
from vllm.model_executor.layers.linear import LinearBase
from vllm.model_executor.layers.quantization import register_quantization_config
from vllm.model_executor.layers.quantization.base_config import QuantizeMethodBase
from vllm.model_executor.layers.vocab_parallel_embedding import (
    VocabParallelEmbedding,
)

from vllm_ascend import envs
from vllm_ascend._310p.quantization.methods.registry import (
    get_scheme_class,
)
from vllm_ascend.quantization.configs.modelslim_config import (
    AscendModelSlimConfig,
    get_quant_type_for_layer,
)
from vllm_ascend.quantization.method_adapters import AscendFusedMoEMethod, AscendLinearMethod
from vllm_ascend.quantization.utils import is_fused_moe_layer
from vllm_ascend.utils import ASCEND_QUANTIZATION_METHOD


def create_scheme_for_layer(
    quant_type: str,
    prefix: str,
    layer_type: str,
):
    """Create a quantization scheme instance for a layer.

    Args:
        quant_type: The quantization type string (e.g., "W8A8_DYNAMIC").
        prefix: The layer prefix.
        layer_type: The type of layer ("linear", "moe", "attention").

    Returns:
        An instance of the appropriate quantization scheme class.
    """
    logger.info_once("Using vLLM Ascend ModelSlim quantization.")
    if quant_type is None:
        err_msg = f"Could not determine quantization type for layer {prefix} (layer_type={layer_type})."
        logger.error(err_msg)
        raise ValueError(err_msg)

    # Use registry to get scheme class
    scheme_cls = get_scheme_class(quant_type, layer_type)
    if scheme_cls is not None:
        return scheme_cls()

    err_msg = f"Unsupported quant_type={quant_type} for layer_type={layer_type}."
    logger.error(err_msg)
    raise NotImplementedError(err_msg)


@register_quantization_config(ASCEND_QUANTIZATION_METHOD)
class AscendModelSlimConfig310(AscendModelSlimConfig):
    """310P override for ModelSlim quantization config.

    - Uses 310P-local scheme registry to create scheme by (quant_type, layer_type).
    - MUST keep packed_modules_mapping behavior consistent with base, otherwise
      fused modules (qkv_proj / gate_up_proj) will miss and fallback to base,
      causing NZ/transpose issues on 310P.
    """

    def get_quant_method(
        self,
        layer: torch.nn.Module,
        prefix: str,
        tid2eid: Any = None,
    ) -> QuantizeMethodBase | None:
        vllm_config = get_current_vllm_config()
        model_type = vllm_config.model_config.hf_config.model_type

        self._update_packed_modules_mapping(model_type)

        prefix = self.quant_prefix_mapper(model_type, prefix)
        quant_type = get_quant_type_for_layer(self.quant_description, prefix, self.packed_modules_mapping)

        if isinstance(layer, LinearBase):
            if quant_type is None:
                if envs.VLLM_ASCEND_310P_GDN_W8A8:
                    from vllm_ascend._310p.quantization.methods.gdn_shared_w8a8 import (
                        AscendGDNW8A8LinearMethod310,
                        is_gdn_quantized_projection,
                    )

                    if is_gdn_quantized_projection(prefix):
                        logger.debug("Select GDN W8A8 method for %s", prefix)
                        return AscendGDNW8A8LinearMethod310()
                from vllm_ascend.ops.linear import AscendUnquantizedLinearMethod

                logger.debug("Select AscendUnquantizedLinearMethod for %s (layer=%s)", prefix, "LinearBase")
                return AscendUnquantizedLinearMethod()

            scheme = create_scheme_for_layer(quant_type, prefix, "linear")
            logger.debug("Select AscendLinearMethod for %s (layer=%s)", prefix, "LinearBase")
            return AscendLinearMethod(scheme)

        elif is_fused_moe_layer(layer):
            if quant_type is None:
                from vllm_ascend._310p.fused_moe.fused_moe import AscendUnquantizedFusedMoEMethod310

                logger.debug("Select AscendUnquantizedFusedMoEMethod310 for %s (layer=%s)", prefix, "FusedMoE")
                return AscendUnquantizedFusedMoEMethod310(layer.moe_config)
            scheme = create_scheme_for_layer(quant_type, prefix, "moe")
            logger.debug("Select AscendFusedMoEMethod for %s (layer=%s)", prefix, "FusedMoE")
            return AscendFusedMoEMethod(scheme, layer.moe_config)

        elif isinstance(layer, VocabParallelEmbedding):
            if quant_type is not None:
                raise NotImplementedError(
                    f"Quantization type {quant_type} for VocabParallelEmbedding is not supported on 310P."
                )
            from vllm_ascend._310p.ops.vocab_parallel_embedding import AscendUnquantizedEmbeddingMethod310

            logger.debug(
                "Select AscendUnquantizedEmbeddingMethod310 for %s (layer=%s)", prefix, "VocabParallelEmbedding"
            )
            return AscendUnquantizedEmbeddingMethod310()

        logger.debug("No quant method matched for %s, falling back to base", prefix)
        return super().get_quant_method(layer, prefix)

    @staticmethod
    def validate_qwen4exp_w8a8_index(
        weight_index: Any,
        geometry: Any,
    ) -> Any:
        """Validate a Qwen4Exp W8A8 checkpoint index before streaming weights.

        Delegates to :func:`vllm_ascend.models.qwen4_exp.weight_mapping.
        validate_expert_weight_map`, which drives the expected per-expert tensor
        set from the checkpoint-manifest ``geometry`` and rejects a missing,
        extra, duplicate, wrong-shape or wrong-dtype tensor with an actionable
        error (all subclasses of ``WeightMappingError``). ``weight_index`` is a
        safetensors-style ``name -> {"dtype", "shape"}`` mapping (or a sequence of
        such pairs); ``geometry`` is the manifest geometry block (or the parsed
        manifest / its path).

        This is imported lazily so the mapping module (host-side, torch-only) is
        only pulled in when a W8A8 Qwen4Exp checkpoint is actually loaded.
        """
        from vllm_ascend.models.qwen4_exp.weight_mapping import (
            geometry_from_manifest,
            validate_expert_weight_map,
        )

        geometry_keys = ("num_hidden_layers", "num_experts", "moe_intermediate_size", "hidden_size")
        needs_extraction = isinstance(geometry, (str, Path)) or (
            isinstance(geometry, Mapping) and not all(key in geometry for key in geometry_keys)
        )
        if needs_extraction:
            geometry = geometry_from_manifest(geometry)
        return validate_expert_weight_map(weight_index, geometry)
