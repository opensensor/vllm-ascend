# Standard
import functools
import json
import os
import threading
from dataclasses import dataclass
from typing import Any

import regex as re
import torch

# Third Party
from mooncake.store import ReplicateConfig  # type: ignore
from vllm.config import ParallelConfig
from vllm.logger import logger
from vllm.utils.network_utils import get_ip

from vllm_ascend import envs
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend.base import (
    QOS_VALUE_MAX,
    QOS_VALUE_MIN,
    Backend,
    BatchResultShapeError,
    parse_qos_from_extra_config,
    require_aligned_batch_results,
    set_scheduler_device,
)
from vllm_ascend.distributed.kv_transfer.utils.mooncake_transfer_engine import global_te
from vllm_ascend.distributed.parallel_state import get_global_rank

DEFAULT_GLOBAL_SEGMENT_SIZE = 1073741824  # 1.0 GiB
DEFAULT_LOCAL_BUFFER_SIZE = 1073741824  # 1.0 GiB
DEFAULT_TENANT_ID = "default"
MOONCAKE_LAYERWISE_CLIENT_METHODS = (
    "batch_put_session_start",
    "batch_put_from_multi_buffer_ranges",
    "batch_put_session_end",
    "batch_put_session_revoke",
    "batch_get_session_start",
    "batch_get_into_multi_buffer_ranges",
    "batch_get_session_end",
)
_KVPOOL_RANGE_DEBUG_PREFIX = "[KVPOOL_RANGE_DEBUG]"


def _emit_whole_key_debug_event(direction: str, key_count: int) -> None:
    try:
        if not envs.VLLM_ASCEND_KVPOOL_RANGE_DEBUG:
            return
        payload = {
            "event": "whole_key",
            "direction": direction,
            "key_count": int(key_count),
        }
        logger.info("%s %s", _KVPOOL_RANGE_DEBUG_PREFIX, json.dumps(payload, separators=(",", ":")))
    except Exception:
        pass


@functools.lru_cache(maxsize=1)
def _mooncake_setup_supports_ssd_offload() -> bool:
    """True when installed Mooncake exposes SSD kwargs on setup() (v0.3.11+)."""
    from mooncake.store import MooncakeDistributedStore  # type: ignore

    setup = MooncakeDistributedStore.setup
    try:
        import inspect

        sig = inspect.signature(setup)
        return "enable_ssd_offload" in sig.parameters
    except (TypeError, ValueError):
        # pybind11 overloaded bindings often reject inspect.signature
        doc = setup.__doc__ or ""
        return "enable_ssd_offload" in doc


def _ssd_setup_kwargs(config: "MooncakeStoreConfig") -> dict[str, object]:
    """Keyword args for store.setup(); empty on old Mooncake or when SSD is off."""
    if not config.enable_ssd_offload:
        return {}
    if not _mooncake_setup_supports_ssd_offload():
        raise RuntimeError(
            "mooncake.json has enable_ssd_offload=true, but the installed "
            "Mooncake does not support enable_ssd_offload/ssd_offload_path in "
            "MooncakeDistributedStore.setup(). Upgrade Mooncake to v0.3.11 or "
            "later (see Mooncake ssd-offload.md Step 3A), or set "
            "enable_ssd_offload to false."
        )
    return {
        "enable_ssd_offload": config.enable_ssd_offload,
        "ssd_offload_path": config.ssd_offload_path,
    }


def _validate_store_qos() -> None:
    """Validate the store QoS configured via ASCEND_GLOBAL_RESOURCE_CONFIG.

    KV pool transfers go through the Mooncake store, whose HIXL QoS comes from
    the ``store.comm_resource_config.qos`` field. The top-level
    ``comm_resource_config.qos`` belongs to other HIXL users and is not
    validated here. Only integers in [QOS_VALUE_MIN, QOS_VALUE_MAX] are
    supported; an invalid value fails fast with a clear error instead of an
    obscure failure inside the transfer engine.
    """
    config_str = os.getenv("ASCEND_GLOBAL_RESOURCE_CONFIG")
    if not config_str:
        return
    try:
        config = json.loads(config_str)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"ASCEND_GLOBAL_RESOURCE_CONFIG is not valid JSON: {e}. "
            'Expected e.g. \'{"store": {"comm_resource_config": {"qos": 3}}}\'.'
        ) from e
    if not isinstance(config, dict):
        return
    store_config = config.get("store")
    if not isinstance(store_config, dict):
        return
    comm_resource_config = store_config.get("comm_resource_config")
    if not isinstance(comm_resource_config, dict) or "qos" not in comm_resource_config:
        return
    qos = comm_resource_config["qos"]
    if isinstance(qos, bool) or not isinstance(qos, int) or not (QOS_VALUE_MIN <= qos <= QOS_VALUE_MAX):
        raise ValueError(
            f"Invalid store QoS {qos!r} in ASCEND_GLOBAL_RESOURCE_CONFIG "
            f"(store.comm_resource_config.qos): QoS must be an integer in "
            f"[{QOS_VALUE_MIN}, {QOS_VALUE_MAX}]."
        )


def _inject_store_qos(extra_config: dict[str, Any] | None) -> None:
    """Inject the QoS from kv_connector_extra_config into the
    ``store.comm_resource_config.qos`` field of ASCEND_GLOBAL_RESOURCE_CONFIG.

    The QoS is parsed from the connector's extra_config passed by the pool
    worker; the call is a no-op when no qos is configured. Merges into the
    existing config so other HIXL fields (protocol_desc, listen_port, ...)
    are preserved. An explicit extra-config value overrides a qos already
    present in the environment.
    """
    qos = parse_qos_from_extra_config(extra_config)
    if qos is None:
        return
    config_str = os.getenv("ASCEND_GLOBAL_RESOURCE_CONFIG")
    config: dict[str, Any] = {}
    if config_str is not None and config_str.strip():
        try:
            config = json.loads(config_str)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"ASCEND_GLOBAL_RESOURCE_CONFIG is not valid JSON: {e}. "
                'Expected e.g. \'{"store": {"comm_resource_config": {"qos": 3}}}\'.'
            ) from e
        if not isinstance(config, dict):
            raise ValueError(
                "ASCEND_GLOBAL_RESOURCE_CONFIG must be a JSON object when qos_priority "
                "is set in kv_connector_extra_config."
            )
    store_config = config.setdefault("store", {})
    if not isinstance(store_config, dict):
        raise ValueError("The 'store' field of ASCEND_GLOBAL_RESOURCE_CONFIG must be a JSON object.")
    comm_resource_config = store_config.setdefault("comm_resource_config", {})
    if not isinstance(comm_resource_config, dict):
        raise ValueError(
            "The 'store.comm_resource_config' field of ASCEND_GLOBAL_RESOURCE_CONFIG must be a JSON object."
        )
    existing_qos = comm_resource_config.get("qos")
    if existing_qos is not None and existing_qos != qos:
        logger.warning(
            "Overriding store.comm_resource_config.qos=%s from ASCEND_GLOBAL_RESOURCE_CONFIG "
            "with qos=%s from kv_connector_extra_config.",
            existing_qos,
            qos,
        )
    comm_resource_config["qos"] = qos
    os.environ["ASCEND_GLOBAL_RESOURCE_CONFIG"] = json.dumps(config)
    logger.info(
        "Injected store.comm_resource_config.qos=%d from kv_connector_extra_config into ASCEND_GLOBAL_RESOURCE_CONFIG.",
        qos,
    )


class MooncakeBackend(Backend):
    def __init__(
        self,
        parallel_config: ParallelConfig,
        lazy_init: bool = False,
        contribute_memory: bool = True,
        extra_config: dict[str, Any] | None = None,
    ):
        self.parallel_config = parallel_config
        self.config = MooncakeStoreConfig.load_from_env()
        if self.config.protocol != "ascend":
            raise NotImplementedError(f"MooncakeBackend does not support protocol {self.config.protocol!r}.")
        _inject_store_qos(extra_config)
        _validate_store_qos()
        self.device_id = torch.npu.current_device()

        self.store: Any | None = None
        self.local_seg: str | None = None
        self._use_fabric_mem = os.getenv("ASCEND_ENABLE_USE_FABRIC_MEM", "0") == "1"
        # ASCEND_GLOBAL_RESOURCE_CONFIG: dual-protocol / RoCE Store path where the store
        # operates independently of the global transfer engine; setup goes through store
        # and buffers are registered via store.register_buffer() instead of global_te.
        self._use_store_independent_te = bool(os.getenv("ASCEND_GLOBAL_RESOURCE_CONFIG")) and not self._use_fabric_mem
        self._lazy_init = lazy_init and self._use_fabric_mem
        self._contribute_memory = contribute_memory
        self._store_initialized = False
        self._store_init_lock = threading.Lock()

        if not self._lazy_init:
            self.store = self._setup_store()
            self._store_initialized = True

    def ensure_initialized(self):
        if self._store_initialized:
            return

        with self._store_init_lock:
            if self._store_initialized:
                return

            logger.info("Initializing Mooncake store. metadata_server=%s", self.config.metadata_server)
            self.store = self._setup_store()
            self._store_initialized = True

    def _setup_store(self):
        try:
            from mooncake.store import MooncakeDistributedStore  # type: ignore
        except ImportError as e:
            raise ImportError(
                "Please install mooncake by following the instructions at "
                "https://github.com/kvcache-ai/Mooncake/blob/main/doc/en/build.md "  # noqa: E501
                "to run vLLM with MooncakeConnector."
            ) from e

        self.set_device()
        store = MooncakeDistributedStore()
        local_hostname = get_ip()
        ssd_kwargs = _ssd_setup_kwargs(self.config)
        # Each rank that contributes memory to the pool uses its own SSD
        # directory to avoid bucket file collisions. Key by the globally unique
        # rank so that DP/TP/PP/CP replicas never share a directory (dense and
        # MoE alike); only ranks that contribute memory need an offload dir.
        if ssd_kwargs and ssd_kwargs.get("ssd_offload_path") and self._contribute_memory:
            global_rank = get_global_rank(self.parallel_config)
            rank_path = os.path.join(str(ssd_kwargs["ssd_offload_path"]), f"rank_{global_rank}")
            try:
                os.makedirs(rank_path, exist_ok=True)
            except OSError as e:
                raise RuntimeError(f"Failed to create per-rank SSD offload directory: {rank_path!r} ({e})")
            ssd_kwargs["ssd_offload_path"] = rank_path
        setup_kwargs = dict(ssd_kwargs)
        if self.config.tenant_id != DEFAULT_TENANT_ID:
            setup_kwargs["tenant_id"] = self.config.tenant_id
        # ASCEND_ENABLE_USE_FABRIC_MEM: Enable unified memory address direct transmission scheme
        # and only can be used for 800 I/T A3 series.
        # Required supporting hardware versions are as follows:
        # ASCEND_GLOBAL_RESOURCE_CONFIG takes the same store-independent-TE setup path as fabric-mem.
        if not self._use_fabric_mem and not self._use_store_independent_te:
            transfer_engine = global_te.get_transfer_engine(local_hostname, device_name=None)
            self.local_seg = local_hostname + ":" + str(transfer_engine.get_rpc_port())
            ret = store.setup(
                local_hostname=self.local_seg,
                metadata_server=self.config.metadata_server,
                global_segment_size=self.config.global_segment_size if self._contribute_memory else 0,
                local_buffer_size=self.config.local_buffer_size if self._contribute_memory else 0,
                protocol=self.config.protocol,
                rdma_devices=self.config.device_name,
                master_server_addr=self.config.master_server_address,
                engine=transfer_engine.get_engine(),
                **setup_kwargs,
            )
        else:
            self.local_seg = local_hostname
            ret = store.setup(
                local_hostname=self.local_seg,
                metadata_server=self.config.metadata_server,
                global_segment_size=self.config.global_segment_size if self._contribute_memory else 0,
                local_buffer_size=0,
                protocol=self.config.protocol,
                rdma_devices=self.config.device_name,
                master_server_addr=self.config.master_server_address,
                **setup_kwargs,
            )

        if ret != 0:
            msg = "Initialize mooncake failed."
            logger.error(
                "Initialize mooncake failed. ret=%d, metadata_server=%s. Check mooncake config and network.",
                ret,
                self.config.metadata_server,
            )
            raise RuntimeError(msg)
        if ssd_kwargs:
            logger.info(
                "Mooncake SSD offload enabled (Mode A): path=%s",
                self.config.ssd_offload_path,
            )
        logger.info("Mooncake tenant_id=%s", self.config.tenant_id)
        return store

    @classmethod
    def create_scheduler_client(cls, parallel_config: ParallelConfig):
        set_scheduler_device(parallel_config)
        return cls(parallel_config, contribute_memory=False)

    def set_device(self):
        torch.npu.set_device(self.device_id)

    def register_buffer(self, ptrs: list[int], lengths: list[int]):
        if self._use_store_independent_te:
            assert self.store is not None
            for ptr, length in zip(ptrs, lengths):
                ret = self.store.register_buffer(ptr, length)
                if ret != 0:
                    logger.error(
                        "Failed to register buffer via store: ptr=%s, length=%s, ret=%s",
                        ptr,
                        length,
                        ret,
                    )
        elif not self._use_fabric_mem:
            local_hostname = get_ip()
            global_te.get_transfer_engine(local_hostname, device_name=None)
            global_te.register_buffer(ptrs, lengths)

    def exists(self, keys: list[str]) -> list[int]:
        if self._lazy_init and not self._store_initialized:
            logger.debug(
                "MooncakeBackend.exists called before store initialization; treating %d keys as missing.",
                len(keys),
            )
            return [0] * len(keys)
        assert self.store is not None
        return self.store.batch_is_exist(keys)

    def batch_is_readable(self, keys: list[str]) -> list[bool]:
        """Map committed Mooncake objects to the common readability contract."""
        states = require_aligned_batch_results("batch_is_exist", keys, self.batch_is_exist(keys))
        if any(state not in (0, 1) for state in states):
            raise BatchResultShapeError("batch_is_exist returned states other than 0 or 1")
        return [state == 1 for state in states]

    def _build_replicate_config(self) -> ReplicateConfig:
        config = ReplicateConfig()
        if self.config.preferred_segment:
            config.preferred_segment = self.local_seg
        config.prefer_alloc_in_same_node = self.config.prefer_alloc_in_same_node
        return config

    def validate_layerwise_support(self) -> None:
        """Fail before serving traffic when the installed client is too old."""
        self.ensure_initialized()
        missing_methods = [
            method_name
            for method_name in MOONCAKE_LAYERWISE_CLIENT_METHODS
            if self.store is None or not callable(getattr(self.store, method_name, None))
        ]
        if missing_methods:
            raise RuntimeError(
                "Mooncake layerwise requires a client containing the session/range APIs "
                "from Mooncake PR #2881. Missing methods: " + ", ".join(missing_methods)
            )

    def _call_layerwise_batch(self, operation: str, keys: list[str], *args: object) -> list[int]:
        self.ensure_initialized()
        if self.store is None:
            raise RuntimeError(f"Mooncake store is unavailable for {operation}")
        method = getattr(self.store, operation, None)
        if not callable(method):
            raise RuntimeError(f"Mooncake client does not support {operation}")
        return require_aligned_batch_results(operation, keys, method(*args))

    def batch_put_start(self, keys: list[str], sizes: list[int]) -> list[int]:
        return self._call_layerwise_batch(
            "batch_put_session_start",
            keys,
            keys,
            sizes,
            self._build_replicate_config(),
        )

    def batch_copy_put(
        self,
        keys: list[str],
        all_buffers: list[list[int]],
        all_sizes: list[list[int]],
        all_dst_offsets: list[list[int]],
    ) -> list[int]:
        return self._call_layerwise_batch(
            "batch_put_from_multi_buffer_ranges",
            keys,
            keys,
            all_buffers,
            all_sizes,
            all_dst_offsets,
        )

    def batch_commit(self, keys: list[str]) -> list[int]:
        return self._call_layerwise_batch("batch_put_session_end", keys, keys)

    def batch_revoke(self, keys: list[str]) -> list[int]:
        return self._call_layerwise_batch("batch_put_session_revoke", keys, keys)

    def batch_get_start(self, keys: list[str]) -> list[int]:
        return self._call_layerwise_batch("batch_get_session_start", keys, keys)

    def batch_copy_get(
        self,
        keys: list[str],
        all_buffers: list[list[int]],
        all_sizes: list[list[int]],
        all_src_offsets: list[list[int]],
    ) -> list[int]:
        return self._call_layerwise_batch(
            "batch_get_into_multi_buffer_ranges",
            keys,
            keys,
            all_buffers,
            all_sizes,
            all_src_offsets,
        )

    def batch_get_end(self, keys: list[str]) -> int:
        self.ensure_initialized()
        if self.store is None:
            raise RuntimeError("Mooncake store is unavailable for batch_get_session_end")
        method = getattr(self.store, "batch_get_session_end", None)
        if not callable(method):
            raise RuntimeError("Mooncake client does not support batch_get_session_end")
        return int(method(keys))

    def put(self, keys: list[str], addrs: list[list[int]], sizes: list[list[int]]):
        self.ensure_initialized()
        assert self.store is not None
        try:
            config = self._build_replicate_config()
            _emit_whole_key_debug_event("put", len(keys))
            res = self.store.batch_put_from_multi_buffers(keys, addrs, sizes, config)
            failed_codes = [int(value) for value in res if value < 0]
            failed_count = len(failed_codes)
            if failed_count:
                error_codes = sorted(set(failed_codes))
                logger.error(
                    "Failed to put %d keys out of %d. error_codes=%s. Check memory and store capacity.",
                    failed_count,
                    len(keys),
                    error_codes,
                )
                logger.debug("Failed to put key details. keys=%s, result=%s", keys, res)
                if self._lazy_init:
                    logger.warning("First DSV4(compress) request failure is expected. This is normal behavior.")
        except Exception as e:
            logger.error(
                "Failed to put %d keys out of %d. type=%s, error=%s. Check store state and memory.",
                len(keys),
                len(keys),
                type(e).__name__,
                e,
            )
            logger.debug("Failed to put key details. keys=%s", keys)
            if self._lazy_init:
                logger.warning("First DSV4(compress) request failure is expected. This is normal behavior.")

    def get(self, keys: list[str], addrs: list[list[int]], sizes: list[list[int]]):
        if self._lazy_init and not self._store_initialized:
            logger.error(
                "Failed to get %d keys out of %d. Store is not initialized; "
                "call put() first to trigger initialization.",
                len(keys),
                len(keys),
            )
            logger.debug("Failed to get key details. keys=%s", keys)
            return
        assert self.store is not None
        logger.debug(
            "MooncakeBackend.get enter keys=%d sample_keys=%s",
            len(keys),
            keys[:3],
        )
        try:
            _emit_whole_key_debug_event("get", len(keys))
            res = self.store.batch_get_into_multi_buffers(keys, addrs, sizes)
            res_list = list(res)
            failed_codes = [int(value) for value in res_list if value < 0]
            failed_count = len(failed_codes)
            error_codes = sorted(set(failed_codes))
            if failed_count:
                logger.error(
                    "Failed to get %d keys out of %d. error_codes=%s. Check key existence and memory state.",
                    failed_count,
                    len(keys),
                    error_codes,
                )
                logger.debug("Failed to get key details. keys=%s, result=%s", keys, res_list)
            for i, value in enumerate(res_list):
                if value > 0:
                    res_list[i] = 0
            return res_list
        except Exception as e:
            logger.error(
                "Failed to get %d keys out of %d. type=%s, error=%s. Check store state and network.",
                len(keys),
                len(keys),
                type(e).__name__,
                e,
            )
            logger.debug("Failed to get key details. keys=%s", keys)
            return None


@dataclass
class MooncakeStoreConfig:
    metadata_server: str
    global_segment_size: int | str
    local_buffer_size: int
    protocol: str
    device_name: str
    master_server_address: str
    preferred_segment: bool
    prefer_alloc_in_same_node: bool
    enable_ssd_offload: bool = False
    ssd_offload_path: str = ""
    tenant_id: str = DEFAULT_TENANT_ID

    def __post_init__(self) -> None:
        if not self.enable_ssd_offload:
            return
        if not self.ssd_offload_path:
            raise ValueError(
                "enable_ssd_offload is true but ssd_offload_path is empty. Set ssd_offload_path in mooncake.json."
            )
        if not os.path.isabs(self.ssd_offload_path):
            raise ValueError(f"ssd_offload_path must be an absolute path, got: {self.ssd_offload_path!r}")

    @staticmethod
    def from_file(file_path: str) -> "MooncakeStoreConfig":
        with open(file_path) as file:
            config = json.load(file)
        master_server_address = os.getenv("MOONCAKE_MASTER", None)
        global_segment_size_env = os.getenv("MOONCAKE_GLOBAL_SEGMENT_SIZE", None)
        return MooncakeStoreConfig(
            metadata_server=config.get("metadata_server"),
            global_segment_size=_parse_global_segment_size(
                global_segment_size_env
                if global_segment_size_env is not None
                else config.get("global_segment_size", DEFAULT_GLOBAL_SEGMENT_SIZE)
            ),
            local_buffer_size=_parse_global_segment_size(config.get("local_buffer_size", DEFAULT_LOCAL_BUFFER_SIZE)),
            protocol=config.get("protocol", "ascend"),
            device_name=config.get("device_name", ""),
            master_server_address=master_server_address
            if master_server_address is not None
            else config.get("master_server_address"),
            preferred_segment=config.get("preferred_segment", False),
            prefer_alloc_in_same_node=config.get("prefer_alloc_in_same_node", True),
            enable_ssd_offload=bool(config.get("enable_ssd_offload", False)),
            ssd_offload_path=config.get("ssd_offload_path", ""),
            tenant_id=_normalize_tenant_id(config.get("tenant_id", DEFAULT_TENANT_ID)),
        )

    @staticmethod
    def load_from_env() -> "MooncakeStoreConfig":
        config_path = os.getenv("MOONCAKE_CONFIG_PATH")
        if not config_path:
            raise ValueError("The environment variable 'MOONCAKE_CONFIG_PATH' is not set.")
        return MooncakeStoreConfig.from_file(config_path)


def _normalize_tenant_id(value: Any) -> str:
    if value is None:
        return DEFAULT_TENANT_ID
    if not isinstance(value, str):
        raise TypeError(f"tenant_id must be a string or null, got {type(value).__name__}: {value!r}")
    tenant_id = value.strip()
    return tenant_id if tenant_id else DEFAULT_TENANT_ID


def _parse_global_segment_size(value) -> int:
    """
    Parse storage size strings with support for units: GB, MB, KB, B

    Args:
        value: Input value (int, str, or other convertible types)

    Returns:
        int: Size in bytes

    Raises:
        ValueError: For invalid format, missing number, or negative values
        TypeError: For unsupported input types
    """

    if isinstance(value, int):
        return value
    elif not isinstance(value, str):
        try:
            return int(value)
        except (TypeError, ValueError) as e:
            raise TypeError(f"Unsupported type for global_segment_size: {type(value)}") from e

    cleaned_input = value.strip().lower()
    if not cleaned_input:
        raise ValueError("global segment size cannot be empty.")

    UNIT_MULTIPLIERS = {
        "gb": 1024**3,  # 1 GB = 1024^3 bytes
        "mb": 1024**2,  # 1 MB = 1024^2 bytes
        "kb": 1024,  # 1 KB = 1024 bytes
        "b": 1,  # 1 B = 1 byte
    }
    pattern = r"^\s*([\d.]+)\s*(gb|mb|kb|b)?\s*$"
    match = re.match(pattern, cleaned_input)

    if not match:
        raise ValueError(f"Invalid format: '{value}'")

    number_str = match.group(1)
    unit = match.group(2) or "b"

    multiplier = UNIT_MULTIPLIERS[unit]
    return _convert_to_bytes(number_str, multiplier, value)


def _convert_to_bytes(number_str: str, multiplier: int, original_input: str) -> int:
    """
    Convert numeric string to byte count

    Args:
        number_str: Numeric portion of input
        multiplier: Unit conversion factor
        original_input: Original input string (for error messages)

    Returns:
        int: Byte count

    Raises:
        ValueError: For invalid numbers or negative results
    """
    try:
        numeric_value = float(number_str)
    except ValueError:
        raise ValueError(f"Invalid numeric value '{number_str}' in: '{original_input}'")
    # Calculate byte count
    try:
        byte_count = int(numeric_value * multiplier)
    except OverflowError:
        raise ValueError(f"Storage size too large: '{original_input}'")
    return byte_count
