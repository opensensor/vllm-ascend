import hashlib,json,re,sys,time,urllib.request,uuid
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
from tools.glm_perf.resident_control import Control
client=ResidentClient('http://127.0.0.1:8001',timeout=900)
records=[];switches=[]
report=root/'night-speed-20261008/qsa-v996-paired-serving.json'
assert not report.exists()
def save(complete=False):report.write_text(json.dumps(dict(complete=complete,scope='matched v991/v996 serving comparison; cold prefix state deliberately cleared; synthetic token IDs, no model quality evaluation',records=records,switches=switches),indent=2)+'\n')
def idle():
 with urllib.request.urlopen(client.base_url+'/metrics',timeout=30) as response:metrics=response.read().decode()
 values=[float(v) for v in re.findall(r'^vllm:num_requests_(?:running|waiting)(?:\{[^\n]*\})?\s+([0-9.eE+-]+)$',metrics,re.M)]
 assert values and not any(values),'User request active; defer'
def stream(tokens,output,nonce):
 payload=dict(model='glm53-flash-selective-w3',prompt=[101+nonce]+[43]*(tokens-2)+[201+nonce],max_tokens=output,temperature=0,ignore_eos=True,stream=True,stream_options=dict(include_usage=True))
 req=urllib.request.Request(client.base_url+'/v1/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 start=time.monotonic();first=None;last=None;usage=None;pieces=[];done=False
 with urllib.request.urlopen(req,timeout=1200) as response:
  for line in response:
   if not line.startswith(b'data:'):continue
   value=line[5:].strip()
   if value==b'[DONE]':done=True;break
   event=json.loads(value);assert 'error' not in event,event
   if event.get('usage'):usage=event['usage']
   for choice in event.get('choices',[]):
    if choice.get('text'):
     now=time.monotonic();first=now if first is None else first;last=now;pieces.append(choice['text'])
 end=time.monotonic();assert done and usage and first is not None
 assert usage['prompt_tokens']==tokens and usage['completion_tokens']==output
 return dict(prompt_tokens=tokens,completion_tokens=output,ttft_s=first-start,total_s=end-start,generation_tok_s=(output-1)/(end-first) if output>1 else None,visible_generation_tok_s=(output-1)/(last-first) if output>1 and last>first else None,text=''.join(pieces))
for version in (991,996):
 idle();source=(root/f'night-speed-20261008/qsa-v{version}-candidate.py').read_text()
 before=client._acknowledged_rpc('resident_status',matches=client._status_matches)
 rows=client.switch(Control(uuid.uuid4().hex,candidate='qsa_matched_'+str(version),source=source));client.resume()
 assert len(rows)==4 and all(not r['graphs_dirty'] and not r['native_failed'] for r in rows)
 assert sorted((r['pid'],r['weight_storage_digest']) for r in rows)==sorted((r['pid'],r['weight_storage_digest']) for r in before)
 switches.append(dict(version=version,source_sha256=hashlib.sha256(source.encode()).hexdigest(),ranks=len(rows)))
 for tokens,output,nonce in ((640,1,4),(1280,1,5),(6400,1,6),(1280,1,5),(128,64,20),(128,64,21)):
  idle();assert client.request('/pause?mode=wait&clear_cache=true')['status']=='paused';client.resume()
  row=stream(tokens,output,nonce);row['version']=version;records.append(row);save();print(json.dumps(row),flush=True)
idle();smoke=client.request('/v1/completions',dict(model='glm53-flash-selective-w3',prompt='Explain why plants need sunlight in three short sentences.',max_tokens=80,temperature=0))
assert smoke.get('choices') and smoke['choices'][0].get('text')
status=client._acknowledged_rpc('resident_status',matches=client._status_matches)
assert len(status)==4 and all(not r['graphs_dirty'] and not r['native_failed'] and not r['reconstruction']['fallback_dispatches'] for r in status)
save(True)
(root/'night-speed-20261008/qsa-v996-paired-final-status.json').write_text(json.dumps(dict(smoke=smoke,status=status,paused=client.request('/is_paused',method='GET')),indent=2)+'\n')
print('Matched cold prefill/C1 requests completed and candidate healthy',flush=True)
