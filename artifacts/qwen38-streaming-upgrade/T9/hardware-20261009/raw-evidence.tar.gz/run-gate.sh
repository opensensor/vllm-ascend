#!/usr/bin/env bash
set -eo pipefail
source /srv/ai/src/qwen38-w4-hardware-20260927/qwen38-w4-hardware-env.sh
export PYTHONPATH=/srv/ai/src/qwen38-streaming-gate-20261009:/srv/ai/src/vllm-opensensor
export ASCEND_RT_VISIBLE_DEVICES=0
export ASCEND_CUSTOM_OPP_PATH=/srv/ai/src/qwen38-prefill-batch256-coherent-opp-20261005/vendors/qwen38_batch256_coherent_transformer:/srv/ai/src/qwen38-streaming-gate-20261009/vllm_ascend/_cann_ops_custom/vendors/custom_transformer:/srv/ai/src/native-int4-w4a8.KiuhBN/opp-retained-good-20260928
export LD_LIBRARY_PATH=/srv/ai/src/qwen38-prefill-batch256-coherent-opp-20261005/vendors/qwen38_batch256_coherent_transformer/op_api/lib:/srv/ai/src/qwen38-streaming-gate-20261009/vllm_ascend/_cann_ops_custom/vendors/custom_transformer/op_api/lib:/srv/ai/src/native-int4-w4a8.KiuhBN/opp-retained-good-20260928/op_api/lib:$LD_LIBRARY_PATH
exec taskset -c 32-39 /srv/ai/venvs/fork028/bin/python "$@"
