from __future__ import annotations

import importlib
import math
import os
import threading
import time
from collections.abc import Callable, Generator, Sequence
from contextlib import suppress
from typing import Any

import numpy as np
import torch
import vllm.envs as envs
from vllm.config import VllmConfig
from vllm.distributed import (
    get_pcp_group,
    get_pp_group,
    get_tensor_model_parallel_rank,
    get_tensor_model_parallel_world_size,
)
from vllm.distributed.kv_events import BlockStored
from vllm.logger import logger
from vllm.v1.core.kv_cache_utils import BlockHash, maybe_convert_block_hash
from vllm.v1.kv_cache_interface import (
    KVCacheConfig,
    MambaSpec,
    UniformTypeKVCacheSpecs,
)

from vllm_ascend.ascend_config import KVPPConfig
from vllm_ascend.core.kv_cache_placement import map_kvpp_layers_to_owners
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.attention_fence import (
    get_attention_compute_start_gate,
    reset_attention_compute_start_gate,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend import (
    backend_map,
    get_layerwise_data_plane,
    get_layerwise_protocol,
    validate_layerwise_runtime,
    validate_layerwise_topology,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend.base import (
    require_aligned_batch_results,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.backend.session_tracker import (
    LayerwiseSessionTracker,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.coordinator import AscendStoreCoordinator
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.kv_transfer import (
    KVCacheStoreBatch,
    KVCacheStoreKeyLayerRecvingThread,
    KVCacheStoreKeyLayerSendingThread,
    KVCacheStoreLayerRecvingThread,
    KVCacheStoreLayerSendingThread,
    KVCacheStoreRecvingThread,
    KVCacheStoreSendingThread,
    KVTransferThread,
    LayerBatchBuilder,
    _circular_shift,
    record_failed_blocks,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.layerwise_cache_layout import (
    LayerwiseReuseLayout,
    build_layerwise_cache_layout,
    build_layerwise_reuse_layout,
    get_layerwise_kv_cache_specs,
    get_layerwise_physical_layer_index,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.metadata import (
    AscendConnectorMetadata,
    AscendStoreKVConnectorWorkerMetadata,
    ChunkedTokenDatabase,
    KeyMetadata,
    LayerBlockRange,
    LayerLoadTask,
    LayerMultiBlockReqMeta,
    LayerTransferTask,
    ReqMeta,
    block_hash_to_str,
    get_block_hashes,
    get_group_block_size,
    get_group_cache_family,
    get_partial_block_index,
    infer_cache_transfer_granularity,
    infer_cacheable_group_ids,
    infer_dcp_mismatch_info,
    infer_group_block_sizes,
    infer_group_cache_families,
    infer_tp_mismatch_info,
    is_kv_save_role,
    masked_block_runs,
    uses_hybrid_kv_cache,
)
from vllm_ascend.distributed.kv_transfer.kv_pool.ascend_store.metrics import (
    AscendStoreKVConnectorStats,
)
from vllm_ascend.distributed.utils import (
    get_decode_context_model_parallel_rank,
    get_decode_context_model_parallel_world_size,
)

# PERF-TUNE switch: defer the last layer's save drain out of the forward
# critical path; the drain runs at the start of the next step's start_load_kv.
# Opt-in (default off): the synchronous inline drain is the long-standing
# contract that layerwise tests (e.g. test_mooncake_pipeline) and downstream
# readers rely on, and deferring widens the window in which a subsequent
# request can observe a partially published prefix.
_LW_DEFER_LAST_SAVE = os.environ.get("VLLM_ASCEND_LW_DEFER_LAST_SAVE", "0") == "1"

# Read lease TTL (ms) for the layerwise load path. batch_add_lease acquires a
# read lease before batch_copy(G2L); the lease must cover the asynchronous
# multi-layer load time.
LAYERWISE_READ_LEASE_TTL_MS = 5 * 60 * 1000

# A partial snapshot can be visible to readers before the rank responsible for
# saving it has published its final layer.
MEMCACHE_UNMATCHED_STATE = -3101
PARTIAL_LEASE_RETRY_COUNT = 10
PARTIAL_LEASE_RETRY_INTERVAL_S = 0.001
SAVE_BATCH_FAILURE_POLL_INTERVAL_S = 1.0


class KVPoolWorker:
    # The main class for the cache engine.

    def __init__(
        self,
        vllm_config: VllmConfig,
        use_layerwise: bool,
        kv_cache_config: KVCacheConfig | None = None,
        memcache_dp_init_barrier: bool = True,
    ):
        model_config = vllm_config.model_config
        parallel_config = vllm_config.parallel_config
        extra_config = vllm_config.kv_transfer_config.kv_connector_extra_config
        self.vllm_config = vllm_config
        self.use_kvpp = KVPPConfig.from_vllm_config(vllm_config).size > 1
        self.kv_cache_config = kv_cache_config
        hf_text_config = getattr(model_config, "hf_text_config", None)
        hf_config = getattr(model_config, "hf_config", hf_text_config)
        self.hf_config = hf_text_config or hf_config
        self.compress_ratios = getattr(hf_text_config, "compress_ratios", None)
        self.max_model_len = model_config.max_model_len
        if self.compress_ratios is None:
            self.compress_ratios = getattr(hf_config, "compress_ratios", None)
        self.use_compress = self.compress_ratios is not None
        self.dp_rank = parallel_config.data_parallel_rank

        self._init_parallelism_info(model_config, parallel_config)
        self._init_kv_transfer_config(vllm_config, extra_config, use_layerwise, kv_cache_config)
        self._init_key_head_config(model_config, parallel_config)
        validate_layerwise_runtime(
            self.layerwise_protocol,
            use_hybrid=self.block_key_hybrid,
            has_recurrent_state=self.use_mamba,
            tp_mismatch=self.use_block_key_layerwise and self.tp_mismatch,
        )
        self._init_metadata(model_config, vllm_config, extra_config)
        self._init_backend(parallel_config, extra_config, memcache_dp_init_barrier)
        self._init_kv_events(vllm_config)
        self._init_state_vars()
        self._init_layerwise_config()
        self._kv_stats = AscendStoreKVConnectorStats()
        self._kv_stats_lock = threading.Lock()

    def _init_parallelism_info(self, model_config, parallel_config) -> None:
        self.local_rank = envs.LOCAL_RANK

        self.use_mla = False
        if hasattr(model_config, "use_mla") and isinstance(model_config.use_mla, bool) and model_config.use_mla:
            self.use_mla = True
        self.use_sparse = hasattr(model_config.hf_text_config, "index_topk")

        self.tp_rank = get_tensor_model_parallel_rank()
        self.tp_size = get_tensor_model_parallel_world_size()
        self.pp_size = parallel_config.pipeline_parallel_size
        self.pp_rank = get_pp_group().rank_in_group if self.pp_size > 1 else 0

        self.pcp_size = get_pcp_group().world_size
        self.pcp_rank = get_pcp_group().rank_in_group if self.pcp_size > 1 else 0
        self.kvpp_rank = self.pcp_rank * self.tp_size + self.tp_rank
        self.dcp_size = get_decode_context_model_parallel_world_size()
        self.dcp_rank = get_decode_context_model_parallel_rank() if self.dcp_size > 1 else 0
        self.model_name = model_config.model.split("/")[-1]

        # Global layer addressing for layerwise keys under pipeline parallel:
        # get_num_layers returns the per-stage layer count, so record the
        # stage's global layer offset and the model-wide total layers used by
        # the layerwise key space.
        self.pp_layer_offset = 0
        self.total_layers = None
        try:
            start, _ = model_config.get_layers_start_end_indices(parallel_config)
            self.pp_layer_offset = start
            self.total_layers = model_config.get_total_num_hidden_layers()
        except AttributeError:
            # Older vLLM without PP layer-index APIs: fall back to the
            # non-PP layout (offset 0, total == local).
            self.pp_layer_offset = 0
            self.total_layers = None
        except Exception as e:
            logger.warning(
                "Failed to get PP layer indices (pp_size=%d), falling back to local layer addressing: %s",
                self.pp_size,
                e,
            )
            self.pp_layer_offset = 0
            self.total_layers = None

    def _init_kv_transfer_config(self, vllm_config, extra_config, use_layerwise, kv_cache_config) -> None:
        self._extra_config = extra_config
        self.use_layerwise = use_layerwise
        self.kv_role = vllm_config.kv_transfer_config.kv_role
        self.load_async = extra_config.get("load_async", False)
        self._invalid_block_ids: set[int] = set()
        self._invalid_block_ids_lock = threading.Lock()
        self.consumer_is_to_put = extra_config.get("consumer_is_to_put", False)
        self.backend = extra_config.get("backend", "mooncake")
        self.backend_name = self.backend.lower()
        self.layerwise_protocol = get_layerwise_protocol(self.backend_name)
        self.layerwise_data_plane = get_layerwise_data_plane(self.layerwise_protocol)
        self.use_block_key_layerwise = self.use_layerwise and self.layerwise_data_plane == "block_key"
        self.use_layerwise_transfer = self.use_layerwise and self.layerwise_data_plane == "gva"
        validate_layerwise_topology(self.layerwise_protocol, vllm_config.parallel_config, self.use_layerwise)
        kv_cache_groups = kv_cache_config.kv_cache_groups if kv_cache_config is not None else None
        self.use_hybrid = uses_hybrid_kv_cache(vllm_config.scheduler_config, kv_cache_groups) or (
            self.use_block_key_layerwise and kv_cache_groups is not None and len(kv_cache_groups) > 1
        )
        self.block_key_hybrid = self.use_block_key_layerwise and self.use_hybrid
        self._attention_saved_layers: set[int] = set()
        self.use_mamba = self._uses_mamba_kv_cache(self.use_hybrid, kv_cache_config)
        speculative_config = getattr(vllm_config, "speculative_config", None)
        use_eagle_fn = getattr(speculative_config, "use_eagle", None)
        self.use_eagle = use_eagle_fn() is True if callable(use_eagle_fn) else False
        self.original_block_size = infer_group_block_sizes(vllm_config.cache_config.block_size, kv_cache_groups)
        self.cacheable_group_ids = infer_cacheable_group_ids(kv_cache_groups)
        cacheable_block_sizes = [self.original_block_size[i] for i in self.cacheable_group_ids]
        if self.use_layerwise and len(cacheable_block_sizes) != len(self.original_block_size):
            raise ValueError("AscendStore private KV state requires non-layerwise transfer")
        self.grouped_block_size = [block_size * self.dcp_size for block_size in self.original_block_size]
        requested_hash_block_size = vllm_config.cache_config.prefix_match_unit
        if not isinstance(requested_hash_block_size, int):
            requested_hash_block_size = None
        self.hash_block_size = (
            requested_hash_block_size if requested_hash_block_size is not None else min(cacheable_block_sizes)
        ) * self.dcp_size
        for group_id in self.cacheable_group_ids:
            group_block_size = self.grouped_block_size[group_id]
            assert group_block_size % self.hash_block_size == 0, "block_size must be divisible by hash_block_size"
        self.block_size = self.grouped_block_size[0]
        self.lcm_block_size = math.lcm(*(self.grouped_block_size[i] for i in self.cacheable_group_ids))
        self.num_kv_cache_groups = len(self.grouped_block_size)
        self.layerwise_keys = (
            self.layerwise_protocol.bind_layerwise_keys(
                vllm_config=vllm_config,
                kv_cache_config=kv_cache_config,
                model_name=self.model_name,
                use_hybrid=self.use_hybrid,
                grouped_block_size=self.grouped_block_size,
            )
            if self.use_layerwise and self.layerwise_protocol is not None
            else None
        )
        self.kv_cache_group_families = infer_group_cache_families(kv_cache_groups, self.compress_ratios, self.hf_config)
        self.group_uses_align_state = self._infer_group_uses_align_state()
        self.cache_transfer_granularity = infer_cache_transfer_granularity(
            self.grouped_block_size, self.lcm_block_size, self.cacheable_group_ids
        )
        self.h2d_stagger_us = int(extra_config.get("h2d_stagger_us", 0))
        self.layerwise_max_transfer_blocks = int(extra_config.get("layerwise_max_transfer_blocks", 0))
        self.layerwise_max_transfer_bytes = int(extra_config.get("layerwise_max_transfer_bytes", 0))

        logger.info(
            "use_hybrid: %s, use_mamba: %s, num_kv_cache_groups: %s, hash_block_size: %s, lcm_block_size: %s",
            self.use_hybrid,
            self.use_mamba,
            self.num_kv_cache_groups,
            self.hash_block_size,
            self.lcm_block_size,
        )

    def _init_key_head_config(self, model_config, parallel_config) -> None:
        self.current_layer = 0
        self.num_layers = model_config.get_num_layers(parallel_config)

        if self.use_mla:
            self.num_kv_head = 1
        else:
            self.num_kv_head = model_config.get_total_num_kv_heads()

        if self.num_kv_head < self.tp_size:
            self.put_step = self.tp_size // self.num_kv_head
            self.head_or_tp_rank = self.tp_rank // self.put_step
        else:
            self.head_or_tp_rank = self.tp_rank
            self.put_step = 1
        if self.use_kvpp:
            # Every owner saves all blocks of its layer shard, including its MTP replica.
            self.head_or_tp_rank = self.kvpp_rank
            self.put_step = 1
        self.my_key_index = (
            self.pcp_rank * self.dcp_size * (self.tp_size // self.put_step)
            + self.dcp_rank * (self.tp_size // self.put_step)
            + self.head_or_tp_rank
        )
        self.num_ranks_per_layer = self.pcp_size * self.dcp_size * (self.tp_size // self.put_step)

        extra_cfg = self._extra_config
        tp_mismatch_info = infer_tp_mismatch_info(
            self.kv_role,
            extra_cfg,
            self.tp_size,
            self.num_kv_head,
            self.use_mla,
        )
        self.peer_tp_size = tp_mismatch_info.peer_tp_size
        self.effective_tp_size = tp_mismatch_info.effective_tp_size
        self.tp_mismatch = tp_mismatch_info.enabled
        if self.tp_mismatch:
            if self.use_sparse:
                raise ValueError(
                    f"TP mismatch (local_tp={self.tp_size}, peer_tp={self.peer_tp_size}) "
                    "is not supported with sparse KV layouts (use_sparse=True). "
                    "Strided I/O requires uniform block_len across all cache entries."
                )
            if self.use_layerwise:
                raise ValueError(
                    f"TP mismatch (local_tp={self.tp_size}, peer_tp={self.peer_tp_size}) "
                    "is not supported with layerwise KV transfer (use_layerwise=True). "
                    "The layerwise threads do not implement TP-mismatch handling."
                )
            if self.use_hybrid:
                raise NotImplementedError(
                    f"TP mismatch (local_tp={self.tp_size}, peer_tp={self.peer_tp_size}) "
                    "is not yet supported with hybrid KV cache layouts (e.g. DSV4). "
                    "The strided I/O path assumes a single dense KV group."
                )
            self.local_heads_per_rank = tp_mismatch_info.local_heads_per_rank
            self.effective_heads_per_rank = tp_mismatch_info.effective_heads_per_rank
            self.num_sub_keys = tp_mismatch_info.num_sub_keys
            logger.info(
                "TP mismatch detected: local_tp=%d, peer_tp=%d, effective_tp=%d, "
                "local_heads_per_rank=%d, effective_heads_per_rank=%d, num_sub_keys=%d",
                self.tp_size,
                self.peer_tp_size,
                self.effective_tp_size,
                self.local_heads_per_rank,
                self.effective_heads_per_rank,
                self.num_sub_keys,
            )
        else:
            self.local_heads_per_rank = tp_mismatch_info.local_heads_per_rank
            self.effective_heads_per_rank = tp_mismatch_info.effective_heads_per_rank
            self.num_sub_keys = tp_mismatch_info.num_sub_keys

        # Layerwise GVA layout derives shard stride/offset from the LOCAL dcp
        # size and rank. In PD-disaggregation the producer and consumer are
        # separate worker groups; if they disagree on dcp/pcp size, both sides
        # compute different shard layouts for the SAME pool region and
        # silently corrupt the layerwise KV pool. Reject that configuration
        # explicitly instead of writing misaligned GVA addresses.
        if (
            self.use_layerwise
            and self.kv_role in ("kv_producer", "kv_consumer")
            and infer_dcp_mismatch_info(self.kv_role, self._extra_config, self.dcp_size, self.pcp_size)
        ):
            peer_role = "prefill" if self.kv_role == "kv_consumer" else "decode"
            raise ValueError(
                f"Decode-context-parallel mismatch in PD-disaggregation "
                f"(local dcp_size={self.dcp_size}, local pcp_size={self.pcp_size}, "
                f"peer role={peer_role}) is not supported with layerwise KV "
                f"transfer. Both the producer and consumer must use the same "
                f"dcp_size/pcp_size so the layerwise GVA shard layout is consistent."
            )

    def _init_metadata(self, model_config, vllm_config, extra_config) -> None:
        partitions = None
        if self.kv_role == "kv_consumer" and self.consumer_is_to_put:
            num_hidden_layers = model_config.hf_text_config.num_hidden_layers
            partition_list_str = extra_config.get("prefill_pp_layer_partition", None)
            prefill_pp_size = int(extra_config.get("prefill_pp_size", 1))

            if partition_list_str is not None:
                try:
                    partitions = [int(layer) for layer in partition_list_str.split(",")]
                except ValueError as err:
                    raise ValueError("Invalid partition string: {}".format(partition_list_str)) from err
                if len(partitions) != prefill_pp_size:
                    raise ValueError(f"{len(partitions)=} does not match {prefill_pp_size=}.")
                if sum(partitions) != num_hidden_layers:
                    raise ValueError(f"{sum(partitions)=} does not match {num_hidden_layers=}.")
            else:
                layers_per_partition = num_hidden_layers // prefill_pp_size
                partitions = [layers_per_partition for _ in range(prefill_pp_size)]

                if remaining_layers := num_hidden_layers % prefill_pp_size:
                    for i in range(2, remaining_layers + 2):
                        partitions[-i] += 1

        self.metadata: list[KeyMetadata] = []
        for group_id in range(self.num_kv_cache_groups):
            # the mamba kv_heads is not same with the full attention, can't share the cache data
            group_tp_rank = self.tp_rank if self.group_uses_align_state[group_id] else self.head_or_tp_rank
            self.metadata.append(
                KeyMetadata(
                    model_config.model.rstrip("/").split("/")[-1],
                    group_tp_rank,
                    self.dcp_rank,
                    self.pp_rank,
                    group_id,
                )
            )

        self.token_database = ChunkedTokenDatabase(
            self.metadata, self.grouped_block_size, partitions, hash_block_size=self.hash_block_size
        )
        self.cache_coordinator = self._build_cache_coordinator(vllm_config)
        self.token_database.cache_coordinator = self.cache_coordinator

    def _init_backend(self, parallel_config, extra_config, memcache_dp_init_barrier: bool = True) -> None:
        backend = backend_map.get(self.backend.lower())
        assert backend is not None
        backend_path = backend.get("path")
        backend_name = backend.get("name")
        assert backend_path is not None and backend_name is not None
        backend_module = importlib.import_module(backend_path)
        real_backend = getattr(backend_module, backend_name)

        backend_kwargs = {}
        # lazy_init is requested only for compressed models. Each backend owns
        # the hardware/protocol checks that decide whether it can honor it.
        backend_kwargs["lazy_init"] = self.use_compress
        # The connector's extra_config (with MultiConnector the child's own
        # config, not the top-level one) carries the QoS the backends inject.
        backend_kwargs["extra_config"] = extra_config
        if self.backend_name == "memcache":
            backend_kwargs["dp_init_barrier"] = memcache_dp_init_barrier
        self.m_store = real_backend(  # type: ignore[misc]
            parallel_config,
            **backend_kwargs,
        )

    def _init_kv_events(self, vllm_config) -> None:
        kv_event_config = vllm_config.kv_events_config
        self.enable_kv_events = False
        if kv_event_config and kv_event_config.enable_kv_cache_events:
            self.enable_kv_events = True

    def _init_state_vars(self) -> None:
        self.kv_send_thread: KVTransferThread | None = None
        self.kv_recv_thread: KVTransferThread | None = None
        self._previous_save_batch: KVCacheStoreBatch | None = None
        self._transfer_threads_started = False
        self.external_slot_release_waiter: Callable[[int], None] | None = None
        # Per-rank GVA cache: maps per-rank store key to its allocated GVA.
        # batch_alloc is non-idempotent (returns MMC_DUPLICATED_OBJECT for an
        # existing key without registering the blob), so the worker must track
        # which keys it has already allocated and reuse those GVAs instead of
        # re-allocating them on every save step.
        self._allocated_gvas: dict[str, int] = {}
        self._put_started_keys: set[str] = set()
        self._put_started_keys_lock = threading.Lock()
        self._load_session_lock = threading.Lock()
        self._layer_load_aborted = threading.Event()
        self._layerwise_session_tracker = LayerwiseSessionTracker()
        self._current_layerwise_request_ids: set[str] = set()
        self._current_layerwise_last_chunk_req_ids: set[str] = set()
        # PERF-TUNE(4): per-step RPC result caches. Defined once here so
        # mypy does not flag repeated attribute definitions; they are reset
        # per step via .clear() in process_layer_data().
        self._step_keyinfo_cache: dict[str, Any] = {}
        self._step_lease_result: dict[str, int] = {}
        self._step_exist_cache: dict[str, int] = {}

    def _init_layerwise_config(self) -> None:
        # Build mapping: physical_layer -> [(group_id, layer_idx_in_group), ...]
        # layer_idx_in_group is the index of the physical layer within the
        # group (not the index in layer_names). Multiple cache names at the
        # same physical layer are treated as entries of one layer.
        self.physical_layer_to_group_layers: dict[int, list[tuple[int, int]]] = {}
        self._global_to_local_layer: dict[int, int] = {}
        self._layerwise_reuse_layout: LayerwiseReuseLayout | None = None
        self._recurrent_layers: set[int] = set()
        # Defaults for partial initialization (unit tests construct the worker
        # without the full _init_parallelism_info path).
        if not hasattr(self, "layerwise_key_layers"):
            self.layerwise_key_layers = 0
            self.layerwise_key_layer_offset = 0

        # Layerwise pool-key layer addressing. Without pipeline parallel the
        # key space is the local layer range [0, num_layers) with offset 0
        # (identical to previous releases). With PP>1 each stage emits global
        # layer ids derived from its actual stage start, so producers and
        # consumers share one global layer key space regardless of which
        # stage computed the layer.
        if getattr(self, "pp_size", 1) > 1 and getattr(self, "total_layers", None) is not None:
            self.layerwise_key_layers = self.num_layers
            self.layerwise_key_layer_offset = self.pp_layer_offset
            logger.info(
                "Layerwise PP key space: stage %d/%d writes global layers [%d, %d) (total %d).",
                self.pp_rank,
                self.pp_size,
                self.layerwise_key_layer_offset,
                self.layerwise_key_layer_offset + self.num_layers,
                self.total_layers,
            )
        else:
            self.layerwise_key_layers = self.num_layers
            self.layerwise_key_layer_offset = 0

        if self.kv_cache_config is not None:
            base_layers = getattr(
                self.hf_config,
                "num_hidden_layers",
                self.num_layers,
            )
            physical_layers = {
                self._extract_physical_layer_index(layer_name)
                for group_spec in self.kv_cache_config.kv_cache_groups
                for layer_name in group_spec.layer_names
            }
            if physical_layers:
                self._global_to_local_layer = {
                    global_layer: local_layer for local_layer, global_layer in enumerate(sorted(physical_layers))
                }
                if getattr(self, "use_layerwise", False) or self.use_layerwise_transfer:
                    self._recurrent_layers = {
                        self._global_to_local_layer[self._extract_physical_layer_index(name)]
                        for name, spec in get_layerwise_kv_cache_specs(self.kv_cache_config).items()
                        if isinstance(spec, MambaSpec)
                    }
                effective_num_layers = max(self.num_layers, len(physical_layers))
                if effective_num_layers != self.num_layers:
                    logger.info(
                        "KVPoolWorker: updated num_layers %d -> %d from cache group layout.",
                        self.num_layers,
                        effective_num_layers,
                    )
                    self.num_layers = effective_num_layers
            if self.use_layerwise_transfer:
                self._layerwise_reuse_layout = build_layerwise_reuse_layout(
                    get_layerwise_kv_cache_specs(self.kv_cache_config),
                    base_layers,
                    self._extra_config,
                )

        if self.kv_cache_config is not None and self.num_kv_cache_groups > 1:
            for group_id, group_spec in enumerate(self.kv_cache_config.kv_cache_groups):
                physical_layers = set()
                for layer_name in group_spec.layer_names:
                    physical_layer = self._extract_physical_layer_index(layer_name)
                    physical_layers.add(self._global_to_local_layer[physical_layer])
                phys_to_layer_idx = {
                    physical_layer: layer_index for layer_index, physical_layer in enumerate(sorted(physical_layers))
                }

                # Add one entry per unique physical layer (no duplicates)
                for physical_layer, layer_idx_in_group in phys_to_layer_idx.items():
                    existing = self.physical_layer_to_group_layers.setdefault(physical_layer, [])
                    entry = (group_id, layer_idx_in_group)
                    if entry not in existing:
                        existing.append(entry)

                logger.info(
                    "layerwise group %d: %d layer_names, %d unique physical layers",
                    group_id,
                    len(group_spec.layer_names),
                    len(phys_to_layer_idx),
                )

        self.layer_load_tasks: list[list[LayerTransferTask]] = [[] for _ in range(self.num_layers)]
        self.layer_save_tasks: list[list[LayerTransferTask]] = [[] for _ in range(self.num_layers)]
        self.layer_load_finished_events: list[threading.Event] | None = None
        self.layer_save_finished_events: list[threading.Event] | None = None

        self.next_layer_to_submit = 0
        self.layerwise_offload = False
        self.independent_layers: list[int] = []
        self.prefetch_layer_map: dict[int, int] = {}
        if self.use_layerwise_transfer:
            if self._layerwise_reuse_layout is None:
                cache_layout = build_layerwise_cache_layout(
                    self.num_layers,
                    self._extra_config,
                )
                self.layerwise_offload = cache_layout.has_layer_reuse
                self.independent_layers = cache_layout.independent_layers
                self.prefetch_layer_map = cache_layout.prefetch_layer_map
                self.num_prefetch_layers = cache_layout.num_prefetch_layers
            else:
                layout = self._layerwise_reuse_layout
                stage_globals = sorted(layout.layer_cache_specs)
                if stage_globals:
                    self.prefetch_layer_map, self.independent_layers = self._remap_layout_to_stage_local(
                        layout.prefetch_layer_map,
                        layout.independent_layers,
                        stage_globals,
                    )
                else:
                    self.prefetch_layer_map = layout.prefetch_layer_map
                    self.independent_layers = layout.independent_layers
                self.layerwise_offload = layout.has_layer_reuse
                self.num_prefetch_layers = layout.num_prefetch_layers
        else:
            self.num_prefetch_layers = 2
            if self.use_layerwise:
                prefetch_layers = self._extra_config.get("layerwise_prefetch_layers", 2)
                if isinstance(prefetch_layers, bool):
                    raise ValueError("layerwise_prefetch_layers must be a positive integer")
                try:
                    self.num_prefetch_layers = int(prefetch_layers)
                except (TypeError, ValueError) as exc:
                    raise ValueError("layerwise_prefetch_layers must be a positive integer") from exc
                if self.num_prefetch_layers <= 0:
                    raise ValueError("layerwise_prefetch_layers must be a positive integer")
        self.sync_save_events: list[torch.npu.Event] | None = None

        logger.info(
            "layerwise config: num_layers=%d num_groups=%d physical_layer_to_group_layers_sample=%s",
            self.num_layers,
            self.num_kv_cache_groups,
            {k: v for k, v in list(self.physical_layer_to_group_layers.items())[:3]},
        )

    @staticmethod
    def _remap_layout_to_stage_local(
        prefetch_layer_map: dict[int, int],
        independent_layers: list[int],
        stage_globals: list[int],
    ) -> tuple[dict[int, int], list[int]]:
        """Translate a global-indexed reuse layout to stage-local indices."""
        global_to_local = {global_idx: local_idx for local_idx, global_idx in enumerate(stage_globals)}
        return (
            {global_to_local[layer]: global_to_local[source] for layer, source in prefetch_layer_map.items()},
            [global_to_local[layer] for layer in independent_layers],
        )

    def _build_group_layer_builders(self) -> list[LayerBatchBuilder]:
        builders = []
        # Sync layerwise_key_layers with the (possibly updated) num_layers.
        # When num_kv_cache_groups == 1 and extra layers (e.g. MTP or
        # spec-decode draft layers) are present, num_layers is updated in
        # register_kv_caches to include them; the key layer count must follow
        # or those extra layers are skipped during the save/load lifecycle. A
        # block-key store owns a stage-local object, so its count stays local
        # under PP. A GVA store retains the global PP layout and offset below.
        if self.use_block_key_layerwise or (self.num_kv_cache_groups == 1 and getattr(self, "pp_size", 1) == 1):
            self.layerwise_key_layers = self.num_layers
        for group_id in range(self.num_kv_cache_groups):
            group_num_layers = self.group_num_layers.get(group_id, self.num_layers)
            group_page_size = (
                sum(self.group_block_len[group_id])
                if self.use_block_key_layerwise
                else self._global_group_alloc_size(group_id)
            )
            # Global byte offsets for the shared GVA region:
            #   PP: each stage writes its local layers at
            #       (pp_layer_offset + local_layer) * per_layer_bytes.
            #   DCP (shard-major): ranks sharing head_or_tp_rank (put_step>1)
            #       hold different context shards of the same logical block
            #       and share ONE region; shard d occupies the byte range
            #       [d * shard_stride, (d+1) * shard_stride) where the stride
            #       is the group byte total aligned up to the GVA hugepage
            #       size (unaligned strides yield misaligned GVA addresses).
            #       With put_step == 1 every rank owns a distinct region key
            #       and no shard separation is needed.
            layer_byte_offset = 0
            gbl = self.group_block_len.get(group_id) or []
            if not self.use_block_key_layerwise and gbl and group_num_layers > 0:
                per_layer = sum(gbl) // group_num_layers
                if getattr(self, "pp_size", 1) > 1:
                    layer_byte_offset += int(getattr(self, "layerwise_key_layer_offset", 0)) * per_layer
                if self.dcp_size > 1 and self.put_step > 1:
                    # Use the GLOBAL region size (PP-aware) as the basis for
                    # the per-shard stride; under PP>1 the local sum(gbl) only
                    # covers this stage's layers and would under-allocate.
                    shard_stride = self._global_group_alloc_size(group_id) // self.dcp_size
                    shard_idx = self.dcp_rank
                    layer_byte_offset += shard_idx * shard_stride
            builders.append(
                LayerBatchBuilder(
                    self.token_database,
                    group_page_size,
                    group_num_layers,
                    group_id=group_id,
                    layer_byte_offset=layer_byte_offset,
                )
            )
        return builders

    def set_external_slot_release_waiter(self, waiter: Callable[[int], None]) -> bool:
        """Accept the MultiConnector composite slot-release waiter.

        Only the layerwise transfer mode has receive threads waiting on an
        externally supplied slot-release callback, so the gate lives here
        (at the data-plane consumer) instead of at the connector proxy.
        """
        if not self.use_layerwise_transfer:
            return False
        self.external_slot_release_waiter = waiter
        # The receive thread snapshots the waiter at construction; if it is
        # already running, hand the waiter over directly so a late
        # registration still takes effect.
        if isinstance(self.kv_recv_thread, KVCacheStoreLayerRecvingThread):
            self.kv_recv_thread.external_slot_release_waiter = waiter
        return True

    def _start_kv_transfer_threads(self) -> None:
        if self._transfer_threads_started:
            return

        if self.use_layerwise:
            self.get_event = threading.Event()
            self.layer_load_finished_events = [threading.Event() for i in range(self.num_layers)]
            self.layer_save_finished_events = [threading.Event() for i in range(self.num_layers)]
            self.sync_save_events = [torch.npu.Event() for i in range(self.num_layers)]
            can_save = is_kv_save_role(self.kv_role, self.consumer_is_to_put)
            if (self.use_block_key_layerwise or self.use_layerwise_transfer) and can_save:
                ready_event_sending = threading.Event()
                self.kv_send_thread = KVCacheStoreLayerSendingThread(
                    self.m_store,
                    self.token_database,
                    self.block_size,
                    self.tp_rank,
                    self.tp_size,
                    self.dcp_size,
                    self.page_size_bytes,
                    ready_event_sending,
                    self.num_layers,
                    self.layer_save_finished_events,
                    self.sync_save_events,
                    self.layerwise_max_transfer_blocks,
                    self.layerwise_max_transfer_bytes,
                    group_builders=self._build_group_layer_builders(),
                    put_started_keys=self._put_started_keys,
                    put_started_keys_lock=self._put_started_keys_lock,
                    session_tracker=self._layerwise_session_tracker if self.use_block_key_layerwise else None,
                )
                self.kv_send_thread.start()
                ready_event_sending.wait()
            elif can_save:
                ready_event_sending = threading.Event()
                self.kv_send_thread = KVCacheStoreKeyLayerSendingThread(
                    self.m_store,
                    self.token_database,
                    self.block_size,
                    self.tp_rank,
                    self.tp_size,
                    self.dcp_size,
                    self.put_step,
                    ready_event_sending,
                    self.num_layers,
                    self.layer_save_finished_events,
                    self.sync_save_events,
                    layer_offset=getattr(self, "layerwise_key_layer_offset", 0),
                )
                self.kv_send_thread.start()
                ready_event_sending.wait()
            ready_event = threading.Event()
            if self.use_block_key_layerwise or self.use_layerwise_transfer:
                self.kv_recv_thread = KVCacheStoreLayerRecvingThread(
                    self.m_store,
                    self.token_database,
                    self.block_size,
                    self.tp_rank,
                    self.tp_size,
                    self.dcp_size,
                    self.page_size_bytes,
                    ready_event,
                    self.get_event,
                    self.layer_load_finished_events,
                    self.layer_save_finished_events,
                    self.sync_save_events,
                    self.num_layers,
                    self.h2d_stagger_us,
                    self.layerwise_max_transfer_blocks,
                    self.layerwise_max_transfer_bytes,
                    group_builders=self._build_group_layer_builders(),
                    external_slot_release_waiter=self.external_slot_release_waiter,
                    save_failure_checker=(
                        self.kv_send_thread.raise_if_failed if self.kv_send_thread is not None else None
                    ),
                    invalid_block_ids=self._invalid_block_ids,
                    invalid_block_ids_lock=self._invalid_block_ids_lock,
                    load_abort_event=self._layer_load_aborted,
                )
            else:
                self.kv_recv_thread = KVCacheStoreKeyLayerRecvingThread(
                    self.m_store,
                    self.token_database,
                    self.block_size,
                    self.tp_rank,
                    self.tp_size,
                    self.dcp_size,
                    ready_event,
                    self.get_event,
                    self.layer_load_finished_events,
                    self.layer_save_finished_events,
                    self.num_layers,
                    layer_offset=getattr(self, "layerwise_key_layer_offset", 0),
                )
            self.kv_recv_thread.start()
            ready_event.wait()
        else:
            if self.kv_role in ["kv_producer", "kv_both"] or self.consumer_is_to_put:
                ready_event_sending = threading.Event()
                self.kv_send_thread = KVCacheStoreSendingThread(
                    self.m_store,
                    self.token_database,
                    self.grouped_block_size,
                    self.tp_rank,
                    self.tp_size,
                    # KVPP owners hold different layers, not PCP replicas.
                    0 if self.use_kvpp else self.pcp_rank,
                    1 if self.use_kvpp else self.pcp_size,
                    self.dcp_size,
                    self.put_step,
                    self.kv_role,
                    ready_event_sending,
                    self.group_uses_align_state,
                    self.enable_kv_events,
                    worker=self if self.tp_mismatch else None,
                )
                self.kv_send_thread.start()
                ready_event_sending.wait()
            if self.load_async:
                ready_event = threading.Event()
                self.kv_recv_thread = KVCacheStoreRecvingThread(
                    self.m_store,
                    self.token_database,
                    self.grouped_block_size,
                    self.tp_rank,
                    self.tp_size,
                    self.dcp_size,
                    ready_event,
                    invalid_block_ids=self._invalid_block_ids,
                    invalid_block_ids_lock=self._invalid_block_ids_lock,
                    worker=self if self.tp_mismatch else None,
                    record_operation=self._record_kv_connector_operation,
                )
                self.kv_recv_thread.start()
                ready_event.wait()
        self._transfer_threads_started = True

    def _build_cache_coordinator(self, vllm_config: VllmConfig) -> AscendStoreCoordinator | None:
        if self.kv_cache_config is None or not self.use_hybrid:
            return None
        speculative_config = getattr(vllm_config, "speculative_config", None)
        use_eagle_fn = getattr(speculative_config, "use_eagle", None)
        use_eagle = bool(use_eagle_fn()) if callable(use_eagle_fn) else False
        retention_interval = self.kv_cache_config.prefix_cache_retention_interval
        return AscendStoreCoordinator(
            self.kv_cache_config.kv_cache_groups,
            scheduler_block_size=self.cache_transfer_granularity,
            hash_block_size=self.hash_block_size,
            group_block_sizes=self.grouped_block_size,
            group_cache_families=self.kv_cache_group_families,
            use_eagle=use_eagle,
            retention_interval=retention_interval,
        )

    def _infer_group_uses_align_state(self) -> list[bool]:
        if self.kv_cache_config is None:
            return [False]

        group_uses_align_state: list[bool] = []
        for group in self.kv_cache_config.kv_cache_groups:
            kv_cache_spec = group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                specs = [kv_cache_spec.kv_cache_specs[layer_name] for layer_name in group.layer_names]
            else:
                specs = [kv_cache_spec]
            group_uses_align_state.append(
                any(
                    isinstance(spec, MambaSpec) and getattr(spec, "mamba_cache_mode", None) == "align" for spec in specs
                )
            )
        return group_uses_align_state

    @staticmethod
    def _uses_mamba_kv_cache(use_hybrid: bool, kv_cache_config: KVCacheConfig | None):
        if not use_hybrid or kv_cache_config is None:
            return False
        for group in kv_cache_config.kv_cache_groups:
            kv_cache_spec = group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                if any(isinstance(spec, MambaSpec) for spec in kv_cache_spec.kv_cache_specs.values()):
                    return True
            elif isinstance(kv_cache_spec, MambaSpec):
                return True
        return False

    @staticmethod
    def _as_cache_tuple(cache_or_caches) -> tuple[torch.Tensor, ...]:
        if isinstance(cache_or_caches, torch.Tensor):
            cache_or_caches = (cache_or_caches,)
        # NoPE MLA exposes an empty RoPE view whose data_ptr() is zero.
        return tuple(cache for cache in cache_or_caches if cache.numel())

    def _get_cache_block_metadata(self, cache: torch.Tensor) -> tuple[int, int, int, int]:
        tensor_num_blocks = cache.shape[0]
        assert tensor_num_blocks % self.num_blocks == 0, (
            "The external block size must be an integer multiple of the kernel block size."
        )
        block_size_scale = tensor_num_blocks // self.num_blocks
        block_len = cache[0].numel() * cache.element_size() * block_size_scale
        block_stride = cache.stride(0) * cache.element_size() * block_size_scale
        region_len = (self.num_blocks - 1) * block_stride + block_len if self.num_blocks else 0
        return block_len, block_stride, region_len, block_size_scale

    @staticmethod
    def _get_storage_key(cache: torch.Tensor) -> int:
        try:
            return cache.untyped_storage().data_ptr()
        except AttributeError:
            return cache.storage().data_ptr()

    def _extract_physical_layer_index(self, layer_name: str) -> int:
        base_layers = getattr(
            self.hf_config,
            "num_hidden_layers",
            self.num_layers,
        )
        return get_layerwise_physical_layer_index(layer_name, base_layers)

    def _global_group_alloc_size(self, group_id: int) -> int:
        # GLOBAL region size: per-layer bytes x TOTAL model layers.
        # Under PP each stage sees a LOCAL group view (non-uniform splits make
        # the per-stage layer counts differ) but all stages plus the decode
        # side share ONE region per pool key, so the region must cover the
        # union of all writers. vllm groups layers by identical cache spec,
        # so per-layer bytes are uniform within a group.
        gbl = self.group_block_len.get(group_id) or []
        if not gbl:
            return self.page_size_bytes
        # Backward compatibility: when total_layers is not set (unit tests,
        # partial init), fall back to the LOCAL sum (pre-PP behavior).
        total_layers = getattr(self, "total_layers", None)
        if not total_layers or not isinstance(total_layers, int):
            return sum(gbl)
        n_local = int(self.group_num_layers.get(group_id, 0))
        if n_local <= 0:
            return sum(gbl)
        per_layer = (sum(gbl) + n_local - 1) // n_local
        n_global = max(total_layers, int(self.num_layers), n_local)
        # DCP shard-major layout: ranks sharing head_or_tp_rank (put_step>1,
        # e.g. MLA) hold different context shards of the same logical block
        # and share ONE region, so the region must cover all shards. The
        # per-shard stride is the group byte total aligned up to the GVA
        # hugepage size: hybrid DSA groups have non-uniform per-layer bytes,
        # and an unaligned stride would yield misaligned GVA addresses that
        # SDMA rejects. With put_step == 1 every rank owns a distinct region
        # key and no shard separation is needed.
        if self.put_step > 1 and self.dcp_size > 1:
            gva_align = 2 * 1024 * 1024
            shard_stride = (per_layer * n_global + gva_align - 1) // gva_align * gva_align
            return shard_stride * self.dcp_size
        return per_layer * n_global

    def _infer_cache_group_metadata(self, group_id: int, layer_names: list[str]):
        group_addrs: list[int] = []
        group_block_lens: list[int] = []
        group_block_strides: list[int] = []
        layer_names_by_physical: dict[int, list[str]] = {}
        for layer_name in layer_names:
            phys = self._extract_physical_layer_index(layer_name)
            phys = self._global_to_local_layer.get(phys, phys)
            layer_names_by_physical.setdefault(phys, []).append(layer_name)

        layer_cache_entry_offsets = [0]
        for phys in sorted(layer_names_by_physical):
            for layer_name in sorted(layer_names_by_physical[phys]):
                cache_or_caches = self.kv_caches[layer_name]
                for cache in self._as_cache_tuple(cache_or_caches):
                    base_addr = cache.data_ptr()
                    block_len, block_stride, _, _ = self._get_cache_block_metadata(cache)
                    group_addrs.append(base_addr)
                    group_block_lens.append(block_len)
                    group_block_strides.append(block_stride)
            layer_cache_entry_offsets.append(len(group_addrs))
        self.group_kv_caches_base_addr[group_id] = group_addrs
        self.group_block_len[group_id] = group_block_lens
        self.group_block_stride[group_id] = group_block_strides
        self.group_layer_cache_entry_offsets[group_id] = layer_cache_entry_offsets
        self.group_num_layers[group_id] = len(layer_names_by_physical)

    def _align_kv_ptrs(self, registered_regions: dict[int, tuple[int, int]]):
        """
        In hybrid scenario, where a KVCacheTensor is shared by multiple layers,
        but sometimes, layers cannot be evenly distributed among multiple groups,
        the layers sharing the KVCacheTensor may not completely occupy all the space of the KVCacheTensor.
        This results in the calculated start address not being the previously aligned address.
        Therefore, we down-align the start address to meet the 2MB alignment requirement.
        """
        if not self.use_hybrid:
            return
        alignment = 2 * 1024 * 1024
        for storage_key in registered_regions:
            start, end = registered_regions[storage_key]
            new_start = start // alignment * alignment
            # Because the addresses of raw tensors are aligned to 2MB,
            # all shared sub-tensors, when aligned downwards, should theoretically not exceed the address bounds.
            assert new_start >= storage_key, "invalid kv cache tensor, raw tensor ptr must be align to 2MB"
            registered_regions[storage_key] = (new_start, end)

    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]):
        _, first_kv_cache_tuple = next(iter(kv_caches.items()))
        first_kv_cache_tuple = self._as_cache_tuple(first_kv_cache_tuple)
        first_kv_cache = first_kv_cache_tuple[0]

        self.num_blocks = (
            self.kv_cache_config.num_blocks if self.kv_cache_config is not None else first_kv_cache.shape[0]
        )
        logger.info("num_blocks: %s", self.num_blocks)
        self.block_len = []
        self.block_stride = []
        for cache in first_kv_cache_tuple:
            block_len, block_stride, _, _ = self._get_cache_block_metadata(cache)
            logger.info("block_shape: %s", cache.shape[1:])
            self.block_len.append(block_len)
            self.block_stride.append(block_stride)

        self.group_kv_caches_base_addr: dict[int, list[int]] = {}
        self.group_block_len: dict[int, list[int]] = {}
        self.group_block_stride: dict[int, list[int]] = {}
        self.group_layer_cache_entry_offsets: dict[int, list[int]] = {}
        self.kv_caches = kv_caches
        if self.use_kvpp:
            owners = map_kvpp_layers_to_owners(self.vllm_config, kv_caches.keys())
            kv_caches = {
                name: caches for name, caches in kv_caches.items() if owners.get(name) in (None, self.kvpp_rank)
            }
            self.kv_caches = kv_caches
        self.group_kv_cache_families: dict[int, str] = {
            group_id: get_group_cache_family(self.kv_cache_group_families, group_id)
            for group_id in range(self.num_kv_cache_groups)
        }
        self.group_num_layers: dict[int, int] = {}

        logger.info(
            "Registering KV_Caches. use_mla: %s, use_sparse: %s, shape %s",
            self.use_mla,
            self.use_sparse,
            first_kv_cache.shape,
        )

        self.kv_caches_base_addr = []

        registered_regions: dict[int, tuple[int, int]] = {}
        for cache_or_caches in kv_caches.values():
            for cache in self._as_cache_tuple(cache_or_caches):
                base_addr = cache.data_ptr()
                _, _, region_len, _ = self._get_cache_block_metadata(cache)
                if not isinstance(region_len, int):
                    region_len = 0
                self.kv_caches_base_addr.append(base_addr)
                storage_key = self._get_storage_key(cache)
                start = base_addr
                end = base_addr + region_len
                if storage_key in registered_regions:
                    old_start, old_end = registered_regions[storage_key]
                    registered_regions[storage_key] = (min(old_start, start), max(old_end, end))
                else:
                    registered_regions[storage_key] = (start, end)

        self._align_kv_ptrs(registered_regions)
        ptrs = [start for start, _ in registered_regions.values()]
        lengths = [end - start for start, end in registered_regions.values()]

        if self.kv_cache_config is not None and self.use_hybrid:
            for group_id, group_spec in enumerate(self.kv_cache_config.kv_cache_groups):
                layer_names = group_spec.layer_names
                if self.use_kvpp:
                    layer_names = [name for name in layer_names if name in kv_caches]
                self._infer_cache_group_metadata(group_id, layer_names)
        else:
            self._infer_cache_group_metadata(0, list(kv_caches.keys()))

        # group_num_layers is computed from the actual kv_caches dict which
        # includes ALL attention layers (main + MTP). For single-group models,
        # sum(group_num_layers.values()) equals the physical layer count
        # (including MTP). For multi-group models, it counts (group, layer)
        # pairs which is NOT the physical layer count — keep the original
        # num_layers (physical layers) in that case.
        original_num_layers = self.num_layers
        new_num_layers = sum(self.group_num_layers.values())
        if not self.use_kvpp and self.num_kv_cache_groups == 1 and new_num_layers != original_num_layers:
            self.num_layers = new_num_layers
            logger.info(
                "KVPoolWorker: updated num_layers %d -> %d (includes MTP/spec-decode draft layers).",
                original_num_layers,
                self.num_layers,
            )
            self.layer_load_tasks = [[] for _ in range(self.num_layers)]
            self.layer_save_tasks = [[] for _ in range(self.num_layers)]

        self.page_size_bytes = sum(self.block_len)
        self.token_database.set_group_buffers(
            self.group_kv_caches_base_addr,
            self.group_block_len,
            self.group_block_stride,
            cache_role="kv",
            group_cache_families=self.group_kv_cache_families,
            group_num_layers=self.group_num_layers,
            group_layer_cache_entry_offsets=self.group_layer_cache_entry_offsets,
        )

        if self.tp_mismatch:
            first_cache = self._as_cache_tuple(next(iter(kv_caches.values())))[0]
            self.elem_size = first_cache.element_size()
            self.head_dim = first_cache.shape[-1]
            # block_len[0] = block_size * num_kv_head_per_local_rank * head_dim * elem_size
            self.per_token_bytes = self.group_block_len[0][0] // self.block_size
            self.sub_size_bytes = self.effective_heads_per_rank * self.head_dim * self.elem_size
            logger.info(
                "TP mismatch strided I/O: per_token_bytes=%d, sub_size_bytes=%d",
                self.per_token_bytes,
                self.sub_size_bytes,
            )

        # Initialize store, register buffers, and start transfer threads
        # directly here (like main) — no separate init_backend handshake.
        if self.use_layerwise_transfer:
            self.m_store.ensure_initialized()
        self.m_store.register_buffer(ptrs, lengths)
        if self.use_block_key_layerwise:
            self.m_store.validate_layerwise_support()
        self._start_kv_transfer_threads()

    def prepare_layerwise_step(self, metadata: AscendConnectorMetadata) -> None:
        """Prepare per-step hook state when the runner binds metadata."""
        assert self.use_layerwise
        self._drain_deferred_last_save()
        self.current_layer = 0
        self.layerwise_retrievers: list[Any] = []
        self.next_layer_to_submit = 0
        reset_attention_compute_start_gate()
        self._attention_saved_layers = set()
        self.process_layer_data(metadata.requests)

    def start_load_kv(self, metadata: AscendConnectorMetadata):
        if self.use_layerwise:
            # wait_for_layer_load submits loads from tasks prepared at bind.
            # A deferred call must not reset state between target and MTP.
            return
        self.current_layer = 0
        self.layerwise_retrievers = []
        logger.debug("KV pool worker start_load_kv requests=%d", len(metadata.requests))
        if len(metadata.requests) == 0:
            return
        for request in metadata.requests:
            load_spec = request.load_spec
            if load_spec is None or not load_spec.can_load:  # load =0
                logger.debug(
                    "KV pool worker skip get req=%s reason=%s",
                    request.req_id,
                    "no_load_spec" if load_spec is None else f"can_load={load_spec.can_load}",
                )
                continue
            request.skip_null_blocks_by_group = self.group_uses_align_state
            load_group_ids = request.kv_cache_group_ids or [0]
            token_len = request.token_len_chunk
            if (load_spec.kvpool_cached_tokens % self.cache_transfer_granularity != 0) and (
                load_spec.kvpool_cached_tokens == token_len - 1
            ):
                token_len = load_spec.kvpool_cached_tokens + 1
            else:
                token_len = load_spec.kvpool_cached_tokens
            load_spec.token_len = token_len
            logger.debug(
                "KV pool worker prepare get req=%s token_len_chunk=%d get_token_len=%d "
                "vllm_cached=%d kvpool_cached=%d groups=%s load_async=%s",
                request.req_id,
                request.token_len_chunk,
                token_len,
                load_spec.vllm_cached_tokens,
                load_spec.kvpool_cached_tokens,
                load_group_ids,
                self.load_async,
            )
            if self.load_async:
                self.kv_recv_thread.add_request(  # type: ignore[union-attr]
                    request,
                )
                continue

            if self.tp_mismatch:
                # TP mismatch is restricted to non-hybrid, single-group KV.
                group_block_size = self.grouped_block_size[0]
                mask_num = load_spec.vllm_cached_tokens // group_block_size * group_block_size
                self._load_kv_tp_mismatch(
                    request.block_hashes,
                    request.block_ids_by_group[0],
                    token_len,
                    mask_num,
                )
                continue

            addr_list = []
            size_list = []
            key_list = []
            block_id_list: list[int] = []
            load_masks = self.token_database.load_mask(request.block_hashes, token_len)
            for group_id in load_group_ids:
                if group_id >= len(request.block_ids_by_group):
                    continue
                block_ids = request.block_ids_by_group[group_id]
                group_block_size = self.grouped_block_size[group_id]
                mask_num = load_spec.vllm_cached_tokens // group_block_size * group_block_size
                skip_null = group_id < len(self.group_uses_align_state) and self.group_uses_align_state[group_id]

                def chunk_filter(start: int, group_id=group_id, load_masks=load_masks) -> bool:
                    return self.token_database.mask_allows_chunk(load_masks, group_id, start)

                for (
                    start,
                    end,
                    key,
                    _block_hash,
                    block_id,
                ) in self.token_database.process_token_key_strings_with_block_ids(
                    token_len,
                    request.block_hashes,
                    block_ids,
                    mask_num,
                    kv_cache_group_id=group_id,
                    skip_null_blocks=skip_null,
                    chunk_filter=chunk_filter,
                ):
                    addr, size, block_id = self.token_database.prepare_value(
                        start,
                        end,
                        block_ids,
                        kv_cache_group_id=group_id,
                        block_id=block_id,
                    )
                    key_list.append(key)
                    addr_list.append(addr)
                    size_list.append(size)
                    block_id_list.append(block_id)
            if not key_list:
                continue
            key_list_c = _circular_shift(key_list, self.tp_rank % len(key_list))
            addr_list_c = _circular_shift(addr_list, self.tp_rank % len(addr_list))
            size_list_c = _circular_shift(size_list, self.tp_rank % len(size_list))
            block_id_list_c = _circular_shift(block_id_list, self.tp_rank % len(block_id_list))
            logger.debug(
                "KV pool worker calls backend get request=%s token_len=%d groups=%s keys=%d sample_keys=%s",
                request.req_id,
                token_len,
                load_group_ids,
                len(key_list_c),
                key_list_c[:3],
            )
            load_get_start = time.perf_counter()
            ret = self.m_store.get(key_list_c, addr_list_c, size_list_c)
            self._record_kv_connector_operation(
                "load_get",
                time.perf_counter() - load_get_start,
                len(key_list_c),
            )
            if ret is not None and any(r != 0 for r in ret):
                missing_block_ids = record_failed_blocks(
                    block_id_list_c,
                    ret,
                )
                if len(request.block_ids_by_group) == 1:
                    self._invalid_block_ids.update(missing_block_ids)
                elif missing_block_ids:
                    logger.error(
                        "KV load failed for hybrid request %s. "
                        "Skip invalid-block fallback to avoid scheduler crash. "
                        "failed_blocks=%s",
                        request.req_id,
                        missing_block_ids,
                    )
            elif ret is None:
                missing_block_ids = record_failed_blocks(
                    block_id_list_c,
                    [1] * len(block_id_list_c),
                )
                if len(request.block_ids_by_group) == 1:
                    self._invalid_block_ids.update(missing_block_ids)
                elif missing_block_ids:
                    logger.error(
                        "KV load failed for hybrid request %s. "
                        "Skip invalid-block fallback to avoid scheduler crash. "
                        "failed_blocks=%s",
                        request.req_id,
                        missing_block_ids,
                    )
            logger.debug(
                "KV pool worker backend get returned request=%s token_len=%d groups=%s keys=%d",
                request.req_id,
                token_len,
                load_group_ids,
                len(key_list_c),
            )

    def _record_kv_connector_operation(self, operation: str, duration_seconds: float, num_keys: int) -> None:
        with self._kv_stats_lock:
            self._kv_stats.record_operation(operation, duration_seconds, num_keys)

    def get_stats(self) -> AscendStoreKVConnectorStats | None:
        with self._kv_stats_lock:
            if self._kv_stats.is_empty():
                return None
            stats = self._kv_stats
            self._kv_stats = AscendStoreKVConnectorStats()
            return stats

    def _is_layerwise_save_leader(self) -> bool:
        """Exactly one rank per (pcp, dcp, head_or_tp) group saves/allocates.

        Without DCP the plain ``tp_rank % put_step == 0`` dedup is correct
        because all TP ranks hold identical KV. With DCP the context is
        sharded: ranks sharing (dcp_rank, head_or_tp_rank) hold the same
        shard, while the put_step groups span DIFFERENT shards -- the plain
        dedup would drop every non-zero DCP shard from the pool. The leader
        is the smallest tp_rank inside the rank's own (dcp, head) group.
        """
        if self.dcp_size <= 1:
            return self.tp_rank % self.put_step == 0
        head = self.tp_rank // self.put_step
        peers = [
            t for t in range(head * self.put_step, (head + 1) * self.put_step) if t % self.dcp_size == self.dcp_rank
        ]
        if not peers:
            return True
        return self.tp_rank == min(peers)

    def _process_save_for_layer_batch(
        self,
        requests: list[ReqMeta],
        layer_id: int,
        group_id: int = 0,
        layer_idx_in_group: int = 0,
    ) -> None:
        # Only one rank in each (pcp, dcp, head_or_tp) group saves to the
        # pool. Other ranks in the same group share the same KV shard
        # (e.g. MLA latent replicated across the non-DCP TP ranks), so they
        # skip save to avoid redundant writes. With DCP>1 the plain put_step
        # dedup would drop every non-zero DCP shard (see
        # _is_layerwise_save_leader).
        if not self._is_layerwise_save_leader():
            return
        block_size = get_group_block_size(self.grouped_block_size, group_id)
        request_block_ranges = []
        for request in requests:
            if request.can_save is None or not request.can_save:
                continue
            save_start_block = request.save_start_token // block_size
            save_end_block = request.save_end_token // block_size
            group_block_hashes = get_block_hashes(
                request.block_hashes,
                block_size,
                self.hash_block_size,
            )
            partial_block_index = get_partial_block_index(
                request.target_token_len,
                block_size,
                len(group_block_hashes),
                self.layerwise_offload,
            )
            # Skip blocks that are hit in the KV pool — their KV is already
            # in the pool (loaded via load_prepare), so re-saving would write
            # to a READABLE blob and fail with MMC_UNMATCHED_KEY.
            if request.load_spec is not None and request.load_spec.can_load:
                pool_hit_tokens = (
                    request.load_spec.kvpool_store_skip_tokens
                    if request.load_spec.kvpool_store_skip_tokens is not None
                    else request.load_spec.kvpool_cached_tokens
                )
                hit_full_blocks = pool_hit_tokens // block_size
                save_start_block = max(save_start_block, hit_full_blocks)
            if partial_block_index is None:
                partial_block_index = request.partial_block_index
            group_store_mask = (
                request.store_masks[group_id]
                if request.store_masks is not None and group_id < len(request.store_masks)
                else None
            )
            block_runs = masked_block_runs(group_store_mask, save_start_block, save_end_block)
            if not block_runs and partial_block_index is None:
                continue
            for run_idx, (run_start_block, run_end_block) in enumerate(block_runs):
                # The trailing partial block rides on the last run (or on its
                # own zero-length range) so it is transferred exactly once.
                is_last_run = run_idx == len(block_runs) - 1
                request_block_ranges.append(
                    LayerBlockRange(
                        request=request,
                        start_block=run_start_block,
                        end_block=run_end_block,
                        partial_block_index=partial_block_index if is_last_run else None,
                    )
                )
            if not block_runs and partial_block_index is not None:
                request_block_ranges.append(
                    LayerBlockRange(
                        request=request,
                        start_block=partial_block_index,
                        end_block=partial_block_index,
                        partial_block_index=partial_block_index,
                    )
                )
        if request_block_ranges:
            self.layer_save_tasks[layer_id].append(
                LayerTransferTask(
                    layer_id=layer_id,
                    block_ranges=request_block_ranges,
                    group_id=group_id,
                    layer_idx_in_group=layer_idx_in_group,
                    use_key_major_ranges=self.use_block_key_layerwise,
                    final_group_layer=layer_idx_in_group
                    == getattr(self, "group_num_layers", {}).get(group_id, self.num_layers) - 1,
                )
            )

    def _process_load_for_layer_batch(
        self,
        requests: list[ReqMeta],
        layer_id: int,
        group_id: int = 0,
        layer_idx_in_group: int = 0,
    ) -> None:
        block_size = get_group_block_size(self.grouped_block_size, group_id)
        request_block_ranges = []
        for request in requests:
            if self.use_block_key_layerwise:
                # Block-key sessions retain committed block ownership across
                # chunked-prefill steps.  A later chunk can therefore have no
                # new load_spec while still needing to restore the previously
                # committed prefix into its newly allocated local blocks.
                populated_slots = [index for index, key in enumerate(request.load_block_keys) if key is not None]
                if not populated_slots:
                    continue
                request_block_ranges.append(
                    LayerBlockRange(
                        request=request,
                        start_block=min(populated_slots),
                        end_block=max(populated_slots) + 1,
                    )
                )
                continue
            if request.load_spec is None or not request.load_spec.can_load:
                continue
            cached_tokens = request.load_spec.kvpool_cached_tokens
            if not getattr(self, "use_eagle", False) and request.load_spec.kvpool_store_skip_tokens is not None:
                cached_tokens = request.load_spec.kvpool_store_skip_tokens
            if (
                getattr(self, "use_eagle", False)
                and request.load_spec.kvpool_cached_tokens == request.target_token_len - 1
            ):
                # Full-hit path: the trailing block is recomputed and will be
                # re-stored by the normal save path, so never skip it here.
                logger.debug(
                    "Reqid: %s full-hit tail recompute path, tail block will be re-stored",
                    request.req_id,
                )
            group_block_hashes = get_block_hashes(
                request.block_hashes,
                block_size,
                self.hash_block_size,
            )
            load_start_block = (
                request.load_spec.vllm_cached_tokens // block_size
                if not self.layerwise_offload or layer_id in self.independent_layers
                else 0
            )
            cached_full_blocks = cached_tokens // block_size
            full_blocks = min(cached_full_blocks, len(group_block_hashes))
            partial_block_index = get_partial_block_index(
                cached_tokens,
                block_size,
                len(group_block_hashes),
                self.layerwise_offload,
            )
            if not self.layerwise_offload or layer_id in self.independent_layers:
                partial_block_index = None
            partial_gva = (
                request.partial_load_gva_per_group[group_id]
                if group_id < len(request.partial_load_gva_per_group)
                else request.last_block_gva
            )
            if partial_gva is None or partial_gva <= 0:
                partial_block_index = None
            if partial_block_index is not None and partial_block_index < load_start_block:
                partial_block_index = None
            group_load_mask = (
                request.load_masks[group_id]
                if request.load_masks is not None and group_id < len(request.load_masks)
                else None
            )
            block_runs = masked_block_runs(group_load_mask, load_start_block, full_blocks)
            if not block_runs and partial_block_index is None:
                continue
            for run_idx, (run_start_block, run_end_block) in enumerate(block_runs):
                # The trailing partial block rides on the last run (or on its
                # own zero-length range) so it is transferred exactly once.
                is_last_run = run_idx == len(block_runs) - 1
                request_block_ranges.append(
                    LayerBlockRange(
                        request=request,
                        start_block=run_start_block,
                        end_block=run_end_block,
                        partial_block_index=partial_block_index if is_last_run else None,
                    )
                )
            if not block_runs and partial_block_index is not None:
                request_block_ranges.append(
                    LayerBlockRange(
                        request=request,
                        start_block=partial_block_index,
                        end_block=partial_block_index,
                        partial_block_index=partial_block_index,
                    )
                )
        if request_block_ranges:
            self.layer_load_tasks[layer_id].append(
                LayerTransferTask(
                    layer_id=layer_id,
                    block_ranges=request_block_ranges,
                    group_id=group_id,
                    layer_idx_in_group=layer_idx_in_group,
                    use_key_major_ranges=self.use_block_key_layerwise,
                    final_group_layer=layer_idx_in_group
                    == getattr(self, "group_num_layers", {}).get(group_id, self.num_layers) - 1,
                )
            )

    def _make_layerwise_full_key(self, group_id: int, block_hash_hex: str) -> str:
        """Use the backend-bound layout shared with scheduler hit checks."""
        assert self.layerwise_keys is not None
        return self.layerwise_keys.make_full_key(group_id, block_hash_hex, self.head_or_tp_rank, self.pp_rank)

    def _make_layerwise_partial_key(
        self,
        request: ReqMeta,
        group_id: int,
        block_index: int,
        end_token: int,
    ) -> str:
        return self.layerwise_protocol.make_partial_key(
            self.model_name,
            request.req_id,
            group_id,
            block_index,
            end_token,
            self.head_or_tp_rank,
            self.pp_rank,
            self.pp_size,
        )

    def _refresh_allocated_gvas(self, keys: list[str]) -> None:
        """Drop local GVA entries whose MemCache blobs were evicted."""
        cached_keys = list(dict.fromkeys(key for key in keys if key in self._allocated_gvas))
        if not cached_keys:
            return
        # PERF-TUNE(4): reuse this step's existence results for repeated keys
        step_cache = getattr(self, "_step_exist_cache", None) or {}
        self._step_exist_cache = step_cache
        uncached_keys = [k for k in cached_keys if k not in step_cache]
        if uncached_keys:
            fetched_states = self.m_store.batch_is_exist(uncached_keys)
            if len(fetched_states) != len(uncached_keys):
                raise RuntimeError(
                    "MemCache exists check returned unexpected number of states: "
                    f"expected={len(uncached_keys)}, actual={len(fetched_states)}"
                )
            for k, st in zip(uncached_keys, fetched_states):
                step_cache[k] = st
        exists_states = [step_cache[k] for k in cached_keys]
        for key, exists in zip(cached_keys, exists_states):
            if exists == 0:
                self._allocated_gvas.pop(key, None)
            elif exists != 1:
                raise RuntimeError(f"MemCache exists check failed for {key}: state={exists}")

    def _alloc_gvas_for_save(self, requests: list[ReqMeta]) -> None:
        """Allocate per-group GVA on the worker side right before batch_copy.

        For multi-group models, iterates all KV cache groups and allocates
        per-group GVAs. Key format: model@group_id@hash@head_or_tp_rank
        (multi-group) or model@hash@head_or_tp_rank (single-group, backward
        compat with PR #11585).
        """
        if not self.use_layerwise_transfer:
            return
        if self.kv_role == "kv_consumer" and not self.consumer_is_to_put:
            return
        if not self._is_layerwise_save_leader():
            return
        for request in requests:
            if request.can_save is None or not request.can_save:
                continue
            block_hashes = request.block_hashes

            all_group_gvas: list[np.ndarray] = []
            all_group_block_ids: list[np.ndarray] = []
            all_group_save_keys: list[str] = []
            request.partial_save_gva_per_group = [0] * self.num_kv_cache_groups
            for group_id in range(self.num_kv_cache_groups):
                group_block_size = self.grouped_block_size[group_id]
                effective_block_size = group_block_size
                alloc_size = self._global_group_alloc_size(group_id)

                group_block_hashes = get_block_hashes(block_hashes, effective_block_size, self.hash_block_size)
                block_ids_by_group = (
                    request.block_ids_by_group_np[group_id]
                    if (request.block_ids_by_group_np is not None and group_id < len(request.block_ids_by_group_np))
                    else request.block_ids_np
                )
                if block_ids_by_group is None:
                    raise RuntimeError(f"Block IDs are not initialized for request {request.req_id}")

                save_start_block = request.save_start_token // effective_block_size
                save_end_block = request.save_end_token // effective_block_size
                if request.load_spec is not None and request.load_spec.can_load:
                    pool_hit_tokens = (
                        request.load_spec.kvpool_store_skip_tokens
                        if request.load_spec.kvpool_store_skip_tokens is not None
                        else request.load_spec.kvpool_cached_tokens
                    )
                    hit_full_blocks = pool_hit_tokens // effective_block_size
                    save_start_block = max(save_start_block, hit_full_blocks)
                group_store_mask = (
                    request.store_masks[group_id]
                    if request.store_masks is not None and group_id < len(request.store_masks)
                    else None
                )
                end_limit = min(save_end_block, len(group_block_hashes))
                candidate_blocks = [
                    block_idx
                    for block_idx in range(save_start_block, end_limit)
                    if group_store_mask is None or block_idx >= len(group_store_mask) or group_store_mask[block_idx]
                ]
                candidate_keys = [
                    self._make_layerwise_full_key(
                        group_id,
                        block_hash_to_str(group_block_hashes[block_idx]),
                    )
                    for block_idx in candidate_blocks
                ]
                self._refresh_allocated_gvas(candidate_keys)
                # Skip blocks that are still present and readable in MemCache.
                # Only a leading run of already-allocated blocks is skipped so
                # the readable-blob write failure semantics stay unchanged.
                allocated_prefix = 0
                for block_idx in candidate_blocks:
                    key = self._make_layerwise_full_key(group_id, block_hash_to_str(group_block_hashes[block_idx]))
                    if key in self._allocated_gvas:
                        allocated_prefix += 1
                    else:
                        break
                transfer_blocks = candidate_blocks[allocated_prefix:]

                block_gvas: list[int] = []
                new_keys: list[str] = []
                new_positions: list[int] = []
                for blk_idx in transfer_blocks:
                    key = self._make_layerwise_full_key(group_id, block_hash_to_str(group_block_hashes[blk_idx]))
                    cached = self._allocated_gvas.get(key)
                    if cached is not None:
                        block_gvas.append(cached)
                    else:
                        new_keys.append(key)
                        new_positions.append(len(block_gvas))
                        block_gvas.append(0)

                if new_keys:
                    new_gvas = self.m_store.batch_alloc(
                        new_keys, [alloc_size] * len(new_keys), LAYERWISE_READ_LEASE_TTL_MS
                    )
                    if any(gva <= 0 for gva in new_gvas):
                        logger.error(
                            "alloc_gvas FAIL: req=%s group=%d alloc_size=%d new_keys=%d gvas_sample=%s zero_count=%d",
                            request.req_id,
                            group_id,
                            alloc_size,
                            len(new_keys),
                            new_gvas[:5],
                            sum(1 for g in new_gvas if g <= 0),
                        )
                    for pos, key, gva in zip(new_positions, new_keys, new_gvas):
                        if gva > 0:
                            block_gvas[pos] = gva
                            self._allocated_gvas[key] = gva
                            all_group_save_keys.append(key)

                partial_block_index = get_partial_block_index(
                    request.target_token_len,
                    effective_block_size,
                    len(group_block_hashes),
                    self.layerwise_offload,
                )
                if partial_block_index is not None and partial_block_index < len(block_ids_by_group):
                    partial_key = self._make_layerwise_partial_key(
                        request,
                        group_id,
                        partial_block_index,
                        request.target_token_len,
                    )
                    partial_gva = self._allocated_gvas.get(partial_key)
                    if partial_gva is None:
                        allocated = self.m_store.batch_alloc(
                            [partial_key],
                            [alloc_size],
                            LAYERWISE_READ_LEASE_TTL_MS,
                        )
                        partial_gva = allocated[0] if allocated else 0
                        if partial_gva > 0:
                            self._allocated_gvas[partial_key] = partial_gva
                            all_group_save_keys.append(partial_key)
                        else:
                            logger.error(
                                "alloc_gvas: partial allocation failed req=%s group=%d block=%d gva=%d",
                                request.req_id,
                                group_id,
                                partial_block_index,
                                partial_gva,
                            )
                    # Partial keys are request-scoped; do not retain them forever.
                    self._allocated_gvas.pop(partial_key, None)
                    request.partial_save_gva_per_group[group_id] = partial_gva

                logger.debug(
                    "alloc_gvas: req=%s group=%d eff_bs=%d save_blocks=[%d,%d) "
                    "new_keys=%d cached_keys=%d masked=%s alloc_size=%d",
                    request.req_id,
                    group_id,
                    effective_block_size,
                    save_start_block,
                    save_end_block,
                    len(new_keys),
                    len(block_gvas) - len(new_keys),
                    group_store_mask is not None,
                    alloc_size,
                )

                # Pad block_gvas to match block_ids length (fill 0 for non-transferred blocks)
                full_gvas = [0] * len(block_ids_by_group)
                for blk_idx, gva in zip(transfer_blocks, block_gvas):
                    if blk_idx < len(full_gvas):
                        full_gvas[blk_idx] = gva

                all_group_gvas.append(np.asarray(full_gvas, dtype=np.int64))
                all_group_block_ids.append(np.asarray(block_ids_by_group, dtype=np.int64))

            if all_group_gvas:
                request.save_keys = all_group_save_keys
                request.block_gvas_by_group_np = all_group_gvas
                request.block_ids_by_group_np = all_group_block_ids
                request.block_gvas_np = all_group_gvas[0]
                request.gva_block_offset = 0

    def _prepare_load_gvas(self, requests: list[ReqMeta]) -> None:
        """Fetch per-rank GVA and acquire read lease for the load path.

        memcache requires batch_copy (read) to find the blob in the per-process
        gvaBlobTracker with a valid lease. The scheduler only checks existence
        (batch_is_exist) to decide the load range; before batch_copy(G2L) the
        worker must, for its own per-rank keys:
          1. batch_get_key_info to fetch the GVA (fills block_gvas_np)
          2. batch_add_lease to register the blob locally + acquire a read lease
        """
        if not self.use_layerwise_transfer:
            return
        for request in requests:
            if request.load_spec is None or not request.load_spec.can_load:
                continue
            cached_tokens = request.load_spec.kvpool_cached_tokens
            if not getattr(self, "use_eagle", False) and request.load_spec.kvpool_store_skip_tokens is not None:
                cached_tokens = request.load_spec.kvpool_store_skip_tokens
            if (
                getattr(self, "use_eagle", False)
                and request.load_spec.kvpool_cached_tokens == request.target_token_len - 1
            ):
                # Full-hit path: the trailing block is recomputed and will be
                # re-stored by the normal save path, so never skip it here.
                logger.debug(
                    "Reqid: %s full-hit tail recompute path, tail block will be re-stored",
                    request.req_id,
                )
            block_hashes = request.block_hashes
            request.load_masks = self._compute_reachable_load_masks(request, cached_tokens)

            all_group_load_gvas: list[np.ndarray] = []
            all_group_load_keys: list[str] = []
            request.partial_load_gva_per_group = [0] * self.num_kv_cache_groups
            for group_id in range(self.num_kv_cache_groups):
                group_block_size = self.grouped_block_size[group_id]
                effective_block_size = group_block_size

                group_block_hashes = get_block_hashes(block_hashes, effective_block_size, self.hash_block_size)
                load_start_block = (
                    0 if self.layerwise_offload else request.load_spec.vllm_cached_tokens // effective_block_size
                )
                cached_full_blocks = cached_tokens // effective_block_size
                full_blocks = min(cached_full_blocks, len(group_block_hashes))

                block_ids_by_group = (
                    request.block_ids_by_group_np[group_id]
                    if (request.block_ids_by_group_np is not None and group_id < len(request.block_ids_by_group_np))
                    else request.block_ids_np
                )
                if block_ids_by_group is None:
                    all_group_load_gvas.append(np.zeros(0, dtype=np.int64))
                    continue
                full_len = len(block_ids_by_group)

                partial_block_index = get_partial_block_index(
                    cached_tokens,
                    effective_block_size,
                    len(group_block_hashes),
                    self.layerwise_offload,
                )
                if partial_block_index is not None and (
                    partial_block_index < load_start_block or partial_block_index >= full_len
                ):
                    partial_block_index = None

                if load_start_block >= full_blocks and partial_block_index is None:
                    all_group_load_gvas.append(np.zeros(full_len, dtype=np.int64))
                    continue

                group_load_mask = (
                    request.load_masks[group_id]
                    if request.load_masks is not None and group_id < len(request.load_masks)
                    else None
                )
                block_indices = [
                    block_idx
                    for block_idx in range(load_start_block, full_blocks)
                    if group_load_mask is None or block_idx >= len(group_load_mask) or group_load_mask[block_idx]
                ]
                keys = [
                    self._make_layerwise_full_key(group_id, block_hash_to_str(group_block_hashes[block_idx]))
                    for block_idx in block_indices
                ]
                has_partial_key = False
                if partial_block_index is not None:
                    keys.append(
                        self._make_layerwise_partial_key(
                            request,
                            group_id,
                            partial_block_index,
                            cached_tokens,
                        )
                    )
                    block_indices.append(partial_block_index)
                    has_partial_key = True
                if not keys:
                    all_group_load_gvas.append(np.zeros(full_len, dtype=np.int64))
                    continue

                # PERF-TUNE(4): dedup identical keys across concurrent requests
                ki_cache = getattr(self, "_step_keyinfo_cache", None) or {}
                self._step_keyinfo_cache = ki_cache
                uncached = [k for k in keys if k not in ki_cache]
                if uncached:
                    fetched_infos = self.m_store.batch_get_key_info(uncached)
                    if len(fetched_infos) != len(uncached):
                        raise RuntimeError(
                            "MemCache key info check returned unexpected number of results: "
                            f"expected={len(uncached)}, actual={len(fetched_infos)}"
                        )
                    for k, ki in zip(uncached, fetched_infos):
                        ki_cache[k] = ki
                key_infos = [ki_cache[k] for k in keys]
                gvas = []
                valid_gva_indices = []
                invalid_block_ids: list[int] = []
                for ki, key, block_idx in zip(key_infos, keys, block_indices):
                    sizes = ki.size()
                    gva = ki.gva_list()[0] if sizes and sizes > 0 else 0
                    gvas.append(gva)
                    if gva > 0:
                        valid_gva_indices.append(len(gvas) - 1)
                    else:
                        if block_idx < len(block_ids_by_group):
                            invalid_block_ids.append(int(block_ids_by_group[block_idx]))
                        logger.warning(
                            "load_gvas: req=%s group=%d got invalid gva=%d (size=%d), block_id=%s load failed",
                            request.req_id,
                            group_id,
                            gva,
                            sizes if sizes else 0,
                            int(block_ids_by_group[block_idx]) if block_idx < len(block_ids_by_group) else "N/A",
                        )

                # Only call batch_add_lease for keys with valid size.
                # PERF-TUNE(4): keys leased earlier in this step reuse their
                # recorded result code; only new keys hit the RPC. The result
                # list below stays aligned with valid_gva_indices.
                lease_cache = getattr(self, "_step_lease_result", None) or {}
                self._step_lease_result = lease_cache
                valid_keys = [keys[index] for index in valid_gva_indices]
                new_lease_keys = [k for k in valid_keys if k not in lease_cache]
                if new_lease_keys:
                    new_results = self.m_store.batch_add_lease(new_lease_keys, LAYERWISE_READ_LEASE_TTL_MS)
                    if len(new_results) != len(new_lease_keys):
                        raise RuntimeError(
                            "MemCache lease returned unexpected number of results: "
                            f"expected={len(new_lease_keys)}, actual={len(new_results)}"
                        )
                    for k, res in zip(new_lease_keys, new_results):
                        lease_cache[k] = res
                if valid_keys:
                    lease_results = [lease_cache[k] for k in valid_keys]
                    leased_keys = []
                    for gva_index, lease_res in zip(valid_gva_indices, lease_results):
                        block_idx = block_indices[gva_index]
                        if lease_res == MEMCACHE_UNMATCHED_STATE and block_idx == partial_block_index:
                            partial_key = keys[gva_index]
                            for retry in range(1, PARTIAL_LEASE_RETRY_COUNT + 1):
                                time.sleep(PARTIAL_LEASE_RETRY_INTERVAL_S)
                                retry_results = self.m_store.batch_add_lease(
                                    [partial_key],
                                    LAYERWISE_READ_LEASE_TTL_MS,
                                )
                                if len(retry_results) != 1:
                                    raise RuntimeError(
                                        "MemCache partial lease retry returned "
                                        f"unexpected number of results: {len(retry_results)}"
                                    )
                                lease_res = retry_results[0]
                                lease_cache[partial_key] = lease_res
                                if lease_res != MEMCACHE_UNMATCHED_STATE:
                                    break
                        block_id = int(block_ids_by_group[block_idx]) if block_idx < len(block_ids_by_group) else None
                        if lease_res == 0:
                            leased_keys.append(keys[gva_index])
                        else:
                            gvas[gva_index] = 0
                            if block_id is not None:
                                invalid_block_ids.append(block_id)
                            logger.warning(
                                "load_gvas: req=%s group=%d lease failed result=%d, block_id=%s load failed",
                                request.req_id,
                                group_id,
                                lease_res,
                                block_id,
                            )
                else:
                    lease_results = []
                    leased_keys = []

                # Report invalid blocks to scheduler for recompute.
                # Single-group models can safely report individual block IDs.
                # Multi-group (hybrid) models must not report partial group
                # failures, as the scheduler cannot handle inconsistent KV
                # cache state across groups (see PR #9701 for rationale).
                if invalid_block_ids:
                    if self.num_kv_cache_groups == 1:
                        with self._invalid_block_ids_lock:
                            self._invalid_block_ids.update(invalid_block_ids)
                    else:
                        leased_keys_to_release = list(
                            dict.fromkeys(
                                [
                                    *all_group_load_keys,
                                    *leased_keys,
                                ]
                            )
                        )
                        if leased_keys_to_release:
                            self.m_store.batch_remove_lease(leased_keys_to_release)
                        raise RuntimeError(
                            "Layerwise multi-group KV load failed and cannot "
                            "safely fall back to per-block recomputation: "
                            f"request={request.req_id}, "
                            f"failed_blocks={invalid_block_ids}"
                        )
                all_group_load_keys.extend(leased_keys)

                logger.debug(
                    "load_gvas: req=%s group=%d eff_bs=%d load_blocks=[%d,%d) keys=%d valid_gvas=%d lease_fail=%d",
                    request.req_id,
                    group_id,
                    effective_block_size,
                    load_start_block,
                    full_blocks,
                    len(keys),
                    sum(1 for g in gvas if g > 0),
                    sum(1 for r in lease_results if r != 0),
                )

                # Pad to match block_ids_by_group length, filling only the
                # positions whose keys were actually queried (the trailing
                # partial key is excluded from the per-position fill).
                full_gvas = [0] * full_len
                full_key_count = len(block_indices) - (1 if has_partial_key else 0)
                for gva_index in range(full_key_count):
                    block_idx = block_indices[gva_index]
                    if block_idx < len(full_gvas):
                        full_gvas[block_idx] = gvas[gva_index]
                all_group_load_gvas.append(np.asarray(full_gvas, dtype=np.int64))
                if has_partial_key and gvas:
                    request.partial_load_gva_per_group[group_id] = gvas[-1]

            if all_group_load_gvas:
                request.load_keys = all_group_load_keys
                request.load_block_gvas_by_group_np = all_group_load_gvas
                request.load_block_gvas_np = all_group_load_gvas[0]
                request.load_gva_block_offset = 0

    def _record_layerwise_invalid_blocks(self, block_ids: list[int]) -> None:
        if not block_ids:
            return
        with self._invalid_block_ids_lock:
            self._invalid_block_ids.update(block_ids)

    def _is_layerwise_save_owner(self) -> bool:
        return is_kv_save_role(self.kv_role, self.consumer_is_to_put) and self.tp_rank % self.put_step == 0

    def _make_mooncake_layerwise_key(self, block_hash_or_tail: str) -> str:
        return self._make_layerwise_full_key(0, block_hash_or_tail)

    def _groups_for_layerwise_transfer(self, local_layer: int) -> list[tuple[int, int]]:
        if self.use_block_key_layerwise:
            # The map and buffer builders both use stage-local physical layer
            # indices. A group's dense layer index is a third, distinct axis.
            if self.num_kv_cache_groups == 1:
                return [(0, local_layer)]
            groups = self.physical_layer_to_group_layers.get(local_layer)
            if groups is None:
                raise RuntimeError(f"Mooncake layerwise: no KV cache group for local layer {local_layer}")
            return groups
        # GVA groups use stage-local indices too; PP offsets apply to pool keys and remote addresses.
        return self.physical_layer_to_group_layers.get(local_layer, [(0, local_layer)])

    def _layerwise_key_batches(self, keys: list[str]) -> list[list[str]]:
        batch_size = self.layerwise_max_transfer_blocks if self.layerwise_max_transfer_blocks > 0 else max(1, len(keys))
        return [keys[start : start + batch_size] for start in range(0, len(keys), batch_size)]

    def _filter_pool_existing_keys(self, keys: list[str]) -> list[str]:
        """Drop keys whose block is already readable in the pool.

        A block-key backend may reject overwriting a committed object: the put
        session start fails for that key and a following range write can make
        the readable object unusable. The layerwise save path must therefore
        never open a session over a key that is already complete.

        This mirrors ``KVCacheStoreSendingThread._get_missing_indices``, which
        is what keeps the non-layerwise path immune to both repeat requests
        sharing a prefix and concurrent prefill ranks writing the same keys.

        Returns the subset of ``keys`` that is safe to start a session for.
        Failing open (treat as missing) is intentional: an unreadable pool costs
        hits, while a bogus skip would cost the blocks themselves.
        """
        if not keys:
            return []
        if not getattr(self.m_store, "requires_exists_before_put", True):
            return keys
        exists = getattr(self.m_store, "exists", None)
        if not callable(exists):
            exists = getattr(self.m_store, "batch_is_exist", None)
        if not callable(exists):
            return keys

        missing: list[str] = []
        for key_batch in self._layerwise_key_batches(keys):
            try:
                states = exists(key_batch)
                if len(states) != len(key_batch):
                    raise RuntimeError(
                        "Block-key pool existence check returned unexpected number of states: "
                        f"expected={len(key_batch)}, actual={len(states)}"
                    )
                missing.extend(key for key, state in zip(key_batch, states, strict=True) if int(state) != 1)
            except Exception as exc:
                logger.error(
                    "Block-key pool existence check failed keys=%d error=%s; treating all as missing",
                    len(key_batch),
                    exc,
                )
                missing.extend(key_batch)
        return missing

    def _start_layerwise_put_keys(self, keys: list[str], object_size: int) -> list[int]:
        results: list[int] = []
        for key_batch in self._layerwise_key_batches(keys):
            results.extend(
                require_aligned_batch_results(
                    "batch_put_start",
                    key_batch,
                    self.m_store.batch_put_start(key_batch, [object_size] * len(key_batch)),
                )
            )
        return results

    def _start_layerwise_get_keys(self, keys: list[str]) -> list[int]:
        results: list[int] = []
        for key_batch in self._layerwise_key_batches(keys):
            results.extend(
                require_aligned_batch_results(
                    "batch_get_start",
                    key_batch,
                    self.m_store.batch_get_start(key_batch),
                )
            )
        return results

    def _layerwise_object_size_bytes(self) -> int:
        group_block_len = getattr(self, "group_block_len", {}).get(0, [])
        object_size = sum(group_block_len) if group_block_len else self.page_size_bytes
        if object_size <= 0:
            raise RuntimeError(f"Layerwise object size must be positive, got {object_size}")
        return object_size

    def _queue_layerwise_revoke_keys(self, keys: list[str]) -> None:
        if not keys:
            return
        try:
            assert isinstance(self.kv_send_thread, KVCacheStoreLayerSendingThread)
            self.kv_send_thread.add_revoke_request(keys)
        except Exception as exc:
            logger.error("Failed to queue layerwise revoke keys=%s error=%s", keys, exc)
            with self._put_started_keys_lock:
                self._put_started_keys.difference_update(keys)

    def _end_layerwise_load_keys(self, keys: list[str]) -> None:
        for key_batch in self._layerwise_key_batches(list(dict.fromkeys(keys))):
            try:
                result = self.m_store.batch_get_end(key_batch)
                if result != 0:
                    logger.error("Layerwise batch_get_end failed keys=%s result=%s", key_batch, result)
            except Exception as exc:
                logger.error("Layerwise batch_get_end raised keys=%s error=%s", key_batch, exc)

    def _release_layerwise_requests_for_retry(self, req_ids: set[str]) -> None:
        with self._load_session_lock:
            self._end_layerwise_load_keys(self._layerwise_session_tracker.release_for_retry(req_ids))

    def _release_layerwise_requests_terminal(self, req_ids: set[str]) -> None:
        with self._load_session_lock:
            self._end_layerwise_load_keys(self._layerwise_session_tracker.release_terminal(req_ids))

    def _release_failed_layerwise_get_attempts(self, request_ids_by_key: dict[str, set[str]]) -> None:
        with self._load_session_lock:
            keys = self._layerwise_session_tracker.release_failed_get_attempts(request_ids_by_key)
            self._end_layerwise_load_keys(keys)

    def _finish_current_layerwise_load_sessions(self) -> None:
        if not self.use_block_key_layerwise:
            return
        if self._layer_load_aborted.is_set():
            req_ids = self._current_layerwise_request_ids.copy()
            self._release_layerwise_requests_for_retry(req_ids)
        else:
            req_ids = self._current_layerwise_last_chunk_req_ids.copy()
            self._release_layerwise_requests_terminal(req_ids)
        self._current_layerwise_request_ids.difference_update(req_ids)
        self._current_layerwise_last_chunk_req_ids.difference_update(req_ids)

    def _prepare_layerwise_put_session(self, request: ReqMeta) -> None:
        request.save_block_keys = []
        request.save_last_block_key = None
        if not self._is_layerwise_save_owner() or not request.can_save:
            return

        start_block = request.save_start_token // self.block_size
        end_block = request.save_end_token // self.block_size
        if request.load_spec is not None and request.load_spec.can_load:
            pool_hit_tokens = (
                request.load_spec.kvpool_store_skip_tokens
                if request.load_spec.kvpool_store_skip_tokens is not None
                else request.load_spec.kvpool_cached_tokens
            )
            start_block = max(start_block, pool_hit_tokens // self.block_size)
        group_block_hashes = get_block_hashes(request.block_hashes, self.block_size, self.hash_block_size)
        request.save_key_block_offset = start_block
        request.save_block_keys = [None] * max(0, end_block - start_block)
        key_slots: list[tuple[str, int | None, int]] = []
        for block_index in range(start_block, min(end_block, len(group_block_hashes))):
            key = self._make_mooncake_layerwise_key(block_hash_to_str(group_block_hashes[block_index]))
            request.save_block_keys[block_index - start_block] = key
            key_slots.append((key, block_index - start_block, block_index))

        if request.partial_block_index is not None:
            request.save_last_block_key = self._make_mooncake_layerwise_key(f"{request.req_id}_lastblock")
            key_slots.append((request.save_last_block_key, None, request.partial_block_index))

        requested_keys = list(dict.fromkeys(key for key, _, _ in key_slots))
        if not requested_keys:
            return
        with self._put_started_keys_lock:
            previously_started = set(requested_keys) & self._put_started_keys
            new_keys = [key for key in requested_keys if key not in self._put_started_keys]

        started = set(previously_started)
        if new_keys:
            try:
                results = self._start_layerwise_put_keys(new_keys, self._layerwise_object_size_bytes())
            except Exception as exc:
                logger.error("Layerwise batch_put_start failed keys=%s error=%s", new_keys, exc)
                with self._put_started_keys_lock:
                    self._put_started_keys.update(new_keys)
                self._queue_layerwise_revoke_keys(new_keys)
            else:
                newly_started = {key for key, result in zip(new_keys, results, strict=True) if result == 0}
                with self._put_started_keys_lock:
                    self._put_started_keys.update(newly_started)
                started.update(newly_started)

        for key, slot, _ in key_slots:
            if key in started:
                if slot is None:
                    request.save_last_block_key = key
            elif slot is None:
                request.save_last_block_key = None
            else:
                request.save_block_keys[slot] = None
        self._layerwise_session_tracker.register_put_keys(
            request.req_id,
            ((key, block_index) for key, _, block_index in key_slots if key in started),
        )

    def _prepare_layerwise_get_session(self, request: ReqMeta) -> list[tuple[str, int, int | None]]:
        request.load_block_keys = []
        request.load_last_block_key = None
        request.load_keys = []
        current_entries: list[tuple[str, int]] = []
        load_spec = request.load_spec
        if load_spec is not None and load_spec.can_load:
            cached_tokens = load_spec.kvpool_cached_tokens
            if not self.use_eagle and load_spec.kvpool_store_skip_tokens is not None:
                cached_tokens = load_spec.kvpool_store_skip_tokens
            start_block = load_spec.vllm_cached_tokens // self.block_size
            cached_full_blocks = cached_tokens // self.block_size
            group_block_hashes = get_block_hashes(request.block_hashes, self.block_size, self.hash_block_size)
            end_block = min(cached_full_blocks, len(group_block_hashes))
            for block_index in range(start_block, end_block):
                current_entries.append(
                    (
                        self._make_mooncake_layerwise_key(block_hash_to_str(group_block_hashes[block_index])),
                        block_index,
                    )
                )
            needs_last_block = cached_tokens % self.block_size != 0 or (
                cached_tokens > 0 and end_block < cached_full_blocks
            )
            partial_block_index = cached_full_blocks if cached_tokens % self.block_size else cached_full_blocks - 1
            if needs_last_block and 0 <= partial_block_index < len(request.block_ids):
                current_entries.append(
                    (
                        self._make_mooncake_layerwise_key(f"{request.req_id}_lastblock"),
                        partial_block_index,
                    )
                )

        load_entries = self._layerwise_session_tracker.prepare_load_entries(request.req_id, current_entries)
        valid_entries = [
            (key, block_index) for key, block_index in load_entries if 0 <= block_index < len(request.block_ids)
        ]
        if not valid_entries:
            return []
        request.load_key_block_offset = 0
        request.load_block_keys = [None] * (max(block_index for _, block_index in valid_entries) + 1)
        key_slots: list[tuple[str, int, int | None]] = []
        for key, block_index in valid_entries:
            request.load_block_keys[block_index] = key
            key_slots.append((key, request.block_ids[block_index], block_index))
        return key_slots

    def _open_layerwise_get_sessions(self, request_key_slots: list[tuple[ReqMeta, str, int, int | None]]) -> None:
        if not request_key_slots:
            return
        keys = list(dict.fromkeys(key for _, key, _, _ in request_key_slots))
        request_ids_by_key: dict[str, set[str]] = {}
        for request, key, _, _ in request_key_slots:
            request_ids_by_key.setdefault(key, set()).add(request.req_id)
        try:
            results = self._start_layerwise_get_keys(keys)
        except Exception as exc:
            logger.error("Layerwise batch_get_start failed keys=%s error=%s", keys, exc)
            self._release_failed_layerwise_get_attempts(request_ids_by_key)
            self._record_layerwise_invalid_blocks([block_id for _, _, block_id, _ in request_key_slots])
            for request, _, _, slot in request_key_slots:
                if slot is None:
                    request.load_last_block_key = None
                else:
                    request.load_block_keys[slot] = None
            return

        results_by_key = dict(zip(keys, results, strict=True))
        for key, result in results_by_key.items():
            self._layerwise_session_tracker.record_get_result(key, request_ids_by_key[key], succeeded=result == 0)
        request_load_keys: dict[int, list[str]] = {}
        request_seen_keys: dict[int, set[str]] = {}
        requests_by_id: dict[int, ReqMeta] = {}
        for request, key, block_id, slot in request_key_slots:
            request_identity = id(request)
            requests_by_id[request_identity] = request
            request_load_keys.setdefault(request_identity, [])
            request_seen_keys.setdefault(request_identity, set())
            if results_by_key[key] == 0:
                if key not in request_seen_keys[request_identity]:
                    request_load_keys[request_identity].append(key)
                    request_seen_keys[request_identity].add(key)
                continue
            self._record_layerwise_invalid_blocks([block_id])
            if slot is None:
                request.load_last_block_key = None
            else:
                request.load_block_keys[slot] = None
        for request_identity, request in requests_by_id.items():
            request.load_keys = request_load_keys[request_identity]

    def _prepare_block_key_layerwise_sessions(self, requests: list[ReqMeta]) -> None:
        self._layer_load_aborted.clear()
        self._current_layerwise_request_ids = {request.req_id for request in requests}
        self._current_layerwise_last_chunk_req_ids = {request.req_id for request in requests if request.is_last_chunk}
        get_key_slots: list[tuple[ReqMeta, str, int, int | None]] = []
        for request in requests:
            get_key_slots.extend(
                (request, key, block_id, slot) for key, block_id, slot in self._prepare_layerwise_get_session(request)
            )
        self._open_layerwise_get_sessions(get_key_slots)
        for request in requests:
            self._prepare_layerwise_put_session(request)

    def _build_shared_save_data(self) -> None:
        """Build shared block data once and attach to all layer save tasks.

        For GVA path (KVCacheStoreLayerSendingThread): pre-computes
        SharedBlockData via LayerBatchBuilder.build_shared().

        For Key path (KVCacheStoreKeyLayerSendingThread): pre-computes
        cached process_tokens via build_cached_process_tokens().

        In multi-group mode, shared data is built per-group because each
        group has different block_ranges (different effective_block_size).
        """
        if isinstance(self.kv_send_thread, KVCacheStoreLayerSendingThread):
            all_save_keys: list[str] = []
            for group_id in range(self.num_kv_cache_groups):
                first_task = None
                for layer_id in range(self.num_layers):
                    for task in self.layer_save_tasks[layer_id]:
                        if task.group_id == group_id:
                            first_task = task
                            break
                    if first_task:
                        break
                if first_task is None:
                    continue
                shared = self.kv_send_thread.build_shared_data(first_task)
                if shared is not None:
                    all_save_keys.extend(shared.save_keys)
                    for layer_id in range(self.num_layers):
                        for task in self.layer_save_tasks[layer_id]:
                            if task.group_id == group_id:
                                task.shared_block_data = shared
            last_task = None
            for tasks in self.layer_save_tasks:
                for task in tasks:
                    task.write_finish_keys.clear()
                    if task.shared_block_data is not None:
                        last_task = task
            if last_task is not None:
                last_task.write_finish_keys.extend(dict.fromkeys(all_save_keys))
        elif isinstance(self.kv_send_thread, KVCacheStoreKeyLayerSendingThread):
            first_task = None
            for layer_id in range(self.num_layers):
                if self.layer_save_tasks[layer_id]:
                    first_task = self.layer_save_tasks[layer_id][0]
                    break
            if first_task is None:
                return
            cached = self.kv_send_thread.build_cached_process_tokens(first_task)
            if cached is not None:
                for layer_id in range(self.num_layers):
                    for task in self.layer_save_tasks[layer_id]:
                        task.cached_process_tokens = cached

    def _build_shared_load_data(self) -> None:
        """Build shared block data once and attach to all layer load tasks.

        In multi-group mode, shared data is built per-group because each
        group has different block_ranges (different effective_block_size).
        """
        if not isinstance(self.kv_recv_thread, KVCacheStoreLayerRecvingThread):
            return
        for group_id in range(self.num_kv_cache_groups):
            first_task = None
            for layer_id in range(self.num_layers):
                for task in self.layer_load_tasks[layer_id]:
                    if task.group_id == group_id:
                        first_task = task
                        break
                if first_task:
                    break
            if first_task is None:
                continue
            shared = self.kv_recv_thread.build_shared_data(first_task)
            if shared is not None:
                for layer_id in range(self.num_layers):
                    for task in self.layer_load_tasks[layer_id]:
                        if task.group_id == group_id:
                            task.shared_block_data = shared

    def _compute_reachable_store_masks(
        self,
        request: ReqMeta,
    ) -> tuple[Sequence[bool] | None, ...] | None:
        """Per-group reachable-store masks for the layerwise save path.

        Mirrors the non-layerwise store path (KVCacheStoreSendingThread):
        for reachability-limited groups (sliding window / compressor state)
        only the blocks the KV cache managers consider reachable are
        persisted, instead of the full sequence. Falls back to None (store
        everything) when the coordinator is unavailable or the save extent
        is not aligned.
        """
        if getattr(self, "block_key_hybrid", False) and request.can_save and request.save_end_token > 0:
            if self.cache_coordinator is None or request.save_end_token % self.cache_transfer_granularity:
                raise ValueError("Block-key hybrid saves require a coordinator-aligned full-block boundary")
            return self.token_database.store_mask(request.save_end_token, request.num_prompt_tokens)
        if self.cache_coordinator is None:
            return None
        if request.save_end_token <= 0:
            return None
        if request.save_end_token % self.cache_transfer_granularity != 0:
            return None
        try:
            return self.token_database.store_mask(request.save_end_token, request.num_prompt_tokens)
        except AssertionError:
            return None

    def _compute_reachable_load_masks(
        self,
        request: ReqMeta,
        cached_tokens: int,
    ) -> tuple[Sequence[bool] | None, ...] | None:
        """Per-group load masks for the layerwise load path.

        Mirrors the non-layerwise load path: only the blocks the KV cache
        managers need for a hit of ``cached_tokens`` are fetched, which is a
        subset of the blocks persisted by the reachable store masks.
        """
        if getattr(self, "block_key_hybrid", False) and cached_tokens > 0:
            if self.cache_coordinator is None:
                raise ValueError("Block-key hybrid loads require a reachability coordinator")
            return self.token_database.load_mask(request.block_hashes, cached_tokens)
        if self.cache_coordinator is None or cached_tokens <= 0:
            return None
        try:
            return self.token_database.load_mask(request.block_hashes, cached_tokens)
        except AssertionError:
            return None

    def _drain_deferred_last_save(self) -> None:
        """PERF-TUNE(2): deferred tail of the previous step's last-layer save."""
        if not getattr(self, "_pending_last_save_drain", False):
            return
        self._pending_last_save_drain = False
        assert self.kv_send_thread is not None
        # PP-aware: only the per-stage LOCAL layers are forwarded; mirror
        # save_kv_layer's num_local computation for the drain lifecycle.
        if getattr(self, "pp_size", 1) > 1:
            num_local = getattr(self, "layerwise_key_layers", 0) or self.num_layers
        else:
            num_local = self.num_layers
        self._wait_for_final_layer_save(num_local, self.kv_send_thread)

    def process_layer_data(self, requests: list[ReqMeta]) -> None:
        # Keep this method safe for direct callers as well as metadata binding.
        # Worker threads may still own the lists from the preceding step.
        self.layer_save_tasks = [[] for _ in range(self.num_layers)]
        self.layer_load_tasks = [[] for _ in range(self.num_layers)]
        if not requests:
            return
        # PERF-TUNE(4): cache repeated memcache RPC results within this step.
        self._step_keyinfo_cache = {}
        self._step_lease_result = {}
        self._step_exist_cache = {}
        # Mooncake uses the projected stage-local cache layout, including any
        # draft layers. The GVA/key planes retain their existing PP key count.
        if not self.use_block_key_layerwise and getattr(self, "pp_size", 1) > 1:
            num_local = getattr(self, "layerwise_key_layers", 0) or self.num_layers
        else:
            num_local = self.num_layers
        for request in requests:
            request.store_masks = self._compute_reachable_store_masks(request)
        group_requests = {}
        if self.use_block_key_layerwise:
            group_requests = self.layerwise_protocol.prepare_layerwise_sessions(self, requests)
        for local_layer in range(num_local):
            for group_id, layer_idx_in_group in self._groups_for_layerwise_transfer(local_layer):
                self._process_save_for_layer_batch(
                    group_requests.get(group_id, requests), local_layer, group_id, layer_idx_in_group
                )
        # Protect the previous partial before allocating the next snapshot.
        self._prepare_load_gvas(requests)
        self._alloc_gvas_for_save(requests)
        self._build_shared_save_data()
        for local_layer in range(num_local):
            for group_id, layer_idx_in_group in self._groups_for_layerwise_transfer(local_layer):
                self._process_load_for_layer_batch(
                    group_requests.get(group_id, requests), local_layer, group_id, layer_idx_in_group
                )
        self._build_shared_load_data()

    def _check_hybrid_load_errors(self) -> None:
        # A hybrid block ID can belong to SWA, compressed KV or compressor
        # state. Do not feed partially restored state to the attention kernel.
        with self._invalid_block_ids_lock:
            if self._invalid_block_ids:
                self._layer_load_aborted.set()
                raise RuntimeError("Hybrid layerwise load failed; refusing incomplete KV/state")

    def _submit_attention_save(self, layer_id: int) -> None:
        """Start current-layer put only once KV is ready at attention entry."""
        if not is_kv_save_role(self.kv_role, self.consumer_is_to_put):
            return
        assert self.sync_save_events is not None
        assert self.layer_save_finished_events is not None
        assert self.kv_send_thread is not None
        sync_save_events = self.sync_save_events
        save_finished_events = self.layer_save_finished_events
        send_thread = self.kv_send_thread
        self._attention_saved_layers.add(layer_id)
        sync_save_events[layer_id].record()
        tasks = self.layer_save_tasks[layer_id]
        if not tasks:
            save_finished_events[layer_id].set()
            return
        for task in tasks:
            for block_range in task.block_ranges:
                send_thread.add_stored_request(block_range.request.req_id)
        send_thread.add_request(tasks)

    def _finish_attention_window(self) -> None:
        try:
            self._drain_attention_transfers()
        except Exception:
            self._layer_load_aborted.set()
            self._finish_current_layerwise_load_sessions()
            raise

    def _drain_attention_transfers(self, drain_recv: bool | None = None, full: bool = False) -> None:
        """Apply the configured transfer policy at an attention boundary.

        The LOAD queue is deliberately left running. Every load this rank needs
        is already guaranteed complete by ``wait_for_layer_load`` before the
        layer consumes it, and the rest of that queue is exactly the prefetch
        issued for layers L+1..L+P to overlap with the compute currently in
        flight. Draining it here therefore waited, on every single layer, for
        transfers that were scheduled early on purpose, which is what pinned the
        fence at ~900 ms per layer and made layerwise slower than the
        non-layerwise bulk path. This matches the MemCache layerwise path, which
        gates the *start* of transfers to the attention boundary and never
        quiesces the load queue.

        The SAVE queue is bounded rather than drained. A committed block-key
        object is unreadable until the put session ends, so a put that is
        still open while the next collective launches cannot expose a partial
        block to any reader; the cost of waiting for it here is purely that the
        transfer stops overlapping compute. Letting the send thread run a bounded
        number of layers behind the compute stream keeps the ranged puts off the
        critical path, and ordering is preserved because that thread still
        consumes the queue in submission order. ``save_kv_layer`` waits for the
        final layer's save at the end of every step, which implies every earlier
        layer committed, so publication is still complete before the step ends.

        ``full`` drains the selected queues to zero, defaulting to both queues
        for teardown. Step completion passes ``drain_recv=False`` to wait only
        for outstanding PUTs.
        """
        if full and drain_recv is None:
            drain_recv = True
        elif drain_recv is None:
            drain_recv = self.layerwise_protocol.fence_drains_recv()
        channels = [("send", self.kv_send_thread)]
        if drain_recv:
            channels.insert(0, ("recv", self.kv_recv_thread))
        for channel, thread in channels:
            if thread is None:
                continue
            backlog_limit = 0 if (full or channel != "send") else self.layerwise_protocol.send_fence_backlog()
            queue = thread.request_queue
            with queue.all_tasks_done:
                while queue.unfinished_tasks > backlog_limit:
                    thread.raise_if_failed()
                    queue.all_tasks_done.wait(timeout=0.1)
            thread.raise_if_failed()
        if drain_recv and self.kv_recv_thread is not None:
            # Errors are still surfaced per layer by wait_for_layer_load.
            self._check_hybrid_load_errors()

    def _submit_ready_layer_loads(self) -> None:
        assert self.kv_recv_thread is not None
        recv_thread = self.kv_recv_thread

        def submit_layer_load(layer_id: int) -> bool:
            reuse_source = self.prefetch_layer_map.get(layer_id)
            if not self.layer_load_tasks[layer_id] and reuse_source is None:
                return False
            attention_start_gate = None
            if self.layer_load_tasks[layer_id] and layer_id != self.current_layer:
                attention_start_gate = get_attention_compute_start_gate()
            recv_thread.add_request(
                LayerLoadTask(  # type: ignore[arg-type]
                    wait_for_save_layer=reuse_source,
                    transfer_tasks=self.layer_load_tasks[layer_id],
                    layer_id=layer_id,
                    attention_start_gate=attention_start_gate,
                )
            )
            return True

        submit_count = self.num_prefetch_layers if self.current_layer == 0 else 1
        if getattr(self, "block_key_hybrid", False):
            submit_count = max(0, self.current_layer + self.num_prefetch_layers + 1 - self.next_layer_to_submit)
        submitted_layers = 0
        while submitted_layers < submit_count and self.next_layer_to_submit < self.num_layers:
            layer_id = self.next_layer_to_submit
            self.next_layer_to_submit += 1
            if submit_layer_load(layer_id):
                submitted_layers += 1

    def wait_for_layer_load(self) -> None:
        if self.current_layer >= self.num_layers:
            return
        assert self.layer_load_finished_events is not None
        assert self.kv_recv_thread is not None
        gate = reset_attention_compute_start_gate()
        try:
            self.kv_recv_thread.raise_if_failed()
            if getattr(self, "block_key_hybrid", False):
                layer_id = self.current_layer
                # Conv/recurrent state is updated inside attention, after this
                # entry event. Preserve its post-compute save hook.
                if layer_id not in self._recurrent_layers:
                    gate.on_start = lambda: self._submit_attention_save(layer_id)
                gate.on_finish = self._finish_attention_window
            if getattr(self, "block_key_hybrid", False) and self.next_layer_to_submit <= self.current_layer:
                # An unprefetched demand load must not race earlier collectives.
                boundary = torch.npu.Event()
                boundary.record()
                boundary.synchronize()
            self._submit_ready_layer_loads()
            should_wait = (
                bool(self.layer_load_tasks[self.current_layer]) or self.current_layer in self.prefetch_layer_map
            )
            if should_wait:
                while not self.layer_load_finished_events[self.current_layer].wait(timeout=10):
                    self.kv_recv_thread.raise_if_failed()
                    logger.info("Layerwise %d load not done, keep waiting", self.current_layer)
                self.kv_recv_thread.raise_if_failed()
            elif self.external_slot_release_waiter is not None:
                self.external_slot_release_waiter(self.current_layer)
            if getattr(self, "block_key_hybrid", False):
                self._check_hybrid_load_errors()
        except Exception:
            if hasattr(self, "_layer_load_aborted"):
                self._layer_load_aborted.set()
            if getattr(self, "block_key_hybrid", False):
                gate.cancel()
                # Range calls must finish before releasing their get sessions.
                with suppress(Exception):
                    self._drain_attention_transfers(full=True)
            if getattr(self, "use_block_key_layerwise", False):
                self._finish_current_layerwise_load_sessions()
            raise
        self.layer_load_finished_events[self.current_layer].clear()
        if getattr(self, "block_key_hybrid", False) and self.current_layer == self.num_layers - 1:
            # The final model layer can have no reachable load rows. Completion
            # belongs to the whole request, not whichever group happens to end here.
            for req_id in self._current_layerwise_last_chunk_req_ids:
                self.kv_recv_thread.set_finished_request(req_id)
        if getattr(self, "use_block_key_layerwise", False) and (
            self._layer_load_aborted.is_set() or self.current_layer == self.num_layers - 1
        ):
            self._finish_current_layerwise_load_sessions()
        if hasattr(self, "kv_role") and not is_kv_save_role(self.kv_role, getattr(self, "consumer_is_to_put", False)):
            self.current_layer += 1

    def get_block_ids_with_load_errors(self) -> set[int]:
        with self._invalid_block_ids_lock:
            invalid_blocks = self._invalid_block_ids.copy()
            self._invalid_block_ids.clear()
        return invalid_blocks

    def save_kv_layer(self, connector_metadata: AscendConnectorMetadata) -> None:
        # Match process_layer_data(), including stage-local draft layers.
        if not self.use_block_key_layerwise and getattr(self, "pp_size", 1) > 1:
            num_local = getattr(self, "layerwise_key_layers", 0) or self.num_layers
        else:
            num_local = self.num_layers
        if self.current_layer >= num_local:
            return
        assert self.sync_save_events is not None
        assert self.layer_save_finished_events is not None
        assert self.kv_send_thread is not None
        send_thread = self.kv_send_thread
        send_thread.raise_if_failed()
        if self.current_layer not in self._attention_saved_layers:
            self.sync_save_events[self.current_layer].record()
            if self.layer_save_tasks[self.current_layer]:
                for task in self.layer_save_tasks[self.current_layer]:
                    for block_range in task.block_ranges:
                        send_thread.add_stored_request(block_range.request.req_id)
                send_thread.add_request(self.layer_save_tasks[self.current_layer])  # type: ignore[arg-type]
            else:
                self.layer_save_finished_events[self.current_layer].set()
        if self.block_key_hybrid:
            # Recurrent and record-only paths do not exit an attention window.
            self._finish_attention_window()
        if self.current_layer == num_local - 1:
            if _LW_DEFER_LAST_SAVE:
                # PERF-TUNE(2): move the last layer's save drain off the forward
                # critical path. The drain (host wait + event reset) runs at the
                # start of the NEXT step's start_load_kv, absorbing the send
                # thread's tail latency into the inter-step scheduling gap.
                self._pending_last_save_drain = True
            else:
                self._wait_for_final_layer_save(num_local, send_thread)
        self.current_layer += 1

    def _wait_for_final_layer_save(self, num_local: int, send_thread: KVTransferThread) -> None:
        """Keep layerwise source buffers alive until the step's last PUT commits."""
        assert self.layer_save_finished_events is not None
        save_finished_events = self.layer_save_finished_events
        while not save_finished_events[num_local - 1].wait(timeout=10):
            send_thread.raise_if_failed()
            logger.info("Layerwise %d save not done, keep waiting", num_local - 1)
        send_thread.raise_if_failed()
        if self.block_key_hybrid:
            # An empty final layer signals completion without waiting for PUTs
            # from earlier layers. Drain those before the next step reuses KV.
            self._drain_attention_transfers(drain_recv=False, full=True)
        elif self.use_block_key_layerwise:
            # An empty final layer sets its event on the compute thread, ahead
            # of earlier queued PUTs. Drain at the step boundary before source
            # blocks can be reused. Layer-to-layer overlap remains unchanged.
            for layer_id in range(num_local - 1):
                while not save_finished_events[layer_id].wait(timeout=10):
                    send_thread.raise_if_failed()
            send_thread.raise_if_failed()
        reuse_source_layers = set(self.prefetch_layer_map.values())
        for layer_id in range(num_local):
            if layer_id in reuse_source_layers:
                continue
            if save_finished_events[layer_id].is_set():
                save_finished_events[layer_id].clear()

    def wait_for_previous_save(self) -> None:
        save_batch = self._previous_save_batch
        if save_batch is None:
            return

        assert self.kv_send_thread is not None
        send_thread = self.kv_send_thread
        wait_start = time.perf_counter()
        while True:
            send_thread.raise_if_failed()
            if save_batch.done.wait(timeout=SAVE_BATCH_FAILURE_POLL_INTERVAL_S):
                break
        elapsed = time.perf_counter() - wait_start
        logger.debug(
            "Previous KV save batch completed after waiting %.3f ms tp_rank=%d",
            elapsed * 1000,
            self.tp_rank,
        )
        self._previous_save_batch = None

    def wait_for_save(self, connector_metadata: AscendConnectorMetadata) -> None:
        current_event = None
        assert self.kv_send_thread is not None
        send_thread = self.kv_send_thread
        requests: list[ReqMeta] = []

        for request in connector_metadata.requests:
            can_save = request.can_save
            if can_save is None or not can_save:
                continue
            if current_event is None:
                current_event = torch.npu.Event()
                current_event.record()
            request.skip_null_blocks_by_group = self.group_uses_align_state
            request.current_event = current_event
            requests.append(request)

        if not requests:
            return

        if not isinstance(send_thread, KVCacheStoreSendingThread):
            raise TypeError(
                f"Non-layerwise KV save requires KVCacheStoreSendingThread, but got {type(send_thread).__name__}"
            )
        self._previous_save_batch = send_thread.add_save_batch(requests)

    def retrieve_layer(
        self,
        request: ReqMeta,
    ) -> Generator[torch.Tensor | None, None, None]:
        """
        Retrieve the KV cache in a layerwise manner.

        :param torch.Tensor tokens: The tokens of the corresponding KV caches.

        :param Optional[torch.Tensor] mask: The mask for the tokens. Should
            have the same length as tokens. And the mask should ALWAYS be like
            FFFFFTTTTTTT, where True means the tokens needs to be matched.

        :param **kwargs: The additional arguments for the KV transfer which
            will be passed into the npu_transfer.

        return: A generator that yields Optional[torch.Tensor]. The tensor will
            be the boolean mask indicating which tokens are retrieved and will
            only be returned in the last iteration.
        """
        token_len = request.token_len_chunk
        mask_num = (
            request.load_spec.vllm_cached_tokens  # type: ignore[union-attr]
            // self.block_size
            * self.block_size
        )
        num_required_tokens = token_len - mask_num

        ret_mask = torch.zeros(token_len, dtype=torch.bool, device="cpu")

        starts = []
        ends = []
        keys = []
        first_flag = True
        for start, end, key in self.token_database.process_tokens(token_len, request.block_hashes, mask_num):
            keys_multi_layer = key.split_layers(
                getattr(self, "layerwise_key_layers", 0) or self.num_layers,
                getattr(self, "layerwise_key_layer_offset", 0),
            )
            starts.append(start)
            ends.append(end)
            keys.append(keys_multi_layer)
            ret_mask[start:end] = True

        if keys:
            # Transpose the keys into layer major format
            keys = [list(row) for row in zip(*keys)]  # [num_layer,block_num]
            for layer_id, keys_multi_chunk in enumerate(keys):
                if not first_flag:
                    is_finish = self.get_event.wait(timeout=3)  # try---cache
                    if not is_finish:
                        logger.info(
                            "Layerwise get failed. Timeout waiting for get_event. Check receiver thread status."
                        )
                self.get_event.clear()
                req_meta = LayerMultiBlockReqMeta(
                    request.req_id, keys_multi_chunk, starts, ends, request.block_ids_by_group, layer_id
                )
                self.kv_recv_thread.add_request(  # type: ignore[union-attr, call-arg]
                    req_meta
                )  # type: ignore[union-attr, call-arg, arg-type]
                first_flag = False
                yield None
        else:
            # If no cache are found, we still need to yield to avoid
            # `StopIteration`
            for layer_id in range(self.num_layers):
                yield None

        retrieved_tokens = torch.sum(ret_mask)
        logger.debug(
            "Retrieved %s out of %s out of total %s tokens",
            retrieved_tokens,
            num_required_tokens,
            token_len,
        )

        yield ret_mask

    def store_layer(
        self,
        request: ReqMeta,
        current_event: torch.npu.Event | None,
    ) -> Generator[None, None, None]:
        """
        Store the KV cache in a layerwise manner.

        :param torch.Tensor tokens: The tokens of the corresponding KV caches.

        :param Optional[torch.Tensor] mask: The mask for the tokens. Should
            have the same length as tokens. And the mask should ALWAYS be like
            FFFFFTTTTTTT, where True means the tokens needs to be matched.

        :param **kwargs: The additional arguments for the storage backend which
            will be passed into the gpu_connector.

        return: A generator that yields None. In the first iteration, the
            generator allocates the memory objects for all layers and moves
            the KV cache of the first layer from GPU to CPU. In the next
            iterations, it moves the KV cache of layer i from GPU to the memory
            objects (on CPU) and puts the memory objects of layer i-1 to the
            storage backends. In the last iteration, it puts the memory objects
            of the last layer to the storage backends.
        """
        starts = []
        ends = []
        keys = []
        group_id = 0
        group_block_size = self.grouped_block_size[group_id]
        group_block_hashes = get_block_hashes(request.block_hashes, group_block_size, self.hash_block_size)
        for start, end, key in self.token_database.process_tokens(request.token_len_chunk, request.block_hashes):
            keys_multi_layer = key.split_layers(
                getattr(self, "layerwise_key_layers", 0) or self.num_layers,
                getattr(self, "layerwise_key_layer_offset", 0),
            )
            starts.append(start)
            ends.append(end)
            keys.append(keys_multi_layer)  # [block_num,layer_num]

        if keys:
            keys = [list(row) for row in zip(*keys)]  # [layer_num,block_num]
            for layer_id, keys_multi_chunk in enumerate(keys):
                req_meta = LayerMultiBlockReqMeta(
                    request.req_id,
                    keys_multi_chunk,
                    starts,
                    ends,
                    request.block_ids_by_group,
                    layer_id,
                    request.is_last_chunk,
                    current_event,
                    token_ids=request.token_ids,
                    original_block_size=request.original_block_size,
                    block_hashes=group_block_hashes,
                    kv_cache_group_id=group_id,
                )
                self.kv_send_thread.add_request(  # type: ignore[union-attr, call-arg]
                    req_meta
                )  # type: ignore[union-attr, call-arg, arg-type]
                yield
        else:
            for layer_id in range(self.num_layers):
                yield

    def _make_sub_key_str(self, base_key: str, effective_rank: int) -> str:
        """Rewrite ``@head_or_tp_rank:<local>`` in serialized ``base_key`` to ``<effective_rank>``.

        Under TP mismatch, both sides address the pool at the effective_tp_size
        namespace rather than the local TP rank.
        """
        return self._replace_key_field(base_key, "head_or_tp_rank", effective_rank)

    def _build_strided_addrs(self, block_id: int, token_count: int, sub_idx: int) -> tuple[list[int], list[int]]:
        """Build per-token (addr, size) pairs into local KV cache memory for one
        sub-key inside one block.

        KV cache layout: [num_block, block_size, num_kv_head_per_local_rank, head_dim].
        Heads of consecutive tokens are interleaved with token position, so a
        sub-slice of heads requires one transfer per token. Block stepping uses
        ``block_stride`` because the kernel may pad between blocks.
        """
        head_offset_bytes = sub_idx * self.sub_size_bytes
        addrs: list[int] = []
        sizes: list[int] = []
        # tp_mismatch is restricted to a single dense KV group -> group 0.
        group_addrs = self.group_kv_caches_base_addr[0]
        group_block_len = self.group_block_len[0]
        group_block_stride = self.group_block_stride[0]
        for base_addr, entry_block_len, entry_block_stride in zip(
            group_addrs, group_block_len, group_block_stride, strict=True
        ):
            entry_per_token_bytes = entry_block_len // self.block_size
            block_base = base_addr + block_id * entry_block_stride
            for t in range(token_count):
                addrs.append(block_base + t * entry_per_token_bytes + head_offset_bytes)
                sizes.append(self.sub_size_bytes)
        return addrs, sizes

    def _build_tp_mismatch_keys_and_addrs(
        self,
        block_hashes: list,
        block_ids: list[int],
        token_len: int,
        mask_num: int = 0,
        shard_rank: int | None = None,
        shard_size: int | None = None,
    ) -> tuple[list[str], list[list[int]], list[list[int]], list[int]]:
        """Walk chunks x sub-keys; emit (keys, addrs, sizes, block_ids) for backend put/get.

        Each key represents one (chunk, sub_idx) pair. Its addrs/sizes cover all
        layer-entries x all tokens in the chunk, addressed at the head-slice
        owned by sub_idx within this rank's local cache.
        """
        all_keys: list[str] = []
        all_addrs: list[list[int]] = []
        all_sizes: list[list[int]] = []
        all_block_ids: list[int] = []
        for start, end, base_key, _block_hash, block_id in self.token_database.process_token_key_strings_with_block_ids(
            token_len,
            block_hashes,
            block_ids,
            mask_num=mask_num,
            shard_rank=shard_rank,
            shard_size=shard_size,
        ):
            token_count = end - start
            for sub_idx in range(self.num_sub_keys):
                effective_rank = self.tp_rank * self.num_sub_keys + sub_idx
                addrs, sizes = self._build_strided_addrs(block_id, token_count, sub_idx)
                all_keys.append(self._make_sub_key_str(base_key, effective_rank))
                all_addrs.append(addrs)
                all_sizes.append(sizes)
                all_block_ids.append(block_id)
        return all_keys, all_addrs, all_sizes, all_block_ids

    def _load_kv_tp_mismatch(
        self,
        block_hashes: list,
        block_ids: list[int],
        token_len: int,
        mask_num: int,
    ) -> None:
        keys, addrs, sizes, key_block_ids = self._build_tp_mismatch_keys_and_addrs(
            block_hashes, block_ids, token_len, mask_num
        )
        if not keys:
            return
        offset = self.tp_rank % len(keys)
        keys_c = keys[offset:] + keys[:offset]
        addrs_c = addrs[offset:] + addrs[:offset]
        sizes_c = sizes[offset:] + sizes[:offset]
        block_ids_c = key_block_ids[offset:] + key_block_ids[:offset]
        logger.debug(
            "KV pool worker tp_mismatch get keys=%d sample_keys=%s",
            len(keys_c),
            keys_c[:3],
        )
        load_get_start = time.perf_counter()
        ret = self.m_store.get(keys_c, addrs_c, sizes_c)
        self._record_kv_connector_operation(
            "load_get",
            time.perf_counter() - load_get_start,
            len(keys_c),
        )
        if ret is not None and any(r != 0 for r in ret):
            missing_block_ids = record_failed_blocks(block_ids_c, ret)
            with self._invalid_block_ids_lock:
                self._invalid_block_ids.update(missing_block_ids)
        elif ret is None:
            missing_block_ids = record_failed_blocks(block_ids_c, [1] * len(block_ids_c))
            with self._invalid_block_ids_lock:
                self._invalid_block_ids.update(missing_block_ids)
        logger.debug(
            "KV pool worker tp_mismatch get returned keys=%d",
            len(keys_c),
        )

    def _store_kv_tp_mismatch(self, req_meta: ReqMeta) -> None:
        send_thread = self.kv_send_thread
        if send_thread is None:
            return
        req_id = req_meta.req_id
        if not send_thread.is_stored_request(req_id):  # type: ignore[attr-defined]
            return
        try:
            token_len = req_meta.token_len_chunk
            block_ids = req_meta.block_ids_by_group[0]
            keys, addrs, sizes, _ = self._build_tp_mismatch_keys_and_addrs(
                req_meta.block_hashes,
                block_ids,
                token_len,
                mask_num=0,
                shard_rank=self.pcp_rank,
                shard_size=self.pcp_size,
            )
            if not keys:
                return
            exists_states = send_thread.lookup(keys)  # type: ignore[attr-defined]
            missing_indices = [i for i, exists in enumerate(exists_states) if not exists]
            if not missing_indices:
                return
            keys = [keys[i] for i in missing_indices]
            addrs = [addrs[i] for i in missing_indices]
            sizes = [sizes[i] for i in missing_indices]
            if req_meta.current_event is not None:
                req_meta.current_event.synchronize()
            logger.debug(
                "KV pool worker tp_mismatch put req=%s keys=%d sample_keys=%s",
                req_id,
                len(keys),
                keys[:3],
            )
            self.m_store.put(keys, addrs, sizes)

            if self.enable_kv_events:
                event_block_size = (
                    req_meta.original_block_size[0]
                    if isinstance(req_meta.original_block_size, list)
                    else req_meta.original_block_size
                )
                stored_events: list[BlockStored] = []
                prev_key = None
                for idx, (start, end, _base_key) in enumerate(
                    self.token_database.process_tokens(token_len, req_meta.block_hashes)
                ):
                    if idx >= len(req_meta.block_hashes):
                        break
                    block_hash = maybe_convert_block_hash(req_meta.block_hashes[idx])
                    token_ids = req_meta.token_ids[start:end] if req_meta.token_ids is not None else None
                    stored_events.append(
                        BlockStored(
                            block_hashes=[block_hash],
                            parent_block_hash=prev_key,
                            token_ids=token_ids,
                            block_size=event_block_size,
                            lora_id=None,
                            medium="cpu",
                            lora_name=None,
                        )
                    )
                    prev_key = block_hash
                if stored_events:
                    send_thread.update_kv_event(stored_events)  # type: ignore[attr-defined]
        finally:
            send_thread.dec_stored_request(req_id)  # type: ignore[attr-defined]

    def get_finished(self, finished_req_ids: set[str], meta: AscendConnectorMetadata) -> tuple[set[str], set[str]]:
        if self.use_block_key_layerwise:
            self._release_layerwise_requests_terminal(finished_req_ids | meta.preempted_req_ids)
        if self.kv_send_thread is not None:
            send_thread = self.kv_send_thread
            for req_id in meta.preempted_req_ids:
                if isinstance(send_thread, (KVCacheStoreSendingThread, KVCacheStoreLayerSendingThread)):
                    send_thread.delete_finished_stored_request(req_id)
            self.kv_send_thread.discard_finished_requests(meta.preempted_req_ids)
            # Saves complete synchronously in wait_for_save(), so the scheduler
            # never waits for a request-level finished_sending notification.
            self.kv_send_thread.get_and_clear_finished_requests()
            done_sending: set[str] = set()
        else:
            done_sending = set()

        done_recving = set()
        if self.kv_recv_thread is not None:
            self.kv_recv_thread.discard_finished_requests(meta.preempted_req_ids)
            if self.load_async:
                done_recving = self.kv_recv_thread.get_and_clear_finished_requests(meta.loading_req_ids)

        logger.debug(
            "Number of completed KV cache send requests: %d, receive requests: %d, tp_rank:%d",
            len(done_sending),
            len(done_recving),
            self.tp_rank,
        )
        return done_sending, done_recving

    def ensure_store_initialized(self) -> None:
        ensure_initialized = getattr(self.m_store, "ensure_initialized", None)
        if ensure_initialized is not None:
            ensure_initialized()

    def _build_lookup_keys(
        self,
        token_len: int,
        block_hashes: list[BlockHash],
        group_id: int,
        use_layerwise: bool,
    ) -> tuple[list[str], list[int], list[int]]:
        keys: list[str] = []
        starts: list[int] = []
        ends: list[int] = []
        if use_layerwise:
            for start, end, pool_key in self.token_database.process_tokens(
                token_len, block_hashes, kv_cache_group_id=group_id
            ):
                keys.extend(
                    item.to_string()
                    for item in pool_key.split_layers(
                        getattr(self, "layerwise_key_layers", 0) or self.num_layers,
                        getattr(self, "layerwise_key_layer_offset", 0),
                    )
                )
                starts.append(start)
                ends.append(end)
        else:
            for start, end, key_string, _ in self.token_database.process_token_key_strings(
                token_len, block_hashes, kv_cache_group_id=group_id
            ):
                keys.append(key_string)
                starts.append(start)
                ends.append(end)
        return keys, starts, ends

    def lookup(
        self,
        token_len: int,
        block_hashes: list[BlockHash],
        kv_cache_group_ids: list[int] | None = None,
        use_layerwise: bool = False,
    ) -> int:
        """
        Checks the existence of KV cache of the tokens from the cache engine.
        :param tokens: the input tokens, with shape [seq_len]
        :return: An int indicating how many prefix tokens are cached.
        """
        try:
            hits = []
            kv_cache_group_ids = kv_cache_group_ids or [0]
            coordinator_hit = self._lookup_with_coordinator(
                token_len,
                block_hashes,
                kv_cache_group_ids,
                use_layerwise,
                include_all_ranks=False,
            )
            if coordinator_hit is not None:
                return coordinator_hit
            for group_id in kv_cache_group_ids:
                keys, starts, ends = self._build_lookup_keys(token_len, block_hashes, group_id, use_layerwise)

                if not keys:
                    hits.append(0)
                    continue

                res = self.m_store.exists(keys)  # type: ignore[assignment]

                if use_layerwise:
                    res = self.check_all_layers_exists(
                        res,
                        getattr(self, "layerwise_key_layers", 0) or self.num_layers,
                    )
                if group_id < len(self.group_uses_align_state) and self.group_uses_align_state[group_id]:
                    hit_end = 0
                    for index in range(len(ends) - 1, -1, -1):
                        if (
                            res[index] == 1  # type: ignore[index]
                            and ends[index] % self.cache_transfer_granularity == 0
                        ):
                            hit_end = ends[index]
                            break
                else:
                    hit_end = ends[-1]
                    for index, value in enumerate(res):  # type: ignore[arg-type]
                        if value != 1:
                            hit_end = 0
                            for hit_index in range(index, 0, -1):
                                if starts[hit_index] % self.cache_transfer_granularity == 0:
                                    hit_end = starts[hit_index]
                                    break
                            break
                hits.append(hit_end)
        except Exception as e:
            logger.error(
                "Remote connection failed in get_common_prefix_length. type=%s, error=%s. "
                "Check network and remote store.",
                type(e).__name__,
                e,
            )
            return 0
        return min(hits) if hits else 0

    def _get_group_num_kv_heads(self, group_id: int) -> int:
        if self.use_mla or self.use_sparse:
            return 1
        if group_id < len(self.group_uses_align_state) and self.group_uses_align_state[group_id]:
            return 1
        return self.num_kv_head

    def get_group_tp_size(self, kv_cache_group_id: int):
        if self.use_kvpp:
            return self.tp_size * self.pcp_size
        if self.tp_mismatch:
            return self.effective_tp_size
        if self.group_uses_align_state[kv_cache_group_id]:
            return self.tp_size
        return min(self.tp_size, self._get_group_num_kv_heads(kv_cache_group_id))

    @staticmethod
    def _replace_key_field(key: str, field: str, value: int) -> str:
        marker = f"@{field}:"
        start = key.find(marker)
        if start < 0:
            return key
        value_start = start + len(marker)
        value_end = key.find("@", value_start)
        if value_end < 0:
            value_end = len(key)
        return f"{key[:value_start]}{value}{key[value_end:]}"

    def _expand_lookup_keys_by_rank(self, keys: list[str], group_id: int) -> list[str]:
        # PCP replicas share keys; expand only the physical KV partitions.
        expanded: list[str] = []
        num_head_or_tp_ranks = self.get_group_tp_size(group_id)
        # Keep each rank shard's block/layer keys contiguous to match
        # lookup_scheduler()'s [rank_shard][block] result slicing.
        for pp_rank in range(self.pp_size):
            for dcp_rank in range(self.dcp_size):
                for head_or_tp_rank in range(num_head_or_tp_ranks):
                    for key in keys:
                        rank_key = self._replace_key_field(key, "dcp", dcp_rank)
                        rank_key = self._replace_key_field(rank_key, "head_or_tp_rank", head_or_tp_rank)
                        expanded.append(self._replace_key_field(rank_key, "pp_rank", pp_rank))
        return expanded

    def _expand_lookup_key_variants(self, key: str, group_id: int, include_all_ranks: bool) -> list[str]:
        if not include_all_ranks:
            return [key]
        return self._expand_lookup_keys_by_rank([key], group_id)

    def _lookup_with_coordinator(
        self,
        token_len: int,
        block_hashes: list[BlockHash],
        kv_cache_group_ids: list[int],
        use_layerwise: bool,
        include_all_ranks: bool,
        hbm_hit_tokens: int = 0,
    ) -> int | None:
        if self.cache_coordinator is None or use_layerwise:
            return None
        if sorted(kv_cache_group_ids) != list(range(self.num_kv_cache_groups)):
            return None
        coordinator = self.cache_coordinator

        def query_group_hits(
            group_id: int,
            group_block_hashes: Sequence[BlockHash | str],
            lookup_mask: Sequence[bool] | None,
        ) -> list[BlockHash | str]:
            group_block_size = coordinator.group_effective_block_sizes[group_id]
            present: list[BlockHash | str] = []
            if hbm_hit_tokens:
                # Blocks already computed locally are present by construction;
                # the pool only has to confirm the blocks beyond them.
                present.extend(group_block_hashes[: hbm_hit_tokens // group_block_size])
            lookup_start = hbm_hit_tokens // group_block_size * group_block_size

            def chunk_filter(
                start: int,
                group_block_size=group_block_size,
                lookup_mask=lookup_mask,
            ) -> bool:
                chunk_idx = start // group_block_size
                return lookup_mask is None or (chunk_idx < len(lookup_mask) and lookup_mask[chunk_idx])

            keys: list[str] = []
            chunk_hashes: list[BlockHash | str] = []
            variant_counts: list[int] = []
            for _, _, key_string, chunk_hash in self.token_database.process_token_key_strings(
                token_len,
                block_hashes,
                mask_num=lookup_start,
                kv_cache_group_id=group_id,
                chunk_filter=chunk_filter,
            ):
                variants = self._expand_lookup_key_variants(key_string, group_id, include_all_ranks)
                keys.extend(variants)
                chunk_hashes.append(chunk_hash)
                variant_counts.append(len(variants))

            if keys:
                res = self.m_store.exists(keys)  # type: ignore[assignment]
                offset = 0
                for chunk_hash, count in zip(chunk_hashes, variant_counts, strict=True):
                    values = res[offset : offset + count]  # type: ignore[index]
                    if values and all(value == 1 for value in values):
                        present.append(chunk_hash)
                    offset += count

            logger.debug(
                "KV pool coordinator lookup group=%d token_len=%d keys=%d exists_chunks=%d sample_keys=%s",
                group_id,
                token_len,
                len(keys),
                len(present),
                keys[:3],
            )
            return present

        return coordinator.find_reachable_hit_tokens(
            block_hashes,
            token_len,
            query_group_hits,
            log_context="KV pool coordinator lookup",
        )

    def lookup_scheduler(
        self,
        token_len: int,
        block_hashes: list[BlockHash],
        kv_cache_group_ids: list[int] | None = None,
        use_layerwise: bool = False,
        hbm_hit_tokens: int = 0,
    ) -> int:
        """
        Checks the existence of KV cache of the tokens from the cache engine.
        :param tokens: the input tokens, with shape [seq_len]
        :return: An int indicating how many prefix tokens are cached.
        """
        try:
            hits: list[list[int]] = []
            max_hit_position = self.max_model_len
            kv_cache_group_ids = kv_cache_group_ids or [0]
            coordinator_hit = self._lookup_with_coordinator(
                token_len,
                block_hashes,
                kv_cache_group_ids,
                use_layerwise,
                include_all_ranks=True,
                hbm_hit_tokens=hbm_hit_tokens,
            )
            if coordinator_hit is not None:
                return coordinator_hit
            for group_id in kv_cache_group_ids:
                keys, starts, ends = self._build_lookup_keys(token_len, block_hashes, group_id, use_layerwise)

                if not keys:
                    return 0

                multi_tp_keys = self._expand_lookup_keys_by_rank(keys, group_id)
                num_ranks = len(multi_tp_keys) // len(keys)
                res = self.m_store.exists(multi_tp_keys)  # type: ignore[assignment]
                num_block = len(keys)
                if use_layerwise:
                    res = self.check_all_layers_exists(
                        res,
                        getattr(self, "layerwise_key_layers", 0) or self.num_layers,
                    )
                    num_block = len(keys) // (getattr(self, "layerwise_key_layers", 0) or self.num_layers)
                multi_tp_values = [
                    res[i * num_block : (i + 1) * num_block]  # type: ignore[index]
                    for i in range(num_ranks)
                ]
                logger.debug(
                    "KV pool lookup request token_len=%d group=%d keys=%d multi_tp_keys=%d "
                    "exists_count=%d/%d exists_sample=%s sample_keys=%s",
                    token_len,
                    group_id,
                    len(keys),
                    len(multi_tp_keys),
                    sum(1 for value in res if value == 1),  # type: ignore[union-attr]
                    len(res),
                    list(res[: min(12, len(res))]),  # type: ignore[index]
                    multi_tp_keys[:3],
                )
                if group_id < len(self.group_uses_align_state) and self.group_uses_align_state[group_id]:
                    group_hits = self.find_all_discontinuous_hit_positions(
                        multi_tp_values, ends, num_block, max_hit_position, self.cache_transfer_granularity
                    )
                else:
                    group_hits = self.find_all_continuous_hit_positions(
                        multi_tp_values, ends, num_block, max_hit_position, self.cache_transfer_granularity
                    )
                if not group_hits:
                    return 0
                max_hit_position = min(max_hit_position, group_hits[-1])
                hits.append(group_hits)
                logger.debug(
                    "KV pool scheduler lookup group=%d keys=%d hit=%d token_len=%d",
                    group_id,
                    len(keys),
                    max_hit_position,
                    token_len,
                )
        except Exception as e:
            logger.error(
                "Remote connection failed in lookup. type=%s, error=%s. Check network and remote store.",
                type(e).__name__,
                e,
            )
            return 0
        final_hits = self._max_intersection_hit_position(hits)
        logger.debug(
            "KV pool scheduler lookup final token_len=%d groups=%s hit=%d",
            token_len,
            kv_cache_group_ids,
            final_hits,
        )
        return final_hits

    @staticmethod
    def _max_intersection_hit_position(hits: list[list[int]]) -> int:
        """
        For all attention groups, treat the position of the maximum common hit as the final hit position
        """
        if not hits:
            return 0
        common_elements = set(hits[0]).intersection(*hits[1:])
        if not common_elements:
            return 0
        return max(common_elements)

    def check_all_layers_exists(self, res: list[int], num_layers: int) -> list[int]:
        total_chunks = len(res) // num_layers
        result = []

        for chunk_idx in range(total_chunks):
            start = chunk_idx * num_layers
            end = start + num_layers
            chunk = res[start:end]
            result.append(1 if all(x == 1 for x in chunk) else 0)

        return result

    @staticmethod
    def find_all_discontinuous_hit_positions(
        arr, ends, num_blocks: int, max_hit_position: int, cache_transfer_granularity: int
    ) -> list[int]:
        """
        For mamba attn, there will be some uncached null blocks, we just collect all hit positions,
        and use the last position as final hit position
        """
        hits: list[int] = []
        for i in range(num_blocks):
            if ends[i] > max_hit_position:
                break
            if all(row[i] == 1 for row in arr):
                if ends[i] % cache_transfer_granularity == 0:
                    hits.append(ends[i])
        return hits

    @staticmethod
    def find_all_continuous_hit_positions(
        arr, ends, num_blocks: int, max_hit_position: int, cache_transfer_granularity: int
    ) -> list[int]:
        hits: list[int] = []
        for i in range(num_blocks):
            if ends[i] > max_hit_position:
                break
            if all(row[i] == 1 for row in arr):
                if ends[i] % cache_transfer_granularity == 0:
                    hits.append(ends[i])
            else:
                break
        return hits

    def get_kv_events(self) -> list[BlockStored]:
        if self.enable_kv_events and self.kv_send_thread is not None:
            # collect store kv events form sending thread
            events = self.kv_send_thread.get_kv_events()
            return events
        return []

    def build_connector_worker_meta(self) -> AscendStoreKVConnectorWorkerMetadata | None:
        if self.use_mamba and isinstance(self.kv_send_thread, KVCacheStoreSendingThread):
            if ce := self.kv_send_thread.get_completed_events():
                return AscendStoreKVConnectorWorkerMetadata(ce)
        return None
