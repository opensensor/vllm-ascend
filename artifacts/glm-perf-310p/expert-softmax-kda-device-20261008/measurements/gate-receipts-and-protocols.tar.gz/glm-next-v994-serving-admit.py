import hashlib,json,sys,urllib.request
import regex as re
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007');sys.path.insert(0,str(root/'source-offset-v984'))
from tools.glm_perf.resident_harness import ResidentClient
from tools.glm_perf.resident_native import NativeManifest
build=root/'build-v994-schedule';provenance=json.loads((build/'provenance.json').read_text())
options=provenance['_build'];assert options['prepared_offset_tables']
files=[p for p in build.iterdir() if p.suffix=='.bin']+[build/'provenance.json']+list((build/options['helper_package']).glob('*.py'))
def entry(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
from tools.glm_perf.fused_moe_control import manifest as standard_manifest
report=root/'v994-free-gates-rank0.json'
manifest_source=standard_manifest(build,report).value['validation_source']
# Audit existing cache storage on CPU metadata only, without a source switch.
audit_source="""
    import gc as garbage_collector
    import torch
    audit=[]
    def collect_tensors(value):
        if isinstance(value,torch.Tensor):return [value]
        if isinstance(value,(list,tuple)):return [t for child in value for t in collect_tensors(child)]
        return []
    for obj in garbage_collector.get_objects():
        if type(obj).__name__ != 'NPUWorker310':continue
        data=getattr(obj,'__dict__',None)
        if type(data) is dict and 'model_runner' in data:
            runner=data['model_runner']
            if runner is not None and 'kv_caches' in vars(runner):
                for index,bank in enumerate(vars(runner)['kv_caches']):
                    tensors=collect_tensors(bank)
                    if tensors:audit.append(dict(owner=type(obj).__name__,index=index,shapes=[list(t.shape) for t in tensors],dtypes=[str(t.dtype) for t in tensors],pointers=[t.data_ptr() for t in tensors]))
    for native in resources.values():
        if hasattr(native,'configs'):native.configs.clear()
        if hasattr(native,'scratch'):native.scratch.clear()
    torch.npu.synchronize();garbage_collector.collect();torch.npu.empty_cache()
"""
assert manifest_source.count("    return {'passed':True,")==1
manifest_source=manifest_source.replace("    return {'passed':True,",audit_source+"    return {'passed':True,'cache_storage_audit':audit,")
value=dict(name='reconstruction_v994',libraries=[entry(build/'glm_reconstruction_bridge_v994.so')],assets=[entry(p) for p in files]+[entry(report)],operators=['glm_reconstruction_v994::launch'],validation_source=manifest_source)
manifest=NativeManifest(value);(root/'v994-serving-manifest.json').write_text(json.dumps(value,indent=2))
c=ResidentClient('http://127.0.0.1:8001',timeout=900)
with urllib.request.urlopen(c.base_url+'/metrics',timeout=30) as response:metrics=response.read().decode()
counts=[float(v) for v in re.findall(r'^vllm:num_requests_(?:running|waiting)(?:\{[^\n]*\})?\s+([0-9.eE+-]+)$',metrics,re.M)]
assert counts and not any(counts),'GLM request active; postpone resource qualification'
print('Admitting already-qualified direct W4 L1 in the existing four worker contexts; preserve worker devices, models and weights',flush=True)
rows=c.load_native(manifest)
assert all(r.get('validation',{}).get('passed') and r['validation']['cases']==12 for r in rows)
(root/'v994-serving-admission.json').write_text(json.dumps(rows,indent=2));c.resume()
print('v994 qualified full gates admitted with bounded resident smoke on all four ranks; server resumed',flush=True)
