from pathlib import Path
import hashlib,json,tarfile
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
patterns=['next-three-*.json','next-three-*.log','glm-next-three-*.py','glm-next-qsa-996*.py','v99*-*gates*.json','v99*-serving-admission.json','qsa-v996*.json','night-speed-20261008/next-three-*.json','night-speed-20261008/next-three-*.py','night-speed-20261008/qsa-v99*-*.json','night-speed-20261008/next-three-*-launch.py','source-next-three-20261008/tools/glm_perf/transient_projection.py','prefill-kda-score-matrix-full-v1/*json','prefill-kda-score-matrix-full-v1/*log','prefill-kda-score-matrix-full-v1/validate-full-kda.py','build-v99*-schedule/*log','build-qsa-v996/*log','glm-next-v99*-*recovery.log','glm-qsa-v99*-*recovery.log']
paths=sorted({p for pattern in patterns for p in root.glob(pattern) if p.is_file()})
name=root/'next-three-final-receipts-and-protocols.tar.gz'
with tarfile.open(name,'w:gz') as t:
 for p in paths:t.add(p,arcname=str(p.relative_to(root)))
manifest={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths}
manifest['archive']=dict(name=name.name,bytes=name.stat().st_size,sha256=hashlib.sha256(name.read_bytes()).hexdigest())
(root/'next-three-final-export-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']))
