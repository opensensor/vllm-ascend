import json
from pathlib import Path
import torch
from tools.glm_perf.w4_storage_probe import checkpoint_weights, variants
from tools.glm_perf.fused_weight_layout import unpack_cube, tensor_digest
from tools.glm_perf.native_checkpoint import file_digest, INDEX, MANIFEST, write_json
from tools.glm_perf.glm_int4 import BLOCK

torch.set_num_threads(2)
source = Path('/srv/ai/models/GLM-5.3-Flash-selective-W3-native-int4-310p')
records = []
for layer in (8, 17):
    codes, scales = checkpoint_weights(source, layer, first_expert=0, experts=3)
    for stage, (old, new, scale) in enumerate(zip(codes, variants(codes, scales)['both'], scales)):
        k = scale.shape[-1] * BLOCK
        expected, actual = unpack_cube(old, k), unpack_cube(new, k)
        assert torch.equal(expected, actual), 'real code values changed'
        records.append(dict(layer=layer, stage=('gate_up','down')[stage], experts=[0,1,2],
                            source_shape=list(old.shape), promoted_shape=list(new.shape),
                            signed_values_checked=expected.numel(), source_sha256=tensor_digest(old),
                            promoted_sha256=tensor_digest(new), decoded_sha256=tensor_digest(expected),
                            scales_sha256=tensor_digest(scale), exact_signed_code_equality=True))
        del expected, actual
result = dict(kind='real_expert_cpu_code_gate', complete=True, device='cpu', backend_autoload=False,
              source=str(source), source_index_sha256=file_digest(source / INDEX),
              source_manifest_sha256=file_digest(source / MANIFEST), records=records,
              checkpoint_written=False, kernel_loaded=False, hardware_validation='not_run',
              real_model_evaluated=False)
write_json(Path('real-code-cpu-gate.json'),result)
print(json.dumps(dict(complete=True,signed_values_checked=sum(row['signed_values_checked'] for row in records))))
