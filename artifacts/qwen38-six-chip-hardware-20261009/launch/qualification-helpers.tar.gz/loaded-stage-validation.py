import cProfile,json,statistics,subprocess,time
from pathlib import Path
import torch
import torch.nn.functional as functional
import torch_npu
from tools.qwen4exp.resident_worker import QwenResidentExtension
from tools.qwen4exp.thermal_controller import parse_temperatures
from vllm_ascend.models.qwen4_exp.moe import route_topk
from vllm_ascend.models.qwen4_exp.w4_moe import W4SparseMoE,build_grouped_expert_dispatch,finalize_grouped_routes
from vllm_ascend.models.qwen4_exp.w4a8_int4 import pack_activation_device
METHOD='resident_stage_diagnostic_v12'
ROOT=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
def guard():
 values=parse_temperatures(subprocess.check_output(['npu-smi','info'],text=True,timeout=5),6)
 if max(values)>=90:raise RuntimeError(f'Diagnostic stop: {values}')
 return values

def validate():
 assert torch.ops.qwen_stage_diagnostic_v12.marker()==1
 assert not hasattr(QwenResidentExtension,METHOD)
 @torch.inference_mode()
 def benchmark(self,parameters):
  rank=torch.distributed.get_rank()
  try:
   assert getattr(self.model_runner,'execute_model_state',None) is None
   layer=next(m for m in self.model_runner.model.modules() if isinstance(m,W4SparseMoE))
   resources=self._resident_native_session().resources['qwen_projection_abba_v11']
   projection=resources['streaming_v11'];gather=resources['gather']
   before=self.resident_status()['weight_storage_digest']
   records=[]
   def run(inputs,weights,ids,variant,record=False):
    stages=[]
    def stage(name,fn):
     if not record:return fn()
     start,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
     start.record();host=time.perf_counter();value=fn();host_ms=(time.perf_counter()-host)*1000;end.record()
     stages.append((name,start,end,host_ms));return value
    dispatch=stage('dispatch',lambda:build_grouped_expert_dispatch(weights,ids,num_local_experts=layer.num_local_experts,expert_offset=layer.expert_offset,weight_dtype=layer.compute_dtype,count_mode=layer.grouped_route_count_mode))
    sorted_tokens=stage('sorted_tokens',lambda:dispatch.token_indices.index_select(0,dispatch.order))
    ends=dispatch.group_list.contiguous()
    packed=stage('pack_input',lambda:pack_activation_device(inputs))
    if variant=='baseline':
     prepared=stage('gather_input',lambda:tuple(v.index_select(0,sorted_tokens) for v in packed))
     projected=stage('gate_up',lambda:layer.projections['gate_up_proj'].native_linear(prepared,ends))
    else:
     prepared=stage('gather_input',lambda:gather(packed,sorted_tokens.to(torch.int32).contiguous(),ends))
     projected=stage('gate_up',lambda:projection(layer.projections['gate_up_proj'],prepared,ends))
    hidden=stage('swiglu',lambda:torch_npu.npu_swiglu(projected,dim=-1))
    hidden_packed=stage('pack_hidden',lambda:pack_activation_device(hidden))
    if variant=='streaming_windows':
     output=torch.empty_like(inputs,dtype=layer.compute_dtype)
     for first in [0,8]:
      routed=stage(f'down_{first}',lambda:projection.columns(layer.projections['down_proj'],hidden_packed,ends,first,8))
      combined=stage(f'finalize_{first}',lambda:finalize_grouped_routes(routed,dispatch,weights,layer.compute_dtype,'cann_v2'))
      stage(f'copy_{first}',lambda:output[:,first*160:(first+8)*160].copy_(combined))
      del routed,combined
    else:
     routed=stage('down',lambda:layer.projections['down_proj'].native_linear(hidden_packed,ends) if variant=='baseline' else projection(layer.projections['down_proj'],hidden_packed,ends))
     output=stage('finalize',lambda:finalize_grouped_routes(routed,dispatch,weights,layer.compute_dtype,'cann_v2'))
    return output,stages
   for tokens in parameters['tokens']:
    guard()
    inputs=(torch.randn(tokens,layer.gate.shape[1],generator=torch.Generator().manual_seed(1024))*.1).half().to(layer.gate.device)
    weights,ids=route_topk(functional.linear(inputs,layer.gate),layer.top_k,renormalize=layer.renormalize,routed_scaling_factor=layer.routed_scaling_factor)
    # Explicit diagnostic readback is outside every timing window.
    local=ids.cpu()-layer.expert_offset
    selected=local[(local>=0)&(local<layer.num_local_experts)]
    counts=torch.bincount(selected.flatten(),minlength=layer.num_local_experts)
    reference=layer._forward_grouped(inputs,weights,ids).cpu()
    variants=['baseline','streaming_windows','streaming_full']
    for variant in variants:
     actual,_=run(inputs,weights,ids,variant);torch.testing.assert_close(actual.cpu(),reference,rtol=0,atol=0)
    samples={v:[] for v in variants};stage_samples={v:[] for v in variants}
    for _ in range(3):
     for variant in [*variants,*reversed(variants)]:
      guard();torch.npu.synchronize();start=time.perf_counter();actual,_=run(inputs,weights,ids,variant);torch.npu.synchronize()
      samples[variant].append((time.perf_counter()-start)*1000);del actual
    for _ in range(3):
     for variant in variants:
      guard();torch.npu.synchronize();actual,stages=run(inputs,weights,ids,variant,True);torch.npu.synchronize()
      stage_samples[variant].append({name:{'device_interval_ms':start.elapsed_time(end),'host_enqueue_ms':host_ms} for name,start,end,host_ms in stages});del actual
    record={'rank':rank,'tokens':tokens,'local_routes':int(selected.numel()),'per_expert_routes':counts.tolist(),'exact':True,'median_ms':{v:statistics.median(samples[v]) for v in variants},'samples_ms':samples,'stage_samples':stage_samples,'temperatures_after_c':guard()}
    records.append(record)
    if parameters.get('trace') and rank==0 and tokens==2560:
     try:
      with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True) as trace:
       for variant in variants:
        with torch.autograd.profiler.record_function(variant):run(inputs,weights,ids,variant)
        torch.npu.synchronize()
      trace.export_chrome_trace(str(ROOT/'loaded-stage-rank0-trace.json'))
      record['trace']='loaded-stage-rank0-trace.json'
     except Exception as error:record['trace_error']=f'{type(error).__name__}: {error}'
   assert before==self.resident_status()['weight_storage_digest']
   return {'rank':rank,'passed':True,'records':records,'weight_storage_preserved':True,'serving_candidate':self.resident_status()['candidate']}
  except Exception as error:return {'rank':rank,'passed':False,'error':f'{type(error).__name__}: {error}'}
  finally:
   if hasattr(QwenResidentExtension,METHOD):delattr(QwenResidentExtension,METHOD)
 setattr(QwenResidentExtension,METHOD,benchmark)
 return {'passed':True,'diagnostic_method':METHOD,'production_forward_changed':False}
