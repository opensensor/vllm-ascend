"""Explicit hardware parity gate; no model dispatch installation."""

import hashlib
import json
import subprocess
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
import torch_npu

from projection_fixture import fixture
from tools.qwen4exp.build_streaming import verify_bundle
from tools.qwen4exp.native_prefill import NativeLocalRouteGather, NativeWY
from tools.qwen4exp.native_state_layout import NativeStateLayout
from tools.qwen4exp.native_streaming import NativeStreamingProjection

BUNDLE = Path('/home/matteius/experiments/qwen-streaming-bundle-v5-20261009')
OUTPUT = Path('/home/matteius/experiments/qwen-streaming-hardware-20261009/projection-gate.json')
assert not OUTPUT.exists()
verify_bundle(BUNDLE, require_compiled=True)
candidate = json.loads((BUNDLE / 'candidate.json').read_text())
torch.npu.set_device(0)
torch.empty(1, device='npu')
torch.ops.load_library(str(BUNDLE / candidate['bridges'][0]['path']))
namespace = candidate['namespace']
kernel = getattr(torch.classes, namespace).Kernel
launch = getattr(torch.ops, namespace).launch
binary = BUNDLE / 'binaries/native_streaming.bin'
projection = NativeStreamingProjection(kernel(str(binary), 'qwen_streaming_projection_v1'), launch,
                                      kernel(str(binary), 'qwen_streaming_columns_v1'))


def guard():
    from importlib.util import module_from_spec, spec_from_file_location
    spec = spec_from_file_location('thermal_read', OUTPUT.parent / 'thermal-controller-fixed-v2.py')
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    temperatures = module.parse_temperatures(subprocess.check_output(['npu-smi', 'info'], text=True, timeout=3), 6)
    if max(temperatures) >= 90:
        raise RuntimeError(f'Conservative standalone gate stop: {temperatures}')
    return temperatures


def record(result):
    print(json.dumps(result), flush=True)
    with OUTPUT.open('a') as stream:
        stream.write(json.dumps(result) + '\n')


for rows, outputs, k, experts, active in (
    (17, 128, 128, 4, 17),
    (17, 1280, 2560, 4, 17),
    (17, 2560, 1280, 4, 17),
    (17, 2560, 1280, 4, 0),
    (1, 1280, 2560, 128, 1),
):
    temperatures = guard()
    ends = [0] * (experts - 1) + [active]
    for seed in (89, 91):
        arguments, expected, _ = fixture(rows, outputs, k, ends, seed)
        device = [torch.from_numpy(value).npu() for value in arguments[:9]]
        packed, weight, scale, offset, total, boundaries = device[:4], *device[4:]
        bank = SimpleNamespace(weight=weight.reshape(experts, outputs, k // 2),
                               weight_scale=scale.reshape(experts, outputs, k // 128),
                               weight_offset=offset.reshape(experts, outputs, k // 128),
                               weight_sum=total.reshape(experts, outputs, k // 128))
        started = time.perf_counter()
        actual = projection(bank, packed, boundaries).cpu().numpy()
        elapsed = time.perf_counter() - started
        np.testing.assert_array_equal(actual, expected)
        pieces = []
        for first in range(0, outputs // 128, 8):
            pieces.append(projection.columns(bank, packed, boundaries, first, min(8, outputs // 128 - first)).cpu().numpy())
        np.testing.assert_array_equal(np.concatenate(pieces, axis=-1), expected)
        record({'case': 'projection', 'rows': rows, 'outputs': outputs, 'k': k, 'experts': experts,
                'active': active, 'seed': seed, 'exact': True, 'seconds_including_readback': elapsed,
                'temperatures_before_c': temperatures, 'temperatures_after_c': guard()})
        del device, packed, bank, arguments

record({'projection_parity_passed': True, 'candidate_sha256': candidate['candidate_sha256'],
        'full_model_validated': False, 'performance_measured': False})
