import json
from pathlib import Path
from tools.glm_perf.build_reconstruction import build

root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
source=Path('/srv/ai/src/glm-selective-w3-nz-test-20261004')
cann=Path('/usr/local/Ascend/ascend-toolkit/latest')
rows=json.loads(Path('build-options.json').read_text())
for row in rows:
    directory=root / ('build-v'+str(row['candidate_version'])+'-w4-compact')
    print('COMPILE_ONLY_START',row['mode'],directory,flush=True)
    build(directory,cann,source,**row['options'])
    print('COMPILE_ONLY_COMPLETE',row['mode'],directory,flush=True)
