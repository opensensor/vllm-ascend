import inspect,json
from pathlib import Path
from tools.glm_perf.build_reconstruction import build
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
cann=Path('/usr/local/Ascend/ascend-toolkit/latest')
keys=set(inspect.signature(build).parameters)
for previous,version in ((952,956),(953,957)):
    prior=json.loads((root/f'build-v{previous}/provenance.json').read_text())['_build']
    options={key:value for key,value in prior.items() if key in keys}
    options.update(version=version,prerounded_weight_scales=True)
    output=build(root/f'build-v{version}',cann,Path.cwd(),**options)
    path=output/'provenance.json'
    record=json.loads(path.read_text())
    record['_offline']={'compile_only':True,'hardware_gates':'not_run','baseline_version':previous,'checkpoint_scale_layout':'fp16_rounded_fp32_v1','device_calls':0}
    path.write_text(json.dumps(record,indent=2)+'\n')
    print(f'v{version} compiled with permanent rounded scales; no device calls',flush=True)
