import hashlib,json,os,subprocess,time,urllib.request
from pathlib import Path
r=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
def req(path,body=None):
 q=urllib.request.Request('http://127.0.0.1:8001'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=30) as res:return json.load(res)
status=req('/collective_rpc',{'method':'resident_status'})
(r/'tp6-fixed-final-resident.json').write_text(json.dumps(status,indent=2))
models=req('/v1/models')
(r/'tp6-fixed-final-models.json').write_text(json.dumps(models,indent=2))
pid=int((r/'tp6-fixed-api.pid').read_text())
keys={'ASCEND_CUSTOM_OPP_PATH','PYTHONPATH','ASCEND_RT_VISIBLE_DEVICES','VLLM_ASCEND_KV_CACHE_FRACTION','LD_LIBRARY_PATH'}
workers=[]
for v in status['results']:
 p=Path(f'/proc/{v["pid"]}')
 env=dict(x.split('=',1) for x in p.joinpath('environ').read_bytes().decode().split('\0') if '=' in x)
 libs=sorted(set(l.split()[-1] for l in p.joinpath('maps').read_text().splitlines() if any(n in l for n in ['libcust_opapi','vllm_ascend_C.cpython'])))
 workers.append({'rank':v['rank'],'pid':v['pid'],'environment':{k:env[k] for k in sorted(keys) if k in env},'mapped_library_sha256':{l:hashlib.sha256(Path(l).read_bytes()).hexdigest() for l in libs}})
btime=int(next(l.split()[1] for l in Path('/proc/stat').read_text().splitlines() if l.startswith('btime ')))
start=btime+int(Path(f'/proc/{pid}/stat').read_text().rpartition(')')[2].split()[19])/os.sysconf('SC_CLK_TCK')
thermal=[json.loads(l) for l in (r/'thermal-control-8001.jsonl').read_text().splitlines() if l.startswith('{')]
thermal=[v for v in thermal if v['time']>=start]
spills=sum(g['spill_count'] for v in status['results'] for g in v['prefix_mamba'].values())
restores=sum(g['restore_count'] for v in status['results'] for g in v['prefix_mamba'].values())
metrics=urllib.request.urlopen('http://127.0.0.1:8001/metrics',timeout=10).read().decode()
(r/'tp6-fixed-final-metrics.txt').write_text(metrics)
active=[float(l.rsplit(' ',1)[1]) for l in metrics.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{'))]
records=[json.loads(l) for l in (r/'tp6-fixed-six-capacity.jsonl').read_text().splitlines()]
results=[v for v in records if v.get('event')=='result']
receipt={'recorded_unix_s':time.time(),'api_pid':pid,'source_runtime':'/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009','workers':workers,'thermal_peak_c':max(v['maximum_c'] for v in thermal if v.get('maximum_c') is not None),'thermal_actions':sorted(set(v.get('action') for v in thermal)),'thermal_transitions':[v for v in thermal if v.get('action') not in {'none','holding'}],'checkpoint_spill_count_sum':spills,'checkpoint_restore_count_sum':restores,'running_waiting_after':active,'six_capacity_summary':next(v for v in records if v.get('event')=='summary'),'six_capacity_previews_python_guide':all('Python' in v['text_preview'] for v in results),'planner_token_capacity':1374660,'full_256k_windows_hardware_validated':False,'projection_candidate':'baseline','images_enabled':True,'mtp_enabled':False}
(r/'tp6-fixed-final-receipt.json').write_text(json.dumps(receipt,indent=2))
(r/'tp6-fixed-final-npu-smi.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True,timeout=10))
assert len(workers)==6 and spills==restores==0
receipt["idle_at_receipt"] = all(v==0 for v in active)
(r/"tp6-fixed-final-receipt.json").write_text(json.dumps(receipt,indent=2))
assert receipt['six_capacity_summary']['passed'] and receipt['six_capacity_previews_python_guide']
assert all(v['candidate']=='baseline' and not v['graphs_dirty'] and not v['native_failed'] for v in status['results'])
print(json.dumps({k:v for k,v in receipt.items() if k!='workers'}),flush=True)
