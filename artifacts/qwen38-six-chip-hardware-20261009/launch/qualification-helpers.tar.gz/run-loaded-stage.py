import hashlib,json,time,urllib.request
from pathlib import Path
r=Path('/home/matteius/experiments/qwen-six-chip-test-f25e70c09-20261009')
def call(path,body=None,timeout=60):
 q=urllib.request.Request('http://127.0.0.1:8001'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=timeout) as v:
  raw=v.read();return json.loads(raw) if raw else None
def rpc(method,args=None,timeout=600):return call('/collective_rpc',{'method':method,'args':args or [],'timeout':timeout},timeout+30)
assert call('/is_paused')['is_paused'] is False
before=rpc('resident_status')
assert len(before['results'])==6 and all(not v['native_failed'] and v['candidate']=='baseline' for v in before['results'])
(r/'loaded-stage-before.json').write_text(json.dumps(before,indent=2))
metrics=urllib.request.urlopen('http://127.0.0.1:8001/metrics',timeout=10).read().decode()
assert all(float(l.rsplit(' ',1)[1])==0 for l in metrics.splitlines() if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{')))
call('/pause?mode=wait&clear_cache=false',{},timeout=60)
assert call('/is_paused')['is_paused'] is True
library=r/'diagnostic-marker-v12.so'
value={'name':'qwen_stage_diagnostic_v12','libraries':[{'path':str(library),'sha256':hashlib.sha256(library.read_bytes()).hexdigest()}],'assets':[],'operators':['qwen_stage_diagnostic_v12::marker'],'validation_source':(r/'loaded-stage-validation.py').read_text()}
(r/'loaded-stage-native-manifest.json').write_text(json.dumps(value,indent=2))
prepared=rpc('resident_native_prepare',[json.dumps(value)])
(r/'loaded-stage-native-prepared.json').write_text(json.dumps(prepared,indent=2))
assert all('error' not in v for v in prepared['results']),prepared
keys={v['native_digest'] for v in prepared['results']};assert len(keys)==1
loaded=rpc('resident_native_load',[next(iter(keys))])
(r/'loaded-stage-native-loaded.json').write_text(json.dumps(loaded,indent=2))
assert all('error' not in v and v['validation']['passed'] for v in loaded['results']),loaded
print('Eager loaded-worker parity passed, benchmark beginning',flush=True)
result=rpc('resident_stage_diagnostic_v12',[{'tokens':[128,2560],'trace':True}],timeout=600)
(r/'loaded-stage-result.json').write_text(json.dumps(result,indent=2))
after=rpc('resident_status');(r/'loaded-stage-after.json').write_text(json.dumps(after,indent=2))
call('/resume',{},timeout=60)
assert all(v.get('passed') and v['weight_storage_preserved'] and v['serving_candidate']=='baseline' for v in result['results']),result
assert [v['weight_storage_digest'] for v in before['results']]==[v['weight_storage_digest'] for v in after['results']]
assert all(not v['native_failed'] and not v['graphs_dirty'] and v['candidate']=='baseline' for v in after['results'])
call('/resume',{},timeout=60)
print(json.dumps([{'rank':v['rank'],'cases':[{'tokens':c['tokens'],'seed':c['seed'],'median_ms':c['median_ms']} for c in v['records']]} for v in result['results']]),flush=True)
