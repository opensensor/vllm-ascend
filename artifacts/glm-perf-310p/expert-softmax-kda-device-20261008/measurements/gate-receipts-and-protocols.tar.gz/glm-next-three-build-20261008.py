import hashlib,inspect,json,os,shutil,subprocess,sys,tarfile
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
source=root/'source-next-three-20261008'
source.mkdir(exist_ok=False)
with tarfile.open(root/'next-three-source-20261008.tar.gz') as archive:
 archive.extractall(source,filter='data')
sys.path.insert(0,str(source))
from tools.glm_perf.build_qsa_shared import build as qsa_build
from tools.glm_perf.build_reconstruction import build
cann=Path('/usr/local/Ascend/cann-9.1.0')
print('BUILD QSA v996 softmax head batches',flush=True)
qsa_build(root/'build-qsa-v996',source,cann,root/'build-v984-offsets/compile-reconstruction',996,vector_output=True,vector_accumulate=True,softmax_head_batch=True)
for version,parent,events,bulk in ((992,'build-v984-offsets',True,False),(993,'build-v985-offsets',True,False),(994,'build-v985-offsets',False,True),(995,'build-v985-offsets',True,True)):
 options=json.loads((root/parent/'provenance.json').read_text())['_build']
 options={k:v for k,v in options.items() if k in inspect.signature(build).parameters}
 options.update(version=version,product_pipe_events=events,bulk_route_store=bulk)
 print('BUILD expert',version,'events',events,'bulk',bulk,flush=True)
 build(root/f'build-v{version}-schedule',cann,Path('/srv/ai/src/glm-selective-w3-nz-test-20261004'),**options)
 print('COMPLETE expert',version,flush=True)
from tools.glm_perf.stage_kda_score_matrix import stage
experiment=root/'prefill-kda-score-matrix-full-v1'
experiment.mkdir(exist_ok=False)
parent=root/'prefill-kda-score-row-batch-full-v2'
kda_source=experiment/'source';kda_source.mkdir()
for path in (parent/'source').iterdir():
 if path.name=='third_party':(kda_source/path.name).symlink_to(path.resolve(),target_is_directory=True)
 elif path.is_dir():shutil.copytree(path,kda_source/path.name,ignore=shutil.ignore_patterns('__pycache__'))
 else:shutil.copy2(path,kda_source/path.name)
header=kda_source/'attention/chunk_kda_fwd/op_kernel/chunk_kda_fwd_prepare.h'
expected='131bfc255e0e66bf528f51b759cea529af3c2823c442e3dcf1f6f767d1c75a2c'
record=stage(header,header.with_suffix('.candidate'),expected)
header.with_suffix('.candidate').replace(header)
(experiment/'stage.json').write_text(json.dumps(record,indent=2)+'\n')
build_dir=experiment/'build';build_dir.mkdir()
package=experiment/'opp-score-matrix'
env=dict(os.environ);env['PATH']=str(Path(sys.executable).parent)+os.pathsep+env['PATH']
defines=';'.join('-D'+name for name in ('GLM_KDA_SCORE_CACHE_COLUMNS','GLM_KDA_VECTOR_BETA_SCALE','GLM_KDA_SCORE_VECTOR_REDUCE','GLM_KDA_TAIL_WU_VECTOR','GLM_KDA_GATED_KEY_REUSE','GLM_KDA_SCORE_ROW_BATCH','GLM_KDA_SCORE_MATRIX_BATCH'))
commands=[['cmake','-S',str(kda_source),'-B',str(build_dir),'-G','Ninja','-DASCEND_COMPUTE_UNIT=ascend310p','-DASCEND_OP_NAME=chunk_kda_fwd','-DCUSTOM_ASCEND_CANN_PACKAGE_PATH='+str(cann),'-DCANN_3RD_LIB_PATH='+str(kda_source/'third_party'),'-DBUILD_TYPE=Release','-DVERSION=9.1.0','-DENABLE_OPS_HOST=ON','-DENABLE_OPS_KERNEL=ON','-DOPS_COMPILE_OPTIONS='+defines,'-DPython3_EXECUTABLE='+sys.executable,'-DASCEND_PYTHON_EXECUTABLE='+sys.executable,'-DHI_PYTHON='+sys.executable],['cmake','--build',str(build_dir),'--target','ops_transformer_kernel','-j2']]
for command,label in zip(commands,('configure','build')):
 print('KDA',label,flush=True)
 with (build_dir/(label+'.log')).open('w') as output:subprocess.run(command,cwd=kda_source,env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
objects=list((build_dir/'binary/ascend310p/bin/chunk_kda_fwd').glob('*.o'));assert len(objects)==1,objects
shutil.copytree(parent/'opp-score-row-batch',package)
dest=package/'vendors/custom_transformer/op_impl/ai_core/tbe/kernel/ascend310p/chunk_kda_fwd'
for binary in objects:
 for path in (binary,binary.with_suffix('.json')):shutil.copy2(path,dest/path.name)
shutil.copy2(header,package/'vendors/custom_transformer/op_impl/ai_core/tbe/custom_transformer_impl/ascendc/chunk_kda_fwd'/header.name)
record.update(package=str(package),binary=str(dest/objects[0].name),binary_sha256=hashlib.sha256(objects[0].read_bytes()).hexdigest(),compiler_defines=defines)
(experiment/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print('ALL CANDIDATE SDK BUILDS COMPLETE',flush=True)
