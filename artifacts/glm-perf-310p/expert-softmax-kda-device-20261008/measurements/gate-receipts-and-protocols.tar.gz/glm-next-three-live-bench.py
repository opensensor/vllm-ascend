import hashlib,json,re,sys,time,urllib.request,uuid
from pathlib import Path
root=Path('/srv/ai/artifacts/glm-prefill-weight-reuse-20261007')
sys.path.insert(0,str(root/'runtime-fp16-scales-20261008'))
from tools.glm_perf.resident_harness import ResidentClient
from tools.glm_perf.resident_control import Control
client=ResidentClient('http://127.0.0.1:8001',timeout=900)
# Retain the already-tested complete streaming request/accounting protocol.
protocol=(root/'glm-next-qsa-996-paired-serving.py').read_text()
helpers=protocol[protocol.index('def idle():'):protocol.index('for version in (991,996):')]
exec(compile(helpers,'<complete-stream-accounting>','exec'))
base=(root/'night-speed-20261008/offset-v984-v985-candidate.py').read_text()
binding=(root/'qsa-shared-binding-vector-frozen.py').read_text()
records=[];switches=[]
report=root/'night-speed-20261008/next-three-paired-serving.json';assert not report.exists()
def save(complete=False):report.write_text(json.dumps(dict(complete=complete,kda_package='prefill-kda-score-matrix-full-v1',scope='all candidates use the qualified KDA matrix package; synthetic cold token-ID prompts with cleared prefix state and full-request C1 generation',records=records,switches=switches),indent=2)+'\n')
def make_source(decode,prefill,qsa):
 source=base.replace('reconstruction_v984',f'reconstruction_v{decode}').replace('reconstruction_v985',f'reconstruction_v{prefill}')
 source=source.replace("'decode_version':984",f"'decode_version':{decode}").replace("'prefill_version':985",f"'prefill_version':{prefill}")
 source+=f'''
qsa_parent_replacements = replacements

def replacements(native_resources):
    from types import ModuleType
    capsule=ModuleType('next_three_qsa_binding_{decode}_{prefill}_{qsa}')
    exec(compile({binding!r},'<frozen-qsa-shared-binding>','exec'),capsule.__dict__)
    resource=native_resources['qsa_shared_v{qsa}']
    return capsule.extend_replacements(qsa_parent_replacements(native_resources),resource['shared'],resource['tiling_header'])
'''
 return source
cases=[('parent_kda',984,985,991),('events_decode',992,985,991),('events_prefill',984,993,991),('bulk_store',984,994,991),('combined',992,995,991),('combined_softmax',992,995,996),('parent_repeat',984,985,991)]
for label,decode,prefill,qsa in cases:
 idle();source=make_source(decode,prefill,qsa)
 (root/f'night-speed-20261008/next-three-{label}-candidate.py').write_text(source)
 before=client._acknowledged_rpc('resident_status',matches=client._status_matches)
 rows=client.switch(Control(uuid.uuid4().hex,candidate='next_three_'+label,source=source));client.resume()
 assert len(rows)==4 and all(not row['graphs_dirty'] and not row['native_failed'] for row in rows)
 assert sorted((r['pid'],r['weight_storage_digest']) for r in rows)==sorted((r['pid'],r['weight_storage_digest']) for r in before)
 assert all(r['fp16_scale_storage']['decode_version']==decode and r['fp16_scale_storage']['prefill_version']==prefill for r in rows)
 switches.append(dict(label=label,decode=decode,prefill=prefill,qsa=qsa,source_sha256=hashlib.sha256(source.encode()).hexdigest(),ranks=4));save()
 tests=[(640,1,4),(1280,1,5),(128,64,20),(128,64,21)]
 if label in ('parent_kda','combined','combined_softmax'):tests.insert(2,(6400,1,6))
 for tokens,output,nonce in tests:
  idle();assert client.request('/pause?mode=wait&clear_cache=true')['status']=='paused';client.resume()
  row=stream(tokens,output,nonce);row['label']=label;records.append(row);save();print(json.dumps(row),flush=True)
save(True)
print('All seven isolated/combined pipeline comparisons complete; parent selection retained pending analysis',flush=True)
