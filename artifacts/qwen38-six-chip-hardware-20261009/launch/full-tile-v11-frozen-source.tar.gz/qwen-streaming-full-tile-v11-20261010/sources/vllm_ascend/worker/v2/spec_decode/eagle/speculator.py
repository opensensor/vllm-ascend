# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/v1/worker/gpu/sample/spec_decode/eagle.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
from vllm.config import VllmConfig, replace
from vllm.v1.worker.gpu.spec_decode.eagle.speculator import EagleSpeculator

from vllm_ascend.worker.v2.spec_decode.autoregressive.speculator import (
    AscendAutoRegressiveSpeculator,
)
from vllm_ascend.worker.v2.spec_decode.pcp_utils import (
    disable_profiling_chunk_for_draft,
)


class AscendEagleSpeculator(AscendAutoRegressiveSpeculator, EagleSpeculator):
    """Ascend Eagle speculator: the NPU loop from AscendAutoRegressiveSpeculator
    layered on upstream EagleSpeculator (flat/GQA attention)."""

    def _create_draft_vllm_config(self) -> VllmConfig:
        # EAGLE draft models are dense even when the target is an MoE model.
        # Reusing the target's EP/EPLB flags makes VllmConfig validate the
        # draft as an expert model and fail because the draft has no experts.
        with disable_profiling_chunk_for_draft(self.vllm_config):
            return replace(
                self.vllm_config,
                model_config=self.draft_model_config,
                parallel_config=replace(
                    self.vllm_config.parallel_config,
                    pipeline_parallel_size=1,
                    prefill_context_parallel_size=1,
                    enable_expert_parallel=False,
                    enable_eplb=False,
                ),
            )
