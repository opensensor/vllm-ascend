# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/v1/worker/gpu/sample/spec_decode/autoregressive/speculator.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
import logging
from collections.abc import Mapping
from contextlib import contextmanager
from copy import copy
from typing import TYPE_CHECKING, Any

import numpy as np
import torch
from vllm.config import VllmConfig, replace, set_current_vllm_config
from vllm.config.compilation import CUDAGraphMode
from vllm.distributed import get_dcp_group
from vllm.v1.attention.backend import AttentionBackend
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
from vllm.v1.worker.gpu.block_table import BlockTables
from vllm.v1.worker.gpu.cudagraph_utils import BatchExecutionDescriptor
from vllm.v1.worker.gpu.input_batch import InputBatch, InputBuffers
from vllm.v1.worker.gpu.model_states.interface import ModelState
from vllm.v1.worker.gpu.spec_decode.autoregressive.speculator import AutoRegressiveSpeculator
from vllm.v1.worker.utils import AttentionGroup

from vllm_ascend.attention.attention_v1 import AscendAttentionBackend, AscendAttentionState
from vllm_ascend.attention.dsa_v1 import AscendDSABackend
from vllm_ascend.attention.indexer import AscendSFAIndexerBackend
from vllm_ascend.attention.mla_v1 import AscendMLABackend
from vllm_ascend.attention.sfa_v1 import AscendSFABackend
from vllm_ascend.worker.dcp_utils import DCPManager
from vllm_ascend.worker.v2.aclgraph_utils import _get_graph_update_backend
from vllm_ascend.worker.v2.attn_utils import (
    build_attn_metadata_factory,
    build_attn_metadata_wrapper,
)
from vllm_ascend.worker.v2.input_batch import AscendInputBatch, AscendInputBuffers
from vllm_ascend.worker.v2.pcp_manager import AscendPCPManager
from vllm_ascend.worker.v2.spec_decode.pcp_utils import (
    disable_profiling_chunk_for_draft,
    disable_target_pcp_for_replicated_draft,
    prepare_replicated_pcp_config,
)

if TYPE_CHECKING:
    from vllm_ascend.worker.v2.model_states.default import AscendModelState

logger = logging.getLogger(__name__)


class AscendAutoRegressiveSpeculator(AutoRegressiveSpeculator):
    """Shared Ascend spec-decode loop for AscendEagle/AscendMTPSpeculator.

    GQA, MLA, DSA, and SFA draft decode state share one path. The current MTP path
    uses the draft attention backend recorded by ``set_attn``.

    MLA's per-step state lives in ``.decode`` (cloned per step, written via an
    alias), GQA's is top-level. Both rebuild the base metadata for the padded
    draft batch. MLA also forwards rotary ``positions`` into
    build_attn_metadata. DSA and SFA manage their draft state in their metadata
    builders and skip the generic MLA/GQA init and update logic.
    """

    model_state: "AscendModelState"

    def __init__(self, vllm_config: VllmConfig, device: torch.device):
        """Override the upstream __init__ for Ascend NPUs.

        Ascend attention-metadata building needs more information (e.g.
        seq_lens_cpu from input_batch), so we replace input_buffers with
        AscendInputBuffers after super().__init__.
        """
        vllm_config, self.replicated_pcp = prepare_replicated_pcp_config(vllm_config)
        super().__init__(vllm_config, device)

        self.attn_architecture: str | None = None
        self.attn_backend: type[AttentionBackend] | None = None
        self.draft_vllm_config = self._create_draft_vllm_config()
        self._init_dcp()

        del self.input_buffers
        # AscendInputBuffers has extra `seq_lens_cpu` attribute.
        # so reinitialize input_buffers here.
        self.input_buffers: AscendInputBuffers = AscendInputBuffers(
            max_num_reqs=self.max_num_reqs,
            max_num_tokens=self.max_num_tokens,
            device=device,
        )

        # add more attributes for `input_buffers` in graph mode
        cudagraph_mode = self.vllm_config.compilation_config.cudagraph_mode
        if cudagraph_mode.decode_mode() == CUDAGraphMode.FULL:
            self.input_buffers.draft_seq_lens_cpus = [
                torch.zeros(self.max_num_reqs, dtype=torch.int32, device="cpu")
                for _ in range(self.num_speculative_steps - 1)
            ]

        # when in decode phase of eagle speculator, we need some value in
        # draft model's input_batch. so we keep a reference here.
        self.input_batch: InputBatch | None = None
        self.pcp_manager: AscendPCPManager | None = None

    def _init_dcp(self) -> None:
        self.use_dcp = self.draft_vllm_config.parallel_config.decode_context_parallel_size > 1
        self.dcp_manager: DCPManager | None = None
        if not self.use_dcp:
            return
        self.dcp_manager = DCPManager(
            dcp_world_size=self.draft_vllm_config.parallel_config.decode_context_parallel_size,
            dcp_rank=get_dcp_group().rank_in_group,
            max_buffer_num_tokens=self.max_num_tokens,
            max_num_reqs=self.max_num_reqs,
            device=self.device,
            vllm_config=self.draft_vllm_config,
            use_async_scheduling=self.vllm_config.scheduler_config.async_scheduling,
        )

    def _create_draft_vllm_config(self) -> VllmConfig:
        """Build the runtime config used while executing the draft model."""
        source_parallel_config = self.vllm_config.parallel_config
        dcp_size = source_parallel_config.decode_context_parallel_size
        parallel_config = replace(
            source_parallel_config,
            pipeline_parallel_size=1,
            decode_context_parallel_size=1 if self.replicated_pcp else dcp_size,
        )
        with disable_profiling_chunk_for_draft(self.vllm_config):
            draft_config = replace(
                self.vllm_config,
                model_config=self.draft_model_config,
                parallel_config=parallel_config,
                cache_config=replace(self.vllm_config.cache_config),
            )
        if self.replicated_pcp:
            # TODO: Separate draft execution settings from worker topology.
            # Restore DCP only after the complete draft config reconstruction;
            # this does not rerun validation or recompute DCP-dependent settings.
            draft_config.parallel_config.decode_context_parallel_size = dcp_size
        return draft_config

    # TODO: Remove this method once vllm-project/vllm#53458 or an
    # equivalent upstream fix is merged.
    def _maybe_remove_d2t(self, draft_model: torch.nn.Module) -> None:
        """Drop the identity d2t mapping of a full-vocab EAGLE3 draft."""
        if self.method != "eagle3":
            return
        target_vocab_size = self.draft_model_config.get_vocab_size()
        draft_vocab_size = draft_model.config.draft_vocab_size
        if draft_vocab_size == target_vocab_size:
            draft_model.draft_id_to_target_id = None

    def load_model(self, target_model: torch.nn.Module) -> None:
        super().load_model(target_model)
        if self.vllm_config.parallel_config.pipeline_parallel_size > 1:
            # The draft runs on the last PP stage without an encoder cache.
            # Set this before profiling so compiled inputs stay consistent.
            self.supports_mm_inputs = False

    def load_draft_model(
        self,
        target_model: torch.nn.Module,
        target_attn_layer_names: set[str],
    ) -> torch.nn.Module:
        draft_model = super().load_draft_model(
            target_model,
            target_attn_layer_names,
        )
        self._maybe_remove_d2t(draft_model)
        return draft_model

    @property
    def draft_prefill_attn_groups(self) -> list[list[AttentionGroup]]:
        if self.replicated_pcp:
            return self.attn_groups
        return self.target_attn_groups

    def _prepare_replicated_prefill_attn(
        self,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_reqs_padded: int,
        num_tokens_padded: int,
        cudagraph_runtime_mode: CUDAGraphMode,
    ) -> tuple[
        dict[str, Any] | None,
        dict[str, torch.Tensor] | None,
    ]:
        """Refresh global draft mappings and prepare attention for replicated PCP."""
        input_batch = self.input_batch
        if attn_metadata is None or not self.replicated_pcp or input_batch is None:
            return attn_metadata, slot_mappings

        assert isinstance(input_batch, AscendInputBatch)
        if input_batch.is_dummy:
            return attn_metadata, slot_mappings

        # Omitting out updates the default buffers bound by draft graph capture.
        self.block_tables.gather_block_tables(
            input_batch.idx_mapping,
            num_reqs_padded=num_reqs_padded,
        )
        slot_mappings_tensor = self.block_tables.compute_slot_mappings(
            input_batch.idx_mapping,
            input_batch.query_start_loc,
            input_batch.positions,
            num_tokens_padded=num_tokens_padded,
        )
        # TODO: Remove this early return once FIA supports padded Query tensors
        # whose token count exceeds the cumulative query length. Keep the
        # mapping refresh above when unifying metadata construction.
        if cudagraph_runtime_mode == CUDAGraphMode.FULL and self.attn_architecture in ("MLA", "GQA"):
            return attn_metadata, slot_mappings

        slot_mappings = build_slot_mappings_by_layer(
            slot_mappings_tensor,
            self.kv_cache_config,
        )
        # This is draft prefill, not the later one-token-per-request decode.
        # Query lengths may differ, so do not use _build_uniform_attn_metadata.
        attn_metadata = self._build_attn_metadata(
            num_reqs=input_batch.num_reqs,
            batch_desc=BatchExecutionDescriptor(
                cg_mode=cudagraph_runtime_mode,
                num_tokens=num_tokens_padded,
                num_reqs=num_reqs_padded,
            ),
            query_start_loc_np=input_batch.query_start_loc_np,
            seq_lens_cpu_upper_bound=input_batch.seq_lens_cpu_upper_bound,
            step=0,
        )
        return attn_metadata, slot_mappings

    def init_cudagraph_manager(self, cudagraph_mode: CUDAGraphMode) -> None:
        if self.speculative_config.enforce_eager:
            cudagraph_mode = CUDAGraphMode.NONE
        super().init_cudagraph_manager(cudagraph_mode)
        assert self.prefill_cudagraph_manager is not None
        assert self.decode_cudagraph_manager is not None
        # The Ascend graph managers are patched onto the upstream module and
        # created by super().init_cudagraph_manager without a speculator ref.
        # They need this speculator to update full-graph params, so set it here.
        self.prefill_cudagraph_manager.speculator = self
        self.decode_cudagraph_manager.speculator = self
        self.prefill_cudagraph_manager.update_stream = self.update_stream
        self.decode_cudagraph_manager.update_stream = self.update_stream

    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        # [num_tokens, hidden_size]
        last_hidden_states: torch.Tensor,
        # num_layers x [num_tokens, hidden_size]
        aux_hidden_states: list[torch.Tensor] | None,
        # [num_reqs]
        num_sampled: torch.Tensor,
        # [num_reqs]
        num_rejected: torch.Tensor,
        # [max_num_reqs]
        last_sampled: torch.Tensor,
        # [max_num_reqs]
        next_prefill_tokens: torch.Tensor,
        # [max_num_reqs]
        temperature: torch.Tensor,
        # [max_num_reqs]
        seeds: torch.Tensor,
        dp_sync: Any = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: Any = None,
    ):
        """Override GPU EagleSpeculator.propose for Ascend NPUs,
        because npu attention metadata needs more information,
        we need to cache input_batch, so we can use it later in
        generate_draft.
        """
        self.input_batch = input_batch
        # Replicated drafts use global tokens, unlike the PCP-local target.
        # Every DP rank must take the draft sync, including decode and idle ranks.
        sync_state = None if self.replicated_pcp else dp_sync
        # wrap build_attn_metadata to use Ascend attention metadata building.
        # so we can call super().propose() directly.
        with (
            disable_target_pcp_for_replicated_draft(self),
            build_attn_metadata_wrapper(),
            torch_gather_wrapper(),
        ):
            return super().propose(
                input_batch,
                attn_metadata,
                slot_mappings,
                last_hidden_states,
                aux_hidden_states,
                num_sampled,
                num_rejected,
                last_sampled,
                next_prefill_tokens,
                temperature,
                seeds,
                sync_state,
                dummy_run,
                skip_attn_for_dummy_run,
                mm_inputs,
                is_profile=is_profile,
            )

    def set_attn(
        self,
        model_state: ModelState,
        kv_cache_config: KVCacheConfig,
        block_tables: BlockTables,
        target_input_buffers: InputBuffers,
        target_attn_groups: list[list[AttentionGroup]],
    ) -> None:
        # Initialize the draft attention backend with its PCP=1 config.
        with set_current_vllm_config(self.attn_vllm_config):
            super().set_attn(
                model_state,
                kv_cache_config,
                block_tables,
                target_input_buffers,
                target_attn_groups,
            )

            # Use the first executable draft attention layer as the architecture
            # discriminator and cache it for ACL graph parameter updates.
            self.attn_backend = _get_graph_update_backend(self.attn_groups)
        if issubclass(self.attn_backend, AscendDSABackend):
            self.attn_architecture = "DSA"
        elif issubclass(self.attn_backend, AscendMLABackend):
            self.attn_architecture = "MLA"
        elif issubclass(self.attn_backend, (AscendSFABackend, AscendSFAIndexerBackend)):
            self.attn_architecture = "SFA"
        elif issubclass(self.attn_backend, AscendAttentionBackend):
            self.attn_architecture = "GQA"
        else:
            raise ValueError(f"Unsupported attention backend: {self.attn_backend}")

    def capture(self) -> None:
        logger.info("Capturing model for speculator...")
        # Reset indices to zeros to prevent stale values from prior
        # dummy runs to cause out-of-bounds indexing during capture.
        self.last_token_indices.zero_()

        # Capture the prefill routine (model forward + compute_logits +
        # sample).
        # For FULL graphs, the entire routine is recorded as one graph.
        # For PIECEWISE, only the model's compiled regions are captured
        # and the rest (compute_logits, gumbel_sample) runs eagerly.
        assert self.prefill_cudagraph_manager is not None
        if self.prefill_cudagraph_manager.use_breakable_cg:
            self.prefill_cudagraph_manager.init_breakable_cg_runner(self.model)
        with disable_target_pcp_for_replicated_draft(self):
            self.prefill_cudagraph_manager.capture(
                self._prefill,
                self.model_state,
                self.target_input_buffers,
                self.block_tables,
                self.draft_prefill_attn_groups,
                self.kv_cache_config,
                progress_bar_desc="Capturing prefill CUDA graphs",
            )

        if self.num_speculative_steps == 1:
            return

        # Capture all decode draft generation steps as a single graph.
        assert self.decode_cudagraph_manager is not None
        with (
            disable_target_pcp_for_replicated_draft(self),
            build_attn_metadata_wrapper(),
        ):
            self.decode_cudagraph_manager.capture(
                self._multi_step_decode,
                self.model_state,
                self.input_buffers,
                self.block_tables,
                self.attn_groups,
                self.kv_cache_config,
                progress_bar_desc="Capturing decode CUDA graphs",
            )

    @torch.inference_mode()
    def _run_model(
        self,
        num_tokens: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Override AutoRegressiveSpeculator._run_model for Ascend NPUs."""
        last_hidden_states, hidden_states = super()._run_model(
            num_tokens,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
            mm_inputs,
        )
        return AscendPCPManager.broadcast_replicated_hidden_states(
            last_hidden_states, hidden_states, num_tokens, replicated_pcp=self.replicated_pcp
        )

    def _generate_draft(
        self,
        num_reqs: int,
        num_tokens_padded: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
    ) -> None:
        """Thin override: delegate to upstream single-step ``_generate_draft``,
        then apply Ascend-specific attention-metadata updates required by the
        FIA operator."""
        super()._generate_draft(
            num_reqs,
            num_tokens_padded,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
        )
        if attn_metadata is not None:
            self._update_decode_attn_metadata(attn_metadata, 1, num_reqs)

    def _multi_step_decode(  # type: ignore[misc]
        self,
        num_reqs: int,
        skip_attn: bool,
        batch_desc: BatchExecutionDescriptor,
        num_tokens_across_dp: torch.Tensor | None,
        seq_lens_cpu_upper_bound: torch.Tensor | None = None,
    ) -> None:
        """Minimal override to handle the merged multi-step graph in FULL mode.

        In FULL mode the captured graph already contains all speculative
        steps, so ``run_fullgraph`` is called once instead of once per
        step.  For PIECEWISE / NONE modes we delegate to the upstream
        ``_multi_step_decode`` which iterates over steps and calls
        ``_generate_draft`` per step.
        """
        if batch_desc.cg_mode == CUDAGraphMode.FULL:
            assert self.decode_cudagraph_manager is not None
            self.decode_cudagraph_manager.run_fullgraph(batch_desc)
            return
        super()._multi_step_decode(num_reqs, skip_attn, batch_desc, num_tokens_across_dp, seq_lens_cpu_upper_bound)

    def _prefill(
        self,
        num_reqs: int,
        num_tokens: int,
        attn_metadata: dict[str, Any] | None,
        slot_mappings: dict[str, torch.Tensor] | None,
        num_tokens_across_dp: torch.Tensor | None,
        cudagraph_runtime_mode: CUDAGraphMode = CUDAGraphMode.NONE,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
    ) -> None:
        attn_metadata, slot_mappings = self._prepare_replicated_prefill_attn(
            attn_metadata,
            slot_mappings,
            num_reqs,
            num_tokens,
            cudagraph_runtime_mode=cudagraph_runtime_mode,
        )
        # Draft prefill reuses target metadata, but the target metadata may
        # also contain target-only attention layers (e.g. GDN layers).
        if attn_metadata is not None and self.draft_attn_layer_names is not None:
            attn_metadata = {
                name: metadata for name, metadata in attn_metadata.items() if name in self.draft_attn_layer_names
            }

        super()._prefill(
            num_reqs,
            num_tokens,
            attn_metadata,
            slot_mappings,
            num_tokens_across_dp,
            cudagraph_runtime_mode,
            mm_inputs,
        )

    def _build_attn_metadata(  # type: ignore[misc]
        self,
        num_reqs: int,
        batch_desc: BatchExecutionDescriptor,
        query_start_loc_np: np.ndarray,
        seq_lens_cpu_upper_bound: torch.Tensor,
        step: int,
        causal: bool | Mapping[int, bool] = True,
        dcp_local_seq_lens: torch.Tensor | None = None,
    ) -> dict[str, Any] | None:
        """Build Ascend draft metadata for uniform and explicit query layouts."""
        assert self.input_batch is not None
        seq_lens_cpu = None
        is_prefilling = torch.from_numpy(self.input_batch.is_prefilling_np)
        if self.use_dcp:
            assert self.dcp_manager is not None
            num_reqs_padded = batch_desc.num_reqs or num_reqs
            seq_lens_cpu, is_prefilling = self.dcp_manager.prepare_draft_dcp_metadata_inputs(
                target_seq_lens_cpu=self._get_seq_lens_cpu(num_reqs_padded),
                is_prefilling=is_prefilling,
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs_padded,
                step=step,
                max_model_len=self.max_model_len,
            )

        # Upstream's uniform builder calls self._build_attn_metadata, so this
        # single hook also covers graph capture and eager draft decode.
        with build_attn_metadata_factory(
            self.input_buffers.positions,
            batch_desc.num_tokens,
            is_prefilling,
            seq_lens_cpu=seq_lens_cpu,
            parallel_config=self.draft_vllm_config.parallel_config,
        ):
            attn_metadata = super()._build_attn_metadata(
                num_reqs,
                batch_desc,
                query_start_loc_np,
                seq_lens_cpu_upper_bound,
                step,
                causal,
                dcp_local_seq_lens,
            )
        if attn_metadata is not None:
            for metadata in attn_metadata.values():
                if metadata is None:
                    continue
                metadata.attn_state = AscendAttentionState.DecodeOnly
            # Only draft decode steps (step > 0) update CPU-side lengths.
            # Step 0 is draft prefill and skips this decode update.
            if step > 0:
                self._update_decode_attn_metadata(attn_metadata, step, num_reqs)
        return attn_metadata

    def build_draft_attn_metadatas(
        self,
        num_reqs_padded: int,
        num_tokens_padded: int,
        is_draft_model_prefill: bool,
    ):
        """Build draft_attn_metadatas for partial-merged draft graph."""
        attn_metadata = self.model_state.attn_metadata
        attn_metadata = {
            name: metadata for name, metadata in attn_metadata.items() if name in self.draft_attn_layer_names
        }

        if is_draft_model_prefill:
            prepared_attn_metadata, _ = self._prepare_replicated_prefill_attn(
                attn_metadata,
                None,
                num_reqs_padded,
                num_tokens_padded,
                cudagraph_runtime_mode=CUDAGraphMode.FULL,
            )
            assert prepared_attn_metadata is not None
            return [prepared_attn_metadata]

        draft_attn_metadatas = self._init_decode_draft_attn_metadatas(attn_metadata, num_reqs_padded)

        for i, per_step_attn_metadata in enumerate(draft_attn_metadatas):
            step = i + 1
            assert self.input_batch is not None
            self._update_decode_attn_metadata(per_step_attn_metadata, step, self.input_batch.num_reqs)

        return draft_attn_metadatas

    def _init_decode_draft_attn_metadatas(self, attn_metadata: dict[str, Any] | None, num_reqs_padded: int):
        """Initialize per-step decode attention metadata for graph mode."""
        if attn_metadata is None:
            return

        # DSA and SFA own their per-step sparse-attention state in their
        # metadata builders and do not use draft graph metadata updates.
        if self.attn_architecture in ("DSA", "SFA"):
            return []

        # TODO: _build_attn_metadata pulls data (seq_lens, block_table,
        # ...) from input_buffers internally; future may pass these as CPU
        # params directly to build_attn_metadata, decoupling from input_buffers.
        # Target metadata can contain fewer block-table rows than the draft
        # decode graph requires. Rebuild GQA metadata too, so its block tables
        # and query layout describe the same padded batch as the sequence lengths.
        if self.attn_architecture in ("GQA", "MLA"):
            assert self.input_batch is not None
            attn_metadata = self._build_uniform_attn_metadata(
                batch_desc=BatchExecutionDescriptor(
                    cg_mode=CUDAGraphMode.FULL,
                    num_tokens=num_reqs_padded,  # decode: 1 token/req
                    num_reqs=num_reqs_padded,
                ),
                num_reqs=self.input_batch.num_reqs,
                num_query_per_req=1,
                seq_lens_cpu_upper_bound=self.input_batch.seq_lens_cpu_upper_bound,
                step=1,
            )
            if attn_metadata is None:
                return

        attn_state = AscendAttentionState.DecodeOnly

        draft_attn_metadatas = []
        # attn_metadata is build in vllm's super class.
        # We need to update attn_state for each layer's metadata.
        for seq_lens_cpu in self.input_buffers.draft_seq_lens_cpus:
            per_step_attn_metadata = {k: copy(v) for k, v in attn_metadata.items()}

            seq_lens_cpu = seq_lens_cpu[:num_reqs_padded]
            for metadata in per_step_attn_metadata.values():
                metadata.attn_state = attn_state
                metadata.seq_lens_cpu = seq_lens_cpu
                if self.attn_architecture == "MLA":
                    # clone .decode so per-step seq_lens_list writes don't alias.
                    metadata.decode = copy(metadata.decode)
            draft_attn_metadatas.append(per_step_attn_metadata)

        return draft_attn_metadatas

    def _update_decode_attn_metadata(
        self, attn_metadata: dict[str, Any] | None, step: int, num_reqs: int | None = None
    ):
        """Update per-step decode attention metadata on Ascend."""
        if attn_metadata is None:
            return

        if self.attn_architecture in ("DSA", "SFA"):
            return

        attn_meta = next(iter(attn_metadata.values()))
        num_reqs_padded = attn_meta.seq_lens_cpu.shape[0]
        seq_lens_cpu = self._get_seq_lens_cpu(num_reqs_padded)
        if num_reqs is None:
            num_reqs = num_reqs_padded
        next_seq_lens_cpu = self._calc_next_seq_lens_cpu(seq_lens_cpu, num_reqs, num_reqs_padded, step)

        dcp_local_seq_lens_cpu = None
        if self.use_dcp and self.attn_architecture == "MLA":
            assert self.dcp_manager is not None
            dcp_local_seq_lens_cpu = self.dcp_manager.prepare_dcp_local_seq_lens_cpu(next_seq_lens_cpu)

        query_lens_list = [i for i in range(1, num_reqs_padded + 1)]
        seq_lens_list = next_seq_lens_cpu.tolist()
        for metadata in attn_metadata.values():
            if self.attn_architecture == "MLA":
                decode_metadata = metadata.decode
            else:
                decode_metadata = metadata
            decode_metadata.seq_lens_list = seq_lens_list
            decode_metadata.actual_seq_lengths_q = query_lens_list
            if dcp_local_seq_lens_cpu is not None:
                assert self.dcp_manager is not None
                parallel_config = self.draft_vllm_config.parallel_config
                decode_metadata.update_dcp_seq_lens_cpu(
                    next_seq_lens_cpu,
                    dcp_local_seq_lens_cpu,
                    torch.ones_like(next_seq_lens_cpu),
                    dcp_size=parallel_config.decode_context_parallel_size,
                    dcp_rank=self.dcp_manager.dcp_world_rank,
                    cp_kv_cache_interleave_size=parallel_config.cp_kv_cache_interleave_size,
                )

            metadata.seq_lens_cpu.copy_(next_seq_lens_cpu)

    def build_fia_params(
        self,
        num_reqs_padded: int,
        draft_attn_metadata: Any,
        is_draft_model_prefill: bool,
    ) -> list[dict[str, Any]]:
        layer_name, metadata = next(iter(draft_attn_metadata.items()))
        block_table = metadata.block_tables
        if is_draft_model_prefill:
            return [
                {
                    "layer_name": layer_name,
                    "actual_seq_lengths": metadata.actual_seq_lengths_q,
                    "actual_seq_lengths_kv": metadata.seq_lens_list,
                    "block_table": block_table,
                }
            ]
        assert self.input_batch is not None
        num_reqs = self.input_batch.num_reqs
        query_start_loc = list(range(1, num_reqs_padded + 1))
        fia_params: list[dict[str, Any]] = []
        for step in range(1, self.num_speculative_steps):
            seq_lens = [
                min(int(seq_len) + step, self.max_model_len) for seq_len in self.input_batch.seq_lens_np[:num_reqs]
            ]
            seq_lens.extend([0] * (num_reqs_padded - num_reqs))
            for layer_name in self.draft_attn_layer_names:
                fia_params.append(
                    {
                        "layer_name": layer_name,
                        "actual_seq_lengths": query_start_loc,
                        "actual_seq_lengths_kv": seq_lens,
                        "block_table": block_table,
                    }
                )
        return fia_params

    def _calc_next_seq_lens_cpu(self, seq_lens_cpu, num_reqs, num_reqs_padded, step):
        # NOTE(drslark) to achieve fully alignment with vllm, `num_rejected` should be subtracted from `seq_lens`
        # to avoid extra sync overhead, `v2` is currently aligned with NPU `v1` only

        # follows the logic in `prepare_eagle_decode` and `update_eagle_inputs`
        next_seqs_cpu = torch.clamp(seq_lens_cpu[:num_reqs_padded] + step, max=self.max_model_len)
        next_seqs_cpu[num_reqs:].fill_(0)
        return next_seqs_cpu

    def _get_seq_lens_cpu(self, num_reqs_padded: int) -> torch.Tensor:
        """Return the target sequence lengths for the padded graph batch.

        ``input_batch.seq_lens_np`` can contain only the active requests.
        During full-graph capture the draft batch can be padded to a larger
        graph batch, so using that compact view produces a tensor that is too
        short for ``num_reqs_padded``. The target input buffer owns the same
        sequence lengths and retains the storage required by the padded graph
        batch.
        """
        assert isinstance(self.target_input_buffers, AscendInputBuffers)
        return self.target_input_buffers.seq_lens_cpu[:num_reqs_padded]


# TODO Remove this patch when cann fix the gather bug.
# NOTE(Ronald1995): torch.gather will pollute the cache such as self.input_buffers.positions
# the bug is reported to huawei CANN team, but not fixed yet.
# NOTE(drslark): make a temporary patch only for `torch.gather`
_original_gather = torch.gather


def gather(input, dim, index, *, sparse_grad=False, out=None):
    if out is None:
        return _original_gather(input, dim, index, sparse_grad=sparse_grad)
    out[:] = _original_gather(input, dim, index, sparse_grad=sparse_grad)
    return out


@contextmanager
def torch_gather_wrapper():
    """Context manager to override torch.gather for Ascend NPUs."""
    original_gather = torch.gather
    try:
        torch.gather = gather
        yield
    finally:
        torch.gather = original_gather
