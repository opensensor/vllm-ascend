#!/usr/bin/env bash
set -eo pipefail
source /srv/ai/src/qwen38-w4-hardware-20260927/qwen38-w4-hardware-env.sh
runtime=/srv/ai/src/qwen-six-chip-test-f25e70c09-20261009
export MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export CPATH=/srv/ai/src/qwen38-w4-ce1862e52/csrc/third_party/catlass/include:${CPATH:-}
cd "$runtime/csrc"
bash build.sh --pkg --ops=causal_conv1d_v310,recurrent_gated_delta_rule_v310 --soc=ascend310p --vendor_name=qwen_gdn_stride_v1 --cann_3rd_lib_path=/srv/ai/src/qwen38-coherent-opp-src-20261001-r2/csrc/third_party -j4
mapfile -t packages < <(find build -maxdepth 1 -name 'cann-ops-transformer*.run')
test "${#packages[@]}" -eq 1
bash "${packages[0]}" --install-path="$runtime/gdn-stride-opp"
cmake -S "$runtime" -B "$runtime/bindings-stride" -G Ninja \
 -DCMAKE_BUILD_TYPE=Release -DSOC_VERSION=ascend310p1 \
 -DASCEND_HOME_PATH="$ASCEND_HOME_PATH" \
 -DPYTHON_EXECUTABLE=/srv/ai/venvs/qwen38-w4-test-ce1862/bin/python \
 -DPYTHON_INCLUDE_PATH=/usr/local/python3.12.13/include/python3.12 \
 -DPYTHON_LIBRARY=/usr/local/python3.12.13/lib/libpython3.12.so \
 -DTORCH_NPU_PATH=/srv/ai/venvs/qwen38-w4-test-ce1862/lib/python3.12/site-packages/torch_npu \
 -DCMAKE_PREFIX_PATH=/srv/ai/venvs/qwen38-w4-test-ce1862/lib/python3.12/site-packages/pybind11/share/cmake/pybind11
cmake --build "$runtime/bindings-stride" --parallel 4
